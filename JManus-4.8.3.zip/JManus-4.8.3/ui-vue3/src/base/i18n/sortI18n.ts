/*
 * Copyright 2024-2026 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import EN_MAP from './en'
import ZH_MAP from './zh'

const sortArr: { label: string; value: unknown }[] = []
const checkArr: string[] = []

function mapToArr() {
  for (const enKey in EN_MAP) {
    sortArr.push({
      label: enKey,
      value: EN_MAP[enKey],
    })
    const zh = ZH_MAP[enKey]
    if (!zh) {
      checkArr.push(enKey)
    }
  }
}

mapToArr()
