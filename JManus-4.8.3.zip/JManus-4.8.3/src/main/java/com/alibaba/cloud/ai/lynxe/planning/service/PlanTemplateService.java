/*
 * Copyright 2025 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.alibaba.cloud.ai.lynxe.planning.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.cloud.ai.lynxe.planning.model.po.PlanTemplateVersion;
import com.alibaba.cloud.ai.lynxe.planning.repository.PlanTemplateVersionRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Plan template service class that provides business logic related to plan templates
 */
@Service
public class PlanTemplateService implements IPlanTemplateService {

	private static final Logger logger = LoggerFactory.getLogger(PlanTemplateService.class);

	@Autowired
	private PlanTemplateVersionRepository versionRepository;

	@Autowired
	private ObjectMapper objectMapper;

	/**
	 * Version save result class
	 */
	public static class VersionSaveResult {

		private final boolean saved;

		private final boolean duplicate;

		private final String message;

		private final int versionIndex;

		public VersionSaveResult(boolean saved, boolean duplicate, String message, int versionIndex) {
			this.saved = saved;
			this.duplicate = duplicate;
			this.message = message;
			this.versionIndex = versionIndex;
		}

		public boolean isSaved() {
			return saved;
		}

		public boolean isDuplicate() {
			return duplicate;
		}

		public String getMessage() {
			return message;
		}

		public int getVersionIndex() {
			return versionIndex;
		}

	}

	/**
	 * Save plan version to history record
	 * @param planTemplateId Plan template ID
	 * @param planJson Plan JSON data
	 * @return Save result information
	 */
	@Transactional
	public VersionSaveResult saveToVersionHistory(String planTemplateId, String planJson) {
		// Check if content is the same as the latest version
		if (isContentSameAsLatestVersion(planTemplateId, planJson)) {
			logger.info("Content of plan {} is the same as latest version, skipping version save", planTemplateId);
			Integer maxVersionIndex = versionRepository.findMaxVersionIndexByPlanTemplateId(planTemplateId);
			return new VersionSaveResult(false, true, "Content same as latest version, no new version created",
					maxVersionIndex != null ? maxVersionIndex : -1);
		}

		// Get maximum version number
		Integer maxVersionIndex = versionRepository.findMaxVersionIndexByPlanTemplateId(planTemplateId);
		int newVersionIndex = (maxVersionIndex == null) ? 0 : maxVersionIndex + 1;

		// Save new version
		PlanTemplateVersion version = new PlanTemplateVersion(planTemplateId, newVersionIndex, planJson);
		versionRepository.save(version);

		logger.info("Saved version {} of plan {}", newVersionIndex, planTemplateId);
		return new VersionSaveResult(true, false, "New version saved", newVersionIndex);
	}

	/**
	 * Save plan version to history record (compatibility method)
	 * @param planTemplateId Plan template ID
	 * @param planJson Plan JSON data
	 */
	@Transactional
	public void saveVersionToHistory(String planTemplateId, String planJson) {
		saveToVersionHistory(planTemplateId, planJson);
	}

	/**
	 * Get all version JSON data of the plan
	 * @param planTemplateId Plan template ID
	 * @return List of version JSON data
	 */
	public List<String> getPlanVersions(String planTemplateId) {
		List<PlanTemplateVersion> versions = versionRepository
			.findByPlanTemplateIdOrderByVersionIndexAsc(planTemplateId);
		List<String> jsonVersions = new ArrayList<>();
		for (PlanTemplateVersion version : versions) {
			jsonVersions.add(version.getPlanJson());
		}
		return jsonVersions;
	}

	/**
	 * Get specified version of the plan
	 * @param planTemplateId Plan template ID
	 * @param versionIndex Version index
	 * @return Version JSON data, returns null if version does not exist
	 */
	public String getPlanVersion(String planTemplateId, int versionIndex) {
		PlanTemplateVersion version = versionRepository.findByPlanTemplateIdAndVersionIndex(planTemplateId,
				versionIndex);
		return version != null ? version.getPlanJson() : null;
	}

	/**
	 * Get the latest version of the plan
	 * @param planTemplateId Plan template ID
	 * @return Latest version JSON data, returns null if no version exists
	 */
	public String getLatestPlanVersion(String planTemplateId) {
		Integer maxVersionIndex = versionRepository.findMaxVersionIndexByPlanTemplateId(planTemplateId);
		if (maxVersionIndex == null) {
			return null;
		}
		return getPlanVersion(planTemplateId, maxVersionIndex);
	}

	/**
	 * Check if given content is the same as the latest version
	 * @param planTemplateId Plan template ID
	 * @param planJson Plan JSON data to check
	 * @return Returns true if content is the same, false otherwise
	 */
	public boolean isContentSameAsLatestVersion(String planTemplateId, String planJson) {
		String latestVersion = getLatestPlanVersion(planTemplateId);
		return isJsonContentEquivalent(latestVersion, planJson);
	}

	/**
	 * Intelligently compare if two JSON strings are semantically identical, ignoring
	 * format differences (spaces, line breaks, etc.), only comparing actual content
	 * @param json1 First JSON string
	 * @param json2 Second JSON string
	 * @return Returns true if semantically identical, false otherwise
	 */
	public boolean isJsonContentEquivalent(String json1, String json2) {
		if (json1 == null && json2 == null) {
			return true;
		}
		if (json1 == null || json2 == null) {
			return false;
		}

		// First try simple string comparison
		if (json1.equals(json2)) {
			return true;
		}

		try {
			JsonNode node1 = objectMapper.readTree(json1);
			JsonNode node2 = objectMapper.readTree(json2);
			return node1.equals(node2);
		}
		catch (Exception e) {
			logger.warn("Failed to parse JSON content during comparison, falling back to string comparison", e);
			// If JSON parsing fails, fall back to string comparison
			return json1.equals(json2);
		}
	}

}
