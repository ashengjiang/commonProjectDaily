package com.cainiao.tp.nm.plan.infra.port.policy;

import com.cainiao.tp.nm.plan.api.policy.application.dto.OssAuthDTO;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

public interface FileStoryManager {

    String DEFAULT_BUCKET_NAME = "station-private";

    /**
     * 获取授权
     *
     * @param fileName 文件名
     * @param dirName  目录
     * @return return
     */
    OssAuthDTO getUploadOssTokenConfig(String fileName, String dirName);

    /**
     * 上传
     *
     * @param outputStream outputStream
     * @param dir          存放目录
     * @param fileName     文件名
     * @return ossKey
     */
    String upload(ByteArrayOutputStream outputStream, String dir, String fileName);

    /**
     * 获取下载链接
     * @param fileKey 文件key
     * @param expireTime 有效期/单位s
     * @return return
     */
    String downloadUrl(String fileKey, Long expireTime);


    /**
     * 下载成InputStream
     * 注意：注意使用完以后关闭InputStream
     *
     * @param fileKey 文件key
     * @return return
     */
    InputStream download(String fileKey);
}
