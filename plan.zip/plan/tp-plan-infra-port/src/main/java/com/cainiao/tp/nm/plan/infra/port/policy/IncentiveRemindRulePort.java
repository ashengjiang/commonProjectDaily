package com.cainiao.tp.nm.plan.infra.port.policy;

import com.cainiao.tp.nm.plan.api.policy.application.dto.IncentiveRemindRuleDTO;

import java.util.List;

/**
 * 站点实操激励提醒通知规则端口接口
 * 封装 Diamond 配置中心的规则读取能力
 *
 * @date 2026-03-27
 */
public interface IncentiveRemindRulePort {

    /**
     * 获取当前生效的通知规则列表
     *
     * @return 通知规则列表，若未配置则返回空列表
     */
    List<IncentiveRemindRuleDTO> getRuleList();
}
