package com.cainiao.tp.nm.plan.infra.port.dto.context;

import lombok.Data;

@Data
public class ExpressPermissionContext implements BasePermissionContext {

    private Long expressId;
    private String cpCode;
    private String orgCode;

    private String expressCode;
    private Long userId;
    private String userName;
    private String cnEmployeeId;
    private Integer dutyType;
    private String dutyTypeDesc;
    private Long cityCode;

   private boolean expressCabinetBuyer;
}
