package com.cainiao.tp.nm.plan.infra.port.collect;

public interface TseCollectPointManager {

    /**
     * 查询线索域代收点信息
     */
    CollectPointInfoDTO queryCollectInfo(String collectPointId);
}
