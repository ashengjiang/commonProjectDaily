package com.cainiao.tp.nm.plan.infra.port.purchase;

/**
 * 支付代扣协议签署查询端口 */
public interface PaymentSignManager {

    /**
     * 判断指定用户在指定资金业务场景下是否已签署代扣协议
     *
     * @param userId      用户 ID
     * @return true=已签署，false=未签署
     */
    boolean isSigned(Long userId);
}
