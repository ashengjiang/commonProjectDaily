package com.cainiao.tp.nm.plan.infra.port.policy;

import com.cainiao.tp.nm.plan.api.policy.application.dto.BaseDivisionInfoDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.DivisionDTO;

import java.util.List;
import java.util.Optional;

public interface DivisionManager {

    /**
     * 获取所有的省级列表
     * 注意不包含childrenList
     *
     * @return return
     */
    List<BaseDivisionInfoDTO> getAllProvinceList();

    /**
     * 根据省名称获取数据
     *
     * @param provinceName 省名称
     * @return return
     */
    Optional<BaseDivisionInfoDTO> getProvinceByName(String provinceName);


    /**
     * 根据省名称获取数据
     *
     * @param provinceCode 省名称
     * @return return
     */
    Optional<BaseDivisionInfoDTO> getProvinceByCode(Long provinceCode);

    String getDivisionNameByCode(Long divisionCode);

    DivisionDTO getDivisionChain(Long divisionCode);
}
