package com.cainiao.tp.nm.plan.infra.port.manager;

import com.cainiao.tp.nm.plan.infra.port.dto.PlanExpressDTO;

public interface ExpressInfoManager {


    PlanExpressDTO getExpressDTO(String cpCode, String orgCode);

}
