package com.cainiao.tp.nm.plan.infra.port.tag;

import java.util.List;

public interface TseTagManager {


    /**
     * 查询线索域标签库
     */
    List<String> queryCollectTag(String collectPointId, List<String> tagCodeList);
}
