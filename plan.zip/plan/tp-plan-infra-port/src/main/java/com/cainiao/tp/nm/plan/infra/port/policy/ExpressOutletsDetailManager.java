package com.cainiao.tp.nm.plan.infra.port.policy;

import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.ExpressOutletsDetailDTO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.ExpressOutletsQueryRequest;

/**
 * @code date 2025年06月10日 10:22
 * @code desc:网点基础信息查询
 */

public interface ExpressOutletsDetailManager {

    ExpressOutletsDetailDTO queryExpressOutletsDetail(ExpressOutletsQueryRequest request);
}
