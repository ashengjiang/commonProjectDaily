package com.cainiao.tp.nm.plan.infra.port.purchase;

import com.cainiao.tp.nm.plan.infra.port.dto.purchase.ServiceProductInfoDTO;

/**
 * 服务产品信息查询端口
 * <p>
 * 封装 {@code ServiceProductInfoService#queryServiceProductInfoByCode}，
 * 根据服务产品 code 查询产品信息。
 * </p> */
public interface ServiceProductInfoManager {

    /**
     * 根据服务产品 code 查询产品信息
     *
     * @param serviceCode 服务产品 code
     * @return 服务产品信息（不存在时返回 null）
     */
    ServiceProductInfoDTO queryServiceProductInfoByCode(String serviceCode);
}
