package com.cainiao.tp.nm.plan.infra.port.dto.context;

public interface BasePermissionContext {


}
