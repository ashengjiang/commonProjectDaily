package com.cainiao.tp.nm.plan.infra.port.utils;

import com.cainiao.tp.nm.plan.infra.port.dto.ExpressCodeDTO;
import org.apache.commons.lang3.StringUtils;

public class ExpressUtils {

    private static final String PREFIX = "\\^\\^\\^";

    private static final String BUILD_PREFIX = "^^^";

    public static String build(String expressCode, String cpCode) {
        return cpCode + BUILD_PREFIX + expressCode;
    }

    public static ExpressCodeDTO unpack(String expressCode) {
        if (StringUtils.isBlank(expressCode)) {
            return null;
        }
        String[] split = expressCode.split(PREFIX);
        if (split.length != 2) {
            return null;
        }
        return ExpressCodeDTO.builder().expressCode(split[1]).cpCode(split[0]).build();
    }

    public static void main(String[] args) {
        System.out.println(build("123", "123"));
    }


}
