package com.cainiao.tp.nm.plan.infra.port.policy;

import com.cainiao.tp.nm.plan.api.policy.application.dto.station.NewStaPerformNextLadderDTO;

public interface TpPushStationMessageManager {

    /**
     * 给驿站掌柜下发新站实操激励活动
     * @return
     */
    void sendNewStaPerformSubsidyPopup(Long stationId);

    /**
     * 定期给驿站掌柜下 满足新站激励条件的下发激励活动
     * @return
     */
    void sendNewStaPerformSubsidySatisfyPopup(Long stationId, NewStaPerformNextLadderDTO nextLadderDTO, String jumpUrl) ;

    /**
     * 给驿站掌柜发送实操激励提醒弹窗通知
     *
     * @param stationId     站点 ID
     * @param notifyContent 通知文案内容
     * @param jumpUrl       跳转 URL
     * @param noticeSchemeCode  通知触发方案编码
     */
    void sendIncentiveRemindPopup(Long stationId, String notifyContent, String jumpUrl, String noticeSchemeCode);

}
