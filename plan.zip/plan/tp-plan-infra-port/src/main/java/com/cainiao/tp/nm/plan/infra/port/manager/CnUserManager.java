package com.cainiao.tp.nm.plan.infra.port.manager;

public interface CnUserManager {

    String queryOpenIdByCnUserId(Long cnAccountId);
}
