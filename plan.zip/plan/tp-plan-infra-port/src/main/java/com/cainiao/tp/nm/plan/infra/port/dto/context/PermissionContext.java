package com.cainiao.tp.nm.plan.infra.port.dto.context;

import lombok.Data;

@Data
public class PermissionContext<T extends BasePermissionContext> {

    /**
     * 登陆上下文
     */
    private T context;

    /**
     *com.cainiao.tp.nm.plan.infra.port.common.constants.LoginEntityTypeEnum
     * 登陆身份类型
     */
    private Integer loginType;
}
