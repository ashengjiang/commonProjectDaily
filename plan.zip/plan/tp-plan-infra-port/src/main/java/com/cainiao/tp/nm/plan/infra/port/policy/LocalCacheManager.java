package com.cainiao.tp.nm.plan.infra.port.policy;

import java.io.Serializable;

/**
 * @code date 2025年06月04日 17:35
 * @code desc:null
 */
public interface LocalCacheManager {

    /**
     * 获取缓存
     * @param clazz 返回值类型
     * @return 缓存
     */
    <T> T get(String key, Class<T> clazz);

    /**
     * 设置缓存
     * @param value 缓存值
     * @param key 缓存key
     */
    void set(String key, Serializable value);
}
