package com.cainiao.tp.nm.plan.infra.port.purchase;

import com.cainiao.tp.nm.plan.infra.port.dto.purchase.PlatContractSimpleInfoDTO;

/**
 * 平台合同查询端口
 * <p>
 * 封装 {@code PlatContractReadService#getSimplePlatContract}，
 * 根据服务 code 查询当前可签署的平台合同。
 * </p> */
public interface PlatContractReadManager {

    /**
     * 根据服务 code 查询当前可签署的平台合同
     *
     * @param serviceCode 服务 code
     * @return 当前可签署的合同信息（不存在时返回 null）
     */
    PlatContractSimpleInfoDTO getSimplePlatContract(String serviceCode);
}
