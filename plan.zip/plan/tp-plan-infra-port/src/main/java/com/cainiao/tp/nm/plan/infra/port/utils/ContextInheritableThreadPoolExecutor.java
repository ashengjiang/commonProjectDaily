package com.cainiao.tp.nm.plan.infra.port.utils;

import com.taobao.eagleeye.EagleEye;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;

import java.util.Map;
import java.util.concurrent.*;

/**
 * 支持线程的MDC Context的传递
 */
@Slf4j
public class ContextInheritableThreadPoolExecutor extends ThreadPoolExecutor {

    /**
     * java.lang.Runnable 代理类
     */
    private static class RunnableProxy implements Runnable {
        private final Runnable delegate;
        private final Map<String, String> mdcContext;

        public RunnableProxy(Runnable runnable) {
            this.delegate = runnable;
            this.mdcContext = MDC.getCopyOfContextMap();
        }

        /**
         * 执行异步任务， MDC Context
         */
        @Override
        public void run() {
            // 保存原线程上下文
            Map<String, String> backupMdcContext = MDC.getCopyOfContextMap();

            try {
                try {
                    // 设置线程上下文
                    if (mdcContext != null && !mdcContext.isEmpty()) {
                        MDC.setContextMap(mdcContext);
                    }
                } catch (Exception e) {
                    log.error("RunnableProxy replay exception", e);
                }
                this.delegate.run();
            } finally {
                try {
                    // 恢复原线程上下文
                    if (backupMdcContext != null && !backupMdcContext.isEmpty()) {
                        MDC.setContextMap(backupMdcContext);
                    } else {
                        MDC.clear();
                    }
                } catch (Exception e) {
                    log.error("RunnableProxy restore exception", e);
                }
            }
        }
    }

    /**
     * java.util.concurrent.Callable 代理类
     */
    private static class CallableProxy<V> implements Callable<V> {
        private final Callable<V> delegate;
        private final Map<String, String> mdcContext;


        public CallableProxy(Callable<V> callable) {
            this.delegate = callable;
            this.mdcContext = MDC.getCopyOfContextMap();
        }

        /**
         * 执行异步任务，自动复制EagleEye RpcContext 和 MDC Context
         */
        @Override
        public V call() throws Exception {
            // 保存原线程上下文
            Map<String, String> backupMdcContext = MDC.getCopyOfContextMap();
            try {
                try {
                    // 设置线程上下文
                    if (mdcContext != null && !mdcContext.isEmpty()) {
                        MDC.setContextMap(mdcContext);
                    }
                } catch (Exception e) {
                    log.error("CallableProxy replay exception", e);
                }
                return this.delegate.call();
            } finally {
                try {
                    // 恢复原线程上下文
                    if (backupMdcContext != null && !backupMdcContext.isEmpty()) {
                        MDC.setContextMap(backupMdcContext);
                    } else {
                        MDC.clear();
                    }
                } catch (Exception e) {
                    log.error("CallableProxy restore exception", e);
                }
            }
        }

    }

    /**
     * 提交任务，通过代理类执行方法：
     * java.util.concurrent.AbstractExecutorService#submit(java.util.concurrent.Callable)
     */
    @Override
    public void execute(Runnable command) {
        command = mergeEagleEyeRpcContextRunnable(command);
        Runnable proxy = new RunnableProxy(command);
        super.execute(proxy);
    }

    /**
     * 提交任务，通过代理类执行方法：
     * java.util.concurrent.AbstractExecutorService#submit(java.util.concurrent.Callable)
     */
    @Override
    public <T> Future<T> submit(Callable<T> task) {
        task = mergeEagleEyeRpcContextCallable(task);
        CallableProxy<T> proxy = new CallableProxy<>(task);
        return super.submit(proxy);
    }


    /**
     * 创建线程池
     *
     * @param corePoolSize    核心线程数最大值
     * @param maximumPoolSize 线程总数最大值
     * @param keepAliveTime   非核心线程空闲超时时间
     * @param unit            keepAliveTime 的单位
     * @param workQueue       存放任务的阻塞队列
     */
    public ContextInheritableThreadPoolExecutor(int corePoolSize,
                                                int maximumPoolSize,
                                                long keepAliveTime,
                                                TimeUnit unit,
                                                BlockingQueue<Runnable> workQueue) {
        super(corePoolSize, maximumPoolSize, keepAliveTime, unit, workQueue);
    }

    /**
     * 创建线程池
     *
     * @param corePoolSize    核心线程数最大值
     * @param maximumPoolSize 线程总数最大值
     * @param keepAliveTime   非核心线程空闲超时时间
     * @param unit            keepAliveTime 的单位
     * @param workQueue       存放任务的阻塞队列
     * @param threadFactory   线程工厂
     */
    public ContextInheritableThreadPoolExecutor(int corePoolSize,
                                                int maximumPoolSize,
                                                long keepAliveTime,
                                                TimeUnit unit,
                                                BlockingQueue<Runnable> workQueue,
                                                ThreadFactory threadFactory) {
        super(corePoolSize, maximumPoolSize, keepAliveTime, unit, workQueue,
                threadFactory);
    }

    /**
     * 创建线程池
     *
     * @param corePoolSize    核心线程数最大值
     * @param maximumPoolSize 线程总数最大值
     * @param keepAliveTime   非核心线程空闲超时时间
     * @param unit            keepAliveTime 的单位
     * @param workQueue       存放任务的阻塞队列
     * @param handler         饱和策略
     */
    public ContextInheritableThreadPoolExecutor(int corePoolSize,
                                                int maximumPoolSize,
                                                long keepAliveTime,
                                                TimeUnit unit,
                                                BlockingQueue<Runnable> workQueue,
                                                RejectedExecutionHandler handler) {
        super(corePoolSize, maximumPoolSize, keepAliveTime, unit, workQueue,
                handler);
    }

    /**
     * 创建线程池
     *
     * @param corePoolSize    核心线程数最大值
     * @param maximumPoolSize 线程总数最大值
     * @param keepAliveTime   非核心线程空闲超时时间
     * @param unit            keepAliveTime 的单位
     * @param workQueue       存放任务的阻塞队列
     * @param threadFactory   线程工厂
     * @param handler         饱和策略
     */
    public ContextInheritableThreadPoolExecutor(int corePoolSize,
                                                int maximumPoolSize,
                                                long keepAliveTime,
                                                TimeUnit unit,
                                                BlockingQueue<Runnable> workQueue,
                                                ThreadFactory threadFactory,
                                                RejectedExecutionHandler handler) {

        super(corePoolSize, maximumPoolSize, keepAliveTime, unit, workQueue, threadFactory,
                handler);
    }
    private Runnable mergeEagleEyeRpcContextRunnable(final Runnable runnable) {
        Object rpcContext = EagleEye.currentRpcContext();
        return () -> {
            try {
                EagleEye.setRpcContext(rpcContext);
                runnable.run();
            } finally {
                EagleEye.clearRpcContext();
            }
        };
    }
    private static <V> Callable<V> mergeEagleEyeRpcContextCallable(final Callable<V> callable) {
        Object rpcContext = EagleEye.currentRpcContext();
        return () -> {
            try {
                EagleEye.setRpcContext(rpcContext);
                return callable.call();
            } finally {
                EagleEye.clearRpcContext();
            }
        };
    }
}
