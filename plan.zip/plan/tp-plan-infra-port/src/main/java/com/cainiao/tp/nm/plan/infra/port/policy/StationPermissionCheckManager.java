package com.cainiao.tp.nm.plan.infra.port.policy;

import com.cainiao.tp.nm.plan.infra.port.dto.context.StationPermissionContext;

/**
 * @code date 2025年07月31日 14:26
 * @code desc:站点权限处理管理器
 */
public interface StationPermissionCheckManager {

    StationPermissionContext checkPermission(StationPermissionContext context);
}
