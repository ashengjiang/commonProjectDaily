package com.cainiao.tp.nm.plan.infra.port.policy;

import com.cainiao.tp.nm.plan.api.policy.application.dto.config.NewStaPerformSubsidyConfigDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.NewStaPerformSubsidyPopConfigDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.PolicyApproveConfigDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.PolicyIncentivePlanConfigDTO;

import java.time.LocalDateTime;
import java.util.List;

public interface PolicyConfigManager {

    /**
     * 获取政策审批配置
     * @return
     */
    PolicyApproveConfigDTO getApproveConfig(String bizType, String customType);

    /**
     * 获取政策费用项配置
     * @return 返回这个类型下所有的费用项code 未判断周期
     */
    List<PolicyIncentivePlanConfigDTO> getPlanConfig(String bizType, String customType);

    /**
     * 获取政策费用项配置
     * @return 返回这个类型下所有的费用项code 未判断周期
     */
    PolicyIncentivePlanConfigDTO getPlanConfigByPlanType(String bizType, String customType, String incentivePlanType);

    /**
     * 获取无权限提示
     * @return
     */
    String getPermissionDeniedPrompt();

    /**
     * 获取生效时间
     * @return
     */
    String getPolicySubmitTaskOverTime(LocalDateTime startTime);

    String getMockStaMapping(String stationId);

    NewStaPerformSubsidyPopConfigDTO getNewStaPerformSubsidyPopConfig();

    NewStaPerformSubsidyConfigDTO getNewStaPerformSubsidyConfig();
}
