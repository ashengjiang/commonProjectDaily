package com.cainiao.tp.nm.plan.infra.port.policy;

import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.PolicyOpRightsVO;

import java.util.List;
import java.util.Set;

/**
 * 员工权限加载
 */
public interface EmployeeRightsLoadManager {

    /**
     * 获取员工角色
     *
     * @param employeeId
     * @param expectRoleCodes 预期角色code集合
     * @return
     */
    List<String> getEmployeeRoles(Long employeeId,Set<String> expectRoleCodes);

    /**
     * 获取员工城市权限
     * @param employeeId
     * @return
     */
    PolicyOpRightsVO getDivisionRights(Long employeeId);

    /**
     * 获取菜鸟会员ID
     * @param employeeId 员工id
     * @return 菜鸟会员ID
     */
    String getCnUserId(Long employeeId);

    /**
     * 获取大区部门code
     * @param cityCode 城市code
     * @return 大区部门code
     */
    String selectRegionDeptCode(String cityCode);


    /**
     * 获取员工最高层级code
     * @param employeeId 员工id
     * @return 员工最高层级code
     */
    String getEmployeeHighestLevelCode(Long employeeId);

    /**
     * 查询大区code
     * @param cityCode 城市code
     * @return 大区code
     */
    String queryRegionCodeByCityCode(String cityCode);

    /**
     * 清理员工权限缓存-仅限测试使用
     * @param employeeId employeeId
     */
    void clearCache(Long employeeId);

}
