package com.cainiao.tp.nm.plan.infra.port.dto;

import lombok.Data;

@Data
public class AgreementInfoAndSignDTO {

    /**
     * 协议ID
     */
    private Long agreementId;
    /**
     * 协议code
     */
    private String agreementCode;
    /**
     * 协议名称
     */
    private String agreementName;
    /**
     * 协议url
     */
    private String agreementUrl;

    /**
     * 是否签约  true=签约 false=未签约
     */
    private Boolean signed;
}
