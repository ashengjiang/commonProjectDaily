package com.cainiao.tp.nm.plan.infra.port.purchase;

import com.cainiao.tp.nm.plan.infra.port.dto.purchase.EntityLaunchEditParam;

import java.util.List;

/**
 * 混合合同写入端口
 * <p>
 * 封装 {@code MixContractWriteService#editEntityLaunchRelation}，
 * 编辑实体投放关系。
 * </p> */
public interface MixContractManager {

    /**
     * 编辑实体投放关系
     *
     * @param editParams 实体投放关系编辑参数列表
     * @return 编辑成功的记录 ID 列表
     */
    List<Long> editEntityLaunchRelation(List<EntityLaunchEditParam> editParams);
}
