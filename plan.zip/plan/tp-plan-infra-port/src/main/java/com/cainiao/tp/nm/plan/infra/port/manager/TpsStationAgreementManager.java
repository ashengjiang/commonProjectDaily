package com.cainiao.tp.nm.plan.infra.port.manager;

import com.cainiao.tp.nm.plan.infra.port.dto.purchase.TpsAgreementCreateAndSignDTO;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.TpsAgreementInfoDTO;

/**
 * TPS 协议查询端口 */
public interface TpsStationAgreementManager {

    /**
     * 根据协议 ID 查询协议详情
     *
     * @param agreementId 协议 ID
     * @return 协议详情，查询失败或不存在时返回 null
     */
    TpsAgreementInfoDTO queryDetail(Long agreementId);

    /**
     * 根据协议 code 查询协议详情
     *
     * @param agreementCode 协议编码
     * @return 协议详情，查询失败或不存在时返回 null
     */
    TpsAgreementInfoDTO queryByCode(String agreementCode);

    /**
     * 创建并签署协议实例
     *
     * @param param 创建并签署参数
     * @return 创建并签署后的协议实例 ID，失败时返回 null
     */
    Long createAndSign(TpsAgreementCreateAndSignDTO param);

    /**
     * 查询指定站点是否已签署指定协议
     *
     * @param agreementCode 协议编码
     * @param stationId     站点 ID
     * @return true=已签；false=未签或查询失败
     */
    boolean isSigned(String agreementCode, Long stationId);
}
