package com.cainiao.tp.nm.plan.infra.port.policy;


public interface CacheManager {

    /**
     * 获取缓存
     * @param clazz 返回值类型 复杂对象
     * @return 缓存
     */
    <T> T get(String key, Class<T> clazz);


    /**
     * 获取缓存
     * @param key 缓存key
     * @return 缓存
     */
    String getString(String key);



    /**
     * 设置缓存，面向复杂对象
     * @param expire 过期时间（seconds）
     * @param value 缓存值 not null
     * @param key 缓存key
     */
    <T>void set(String key, T value, int expire);


    /**
     * 设置缓存，面向复杂对象
     * @param expire 过期时间（seconds）
     * @param value 缓存值
     * @param key 缓存key
     */
    void setStr(String key, String value, int expire);

}
