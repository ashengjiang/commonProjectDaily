package com.cainiao.tp.nm.plan.infra.port.policy;

import com.cainiao.aladdin.lock.Lock;

/**
 * http://tiddo.alibaba-inc.com/saas-tair/#/InstanceDetail?username=d72d7419535d4881
 * @date 2021/01/19
 */
public interface PolicyTairLockManager {

    /**
     * 尝试加锁
     * @param lock
     */
     void tryLockAndThrow(Lock lock);

    /**
     * 加锁
     * @param lock
     * @return
     */
     boolean tryLock(Lock lock);

    /**
     * 释放锁
     * @param lock
     * @return
     */
     boolean release(Lock lock);

}
