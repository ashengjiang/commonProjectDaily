package com.cainiao.tp.nm.plan.infra.port.purchase;

import com.cainiao.tp.nm.plan.api.purchase.application.dto.CertifiedEnterpriseInfoDTO;

/**
 * 企业认证查询端口 */
public interface EnterpriseCertifyManager {

    /**
     * 查询已认证的企业信息
     *
     * @param expressCode   CpCode+^^^+oragCode
     * @return 已认证企业信息，未认证或调用失败返回 null
     */
    CertifiedEnterpriseInfoDTO queryCertifiedEnterprise(String expressCode);
}
