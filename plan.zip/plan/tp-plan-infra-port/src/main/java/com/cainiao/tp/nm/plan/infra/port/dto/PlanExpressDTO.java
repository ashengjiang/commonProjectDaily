package com.cainiao.tp.nm.plan.infra.port.dto;

import lombok.Data;

@Data
public class PlanExpressDTO {

    private Long expressId;
    private String expressName;
    private String cpCode;
    private String cpName;
    private String orgCode;
    private Long provinceCode;
    private Long cityCode;
    private Long areaCode;
    private Long townCode;

}
