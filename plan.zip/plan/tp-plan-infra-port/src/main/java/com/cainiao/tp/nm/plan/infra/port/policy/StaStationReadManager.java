package com.cainiao.tp.nm.plan.infra.port.policy;

import com.cainiao.tp.nm.plan.api.policy.application.dto.StationDTO;

/**
 * @code date 2025年08月04日 15:08
 * @code desc:null
 */
public interface StaStationReadManager {

    StationDTO queryStationById(Long stationId);

    StationDTO queryStationByCode(String stationCode);

    StationDTO queryStation(String stationId);
}
