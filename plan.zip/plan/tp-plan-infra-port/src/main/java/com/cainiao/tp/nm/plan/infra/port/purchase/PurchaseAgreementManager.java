package com.cainiao.tp.nm.plan.infra.port.purchase;

import com.cainiao.tp.nm.plan.api.purchase.application.dto.AgreementInfoDTO;
import com.cainiao.tp.nm.plan.infra.port.dto.param.ExpressAgreementParam;

/**
 * 购买协议查询端口
 * <p>
 * 对应技术方案文档「下单流程」中：购买协议是否签署 的检查能力。
 * 下游：网点协议中心（待对接）。
 * </p> */
public interface PurchaseAgreementManager {

    /**
     * 查询指定客户的购买协议签署状态
     *
     * @param pram   param
     *                     {@link com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseCustomerTypeEnum}
     * @return 协议信息（含 agreementCode 与 sign 标志）；未签或调用失败由实现类决定语义
     */
    boolean queryPurchaseAgreement(ExpressAgreementParam pram);
}
