package com.cainiao.tp.nm.plan.infra.port.policy;

import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.IncentivePlanDTO;

public interface PolicyIncentiveTemplateConfigManager {

    /**
     * 获取激励方案基础模版
     * @return
     */
    IncentivePlanDTO getIncentivePlanTemplate(String bizType, String customType
            , String incentivePlanType, String incentivePlanCode, String startTimeStr, String endTimeStr);
}
