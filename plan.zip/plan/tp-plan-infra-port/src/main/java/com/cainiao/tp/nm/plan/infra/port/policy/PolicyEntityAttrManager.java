package com.cainiao.tp.nm.plan.infra.port.policy;

import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiverule.select.EntitySelectRuleDTO;

import java.util.List;
import java.util.Map;

/**
 * @code date 2025年06月03日 15:43
 * @code desc: 政策主体属性匹配度
 */
public interface PolicyEntityAttrManager {

    /**
     * 获取主体属性信息
     * @return
     */
    Map<String, Boolean> hasAttr(EntitySelectRuleDTO entity, Map<String, List<String>> attrMap);
}
