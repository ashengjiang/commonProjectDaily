package com.cainiao.tp.nm.plan.infra.port.purchase;

import com.cainiao.tp.nm.plan.infra.port.dto.purchase.StationExpressInfoDTO;

/**
 * 网点服务端口 */
public interface StationExpressManager {

    /**
     * 根据网点 ID 查询网点信息
     *
     * @param expressId 网点 ID（不是网点 code）
     * @return 网点信息，查询失败或不存在时返回 null
     */
    StationExpressInfoDTO queryExpressInfo(Long expressId);
}
