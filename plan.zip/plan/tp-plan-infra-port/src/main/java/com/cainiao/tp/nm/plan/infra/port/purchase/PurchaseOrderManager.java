package com.cainiao.tp.nm.plan.infra.port.purchase;

import com.cainiao.tp.nm.plan.infra.port.dto.purchase.PurchaseOrderInfoDTO;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.PurchaseOrderPageResultDTO;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.PurchaseOrderQueryDTO;

import java.util.List;

/**
 * 订购订单通用查询端口
 * <p>
 * 提供基于 {@link PurchaseOrderQueryDTO} 的通用查询能力，
 * 上层无需为每个查询场景在 Repository 中新增方法，按需组合查询条件即可。
 * </p> */
public interface PurchaseOrderManager {

    /**
     * 按条件查询订单列表
     *
     * @param queryDTO 查询条件，支持 id、客户、状态、平台订单号、时间范围等过滤
     * @return 订单 DTO 列表（无结果返回空列表）
     */
    List<PurchaseOrderInfoDTO> queryList(PurchaseOrderQueryDTO queryDTO);

    /**
     * 按条件查询单条订单（取第一条）
     *
     * @param queryDTO 查询条件
     * @return 订单 DTO，未命中返回 null
     */
    PurchaseOrderInfoDTO queryOne(PurchaseOrderQueryDTO queryDTO);

    /**
     * 按条件分页查询订单
     *
     * @param queryDTO 查询条件（需设置 page、size）
     * @return 分页结果
     */
    PurchaseOrderPageResultDTO queryPage(PurchaseOrderQueryDTO queryDTO);

    /**
     * 按条件统计订单数
     *
     * @param queryDTO 查询条件
     * @return 记录数
     */
    long count(PurchaseOrderQueryDTO queryDTO);
}
