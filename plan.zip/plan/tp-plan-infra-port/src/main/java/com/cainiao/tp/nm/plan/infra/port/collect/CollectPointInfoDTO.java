package com.cainiao.tp.nm.plan.infra.port.collect;

import com.cainiao.aladdin.domain.BaseBean;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.util.Map;

/**
 * @code date 2024年10月28日 15:57
 * @code desc:代收点信息
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class CollectPointInfoDTO extends BaseBean {

    /**
     * 代收点ID
     */
    private String pointId;

    /**
     * 代收点名称
     */
    private String name;

    /**
     * 代收点来源
     */
    private String source;

    /**
     * 代收点品牌列表
     */
    private String pointBrandCodes;

    /**
     * 0-待生效 1-正常 -1-失效
     */
    private Integer status;

    /**
     * 10-非活跃 20-活跃
     */
    private Integer bizStatus;

    /**
     * 代收点地址
     */
    private String address;

    /**
     * 省份code
     */
    private String provinceCode;

    /**
     * 城市code
     */
    private String cityCode;

    /**
     * 区县code
     */
    private String districtCode;

    /**
     * 街道ID
     */
    private String townCode;

    /**
     * 经度
     */
    private BigDecimal lng;

    /**
     * 纬度
     */
    private BigDecimal lat;

    /**
     * 扩展信息map
     */
    private Map<String, String> featureMap;

}
