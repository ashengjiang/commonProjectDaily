package com.cainiao.tp.nm.plan.infra.port.policy;

import com.cainiao.tp.nm.plan.api.policy.application.dto.param.TgBaseParam;

import java.util.List;

public interface TgManager {


    /**
     * 查询数据
     * @param tgBaseRequest req
     * @return return
     * @param <T> t
     */
    <T> List<T> getListData(TgBaseParam<T> tgBaseRequest);

}
