package com.cainiao.tp.nm.plan.infra.port.manager;

import com.cainiao.tp.nm.plan.infra.port.dto.context.BasePermissionContext;
import com.cainiao.tp.nm.plan.infra.port.dto.context.PermissionContext;

public interface PermissionLoginManager {


    PermissionContext<BasePermissionContext> loginPermission();
}
