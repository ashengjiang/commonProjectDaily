package com.cainiao.tp.nm.plan.infra.port.policy;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.LocalDate;
import java.util.List;

/**
 * 站点实操激励提醒-站点查询端口接口
 * 封装 OpenSearch 站点列表 scroll 查询能力
 *
 * @date 2026-03-27
 */
public interface IncentiveRemindStationManager {

    /**
     * 通过 scroll 方式查询入驻时间 >= joinStartDate 的站点信息列表（含站点ID和入驻日期）
     * 通过 OpenSearch 实例 tp_sta_perform_finance_join 查询，支持超过 5000 条数据的全量拉取
     *
     * @param joinStartDate 入驻时间起始日期（含），仅返回该日期及之后入驻的站点
     * @param pageSize      每批查询大小
     * @param scrollId      上次查询返回的 scrollId，首次查询传 null
     * @return scroll 查询结果，包含站点列表和下一次查询所需的 scrollId
     */
    ScrollResult scrollStations(LocalDate joinStartDate, int pageSize, String scrollId);

    /**
     * 站点入驻信息（站点ID + 入驻日期）
     */
    @Data
    @AllArgsConstructor
    class StationJoinInfo {

        /**
         * 站点 ID
         */
        private String stationId;

        /**
         * 入驻日期
         */
        private LocalDate joinDate;
    }

    /**
     * scroll 查询结果
     */
    @Data
    @AllArgsConstructor
    class ScrollResult {

        /**
         * 本次查询到的站点列表
         */
        private List<StationJoinInfo> stationList;

        /**
         * 下次查询所需的 scrollId，为 null 时表示已无更多数据
         */
        private String scrollId;

        private Long totalCount;

    }

}
