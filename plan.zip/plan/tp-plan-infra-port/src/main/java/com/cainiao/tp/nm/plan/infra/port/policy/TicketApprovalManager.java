package com.cainiao.tp.nm.plan.infra.port.policy;

import java.util.Map;

import com.cainiao.tp.nm.plan.api.policy.application.dto.TpTicketDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.TicketInstanceApprovalStartParam;

/**
 * @code date 2025年06月03日 15:43
 * @code desc:工单审批流程端口
 */
public interface TicketApprovalManager<T,U> {

    /**
     * 发起政策审批
     * @param startParam 开启参数
     * @return 流程实例id
     */
    String startApproval(T startParam);

    /**
     * 根据ticketId查询ticket
     * @param ticketId 工单id
     * @return 工单
     */
    U queryTicketById(Long ticketId);

    /**
     * 更新ticket
     * @param ticketId 工单id
     * @param context 上下文
     */
    void updateTicket(Long ticketId, Map<String, Object> context);

    /**
     * 任务节点超时推进
     * @param taskId 任务id
     * @param action 动作
     */
    void timeOutPush(Long taskId, String action);

    /**
     * 取消流程任务
     * @param processInstanceId 流程实例id
     * @param cancelReason 取消原因
     */
    void cancelProcessInstance(String processInstanceId, String cancelReason);

    /**
     * 根据上下文key查询流程实例id
     * @param definitionKey 流程定义key
     * @param contextUniqueId 上下文唯一ID
     * @return 流程实例id
     */
    String getInstanceIdByContextKey(String definitionKey, String contextUniqueId);

    /**
     * 获取幂等id
     * @param startParam 开启参数
     * @return 幂等id
     */
    String getIdempotentId(T startParam);
}
