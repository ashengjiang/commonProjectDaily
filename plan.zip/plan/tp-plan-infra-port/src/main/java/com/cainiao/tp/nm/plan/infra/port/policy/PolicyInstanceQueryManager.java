package com.cainiao.tp.nm.plan.infra.port.policy;

import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyInstanceDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyInstanceDetailQueryParam;

import java.util.List;

/**
 * @code date 2025年06月03日 15:43
 * @code desc:暴露给基础层的查询政策实例的端口
 */
public interface PolicyInstanceQueryManager {


    /**
     * 查询政策实例
     *
     * @param param 查询请求
     * @return 政策实例
     */
    List<PolicyInstanceDTO> queryPolicyInstanceByParam(PolicyInstanceDetailQueryParam param);


    /**
     * 查询政策实例
     *
     * @param templateId 政策模版id
     * @return 政策实例
     */
    List<PolicyInstanceDTO> queryPolicyInstanceByTemplateId(Long templateId);

    /**
     * 根据ID查询政策实例
     *
     * @param id 政策实例id
     * @return 政策实例
     */
    PolicyInstanceDTO queryPolicyInstanceById(Long id);


    Long countPolicyInstanceByParam(PolicyInstanceDetailQueryParam param);
}
