package com.cainiao.tp.nm.plan.infra.port.policy;

/**
 * 站点实操激励提醒防重发 Tair 端口接口
 * 封装 Tair 防重发标记的读写能力
 *
 * @date 2026-03-27
 */
public interface IncentiveRemindTairPort {

    /**
     * 检查指定站点、规则、触发日期的通知是否已发送
     *
     * @param stationId   站点 ID
     * @param ruleName    规则名称
     * @param triggerDate 触发日期，格式 yyyyMMdd
     * @return true=已发送，false=未发送
     */
    boolean isAlreadySent(String stationId, String ruleName, String triggerDate);

    /**
     * 标记指定站点、规则、触发日期的通知已发送，过期时间 90 天
     *
     * @param stationId   站点 ID
     * @param ruleName    规则名称
     * @param triggerDate 触发日期，格式 yyyyMMdd
     */
    void markAsSent(String stationId, String ruleName, String triggerDate);
}
