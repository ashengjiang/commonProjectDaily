package com.cainiao.tp.nm.plan.infra.port.policy;

import com.cainiao.tp.nm.plan.api.policy.application.dto.ExpressContentDTO;

/**
 * @code date 2025年06月26日 16:01
 * @code desc:null
 */
public interface ExpressAccessCheckManager {

    void checkExpAndJVAccess(ExpressContentDTO context);
}
