package com.cainiao.tp.nm.plan.infra.port.purchase;

import com.cainiao.tp.nm.plan.infra.port.dto.purchase.DuoNiuOrderDetailDTO;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.DuoNiuSkuDetailDTO;

/**
 * 多牛商品查询端口
 * <p>
 * 封装 {@code DuoNiuQueryService} 的查询方法，
 * 根据商品 itemId 查询万里牛 SKU 详情，或根据订单 ID 查询订单详情。
 * </p> */
public interface DuoNiuQueryManager {

    /**
     * 根据 itemId 查询万里牛 SKU 详情
     *
     * @param itemId 商品 itemId
     * @return SKU 详情（含 skusList）；查询失败时抛异常
     */
    DuoNiuSkuDetailDTO querySkuByItemId(Integer itemId);

    /**
     * 根据订单 ID 和供应商 ID 查询万里牛订单详情
     *
     * @param orderId    万里牛订单 ID
     * @param supplierId 供应商 ID
     * @return 订单详情；查询失败时抛异常
     */
    DuoNiuOrderDetailDTO queryOrderDetailById(String orderId, String supplierId);
}
