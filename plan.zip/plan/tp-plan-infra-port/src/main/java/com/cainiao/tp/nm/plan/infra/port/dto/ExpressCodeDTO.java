package com.cainiao.tp.nm.plan.infra.port.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ExpressCodeDTO {

    /**
     * 表达code
     */
    private String expressCode;

    /**
     * cp Code
     */
    private String cpCode;
}
