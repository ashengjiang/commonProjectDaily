package com.cainiao.tp.nm.plan.infra.port.policy;

import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyInstanceRuleDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyInstanceRuleQueryParam;

import java.util.List;

/**
 * @code date 2025年06月03日 15:43
 * @code desc: 暴露给基础层的 查询政策实例规则端口
 */
public interface PolicyInstanceRuleQueryManager {

    /**
     * 查询政策实例规则
     * @param param 查询请求
     * @return 政策实例规则
     */
    List<PolicyInstanceRuleDTO> queryPolicyInstanceRuleByParam(PolicyInstanceRuleQueryParam param);

    /**
     * 统计 政策实例规则
     * @param param 查询请求
     * @return 政策实例规则
     */
    Long countPolicyInstanceRuleByParam(PolicyInstanceRuleQueryParam param);

    PolicyInstanceRuleDTO queryPolicyInstanceRuleById(Long id);

    /**
     * 查询第一个政策实例规则
     * @param instanceId 政策实例id
     * @return 政策实例规则
     */
    PolicyInstanceRuleDTO queryFirstPolicyInstanceRuleByInstanceId(Long instanceId);
}
