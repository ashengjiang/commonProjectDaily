package com.cainiao.tp.nm.plan.infra.port.dto.context;

import com.cainiao.tp.nm.plan.infra.port.dto.context.BasePermissionContext;
import lombok.Data;

/**
 * @code date 2025年07月31日 14:51
 * @code desc:站点权限上下文
 */
@Data
public class StationPermissionContext implements BasePermissionContext {

    private String source;

    private String stationId;

    private Long userId;

    private String userName;

    private Long cnAccountId;

    private Long employeeId;

    private String sessionId;

    private String appKey;

    private Integer authType;

    private Boolean corporation;
    /**
     * 城市
     */
    private String cityCode;
    /**
     * 用户类型 1=淘宝 2=菜鸟登陆态
     */
    private Integer userType;
}
