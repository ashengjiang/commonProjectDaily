package com.cainiao.tp.nm.plan.infra.port.policy;

import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyTemplateDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.PolicyIncentiveExpenseItemDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.IncentivePlanDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.IncentiveExpenseItemQueryParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.IncentivePlanQueryParam;

import java.util.List;

/**
 * @code date 2025年06月04日 15:57
 * @code desc:null
 */
public interface PolicyTemplateQueryManager {

    List<PolicyTemplateDTO> queryPolicyTemplate(String bizType);
    PolicyTemplateDTO queryPolicyTemplateById(Long id);

    /**
     * 外部激励类型,如费用项code
     * @return
     */
    List<IncentivePlanDTO> queryIncentivePlanFromOutBiz(IncentivePlanQueryParam param);

    /**
     * 查询激励费用项列表
     * @param queryParam 查询参数
     * @return 激励费用项列表
     */
    List<PolicyIncentiveExpenseItemDTO> queryIncentiveExpenseItemList(IncentiveExpenseItemQueryParam queryParam);
}
