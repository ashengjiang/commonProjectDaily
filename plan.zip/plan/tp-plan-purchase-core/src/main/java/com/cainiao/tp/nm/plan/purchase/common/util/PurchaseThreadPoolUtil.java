package com.cainiao.tp.nm.plan.purchase.common.util;

import com.cainiao.tp.nm.plan.infra.port.utils.ContextInheritableThreadPoolExecutor;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import org.springframework.stereotype.Component;

import java.util.concurrent.*;

/**
 *线程池
 */
@Component
public class PurchaseThreadPoolUtil {

    /**
     * 主线程数
     */
    private static final int CORE_POOL_SIZE = Runtime.getRuntime().availableProcessors() + 1;

    /**
     * 最大线程数
     */
    private static final int MAXIMUM_POOL_SIZE = Runtime.getRuntime().availableProcessors() << 1;

    /**
     * 队列最大值
     */
    public static final int MAX_VALUE = 10000;

    private ContextInheritableThreadPoolExecutor contextInheritableThreadPoolExecutor;

    private volatile boolean inited = false;

    private synchronized void init() {
        if (inited) {
            return;
        }

        /**
         * 线程池维护线程所允许的空闲时间
         */
        long keepAliveTime = 60;
        contextInheritableThreadPoolExecutor = new ContextInheritableThreadPoolExecutor(CORE_POOL_SIZE, MAXIMUM_POOL_SIZE, keepAliveTime,
                TimeUnit.SECONDS, new LinkedBlockingQueue<>(MAX_VALUE), new ThreadFactoryBuilder().setNameFormat("plan-infra-pool-%d").build(), new ThreadPoolExecutor.AbortPolicy());
        this.contextInheritableThreadPoolExecutor.allowCoreThreadTimeOut(true);
        inited = true;
    }

    public void execute(Runnable runnable) {
        if (!inited) {
            init();
        }
        contextInheritableThreadPoolExecutor.execute(runnable);
    }

    public <T> Future<T> submit(Callable<T> task) {
        if (!inited) {
            init();
        }
        return contextInheritableThreadPoolExecutor.submit(task);
    }

    /**
     * 获取底层线程池，供 {@link java.util.concurrent.CompletableFuture#supplyAsync} 等场景使用
     *
     * @return 线程池 Executor
     */
    public Executor getExecutor() {
        if (!inited) {
            init();
        }
        return contextInheritableThreadPoolExecutor;
    }


}
