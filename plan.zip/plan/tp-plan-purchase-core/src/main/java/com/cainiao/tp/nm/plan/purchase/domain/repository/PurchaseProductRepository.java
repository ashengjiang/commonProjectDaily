package com.cainiao.tp.nm.plan.purchase.domain.repository;

import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseProduct;

import java.util.List;

/**
 * 订购商品仓储接口 */
public interface PurchaseProductRepository {

    /**
     * 根据商品 ID 列表获取商品信息
     *
     * @param productIds 商品 ID 列表
     * @return 商品信息列表
     */
    List<PurchaseProduct> getProductsByIds(List<Long> productIds);

    /**
     * 根据商品 ID 获取商品信息
     *
     * @param productId 商品 ID
     * @return 商品信息
     */
    PurchaseProduct getProductById(Long productId);

    /**
     * 保存商品（插入后回填 ID）
     *
     * @param product 商品领域模型
     * @return 保存后的商品（含 ID）
     */
    PurchaseProduct saveProduct(PurchaseProduct product);

    /**
     * 根据商品 ID 删除商品
     *
     * @param productId 商品 ID
     */
    void deleteProduct(Long productId);

    /**
     * 根据类目 ID 查询所有商品
     *
     * @param categoryId 类目 ID
     * @return 商品列表
     */
    List<PurchaseProduct> getProductsByCategoryId(Integer categoryId);

    /**
     * 更新商品信息
     *
     * @param product 商品领域模型
     */
    void updateProduct(PurchaseProduct product);
}
