package com.cainiao.tp.nm.plan.purchase.common.util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * 万里牛商城签名
 *
 * @date 2024/11/20
 */
public class WLNSignUtils {

    public static String generateSign(Map<String, String> paramMap, String secret) {
        if (paramMap == null) {
            return "";
        }
        try {
            StringBuilder combineString = new StringBuilder();
            // 万里牛要求头尾都加一遍secret
            combineString.append(secret);
            paramMap.forEach((k, v) -> combineString.append(k).append(v));
            combineString.append(secret);
            byte[] bytesOfMessage = combineString.toString().getBytes(StandardCharsets.UTF_8);
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] digest = md.digest(bytesOfMessage);
            String signature = bytesToHexString(digest);
            return signature;
        } catch (Exception e) {
            return "";
        }
    }

    private static String bytesToHexString(byte[] src) {
        if (src == null || src.length == 0) {
            return null;
        }
        try {
            StringBuilder stringBuilder = new StringBuilder();
            for (byte b : src) {
                int v = b & 255;
                String hv = Integer.toHexString(v);
                if (hv.length() < 2) {
                    stringBuilder.append(0);
                }
                stringBuilder.append(hv);
            }
            return stringBuilder.toString();
        } catch (Exception e) {
            return null;
        }
    }

    public static void main(String[] args) {
        /***
         * 测试环境 5824002  c3c34ca38fb797a4
         */
        String appKey="WD_STO_100000021";
        String appSecret = "c3c34ca38fb797a4";
        Map<String, String> paramMap= new HashMap<>();
        Date date = new Date();
//        String timestamp = String.valueOf(date.getTime());
        String timestamp = "1732092440868";
        paramMap.put("timestamp",timestamp);
        paramMap.put("openID",appKey);
        String newSign =  generateSign(paramMap,appSecret);
        System.out.println("appKey:"+appKey+",timestamp:"+timestamp+",生成的签名:"+newSign);
    }
}
