package com.cainiao.tp.nm.plan.purchase.application.component.factory;

import com.cainiao.tp.nm.plan.infra.port.common.exception.PurchaseServiceException;
import com.cainiao.tp.nm.plan.purchase.application.component.AgreementQueryHandler;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * 协议查询处理器工厂
 * <p>
 * 启动期收集所有 {@link AgreementQueryHandler} bean，按 {@code customerType()} 入路由表。
 * 路由策略：精确匹配 customerType；未命中或 customerType 为空时<b>抛业务异常</b>，
 * 不做兜底，避免错路由到不同客户类型的协议查询逻辑。
 * </p> */
@Slf4j
@Component
public class AgreementQueryHandlerFactory implements ApplicationContextAware, InitializingBean {

    private ApplicationContext applicationContext;

    private final Map<Integer, AgreementQueryHandler> handlerMap = Maps.newHashMap();

    @Override
    public void afterPropertiesSet() throws Exception {
        try {
            Map<String, AgreementQueryHandler> beanMap = applicationContext.getBeansOfType(AgreementQueryHandler.class);
            beanMap.values().forEach(handler -> {
                if (handler.customerType() == null) {
                    log.warn("agreementQueryHandler customerType 为空，已忽略，class={}",
                            handler.getClass().getName());
                    return;
                }
                handlerMap.put(handler.customerType(), handler);
            });
        } catch (Exception e) {
            log.error("init agreementQueryHandlerFactory failed", e);
            throw e;
        }
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    /**
     * 根据客户类型获取协议查询处理器；未命中时抛业务异常
     *
     * @param customerType 客户类型 code（对应 {@code PurchaseCustomerTypeEnum} 的 code）
     * @return 处理器实例
     * @throws PurchaseServiceException customerType 为空或无匹配 handler 时抛出
     */
    public AgreementQueryHandler getHandler(Integer customerType) {
        if (customerType == null) {
            throw PurchaseServiceException.ofIllegalParam("customerType 不能为空");
        }
        AgreementQueryHandler handler = handlerMap.get(customerType);
        if (handler == null) {
            throw PurchaseServiceException.ofIllegalParam("不支持的客户类型: " + customerType);
        }
        return handler;
    }
}
