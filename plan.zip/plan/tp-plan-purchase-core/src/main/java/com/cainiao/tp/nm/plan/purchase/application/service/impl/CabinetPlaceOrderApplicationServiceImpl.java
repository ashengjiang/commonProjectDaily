package com.cainiao.tp.nm.plan.purchase.application.service.impl;

import com.cainiao.aladdin.lock.Lock;
import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.ProductInfoResultDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.AttributeOptionDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.CabinetOrderDetailDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.PlaceOrderResultDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.ProductInfoDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PlaceOrderParam;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PreCalculateOrderParam;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.ProductInfoParam;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PurchaseProductParam;
import com.cainiao.tp.nm.plan.api.purchase.common.constants.CabinetInfoConstants;
import com.cainiao.tp.nm.plan.api.purchase.common.constants.ProductAttributeEnum;
import com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseCategoryEnum;
import com.cainiao.tp.nm.plan.infra.port.common.exception.PurchaseServiceException;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyTairLockManager;
import com.cainiao.tp.nm.plan.purchase.application.component.CabinetPlaceOrderHandler;
import com.cainiao.tp.nm.plan.purchase.application.component.factory.CabinetPlaceOrderHandlerFactory;
import com.cainiao.tp.nm.plan.purchase.application.service.CabinetPlaceOrderApplicationService;
import com.cainiao.tp.nm.plan.purchase.application.service.ProductionApplicationService;
import com.cainiao.tp.nm.plan.purchase.common.util.ProductSpecsParser;
import com.cainiao.tp.nm.plan.purchase.common.util.PurchasePlaceOrderLockUtils;
import com.cainiao.tp.nm.plan.purchase.domain.model.valobj.CabinetGridInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 柜子下单
 */
@Slf4j
@Service
public class CabinetPlaceOrderApplicationServiceImpl implements CabinetPlaceOrderApplicationService {

    @Resource
    private ProductionApplicationService productionApplicationService;

    @Resource
    private CabinetPlaceOrderHandlerFactory cabinetPlaceOrderHandlerFactory;

    @Resource
    private PolicyTairLockManager policyTairLockManager;

    @Override
    public CabinetOrderDetailDTO preCalculateOrder(PreCalculateOrderParam param, AbstractOperation operation) {
        if (param == null || CollectionUtils.isEmpty(param.getProductInfoParamList())) {
            return null;
        }

        // 使用 ProductionApplicationService 获取商品信息，确保商品在规则范围内且是上架的
        ProductInfoParam productInfoParam = new ProductInfoParam();
        productInfoParam.setCustomerId(param.getCustomerId());
        productInfoParam.setCustomerType(param.getCustomerType());
        productInfoParam.setCategoryId(PurchaseCategoryEnum.CABINET.getCode());
        ProductInfoResultDTO productInfoResult = productionApplicationService.getProductInfo(productInfoParam, operation);
        if (productInfoResult == null || CollectionUtils.isEmpty(productInfoResult.getProductInfoList())) {
            return null;
        }

        // 构建商品ID到商品的映射（规则范围内且上架的商品）
        Map<Integer, ProductInfoDTO> productInfoMap = productInfoResult.getProductInfoList().stream()
                .collect(Collectors.toMap(ProductInfoDTO::getItemId, p -> p));

        // 校验前端传过来的商品是否都在规则范围内且上架
        List<String> invalidProductIds = param.getProductInfoParamList().stream()
                .map(PurchaseProductParam::getItemId)
                .filter(itemId -> !productInfoMap.containsKey(Integer.parseInt(itemId)))
                .collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(invalidProductIds)) {
            throw PurchaseServiceException.ofIllegalParam(
                    "以下商品不在规则范围内或已下架: " + String.join(", ", invalidProductIds));
        }

        // 初始化结果
        CabinetOrderDetailDTO result = new CabinetOrderDetailDTO();
        result.setMainCabinetNum(0);
        result.setSubCabinetNum(0);
        result.setTotalGridNum(0);
        result.setTinyGridNum(0);
        result.setSmallGridNum(0);
        result.setMiddleGridNum(0);
        result.setBigGridNum(0);
        result.setTotalPrice(BigDecimal.ZERO.doubleValue());

        // 遍历每个商品参数进行计算
        for (PurchaseProductParam productParam : param.getProductInfoParamList()) {
            Integer productId = Integer.parseInt(productParam.getItemId());
            ProductInfoDTO productInfo = productInfoMap.get(productId);

            // 获取购买数量
            int purchaseNum = productParam.getPurchaseNum() != null ? productParam.getPurchaseNum() : 1;

            // 解析商品标签，统计柜子数量
            parseProductLabels(productInfo, purchaseNum, result);

            // 从 attributeOptionList 中解析格口信息，统计格口数量
            parseGridInfo(productInfo, purchaseNum, result);

            // 累加总价
            if (productInfo.getPrice() != null) {
                result.setTotalPrice(result.getTotalPrice() + productInfo.getPrice() * purchaseNum);
            }
        }

        return result;
    }

    @Override
    public PlaceOrderResultDTO placeOrder(PlaceOrderParam param, AbstractOperation operation) {
        if (param == null) {
            throw PurchaseServiceException.ofIllegalParam("下单参数不能为空");
        }

        // 过滤掉购买数量为 0 的商品
        List<PurchaseProductParam> skuInfoList = param.getPurchaseSkuInfoList();
        if (CollectionUtils.isNotEmpty(skuInfoList)) {
            List<PurchaseProductParam> filteredList = skuInfoList.stream()
                    .filter(item -> item.getPurchaseNum() != null && item.getPurchaseNum() > 0)
                    .collect(Collectors.toList());
            param.setPurchaseSkuInfoList(filteredList);
        }

        // 人维度加分布式锁，防止同一个用户并发重复下单
        Lock lock = PurchasePlaceOrderLockUtils.getCabinetPlaceOrderUserLock(buildUserLockKey(param));
        boolean locked = policyTairLockManager.tryLock(lock);
        if (!locked) {
            throw PurchaseServiceException.ofIllegalParam("下单任务处理中，请耐心等待。。。");
        }
        try {
            CabinetPlaceOrderHandler handler = cabinetPlaceOrderHandlerFactory.getHandler(param.getCustomerType());
            return handler.placeOrder(param, operation);
        } finally {
            policyTairLockManager.release(lock);
        }
    }

    /**
     * 构造人维度锁 key
     * 优先使用菜鸟账号ID；缺失时回退到 customerType:customerId，保证至少能按客户维度互斥
     */
    private String buildUserLockKey(PlaceOrderParam param) {
        if (param.getCnUserAccountId() != null) {
            return String.valueOf(param.getCnUserAccountId());
        }
        if (param.getCustomerType() != null && StringUtils.isNotBlank(param.getCustomerId())) {
            return param.getCustomerType() + ":" + param.getCustomerId();
        }
        throw PurchaseServiceException.ofIllegalParam("下单加锁失败：缺少人维度标识(cnUserAccountId / customerId)");
    }

    /**
     * 解析商品标签，统计柜子数量（主柜、副柜）
     *
     * @param productInfo 商品信息 DTO
     * @param purchaseNum 购买数量
     * @param result 订单详情结果
     */
    private void parseProductLabels(ProductInfoDTO productInfo, int purchaseNum, CabinetOrderDetailDTO result) {
        if (CollectionUtils.isEmpty(productInfo.getAttributeOptionList())) {
            return;
        }

        for (AttributeOptionDTO attributeOption : productInfo.getAttributeOptionList()) {
            if (attributeOption == null || attributeOption.getOptionName() == null) {
                continue;
            }

            String optionName = attributeOption.getOptionName();

            // 根据标签类型统计柜子数量
            if (CabinetInfoConstants.MAIN_CABINET.equals(optionName)) {
                result.setMainCabinetNum(result.getMainCabinetNum() + purchaseNum);
            } else if (CabinetInfoConstants.SUB_CABINET.equals(optionName)) {
                result.setSubCabinetNum(result.getSubCabinetNum() + purchaseNum);
            }
        }
    }

    /**
     * 从 attributeOptionList 中提取格口信息 JSON，解析并统计格口数量
     *
     * @param productInfo 商品信息 DTO
     * @param purchaseNum 购买数量
     * @param result 订单详情结果
     */
    private void parseGridInfo(ProductInfoDTO productInfo, int purchaseNum, CabinetOrderDetailDTO result) {
        if (CollectionUtils.isEmpty(productInfo.getAttributeOptionList())) {
            return;
        }

        // 从 attributeOptionList 中找到 code="grid_info" 的项
        String gridInfoJson = productInfo.getAttributeOptionList().stream()
                .filter(attr -> attr != null && ProductAttributeEnum.GRID_INFO.getCode().equals(attr.getCode()))
                .map(AttributeOptionDTO::getValue)
                .findFirst()
                .orElse(null);

        List<CabinetGridInfo> gridList = ProductSpecsParser.parseGridList(gridInfoJson);
        if (CollectionUtils.isEmpty(gridList)) {
            return;
        }

        for (CabinetGridInfo gridInfo : gridList) {
            if (gridInfo == null || gridInfo.getGridType() == null) {
                continue;
            }

            String gridType = gridInfo.getGridType();
            int gridNum = gridInfo.getNum() != null ? gridInfo.getNum() : 0;
            int totalGridNum = gridNum * purchaseNum;

            // 根据格口类型统计数量
            if (CabinetInfoConstants.TINY_GRID.equals(gridType)) {
                result.setTinyGridNum(result.getTinyGridNum() + totalGridNum);
                result.setTotalGridNum(result.getTotalGridNum() + totalGridNum);
            } else if (CabinetInfoConstants.SMALL_GRID.equals(gridType)) {
                result.setSmallGridNum(result.getSmallGridNum() + totalGridNum);
                result.setTotalGridNum(result.getTotalGridNum() + totalGridNum);
            } else if (CabinetInfoConstants.MIDDLE_GRID.equals(gridType)) {
                result.setMiddleGridNum(result.getMiddleGridNum() + totalGridNum);
                result.setTotalGridNum(result.getTotalGridNum() + totalGridNum);
            } else if (CabinetInfoConstants.BIG_GRID.equals(gridType)) {
                result.setBigGridNum(result.getBigGridNum() + totalGridNum);
                result.setTotalGridNum(result.getTotalGridNum() + totalGridNum);
            }
        }
    }
}
