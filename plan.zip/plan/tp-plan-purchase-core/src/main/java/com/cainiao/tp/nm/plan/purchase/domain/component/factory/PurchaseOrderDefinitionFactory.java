package com.cainiao.tp.nm.plan.purchase.domain.component.factory;

import com.cainiao.tp.nm.plan.purchase.domain.component.PurchaseOrderDefinition;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * 订购订单定义工厂 */
@Slf4j
@Component
public class PurchaseOrderDefinitionFactory implements ApplicationContextAware, InitializingBean {

    private ApplicationContext applicationContext;

    private final Map<String, PurchaseOrderDefinition> definitionMap = Maps.newHashMap();

    @Override
    public void afterPropertiesSet() throws Exception {
        try {
            Map<String, PurchaseOrderDefinition> beanMap = applicationContext.getBeansOfType(PurchaseOrderDefinition.class);
            beanMap.values().forEach(
                    definition -> {
                        String key = definition.bizType();
                        if (StringUtils.isNotBlank(definition.customType())) {
                            key += "_" + definition.customType();
                        }
                        definitionMap.put(key, definition);
                    }
            );
        } catch (Exception e) {
            log.error("init purchaseOrderDefinitionFactory failed", e);
            throw e;
        }
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    public PurchaseOrderDefinition getDefinition(String bizType, Integer customType) {
        String key = bizType;
        if (customType!=null) {
            key += "_" + customType;
        }
        return ObjectUtils.firstNonNull(definitionMap.get(key), definitionMap.get(bizType), definitionMap.get("default_default"));
    }
}
