package com.cainiao.tp.nm.plan.purchase.domain.model;

import com.cainiao.aladdin.domain.BaseBean;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Map;

/**
 * 订购支付明细值对象
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class PurchasePaymentDetail extends BaseBean {

    /**
     * 主键
     */
    private Long id;

    /**
     * 订单ID
     */
    private Long orderId;

    /**
     * 支付单ID
     */
    private Long paymentOrderId;

    /**
     * 付款方类型
     */
    private String payerType;

    /**
     * 支付平台
     */
    private String payerPlatform;

    /**
     * 支付金额
     */
    private BigDecimal actualPaidAmount;

    /**
     * 外部支付流水号
     */
    private String externalTransactionNo;

    /**
     * 支付时间
     */
    private LocalDateTime paymentTime;

    /**
     * 支付快照
     */
    private String paymentSnapshot;

    /**
     * 扩展
     */
    private Map<String, String> feature;

}
