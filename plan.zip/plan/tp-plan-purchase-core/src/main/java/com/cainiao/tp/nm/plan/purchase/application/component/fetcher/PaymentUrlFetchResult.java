package com.cainiao.tp.nm.plan.purchase.application.component.fetcher;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 付款链接拉取结果 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PaymentUrlFetchResult {

    /**
     * 付款/确认页跳转链接
     */
    private String itemBuyUrl;

}
