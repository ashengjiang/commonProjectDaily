package com.cainiao.tp.nm.plan.purchase.domain.model.valobj;

import lombok.Data;

@Data
public class AttributeOption {

    private String code;

    private String value;

    private String optionCode;

    private String optionName;
}
