package com.cainiao.tp.nm.plan.purchase.common.util;

import com.alibaba.fastjson.JSON;
import com.cainiao.tp.nm.plan.purchase.domain.model.valobj.CabinetGridInfo;
import lombok.extern.slf4j.Slf4j;

import java.util.Collections;
import java.util.List;

/**
 * 商品规格解析工具类
 * 用于解析 specs JSON 字符串 */
@Slf4j
public class ProductSpecsParser {

    private ProductSpecsParser() {
    }

    /**
     * 解析格口信息 JSON 字符串
     *
     * @param specsJson 格口信息 JSON 字符串
     * @return 格口信息列表
     */
    public static List<CabinetGridInfo> parseGridList(String specsJson) {
        if (specsJson == null || specsJson.trim().isEmpty()) {
            return Collections.emptyList();
        }

        try {
            return JSON.parseArray(specsJson, CabinetGridInfo.class);
        } catch (Exception e) {
            log.warn("解析格口信息失败，specsJson={}", specsJson, e);
            return Collections.emptyList();
        }
    }
}
