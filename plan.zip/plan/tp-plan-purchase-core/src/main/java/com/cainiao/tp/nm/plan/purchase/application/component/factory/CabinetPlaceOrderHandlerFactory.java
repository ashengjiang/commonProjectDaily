package com.cainiao.tp.nm.plan.purchase.application.component.factory;

import com.cainiao.tp.nm.plan.infra.port.common.exception.PurchaseServiceException;
import com.cainiao.tp.nm.plan.purchase.application.component.CabinetPlaceOrderHandler;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * 柜子下单处理器工厂
 * <p>启动期收集所有 {@link CabinetPlaceOrderHandler} bean，按 {@code customerType()} 入路由表。</p>
 * <p>路由策略：精确匹配 customerType；未命中或 customerType 为空时<b>抛业务异常</b>——
 * 站点（"1"）与网点（"10"）的下单流程差异显著（前者无门槛、后者需 4 项前置检查），
 * 错路由会引发资损或合规风险，因此必须显式失败、不做兜底。</p> */
@Slf4j
@Component
public class CabinetPlaceOrderHandlerFactory implements ApplicationContextAware, InitializingBean {

    private ApplicationContext applicationContext;

    private final Map<Integer, CabinetPlaceOrderHandler> handlerMap = Maps.newHashMap();

    @Override
    public void afterPropertiesSet() throws Exception {
        try {
            Map<String, CabinetPlaceOrderHandler> beanMap = applicationContext.getBeansOfType(CabinetPlaceOrderHandler.class);
            beanMap.values().forEach(handler -> {
                if (handler.customerType() == null) {
                    log.warn("cabinetPlaceOrderHandler customerType 为空，已忽略，class={}",
                            handler.getClass().getName());
                    return;
                }
                handlerMap.put(handler.customerType(), handler);
            });
        } catch (Exception e) {
            log.error("init cabinetPlaceOrderHandlerFactory failed", e);
            throw e;
        }
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    /**
     * 根据客户类型获取下单处理器；未命中时抛业务异常。
     *
     * @param customerType 客户类型（对应 {@link com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseCustomerTypeEnum} 的 code）
     * @return 处理器实例
     * @throws PurchaseServiceException customerType 为空或无匹配 handler 时抛出
     */
    public CabinetPlaceOrderHandler getHandler(Integer customerType) {
        if (customerType == null) {
            throw PurchaseServiceException.ofIllegalParam("customerType 不能为空");
        }
        CabinetPlaceOrderHandler handler = handlerMap.get(customerType);
        if (handler == null) {
            throw PurchaseServiceException.ofIllegalParam("不支持的客户类型: " + customerType);
        }
        return handler;
    }
}
