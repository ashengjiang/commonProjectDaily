package com.cainiao.tp.nm.plan.purchase.application.component;

import com.cainiao.tp.nm.plan.infra.port.dto.AgreementInfoAndSignDTO;
import com.cainiao.tp.nm.plan.infra.port.dto.param.QueryAgreementParam;
import com.cainiao.tp.nm.plan.infra.port.dto.param.SignAgreementParam;

public interface AgreementComponent {

    /**
     * 查询协议情况&&是否签约
     *
     * @param param code
     * @return return
     */
    AgreementInfoAndSignDTO queryAgreementInfoAndSigned(QueryAgreementParam param);

    /**
     * 协议签约
     * <p>
     * 按 customerType 路由到不同的实现（站点 / 网点 等）。
     * </p>
     *
     * @param param 签约入参
     * @return 协议实例 ID；不支持签约或签约失败时返回 null
     */
    Long sign(SignAgreementParam param);
}
