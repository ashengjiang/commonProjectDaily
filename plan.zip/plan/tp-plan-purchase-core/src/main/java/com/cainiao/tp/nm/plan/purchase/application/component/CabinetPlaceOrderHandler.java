package com.cainiao.tp.nm.plan.purchase.application.component;

import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.PlaceOrderResultDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PlaceOrderParam;

/**
 * 柜子下单处理器扩展点
 * <p>
 * 按客户类型（{@link com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseCustomerTypeEnum}）路由到不同实现，
 * 由 {@link com.cainiao.tp.nm.plan.purchase.application.component.factory.CabinetPlaceOrderHandlerFactory} 统一分发。
 * 兜底实现使用 {@code customerType()} 返回 {@code "default"} 的 Handler。
 * </p> */
public interface CabinetPlaceOrderHandler {

    /**
     * 客户类型路由键，对应
     * {@link com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseCustomerTypeEnum}
     * 的 code（如 10 表示网点）。
     */
    Integer customerType();

    /**
     * 执行下单
     *
     * @param param     下单入参
     * @param operation 操作上下文
     * @return 下单结果
     */
    PlaceOrderResultDTO placeOrder(PlaceOrderParam param, AbstractOperation operation);


}
