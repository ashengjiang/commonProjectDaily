package com.cainiao.tp.nm.plan.purchase.application.service.impl;

import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.ProductInfoResultDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.AttributeOptionDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.ProductInfoDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.ProductInfoParam;
import com.cainiao.tp.nm.plan.api.purchase.common.constants.ProductAttributeEnum;
import com.cainiao.tp.nm.plan.api.purchase.common.constants.ProductStatusEnum;
import com.cainiao.tp.nm.plan.infra.port.common.exception.PurchaseServiceException;
import com.cainiao.tp.nm.plan.purchase.application.service.ProductionApplicationService;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseProduct;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseRule;
import com.cainiao.tp.nm.plan.purchase.domain.model.valobj.CustomerConfig;
import com.cainiao.tp.nm.plan.purchase.domain.repository.PurchaseProductRepository;
import com.cainiao.tp.nm.plan.purchase.domain.repository.PurchaseRuleRepository;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * 商品信息应用服务实现 */
@Slf4j
@Service
public class ProductionApplicationServiceImpl implements ProductionApplicationService {

    @Resource
    private PurchaseRuleRepository purchaseRuleRepository;

    @Resource
    private PurchaseProductRepository purchaseProductRepository;

    @Override
    public ProductInfoResultDTO getProductInfo(ProductInfoParam param, AbstractOperation operation) {
        // 参数校验
        validateParam(param);

        ProductInfoResultDTO result = new ProductInfoResultDTO();

        // 1. 根据类目 ID 获取所有规则
        List<PurchaseRule> rules = purchaseRuleRepository.getRulesByCategoryId(param.getCategoryId());
        if (CollectionUtils.isEmpty(rules)) {
            result.setProductInfoList(new ArrayList<>());
            return result;
        }

        // 2. 根据用户类型和用户 ID 筛选规则（黑白名单过滤 + 时间校验）
        String customerId = param.getCustomerId();
        Integer customerType = param.getCustomerType();
        LocalDateTime now = LocalDateTime.now();

        List<PurchaseRule> filteredRules = rules.stream()
                .filter(rule -> isRuleEffective(rule, now))
                .filter(rule -> isCustomerAllowed(rule, customerId, customerType))
                .collect(Collectors.toList());

        if (CollectionUtils.isEmpty(filteredRules)) {
            result.setProductInfoList(new ArrayList<>());
            return result;
        }

        // 3. 批量获取商品信息（从数据库）
        List<Long> productIds = filteredRules.stream()
                .map(PurchaseRule::getProductId)
                .filter(Objects::nonNull)
                .distinct()
                .collect(Collectors.toList());
        List<PurchaseProduct> collect = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(productIds)) {
            List<PurchaseProduct> products = purchaseProductRepository.getProductsByIds(productIds);
            // 只保留上架的商品
            collect.addAll(products.stream()
                    .filter(product -> product.getStatus() != null && Objects.equals(product.getStatus(), ProductStatusEnum.ON_SHELF.getCode())).collect(Collectors.toList()));
        }

        // 4. 组装商品信息返回
        List<ProductInfoDTO> productInfoList = collect.stream()
                .map(this::convertRuleToProductInfo)
                .collect(Collectors.toList());

        result.setProductInfoList(productInfoList);
        return result;
    }

    @Override
    public List<PurchaseRule> getProductionRule(ProductInfoParam param) {
        validateParam(param);

        // 1. 根据类目 ID 获取所有规则
        List<PurchaseRule> rules = purchaseRuleRepository.getRulesByCategoryId(param.getCategoryId());
        if (CollectionUtils.isEmpty(rules)) {
            return new ArrayList<>();
        }

        // 2. 按时间有效性 + 客户黑白名单过滤
        LocalDateTime now = LocalDateTime.now();
        return rules.stream()
                .filter(rule -> isRuleEffective(rule, now))
                .filter(rule -> isCustomerAllowed(rule, param.getCustomerId(), param.getCustomerType()))
                .collect(Collectors.toList());
    }

    /**
     * 参数校验
     *
     * @param param 查询参数
     * @throws PurchaseServiceException 参数校验失败
     */
    private void validateParam(ProductInfoParam param) {
        if (param == null) {
            throw PurchaseServiceException.ofIllegalParam("参数不能为空");
        }
        if (param.getCategoryId() == null) {
            throw PurchaseServiceException.ofIllegalParam("类目 ID 不能为空");
        }
        if (param.getCustomerId() == null || param.getCustomerId().trim().isEmpty()) {
            throw PurchaseServiceException.ofIllegalParam("客户 ID 不能为空");
        }
        if (param.getCustomerType() == null) {
            throw PurchaseServiceException.ofIllegalParam("客户类型不能为空");
        }
    }

    /**
     * 判断规则是否在当前时间有效
     * 开始时间为空表示立即生效，结束时间为空表示永久有效
     *
     * @param rule 订购规则
     * @param now  当前时间
     * @return true=规则有效，false=规则无效
     */
    private boolean isRuleEffective(PurchaseRule rule, LocalDateTime now) {
        LocalDateTime startTime = rule.getStartTime();
        LocalDateTime endTime = rule.getEndTime();

        // 检查开始时间：如果开始时间为空，表示立即生效；否则当前时间必须 >= 开始时间
        if (startTime != null && now.isBefore(startTime)) {
            return false;
        }

        // 检查结束时间：如果结束时间为空，表示永久有效；否则当前时间必须 <= 结束时间
        if (endTime != null && now.isAfter(endTime)) {
            return false;
        }

        return true;
    }

    /**
     * 判断用户是否被允许访问该规则
     * 优先检查黑名单，再检查白名单
     *
     * @param rule         订购规则
     * @param customerId   客户 ID
     * @param customerType 客户类型
     * @return true=允许访问，false=不允许访问
     */
    private boolean isCustomerAllowed(PurchaseRule rule, String customerId, Integer customerType) {
        CustomerConfig customerConfig = rule.getCustomerConfig();
        if (customerConfig == null) {
            // 没有客户配置，默认允许所有用户访问
            return true;
        }

        // 检查客户类型是否匹配
        if (customerConfig.getCustomerType() != null) {
            Integer ruleCustomerType = customerConfig.getCustomerType();
            if (!ruleCustomerType.equals(customerType)) {
                // 客户类型不匹配，不允许访问
                return false;
            }
        }

        // 检查黑名单（黑名单优先）
        if (CollectionUtils.isNotEmpty(customerConfig.getBlackList())
                && customerConfig.getBlackList().contains(customerId)) {
            return false;
        }

        // 检查白名单（有白名单时，只有白名单内的用户才能访问）
        if (CollectionUtils.isNotEmpty(customerConfig.getWhiteList())) {
            return customerConfig.getWhiteList().contains(customerId);
        }

        // 没有白名单限制，允许访问
        return true;
    }

    /**
     * 将订购规则转换为商品信息 DTO
     * 从数据库中获取商品信息
     *
     * @param product 订购规则
     * @return 商品信息 DTO
     */
    private ProductInfoDTO convertRuleToProductInfo(PurchaseProduct product) {
        ProductInfoDTO productInfo = new ProductInfoDTO();

        productInfo.setItemId(product.getId().intValue());

        // 从数据库中获取商品信息
        productInfo.setItemTitle(product.getTitle());
        productInfo.setPictureUrl(product.getPictureUrl());
        productInfo.setDetailPicUrl(product.getDetailPicUrl());
        if (product.getPrice() != null) {
            productInfo.setPrice(product.getPrice().doubleValue());
        }

        // 设置产品标签
        List<AttributeOptionDTO> attributeOptionDTOList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(product.getAttributeOptionList())) {
            product.getAttributeOptionList().stream()
                    .map(option -> {
                        AttributeOptionDTO dto = new AttributeOptionDTO();
                        dto.setCode(option.getCode());
                        dto.setValue(option.getValue());
                        dto.setOptionCode(option.getOptionCode());
                        dto.setOptionName(option.getOptionName());
                        return dto;
                    })
                    .forEach(attributeOptionDTOList::add);
        }

        // 将 specs 作为格口信息属性写入 attributeOptionList
        if (product.getSpecs() != null && !product.getSpecs().trim().isEmpty()) {
            AttributeOptionDTO gridInfoAttribute = new AttributeOptionDTO();
            gridInfoAttribute.setCode(ProductAttributeEnum.GRID_INFO.getCode());
            gridInfoAttribute.setValue(product.getSpecs());
            attributeOptionDTOList.add(gridInfoAttribute);
        }

        productInfo.setAttributeOptionList(attributeOptionDTOList);
        return productInfo;
    }


}
