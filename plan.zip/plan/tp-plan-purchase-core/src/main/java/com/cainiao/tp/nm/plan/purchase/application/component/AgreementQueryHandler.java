package com.cainiao.tp.nm.plan.purchase.application.component;

import com.cainiao.tp.nm.plan.infra.port.dto.AgreementInfoAndSignDTO;
import com.cainiao.tp.nm.plan.infra.port.dto.param.QueryAgreementParam;
import com.cainiao.tp.nm.plan.infra.port.dto.param.SignAgreementParam;

/**
 * 协议查询/签约处理器
 * <p>
 * 按客户类型（站点 / 网点 等）路由到不同实现，由
 * {@link com.cainiao.tp.nm.plan.purchase.application.component.factory.AgreementQueryHandlerFactory}
 * 在启动期收集所有实现 Bean 并按 {@link #customerType()} 入路由表。
 * </p> */
public interface AgreementQueryHandler {

    /**
     * 当前处理器支持的客户类型（对应 {@code PurchaseCustomerTypeEnum} 的 code）
     *
     * @return 客户类型 code
     */
    Integer customerType();

    /**
     * 查询协议信息及签约状态
     *
     * @param param 查询参数（agreementCode、customerId 等）
     * @return 协议信息及签约状态
     */
    AgreementInfoAndSignDTO query(QueryAgreementParam param);

    /**
     * 协议签约
     *
     * @param param 签约参数（agreementId、userId、customerId 等）
     * @return 协议实例 ID；不支持签约或签约失败时返回 null
     */
    Long sign(SignAgreementParam param);
}
