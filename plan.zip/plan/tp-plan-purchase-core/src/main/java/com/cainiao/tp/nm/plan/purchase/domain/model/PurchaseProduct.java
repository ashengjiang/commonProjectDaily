package com.cainiao.tp.nm.plan.purchase.domain.model;

import com.cainiao.aladdin.domain.BaseBean;
import com.cainiao.tp.nm.plan.purchase.domain.model.valobj.AttributeOption;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * 订购商品值对象
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class PurchaseProduct extends BaseBean {

    /**
     * 主键
     */
    private Long id;

    /**
     * 商品名称
     */
    private String title;

    /**
     * 子标题
     */
    private String subtitle;

    /**
     * 状态 0=下架 1=上架
     */
    private Integer status;

    /**
     * 类目ID {@link com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseCategoryEnum}
     */
    private Integer categoryId;

    /**
     * 产品主图url
     */
    private String pictureUrl;

    /**
     * 详情页url
     */
    private String detailPicUrl;

    /**
     * 价格 --新增加字段
     */
    private BigDecimal price;

    /**
     * 产品规格 --新增加字段
     */
    private String specs;

    /**
     * 产品描述
     */
    private String description;

    /**
     * 扩展字段
     */
    private Map<String, String> feature;

    /**
     * 属性产品标签
     */
    private List<AttributeOption> attributeOptionList;

}
