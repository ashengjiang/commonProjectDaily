package com.cainiao.tp.nm.plan.purchase.adaptor.component.login;

import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.sutee.commons.base.result.CnResult;
import com.cainiao.sutee.commons.restful.enums.RestResultCodeEnum;
import com.cainiao.sutee.commons.restful.result.CnRestResult;
import com.cainiao.tp.nm.plan.infra.port.manager.PermissionLoginManager;
import com.cainiao.tp.nm.plan.infra.port.dto.context.BasePermissionContext;
import com.cainiao.tp.nm.plan.infra.port.dto.context.PermissionContext;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.lang.reflect.Method;
import java.util.Objects;

/**
 * MTOP 登录态校验切面
 * <p>
 * 拦截标注了 {@link MtopLogin} 的方法，调用 {@link PermissionLoginManager#loginPermission()}
 * 完成登录态解析，将结果存入 {@link MtopLoginContext}，方法执行完毕后自动清除。
 * </p>
 */
@Order
@Slf4j
@Aspect
@Component
public class MtopLoginAspect {

    private static final String CN_RESULT = "CnResult";
    private static final String CN_REST_RESULT = "CnRestResult";

    @Resource
    private PermissionLoginManager permissionLoginManager;

    @Pointcut("execution(* com.cainiao.tp.nm.plan.purchase.adaptor.mtop..*.*(..)) "
            + "&& @annotation(com.cainiao.tp.nm.plan.purchase.adaptor.component.login.MtopLogin)")
    public void mtopLoginPointcut() {
    }

    @Around("mtopLoginPointcut()")
    public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();
        Class<?> returnType = signature.getReturnType();

        MtopLogin mtopLogin = method.getAnnotation(MtopLogin.class);
        if (Objects.isNull(mtopLogin)) {
            return joinPoint.proceed();
        }

        try {
            log.info("MtopLoginAspect.method={},returnType={}", method.getName(), returnType.getName());
            PermissionContext<BasePermissionContext> permissionContext = permissionLoginManager.loginPermission();
            MtopLoginContext.setContext(permissionContext);
            log.info("MtopLoginAspect.loginPermission success, loginType={}", permissionContext.getLoginType());
            return joinPoint.proceed();
        } catch (Exception e) {
            log.warn("MtopLoginAspect.error." + method.getName() + ".登录态校验失败", e);
           throw new AladdinBizException("request.error", getErrorMessage(e));
        } finally {
            MtopLoginContext.remove();
        }
    }

    private Object buildFailedResult(String returnTypeName, String errorMessage) {
        if (CN_RESULT.equals(returnTypeName)) {
            return CnResult.fail(CnResult.SYSTEM_ERROR.getCode(), errorMessage);
        } else if (CN_REST_RESULT.equals(returnTypeName)) {
            return CnRestResult.fail(RestResultCodeEnum.SYSTEM_ERROR, errorMessage);
        }
        throw new AladdinBizException("request.error", "请求返回类型不支持");
    }

    private String getErrorMessage(Exception exception) {
        if (exception instanceof AladdinBizException) {
            return exception.getMessage();
        }
        return "登录态校验失败,请稍后重试";
    }
}
