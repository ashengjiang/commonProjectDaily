package com.cainiao.tp.nm.plan.purchase.application.component.factory;

import com.cainiao.tp.nm.plan.infra.port.common.exception.PurchaseServiceException;
import com.cainiao.tp.nm.plan.purchase.application.component.calculator.PurchasePriceCalculator;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * 订购价格计算器工厂
 * <p>启动期收集所有 {@link PurchasePriceCalculator} bean，按 {@code supportedPaymentMode()} 入路由表。</p>
 * <p>路由策略：精确匹配 paymentMode；未命中或 paymentMode 为空时<b>抛业务异常</b>——
 * 价格计算关系到资金，错路由会引发资损，因此必须显式失败、不做兜底。</p> */
@Slf4j
@Component
public class PurchasePriceCalculatorFactory implements ApplicationContextAware, InitializingBean {

    private ApplicationContext applicationContext;

    private final Map<Integer, PurchasePriceCalculator> calculatorMap = Maps.newHashMap();

    @Override
    public void afterPropertiesSet() throws Exception {
        try {
            Map<String, PurchasePriceCalculator> beanMap = applicationContext.getBeansOfType(PurchasePriceCalculator.class);
            beanMap.values().forEach(calculator -> {
                if (calculator.supportedPaymentMode() == null) {
                    log.warn("purchasePriceCalculator supportedPaymentMode 为空，已忽略，class={}",
                            calculator.getClass().getName());
                    return;
                }
                calculatorMap.put(calculator.supportedPaymentMode(), calculator);
            });
        } catch (Exception e) {
            log.error("init purchasePriceCalculatorFactory failed", e);
            throw e;
        }
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    /**
     * 根据支付方式获取价格计算器；未命中时抛业务异常。
     *
     * @param paymentMode 支付方式（对应 {@link com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchasePaymentModeEnum} 的 code）
     * @return 计算器实例
     * @throws PurchaseServiceException paymentMode 为空或无匹配 calculator 时抛出
     */
    public PurchasePriceCalculator getCalculator(Integer paymentMode) {
        if (paymentMode == null) {
            throw PurchaseServiceException.ofIllegalParam("paymentMode 不能为空");
        }
        PurchasePriceCalculator calculator = calculatorMap.get(paymentMode);
        if (calculator == null) {
            throw PurchaseServiceException.ofIllegalParam("不支持的支付方式: " + paymentMode);
        }
        return calculator;
    }
}
