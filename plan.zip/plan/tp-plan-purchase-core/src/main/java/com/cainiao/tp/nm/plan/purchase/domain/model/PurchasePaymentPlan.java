package com.cainiao.tp.nm.plan.purchase.domain.model;

import lombok.Data;

import java.io.Serializable;

@Data
public class PurchasePaymentPlan implements Serializable {

    private Long id;

    private String payCode;

    private String payName;

    private Integer paymentMode;

    private String paymentConfig;

}
