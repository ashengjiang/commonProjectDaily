package com.cainiao.tp.nm.plan.purchase.application.component.impl;

import com.alibaba.fastjson.JSON;
import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.ProductInfoResultDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.AgreementInfoDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.PlaceOrderResultDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.ProductInfoDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PlaceOrderParam;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.ProductInfoParam;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PurchaseOrderCreateParam;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PurchaseOrderProductSnapshotCreateParam;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PurchaseProductParam;
import com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseCategoryEnum;
import com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseFulfillmentPlatformEnum;
import com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseOrderStatusEnum;
import com.cainiao.tp.nm.plan.api.purchase.common.constants.SnapshotFeatureKeyEnum;
import com.cainiao.tp.nm.plan.infra.port.common.exception.PurchaseServiceException;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.DuoNiuSkuDetailDTO;
import com.cainiao.tp.nm.plan.infra.port.purchase.DuoNiuQueryManager;
import com.cainiao.tp.nm.plan.purchase.application.component.CabinetPlaceOrderContext;
import com.cainiao.tp.nm.plan.purchase.common.util.PurchaseThreadPoolUtil;
import com.cainiao.tp.nm.plan.purchase.application.component.CabinetPlaceOrderHandler;
import com.cainiao.tp.nm.plan.purchase.application.component.calculator.PriceResult;
import com.cainiao.tp.nm.plan.purchase.application.component.calculator.PurchasePriceCalculator;
import com.cainiao.tp.nm.plan.purchase.application.component.factory.PurchasePaymentUrlFetcherFactory;
import com.cainiao.tp.nm.plan.purchase.application.component.factory.PurchasePriceCalculatorFactory;
import com.cainiao.tp.nm.plan.purchase.application.component.fetcher.PaymentUrlFetchResult;
import com.cainiao.tp.nm.plan.purchase.application.component.fetcher.PurchasePaymentUrlFetcher;
import com.cainiao.tp.nm.plan.purchase.application.service.ProductionApplicationService;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseOrder;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseProductSku;
import com.cainiao.tp.nm.plan.purchase.domain.model.valobj.PurchaseOrderProductSnapshot;
import com.cainiao.tp.nm.plan.purchase.domain.repository.PurchaseProductSkuRepository;
import com.cainiao.tp.nm.plan.purchase.domain.service.PurchaseOrderDomainService;
import com.cainiao.tp.nm.plan.purchase.domain.service.PurchaseRuleMatcher;
import com.cainiao.tp.nm.plan.purchase.domain.service.param.PurchaseOrderStatusUpdateParam;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

/**
 * 柜子下单处理器抽象基类（模板方法模式）
 * <p>
 * 固化下单主流程骨架：
 * 入参校验 → 商品规则校验 → 创建订单 → {@link #checkPreConditions(CabinetPlaceOrderContext)}（子类实现） →
 * {@link #isAllPreConditionsPassed(PlaceOrderResultDTO)}（子类实现） → 设置订单状态 → 拉取付款链接
 * </p>
 *
 * <p>
 * 站点与网点的差异点：
 * <ul>
 *   <li><b>站点</b>：无任何前置门槛，{@code checkPreConditions} 返回空 result，{@code isAllPreConditionsPassed} 恒为 true</li>
 *   <li><b>网点</b>：需 4 项并行前置检查（实名认证、资金账户绑定、购买协议签署、支付宝代扣协议签署），全部通过才创建订单</li>
 * </ul>
 * </p> */
@Slf4j
public abstract class AbstractCabinetPlaceOrderHandler implements CabinetPlaceOrderHandler {

    @Resource
    private ProductionApplicationService productionApplicationService;

    @Resource
    private PurchaseOrderDomainService purchaseOrderDomainService;

    @Resource
    protected PurchaseRuleMatcher purchaseRuleMatcher;

    @Resource
    protected PurchaseProductSkuRepository purchaseProductSkuRepository;

    @Resource
    protected PurchasePriceCalculatorFactory purchasePriceCalculatorFactory;

    @Resource
    protected PurchasePaymentUrlFetcherFactory purchasePaymentUrlFetcherFactory;

    @Resource
    protected DuoNiuQueryManager duoNiuQueryManager;

    @Resource
    private PurchaseThreadPoolUtil purchaseThreadPoolUtil;

    @Override
    public final PlaceOrderResultDTO placeOrder(PlaceOrderParam param, AbstractOperation operation) {
        // 1. 入参互斥校验
        validatePlaceOrderParam(param);

        // 2. 校验商品在规则范围内 + 规则匹配 + 反查 SKU 信息 → 按支付方式工厂路由计算价格
        //    （仅"首次下单"分支需要）
        List<PurchaseOrderProductSnapshotCreateParam> snapshotList = null;
        if (param.getOrderId() == null) {
            Map<Integer, ProductInfoDTO> productInfoMap = validateAndGetProductInfo(param, operation);
            snapshotList = matchRulesAndBuildSnapshots(param, productInfoMap);
            // 并行校验库存（使用线程池调用万里牛接口）
            validateInventoryParallel(param, snapshotList);
            calculatePriceForSnapshots(snapshotList, param.getPaymentMode());
        }

        // 3. 创建订购订单（仅"首次下单"分支才创建；"重新付款"分支沿用 orderId，构造轻量 order 对象透传）
        PurchaseOrder order;
        if (param.getOrderId() == null) {
            order = createPurchaseOrder(param, snapshotList, operation);
        } else {
            // "重新付款"分支：当前未反查订单详情，先用仅含 id 的轻量对象保持 fetcher 接口一致；
            // 后续 PurchaseOrderDomainService 暴露反查能力后切换为完整订单。
            order =purchaseOrderDomainService.queryOrderById(param.getOrderId());
        }

        // 4. 前置检查（站点/网点差异点）；以 context 形式传递入参与订单实体，便于后续扩展
        CabinetPlaceOrderContext context = CabinetPlaceOrderContext.builder()
                .param(param)
                .order(order)
                .operation(operation)
                .build();
        PlaceOrderResultDTO result = checkPreConditions(context);

        // 5. 根据前置检查结果设置订单状态：协议已签约完成 → 付款中(PAYING)；签约未完成 → 签约中(SIGNING)
        boolean preConditionsPassed = isAllPreConditionsPassed(result);
        PurchaseOrderStatusEnum nextStatus = preConditionsPassed
                ? PurchaseOrderStatusEnum.PAYING
                : PurchaseOrderStatusEnum.SIGNING;
        if (!nextStatus.getCode().equals(order.getStatus())) {
            updateOrderStatus(order.getId(), nextStatus, operation);
        }

        // 6. 前置未全部通过则不拉付款链接，直接返回（订单已落库为签约中状态，待协议完成后客户重新付款）
        if (!preConditionsPassed) {
            log.info("placeOrder 前置条件未全部通过，订单状态置为签约中，customerType={}, customerId={}, orderId={}, "
                            + "identityVerification={}, bindFundingAccount={}, "
                            + "purchaseAgreement.sign={}, alipayWithholdingAgreement.sign={}",
                    param.getCustomerType(), param.getCustomerId(), order.getId(),
                    result.getIdentityVerification(), result.getBindFundingAccount(),
                    safeGetSign(result.getPurchaseAgreement()), safeGetSign(result.getAlipayWithholdingAgreement()));
            result.setOrderId(order.getId());
            return result;
        }

        Long orderId = order.getId();

        // 7. 按履约平台路由付款链接拉取器；当前阶段订单只允许单一平台，多平台直接抛异常（拆单留待后续扩展）
        PaymentUrlFetchResult fetchResult = fetchPaymentUrl(context);
        String itemBuyUrl = fetchResult.getItemBuyUrl();
        result.setOrderId(orderId);
        result.setItemBuyUrl(itemBuyUrl);

        log.info("placeOrder 成功，customerType={}, customerId={}, orderId={}, itemBuyUrl={}",
                param.getCustomerType(), param.getCustomerId(), orderId, itemBuyUrl);
        return result;
    }

    /**
     * 前置条件检查（子类实现）。
     * <p>站点：直接返回 {@code new PlaceOrderResultDTO()}（无前置门槛）。</p>
     * <p>网点：并行执行 4 项检查（实名 / 资金账户 / 购买协议 / 支付宝代扣协议）并填充 result。</p>
     *
     * @param context 下单上下文，包含 {@link PlaceOrderParam} 与已创建的 {@link PurchaseOrder}
     */
    protected abstract PlaceOrderResultDTO checkPreConditions(CabinetPlaceOrderContext context);

    /**
     * 是否所有前置条件都通过（子类实现）。
     * <p>站点：恒为 true。网点：需 4 项均为 true。</p>
     */
    protected abstract boolean isAllPreConditionsPassed(PlaceOrderResultDTO result);

    /**
     * 入参互斥校验：orderId 与 (purchaseSkuInfoList + paymentMode + deliveryType) 二选一；
     * 首次下单时 purchaseSkuInfoList 中每一项必须带 itemId（SKU 由规则反查得出）。
     */
    private void validatePlaceOrderParam(PlaceOrderParam param) {
        if (param == null) {
            throw PurchaseServiceException.ofIllegalParam("下单参数不能为空");
        }
        // orderId 为空时（首次下单），purchaseSkuInfoList、paymentMode、deliveryType 必填
        if (param.getOrderId() == null) {
            if (CollectionUtils.isEmpty(param.getPurchaseSkuInfoList())) {
                throw PurchaseServiceException.ofIllegalParam("orderId 为空时 purchaseSkuInfoList 必填");
            }
            if (param.getPaymentMode() == null) {
                throw PurchaseServiceException.ofIllegalParam("orderId 为空时 paymentMode 必填");
            }
            if (param.getDeliveryType() == null) {
                throw PurchaseServiceException.ofIllegalParam("orderId 为空时 deliveryType 必填");
            }
            for (PurchaseProductParam sku : param.getPurchaseSkuInfoList()) {
                if (sku == null || sku.getItemId() == null || sku.getItemId().isEmpty()) {
                    throw PurchaseServiceException.ofIllegalParam("purchaseSkuInfoList 中存在 itemId 为空的项");
                }
            }
        }
    }

    /**
     * 校验购买商品都在规则范围内且上架，并返回商品信息映射
     */
    private Map<Integer, ProductInfoDTO> validateAndGetProductInfo(PlaceOrderParam param, AbstractOperation operation) {
        ProductInfoParam productInfoParam = new ProductInfoParam();
        productInfoParam.setCustomerId(param.getCustomerId());
        productInfoParam.setCustomerType(param.getCustomerType());
        productInfoParam.setCategoryId(PurchaseCategoryEnum.CABINET.getCode());
        ProductInfoResultDTO productInfoResult = productionApplicationService.getProductInfo(productInfoParam, operation);
        if (productInfoResult == null || CollectionUtils.isEmpty(productInfoResult.getProductInfoList())) {
            throw PurchaseServiceException.ofIllegalParam("当前客户没有可购买的商品");
        }

        Map<Integer, ProductInfoDTO> productInfoMap = productInfoResult.getProductInfoList().stream()
                .collect(Collectors.toMap(ProductInfoDTO::getItemId, p -> p));

        List<String> invalidItemIds = param.getPurchaseSkuInfoList().stream()
                .map(PurchaseProductParam::getItemId)
                .filter(itemId -> !productInfoMap.containsKey(Integer.parseInt(itemId)))
                .collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(invalidItemIds)) {
            throw PurchaseServiceException.ofIllegalParam(
                    "以下商品不在规则范围内或已下架: " + String.join(", ", invalidItemIds));
        }
        return productInfoMap;
    }

    /**
     * 通过 Domain Service 创建订购订单
     */
    private PurchaseOrder createPurchaseOrder(PlaceOrderParam param,
                                              List<PurchaseOrderProductSnapshotCreateParam> snapshotList,
                                              AbstractOperation operation) {
        PurchaseOrderCreateParam createParam = new PurchaseOrderCreateParam();
        createParam.setCustomId(param.getCustomerId());
        createParam.setCustomType(param.getCustomerType());
        createParam.setPaymentMode(param.getPaymentMode());
        createParam.setDeliveryType(param.getDeliveryType());
        createParam.setFulfillmentPlatform(PurchaseFulfillmentPlatformEnum.WANLINIU.getCode());
        if (operation != null) {
            createParam.setOwnerId(operation.getOperatorId());
            createParam.setOwnerName(operation.getOperatorNick());
        }
        createParam.setProductSnapshotList(snapshotList);
        return purchaseOrderDomainService.createOrder(createParam);
    }

    /**
     * 逐商品行做规则匹配 → 反查 SKU 实体 → 构建快照（含规则、支付方案、SKU 维度字段）。
     * <p>本方法负责把"规则"和"SKU"两类信息写入快照；价格三件套（unitPrice / totalAmount / payableAmount）
     * 留给 {@link #calculatePriceForSnapshots(List, Integer)} 按支付方式工厂路由计算。</p>
     */
    private List<PurchaseOrderProductSnapshotCreateParam> matchRulesAndBuildSnapshots(
            PlaceOrderParam param, Map<Integer, ProductInfoDTO> productInfoMap) {
        List<PurchaseOrderProductSnapshotCreateParam> snapshotList = new ArrayList<>();
        for (PurchaseProductParam skuParam : param.getPurchaseSkuInfoList()) {
            // 1. 规则匹配（含校验"商品+客户类型+提货方式+支付方式"组合）；命中规则的 rule.skuId 即购买 SKU
            PurchaseRuleMatcher.MatchResult match = purchaseRuleMatcher.match(
                    skuParam.getItemId(),
                    param.getCustomerId(), param.getCustomerType(),
                    param.getPaymentMode(), param.getDeliveryType());

            Long matchedSkuId = match.getRule().getSkuId();
            if (matchedSkuId == null) {
                throw PurchaseServiceException.ofIllegalParam(
                        "命中规则未配置 skuId，ruleId=" + match.getRule().getId());
            }

            // 2. 反查 SKU 实体（用于填充快照的 SKU 维度字段；价格在下一步算）
            PurchaseProductSku sku = purchaseProductSkuRepository.getById(matchedSkuId);
            if (sku == null) {
                throw PurchaseServiceException.ofIllegalParam(
                        "SKU 不存在，skuId=" + matchedSkuId + ", itemId=" + skuParam.getItemId());
            }
            if (sku.getStatus() != null && sku.getStatus() == 0) {
                throw PurchaseServiceException.ofIllegalParam(
                        "SKU 已停用，skuId=" + matchedSkuId + ", itemId=" + skuParam.getItemId());
            }

            // 3. 构建快照（productTitle 优先取 ProductInfoDTO，确保展示与计费分离）
            ProductInfoDTO productInfo = productInfoMap.get(Integer.parseInt(skuParam.getItemId()));
            PurchaseOrderProductSnapshotCreateParam snapshot = new PurchaseOrderProductSnapshotCreateParam();
            snapshot.setProductId(skuParam.getItemId());
            snapshot.setProductSkuId(String.valueOf(matchedSkuId));
            snapshot.setProductSkuSource(sku.getSkuSource());
            snapshot.setProductTitle(productInfo != null ? productInfo.getItemTitle() : sku.getSkuName());
            snapshot.setRemake(sku.getDescription());
            snapshot.setProductSpecification(sku.getSpecs());
            snapshot.setQuantity(skuParam.getPurchaseNum() != null ? skuParam.getPurchaseNum() : 1);
            snapshot.setPurchaseRule(match.getRule());
            snapshot.setPurchasePaymentPlan(match.getPaymentPlan());
            Map<String, String> featureMap = new HashMap<>();
            if (sku.getFeature() != null) {
                featureMap.putAll(sku.getFeature());
            }
            featureMap.put(SnapshotFeatureKeyEnum.SKU_SNAPSHOT.getKey(), JSON.toJSONString(sku));
            snapshot.setFeature(featureMap);
            snapshotList.add(snapshot);
        }
        return snapshotList;
    }

    /**
     * 校验库存：根据 SKU 的 sourItemId 调用万里牛接口查询库存
     *
     * @param sku      SKU 实体
     * @param quantity 购买数量
     */
    private void validateInventory(PurchaseProductSku sku, Integer quantity) {
        // 从 SKU 的 feature 中获取 sourItemId（万里牛 itemId）
        String sourItemId = null;
        if (sku.getFeature() != null) {
            sourItemId = sku.getFeature().get(SnapshotFeatureKeyEnum.SOUR_ITEM_ID.getKey());
        }
        if (sourItemId == null || sourItemId.isEmpty()) {
            throw PurchaseServiceException.ofIllegalParam(
                    "SKU 未配置 sourItemId，skuId=" + sku.getSkuId());
        }

        // 调用万里牛接口查询库存
        DuoNiuSkuDetailDTO skuDetail = duoNiuQueryManager.querySkuByItemId(Integer.parseInt(sourItemId));
        if (skuDetail == null) {
            throw PurchaseServiceException.ofIllegalParam(
                    "万里牛商品不存在，sourItemId=" + sourItemId);
        }

        // 比较库存数量和购买数量
        String quantityStr = skuDetail.getQuantity();
        if (quantityStr == null || quantityStr.isEmpty()) {
            throw PurchaseServiceException.ofIllegalParam(
                    "万里牛商品库存信息为空，sourItemId=" + sourItemId);
        }
        int availableQuantity = Integer.parseInt(quantityStr);
        if (availableQuantity < quantity) {
            throw PurchaseServiceException.ofIllegalParam(
                    "商品库存不足");
        }
    }

    /**
     * 并行校验库存：使用线程池并行调用万里牛接口查询库存
     *
     * @param param       下单参数
     * @param snapshotList 快照列表
     */
    private void validateInventoryParallel(PlaceOrderParam param, List<PurchaseOrderProductSnapshotCreateParam> snapshotList) {
        List<Future<Void>> futures = new ArrayList<>();
        for (PurchaseOrderProductSnapshotCreateParam snapshot : snapshotList) {
            // 从快照的 feature 中获取 SKU 信息
            String skuSnapshotJson = snapshot.getFeature() != null ? snapshot.getFeature().get(SnapshotFeatureKeyEnum.SKU_SNAPSHOT.getKey()) : null;
            if (skuSnapshotJson == null || skuSnapshotJson.isEmpty()) {
                throw PurchaseServiceException.ofIllegalParam(
                        "快照未包含 SKU 信息，productId=" + snapshot.getProductId());
            }
            PurchaseProductSku sku = JSON.parseObject(skuSnapshotJson, PurchaseProductSku.class);
            Integer quantity = snapshot.getQuantity();

            // 提交库存校验任务到线程池
            Future<Void> future = purchaseThreadPoolUtil.submit(() -> {
                validateInventory(sku, quantity);
                return null;
            });
            futures.add(future);
        }

        // 等待所有任务完成，如果有异常则抛出
        for (Future<Void> future : futures) {
            try {
                future.get();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw PurchaseServiceException.ofIllegalParam("库存校验被中断");
            } catch (ExecutionException e) {
                Throwable cause = e.getCause();
                if (cause instanceof PurchaseServiceException) {
                    throw (PurchaseServiceException) cause;
                }
                throw PurchaseServiceException.ofIllegalParam("库存校验失败: " + cause.getMessage());
            }
        }
    }

    /**
     * 按支付方式路由计算器，逐行算价并回填快照的价格三件套（unitPrice / totalAmount / payableAmount）。
     * <p>路由策略：{@link PurchasePriceCalculatorFactory#getCalculator(Integer)}（按 paymentMode 精确匹配；
     * 未命中时抛业务异常）。当前默认实现仅支持全款 (paymentMode=1)，其他模式扩展时新增 {@link PurchasePriceCalculator}
     * 实现并标注 {@code @Component} 即可自动入路由表。</p>
     */
    private void calculatePriceForSnapshots(List<PurchaseOrderProductSnapshotCreateParam> snapshotList,
                                            Integer paymentMode) {
        PurchasePriceCalculator calculator = purchasePriceCalculatorFactory.getCalculator(paymentMode);
        for (PurchaseOrderProductSnapshotCreateParam snapshot : snapshotList) {
            // 反查 SKU 实体作为算价基线（matchRulesAndBuildSnapshots 已保证 SKU 存在）
            Long skuId = Long.valueOf(snapshot.getProductSkuId());
            PurchaseProductSku sku = purchaseProductSkuRepository.getById(skuId);
            PriceResult price = calculator.calculate(sku, snapshot.getQuantity(), snapshot.getPurchasePaymentPlan());
            snapshot.setUnitPrice(price.getUnitPrice());
            snapshot.setTotalAmount(price.getTotalAmount());
            snapshot.setPayableAmount(price.getPayableAmount());
        }
    }

    /**
     * 按履约平台路由付款链接拉取器，返回单个付款链接。
     * <p>路由策略：{@link PurchasePaymentUrlFetcherFactory#getFetcher(String)}（按 platform 精确匹配；
     * 未命中时抛业务异常）。当前默认实现仅支持万里牛 ({@link PurchaseFulfillmentPlatformEnum#WANLINIU})，
     * 其他平台扩展时新增 {@link PurchasePaymentUrlFetcher} 实现并标注 {@code @Component} 即可自动入路由表。</p>
     * <p><b>当前阶段约束</b>：订单只允许包含<b>单一履约平台</b>的商品行（按 {@code productSkuSource} 判定）；
     * 出现多平台时直接抛业务异常 —— 跨履约平台需要先做<b>拆单</b>，留待后续迭代支持。</p>
     * <p><b>无平台严禁兜底</b>：snapshotList 为空、或任一行 productSkuSource 为空时，一律抛配置错误。</p>
     */
    private PaymentUrlFetchResult fetchPaymentUrl(CabinetPlaceOrderContext context) {
        List<PurchaseOrderProductSnapshot> snapshotList = context.getOrder().getProductSnapshotList();
        if (CollectionUtils.isEmpty(snapshotList)) {
            throw PurchaseServiceException.ofIllegalParam(
                    "订单无商品行快照，无法判定履约平台，orderId="
                            + (context.getOrder() != null ? context.getOrder().getId() : null));
        }
        String platform = resolveSinglePlatform(snapshotList);
        PurchasePaymentUrlFetcher fetcher = purchasePaymentUrlFetcherFactory.getFetcher(platform);
        return fetcher.fetch(context);
    }

    /**
     * 校验订单行只属于单一履约平台并返回该 platform 值；多平台或空 platform 直接抛业务异常。
     */
    private String resolveSinglePlatform(List<PurchaseOrderProductSnapshot> snapshotList) {
        String platform = null;
        for (PurchaseOrderProductSnapshot snapshot : snapshotList) {
            String current = snapshot.getProductSkuSource();
            if (current == null || current.isEmpty()) {
                throw PurchaseServiceException.ofIllegalParam(
                        "订单行 productSkuSource 为空，无法路由付款链接拉取器，productId=" + snapshot.getProductId());
            }
            if (platform == null) {
                platform = current;
            } else if (!platform.equals(current)) {
                throw PurchaseServiceException.ofIllegalParam(
                        "订单存在多个履约平台 [" + platform + ", " + current + "]，当前阶段不支持跨平台下单，请按平台拆单后重试");
            }
        }
        return platform;
    }

    /**
     * 更新订单状态。
     * <p>operatorId 默认从 {@code AbstractOperation} 取并转换为 {@code Long}；为空时用 {@code 0L} 兜底（系统操作）。</p>
     */
    private void updateOrderStatus(Long orderId, PurchaseOrderStatusEnum status, AbstractOperation operation) {
        PurchaseOrderStatusUpdateParam updateParam = PurchaseOrderStatusUpdateParam.builder()
                .orderId(orderId)
                .status(status.getCode())
                .operateId(operation.getOperatorId())
                .operateName(operation.getOperatorNick())
                .build();
        purchaseOrderDomainService.updateOrderStatus(updateParam);
    }

    /**
     * 安全获取协议签署状态（避免空指针）
     */
    private Boolean safeGetSign(AgreementInfoDTO agreement) {
        return agreement == null ? null : agreement.getSign();
    }
}
