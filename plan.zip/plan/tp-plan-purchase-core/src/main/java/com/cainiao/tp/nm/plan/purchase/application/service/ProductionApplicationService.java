package com.cainiao.tp.nm.plan.purchase.application.service;

import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.ProductInfoResultDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.ProductInfoParam;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseRule;

import java.util.List;

/**
 * 商品信息
 */
public interface ProductionApplicationService {

    /**
     * 查询商品列表
     *
     * @param param     param
     * @param operation 操作人
     * @return return
     */
    ProductInfoResultDTO getProductInfo(ProductInfoParam param, AbstractOperation operation);

    /**
     * 查询出商品规则
     * @param param param
     * @return return
     */
    List<PurchaseRule> getProductionRule(ProductInfoParam param);

}
