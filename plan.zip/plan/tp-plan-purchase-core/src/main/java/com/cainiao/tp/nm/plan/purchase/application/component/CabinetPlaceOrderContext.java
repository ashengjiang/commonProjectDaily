package com.cainiao.tp.nm.plan.purchase.application.component;

import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PlaceOrderParam;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseOrder;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 柜子下单上下文
 * <p>
 * 用于在下单主流程中向子类扩展点（如 {@code checkPreConditions}）传递所需的多维度参数，
 * 避免抽象方法签名因后续扩展而频繁变化。
 * </p>
 *
 * <p>
 * 当前包含字段：
 * <ul>
 *   <li>{@code param}：下单原始入参</li>
 *   <li>{@code order}：已创建/已存在的订购订单实体</li>
 * </ul>
 * 后续如需在前置检查阶段访问商品快照、操作人等，可在此对象按需追加字段。
 * </p> */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CabinetPlaceOrderContext {

    /**
     * 下单原始入参
     */
    private PlaceOrderParam param;

    /**
     * 订购订单实体（已创建或已存在）
     */
    private PurchaseOrder order;

    /**
     * 操作人ID
     */
    private AbstractOperation operation;

}
