package com.cainiao.tp.nm.plan.purchase.adaptor.service;

import com.cainiao.sutee.commons.base.result.CnResult;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.AgreementInfoDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.CabinetOrderDetailDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.PlaceOrderResultDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PlaceOrderParam;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PreCalculateOrderParam;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.vo.CabinetProductInfoResultVO;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.DuoNiuOrderDetailDTO;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.ServiceProductInfoDTO;

import java.util.Map;

/**
 * 柜子订购测试工具 HSF 服务接口（不对外暴露） */
public interface PurchaseBizTestService {

    /**
     * 初始化柜机商品和 SKU 数据（写入数据库）
     *
     * @return 执行结果
     */
    CnResult<String> initCabinetProductData();

    /**
     * 查询商品列表（走真实逻辑）
     *
     * @param customerId   客户 ID
     * @param customerType 客户类型（1=站点, 2=网点）
     * @return 商品列表
     */
    CnResult<CabinetProductInfoResultVO> infoList(String customerId, Integer customerType);

    /**
     * 预计算订单（走真实逻辑）
     *
     * @param param 预计算参数
     * @return 订单明细
     */
    CnResult<CabinetOrderDetailDTO> preCalculateOrder(PreCalculateOrderParam param);

    /**
     * 创建订购订单（走真实逻辑）
     *
     * @param param 下单参数
     * @return 下单结果
     */
    CnResult<PlaceOrderResultDTO> placeOrder(PlaceOrderParam param);

    /**
     * 根据服务产品 code 查询产品信息（走真实逻辑）
     *
     * @param serviceCode 服务产品 code
     * @return 服务产品信息 JSON
     */
    CnResult<ServiceProductInfoDTO> queryServiceProductInfoByCode(String serviceCode);

    /**
     * 删除订单及其关联的商品快照（仅测试使用）
     *
     * @param orderId 订单ID
     * @return 执行结果
     */
    CnResult<String> deleteOrder(Long orderId);

    /**
     * 查询万里牛订单详情（走真实逻辑）
     *
     * @param orderId    万里牛订单 ID
     * @param supplierId 供应商 ID
     * @return 订单详情
     */
    CnResult<DuoNiuOrderDetailDTO> queryDuoNiuOrderDetail(String orderId, String supplierId);

    /**
     * 修改订单状态并追加指定快照的 feature 内容（仅测试使用）
     *
     * @param orderId           订单ID
     * @param status            新状态值
     * @param snapshotId        要更新的快照ID
     * @param additionalFeature 要追加的 feature 内容（会合并到已有 feature Map 中）
     * @return 执行结果
     */
    CnResult<String> updateOrderStatusAndSnapshotFeature(Long orderId, Integer status, Long snapshotId, Map<String, String> additionalFeature);

    /**
     * 给指定商品新增标签属性（仅测试使用）
     * <p>
     * 例如给商品添加型号编码属性：
     * attributeCode = "model_code"（{@link com.cainiao.tp.nm.plan.api.purchase.common.constants.ProductAttributeEnum#MODEL_CODE}）,
     * optionCode = "S00F80"（对应万里牛 snJson 中的 key）
     * </p>
     *
     * @param productId     商品 ID
     * @param attributeCode 属性编码（如 model_code、cabinet_type、grid_info 等，参见 ProductAttributeEnum）
     * @param optionCode    属性选项值（如 S00F80、S00Z29、S00F32）
     * @return 执行结果
     */
    CnResult<String> addProductAttribute(Long productId, String attributeCode, String optionCode);

    /**
     * 触发万里牛状态变更消费逻辑（仅测试使用，绕过 MQ 直接调用）
     *
     * @param orderId     万里牛订单 ID
     * @param orderStatus 万里牛订单状态（2=待发货, 3=已发货, 4=已收货）
     * @param supplierID  供应商 ID
     * @return 执行结果
     */
    CnResult<String> triggerDuoNiuStatusChange(String orderId, String orderStatus, String supplierID);

    /**
     * 查询用户是否已签署代扣协议（仅测试使用）
     *
     * @param userId 用户 ID
     * @return 签署状态
     */
    CnResult<Boolean> checkPaymentSigned(Long userId);

    /**
     * 根据 cpCode 和 orgCode 查询网点信息（仅测试使用）
     *
     * @param cpCode  快递公司编码
     * @param orgCode 组织编码
     * @return 网点信息
     */
    CnResult<com.cainiao.tp.nm.plan.infra.port.dto.PlanExpressDTO> getExpressDTO(String cpCode, String orgCode);

    /**
     * 查询 TPS 协议详情（仅测试使用）
     *
     * @param agreementId 协议 ID
     * @return 协议详情
     */
    CnResult<com.cainiao.tp.nm.plan.infra.port.dto.purchase.TpsAgreementInfoDTO> queryAgreementDetail(Long agreementId);

    /**
     * 根据协议 code 查询 TPS 协议详情（仅测试使用）
     *
     * @param agreementCode 协议编码
     * @return 协议详情
     */
    CnResult<com.cainiao.tp.nm.plan.infra.port.dto.purchase.TpsAgreementInfoDTO> queryAgreementByCode(String agreementCode);

    /**
     * 修改 SKU 的 feature 字段（仅测试使用）
     *
     * @param skuId  SKU ID
     * @param key    feature 的 key
     * @param value  feature 的 value
     * @return 执行结果
     */
    CnResult<String> updateSkuFeature(Long skuId, String key, String value);

    /**
     * 根据 SKU ID 删除 SKU（仅测试使用）
     *
     * @param skuId SKU ID
     * @return 执行结果
     */
    CnResult<String> deleteSku(Long skuId);

    /**
     * 增加接口
     * @param customerId
     * @param customerType
     * @return
     */
    CnResult<AgreementInfoDTO> queryAgreementInfo(String customerId, Integer customerType);
}
