package com.cainiao.tp.nm.plan.purchase.adaptor.component.login;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * MTOP 登录态校验注解
 * <p>
 * 标注在 MTOP 接口方法上，切面会自动调用 {@code PermissionLoginManager#loginPermission()}
 * 完成登录态解析（区分站点/网点），并将结果存入 ThreadLocal，供业务代码通过
 * {@link MtopLoginContext#getContext()} 获取。
 * </p>
 */
@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface MtopLogin {
}
