package com.cainiao.tp.nm.plan.purchase.adaptor.metaq;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.rocketmq.common.message.MessageExt;
import com.cainiao.aladdin.log.AladdinMapLog;
import com.cainiao.aladdin.log.BizType;
import com.cainiao.aladdin.log.utils.AladdinLogUtil;
import com.cainiao.tp.nm.plan.api.purchase.common.constants.SiteAppExtParamKeyEnum;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.DuoNiuOrderDetailDTO;
import com.cainiao.tp.nm.plan.infra.port.purchase.DuoNiuQueryManager;
import com.cainiao.tp.nm.plan.purchase.adaptor.metaq.event.DuoNiuNodeStatusChangeEvent;
import com.cainiao.tp.nm.plan.purchase.application.service.PurchaseOrderStatusApplicationService;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseOrder;
import com.cainiao.tp.nm.plan.purchase.domain.repository.PurchaseOrderRepository;
import com.google.common.base.Charsets;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 万里牛节点状态变更 MQ 消费者
 * <p>
 * 消费 topic: DUO_NIU_NODE_STATUS_CHANGE, tag: duo_niu_node_status_change
 * <br/>
 * 消息示例：{"changeTime":"2026-05-13 21:36:35","orderId":"260513860832421432284247","orderStatus":"1","supplierID":"13854003"}
 * <br/>
 * 业务流程：
 * 1. 解析 MQ 消息体
 * 2. 调用万里牛查询订单详情，获取 siteAppExtParam 中的 planOrderId
 * 3. 根据 planOrderId 查询本地订单
 * 4. 将万里牛订单状态映射为本地订单状态并更新
 * </p> */
@Slf4j
@Component(value = "duoNiuNodeStatusChangeListener")
public class DuoNiuNodeStatusChangeListener extends AbstractMetaQListener<DuoNiuNodeStatusChangeEvent> {


    /** 关注的万里牛订单状态集合（2=待发货, 3=已发货, 4=已收货） */
    private static final java.util.Set<String> INTERESTED_STATUSES = new java.util.HashSet<>(
            java.util.Arrays.asList("1","2", "3", "4"));

    @Resource
    private DuoNiuQueryManager duoNiuQueryManager;

    @Resource
    private PurchaseOrderStatusApplicationService purchaseOrderStatusApplicationService;

    @Resource
    private PurchaseOrderRepository purchaseOrderRepository;

    @Override
    protected DuoNiuNodeStatusChangeEvent convert(MessageExt message) {
        AladdinMapLog mapLog = AladdinLogUtil.newMapLog("duoNiuNodeStatusChangeListener.convert", BizType.DEFAULT);
        try {
            String msgBody = new String(message.getBody(), Charsets.UTF_8);
            return JSON.parseObject(msgBody, DuoNiuNodeStatusChangeEvent.class);
        } catch (Throwable throwable) {
            mapLog.addParam("convert failed", throwable.getMessage());
            AladdinLogUtil.log(log, mapLog, throwable);
            return null;
        }
    }

    @Override
    protected boolean filter(DuoNiuNodeStatusChangeEvent event, MessageExt message) {
        if (StringUtils.isBlank(event.getOrderId()) || StringUtils.isBlank(event.getSupplierID())) {
            log.error("DuoNiuNodeStatusChangeError 消息缺少 orderId 或 supplierID，跳过: {}", JSON.toJSONString(event));
            return false;
        }
        if (!INTERESTED_STATUSES.contains(event.getOrderStatus())) {
            log.info("DuoNiuNodeStatusChange 不关注的订单状态: {}", event.getOrderStatus());
            return false;
        }
        return true;
    }

    /**
     * 测试入口：直接触发状态变更消费逻辑（绕过 MQ）
     *
     * @param orderId     万里牛订单 ID
     * @param orderStatus 万里牛订单状态（2=待发货, 3=已发货, 4=已收货）
     * @param supplierID  供应商 ID
     * @return 消费结果
     */
    public boolean triggerConsume(String orderId, String orderStatus, String supplierID) {
        DuoNiuNodeStatusChangeEvent event = new DuoNiuNodeStatusChangeEvent();
        event.setOrderId(orderId);
        event.setOrderStatus(orderStatus);
        event.setSupplierID(supplierID);
        return doConsume(event, null);
    }

    @Override
    protected boolean doConsume(DuoNiuNodeStatusChangeEvent event, MessageExt message) {
        log.info("DuoNiuNodeStatusChange 开始处理, orderId={}, orderStatus={}, supplierID={}",
                event.getOrderId(), event.getOrderStatus(), event.getSupplierID());
        try {
            // 1. 查询万里牛订单详情
            DuoNiuOrderDetailDTO orderDetail = duoNiuQueryManager.queryOrderDetailById(
                    event.getOrderId(), event.getSupplierID());
            if (orderDetail == null) {
                log.warn("DuoNiuNodeStatusChangeError 查询万里牛订单详情为空, orderId={}", event.getOrderId());
                return false;
            }

            // 2. 从 siteAppExtParam 中解析 planOrderId（优先）
            String siteAppExtParam = orderDetail.getSiteAppExtParam();
            String planOrderIdStr = null;
            if (StringUtils.isNotBlank(siteAppExtParam)) {
                JSONObject extParamJson = JSON.parseObject(siteAppExtParam);
                planOrderIdStr = extParamJson.getString(SiteAppExtParamKeyEnum.PLAN_ORDER_ID.getKey());
            }

            // 3. 如果 siteAppExtParam 中没有，尝试从 extParam 中获取
            if (StringUtils.isBlank(planOrderIdStr)) {
                String extParam = orderDetail.getExtParam();
                if (StringUtils.isNotBlank(extParam)) {
                    JSONObject extParamJson = JSON.parseObject(extParam);
                    planOrderIdStr = extParamJson.getString(SiteAppExtParamKeyEnum.PLAN_ORDER_ID.getKey());
                }
            }

            // 4. 兜底：两次 ext 参数都没拿到 planOrderId，按万里牛 orderId 反查本地订单的 fulfillmentPlatformOrderId
            if (StringUtils.isBlank(planOrderIdStr)) {
                PurchaseOrder localOrder = purchaseOrderRepository.findByFulfillmentPlatformOrderId(event.getOrderId());
                if (localOrder != null && localOrder.getId() != null) {
                    planOrderIdStr = String.valueOf(localOrder.getId());
                    log.info("DuoNiuNodeStatusChange 通过 fulfillmentPlatformOrderId 反查到本地订单, dnOrderId={}, planOrderId={}",
                            event.getOrderId(), planOrderIdStr);
                }
            }

            if (StringUtils.isBlank(planOrderIdStr)) {
                // planOrderId 仍不存在，检查万里牛订单商品是否属于我们的 SKU
                return !checkOrderSkuBelongsToUs(orderDetail, event);
            }

            Long planOrderId = Long.valueOf(planOrderIdStr);

            // 4. 委托给 application service 处理状态变更、SN 码等
            return purchaseOrderStatusApplicationService.processStatusChange(
                    planOrderId, event.getOrderId(), event.getOrderStatus(), orderDetail, event.getChangeTime());
        } catch (Exception e) {
            log.error("DuoNiuNodeStatusChangeError 处理异常, orderId={}, orderStatus={}, supplierID={}，errorMsg={}",
                    event.getOrderId(), event.getOrderStatus(), event.getSupplierID(),e.getMessage(), e);
            return false;
        }
    }

    /**
     * 当 siteAppExtParam 中缺少 planOrderId 时，遍历万里牛订单商品列表，
     * 检查其 skuId 是否在我们的 SKU 表中存在。
     *
     * @return true=SKU 属于我们（需要重试），false=不属于我们的 SKU（可以跳过）
     */
    private boolean checkOrderSkuBelongsToUs(DuoNiuOrderDetailDTO orderDetail, DuoNiuNodeStatusChangeEvent event) {
        List<DuoNiuOrderDetailDTO.OrderItemDTO> orders = orderDetail.getOrders();
        if (CollectionUtils.isEmpty(orders)) {
            log.info("DuoNiuNodeStatusChange siteAppExtParam 中缺少 planOrderId 且 orders 为空，跳过, dnOrderId={}",
                    event.getOrderId());
            return false;
        }

        List<String> skuIds = orders.stream()
                .map(DuoNiuOrderDetailDTO.OrderItemDTO::getSkuId)
                .filter(StringUtils::isNotBlank)
                .collect(Collectors.toList());

        List<String> matchedSkuIds = purchaseOrderStatusApplicationService.checkSkuBelongsToUs(skuIds);

        if (CollectionUtils.isNotEmpty(matchedSkuIds)) {
            log.error("DuoNiuNodeStatusChangeError siteAppExtParam 中缺少 planOrderId，但订单商品 skuId 匹配到本地 SKU 表，"
                            + "疑似我方订单未正确传递 planOrderId, dnOrderId={}, siteAppExtParam={}, matchedSkuIds={}",
                    event.getOrderId(), orderDetail.getSiteAppExtParam(), matchedSkuIds);
            return true;
        }

        log.info("DuoNiuNodeStatusChange siteAppExtParam 中缺少 planOrderId，且订单商品不属于我方 SKU，跳过, dnOrderId={}",
                event.getOrderId());
        return false;
    }
}
