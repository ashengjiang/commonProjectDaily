package com.cainiao.tp.nm.plan.purchase.application.component.calculator;

import com.cainiao.tp.nm.plan.api.purchase.application.dto.PurchasePaymentPlanDTO;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseProductSku;

/**
 * 订购价格计算策略（按支付方式路由）。
 * <p>每个实现类声明自己负责的 {@code paymentMode}，由
 * {@link com.cainiao.tp.nm.plan.purchase.application.component.factory.PurchasePriceCalculatorFactory}
 * 在启动期收集入路由表；下单流程根据入参 paymentMode 选取对应策略计算价格三件套。</p> */
public interface PurchasePriceCalculator {

    /**
     * 当前策略支持的支付方式
     * （对应 {@link com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchasePaymentModeEnum} 的 code）
     */
    Integer supportedPaymentMode();

    /**
     * 按当前策略计算价格三件套。
     *
     * @param sku         规则反查得到的 SKU 实体（提供 paySalePrice 等基线价）
     * @param quantity    购买数量
     * @param paymentPlan 命中的支付方案（可能携带 paymentConfig JSON：折扣/分期等）
     * @return 价格三件套
     */
    PriceResult calculate(PurchaseProductSku sku, Integer quantity, PurchasePaymentPlanDTO paymentPlan);
}
