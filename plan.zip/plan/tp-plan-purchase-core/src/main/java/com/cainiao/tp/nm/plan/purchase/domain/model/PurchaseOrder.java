package com.cainiao.tp.nm.plan.purchase.domain.model;

import com.cainiao.aladdin.domain.BaseBean;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PurchaseOrderCreateParam;
import com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseOrderStatusEnum;
import com.cainiao.tp.nm.plan.purchase.domain.model.valobj.PurchaseOrderProductSnapshot;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 订购订单实体 */
@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PurchaseOrder extends BaseBean {

    /**
     * 主键
     */
    private Long id;

    /**
     * 客户ID
     */
    private String customId;

    /**
     * 客户类型 {@link com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseCustomerTypeEnum}
     */
    private Integer customType;

    /**
     * 状态 {@link com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseOrderStatusEnum}
     */
    private Integer status;

    /**
     * 支付模式 {@link com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchasePaymentModeEnum}
     */
    private Integer paymentMode;

    /**
     * 发货类型 {@link com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseDeliveryTypeEnum}
     */
    private Integer deliveryType;

    /**
     * 总金额（不包含运费）
     */
    private BigDecimal totalAmount;

    /**
     * 应付总金额（不包含运费）
     */
    private BigDecimal payableAmount;

    /**
     * 实际支付总金额（不包含运费）
     */
    private BigDecimal actualPaymentAmount;

    /**
     * 运费
     */
    private BigDecimal shippingFee;

    /**
     * 履约平台
     */
    private String fulfillmentPlatform;

    /**
     * 履约平台订单ID
     */
    private String fulfillmentPlatformOrderId;

    /**
     * 支付时间
     */
    private LocalDateTime paymentTime;

    /**
     * 发货时间
     */
    private LocalDateTime shippingTime;

    /**
     * 签收时间
     */
    private LocalDateTime signTime;

    /**
     * 下单人ID
     */
    private String ownerId;

    /**
     * 下单人名称
     */
    private String ownerName;

    /**
     * 扩展字段
     */
    private Map<String, String> feature;

    /**
     * 创建时间
     */
    private LocalDateTime gmtCreate;

    /**
     * 修改时间
     */
    private LocalDateTime gmtModified;

    /**
     * 商品快照,值对象
     */
    private List<PurchaseOrderProductSnapshot> productSnapshotList;


    /**
     * 创建一个订购订单（价格由快照计算）
     *
     * @param param 创建参数
     * @return 订购订单实体
     */
    public static PurchaseOrder create(PurchaseOrderCreateParam param) {
        // 创建商品快照列表
        List<PurchaseOrderProductSnapshot> snapshotList = param.getProductSnapshotList().stream()
                .map(PurchaseOrderProductSnapshot::create)
                .collect(Collectors.toList());

        // 计算总金额（从快照累加）
        BigDecimal totalAmount = calculateTotalAmount(snapshotList);

        // 计算应付金额（从快照累加）
        BigDecimal payableAmount = calculatePayableAmount(snapshotList);

        PurchaseOrderBuilder builder = PurchaseOrder.builder()
                .customId(param.getCustomId())
                .customType(param.getCustomType())
                .status(PurchaseOrderStatusEnum.CREATE.getCode())
                .paymentMode(param.getPaymentMode())
                .deliveryType(param.getDeliveryType())
                .totalAmount(totalAmount)
                .payableAmount(payableAmount)
                .fulfillmentPlatform(param.getFulfillmentPlatform())
                .ownerId(param.getOwnerId())
                .ownerName(param.getOwnerName())
                .feature(param.getFeature() == null ? new HashMap<>() : param.getFeature())
                .productSnapshotList(snapshotList);
        return builder.build();
    }

    /**
     * 根据商品快照计算总金额
     *
     * @param snapshotList 商品快照列表
     * @return 总金额
     */
    private static BigDecimal calculateTotalAmount(List<PurchaseOrderProductSnapshot> snapshotList) {
        if (null == snapshotList || snapshotList.isEmpty()) {
            return BigDecimal.ZERO;
        }
        return snapshotList.stream()
                .map(PurchaseOrderProductSnapshot::getTotalAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    /**
     * 根据商品快照计算应付金额
     *
     * @param snapshotList 商品快照列表
     * @return 应付金额
     */
    private static BigDecimal calculatePayableAmount(List<PurchaseOrderProductSnapshot> snapshotList) {
        if (null == snapshotList || snapshotList.isEmpty()) {
            return BigDecimal.ZERO;
        }
        return snapshotList.stream()
                .map(PurchaseOrderProductSnapshot::getPayableAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    /**
     * 更新订单状态
     *
     * @param status 新状态
     */
    public void updateStatus(Integer status) {
        this.status = status;
        this.gmtModified = LocalDateTime.now();
    }

    /**
     * 更新订单支付信息
     *
     * @param actualPaymentAmount 实际支付金额
     * @param paymentTime         支付时间
     */
    public void updatePayment(BigDecimal actualPaymentAmount, LocalDateTime paymentTime) {
        this.actualPaymentAmount = actualPaymentAmount;
        this.paymentTime = paymentTime;
        this.gmtModified = LocalDateTime.now();
    }

    /**
     * 更新订单发货信息
     *
     * @param shippingTime 发货时间
     */
    public void updateShipping(LocalDateTime shippingTime) {
        this.shippingTime = shippingTime;
        this.gmtModified = LocalDateTime.now();
    }

    /**
     * 更新订单签收信息
     *
     * @param signTime 签收时间
     */
    public void updateSign(LocalDateTime signTime) {
        this.signTime = signTime;
        this.gmtModified = LocalDateTime.now();
    }

}
