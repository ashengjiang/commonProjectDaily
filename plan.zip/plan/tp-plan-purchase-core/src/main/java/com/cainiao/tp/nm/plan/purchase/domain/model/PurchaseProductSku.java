package com.cainiao.tp.nm.plan.purchase.domain.model;

import com.cainiao.aladdin.domain.BaseBean;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.util.Map;

/**
 * 产品sku值对象
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class PurchaseProductSku extends BaseBean {

    /**
     * 主键
     */
    private Long id;

    /**
     * 产品ID
     */
    private Long productId;

    /**
     * 名称
     */
    private String skuName;

    /**
     * code
     */
    private String skuCode;

    /**
     * id
     */
    private String skuId;

    /**
     * 来源
     */
    private String skuSource;

    /**
     * 状态 0=停用 1=使用
     */
    private Integer status;

    /**
     * 展示价格
     */
    private BigDecimal showSalePrice;

    /**
     * 付款价格
     */
    private BigDecimal paySalePrice;

    /**
     * 产品规格
     */
    private String specs;

    /**
     * 图片url
     */
    private String pictureUrl;

    /**
     * 产品详情页面
     */
    private String detailPicUrl;

    /**
     * sku描述
     */
    private String description;

    /**
     * 扩展字段
     */
    private Map<String, String> feature;

}
