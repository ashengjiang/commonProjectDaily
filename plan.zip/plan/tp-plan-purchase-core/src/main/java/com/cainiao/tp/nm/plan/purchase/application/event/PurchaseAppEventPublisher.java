package com.cainiao.tp.nm.plan.purchase.application.event;

import com.cainiao.tp.nm.plan.purchase.adaptor.metaq.event.PurchaseCustomerSnEvent;

/**
 * 订购模块 MQ 事件发布接口 */
public interface PurchaseAppEventPublisher {

    /**
     * 发送客户 SN 码关联消息
     * topic: purchase_customer_sn, tag: relation
     *
     * @param event SN 码关联事件
     */
    void publishCustomerSnRelation(PurchaseCustomerSnEvent event);
}
