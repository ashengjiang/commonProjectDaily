package com.cainiao.tp.nm.plan.purchase.application.component.factory;

import com.cainiao.tp.nm.plan.infra.port.common.exception.PurchaseServiceException;
import com.cainiao.tp.nm.plan.purchase.application.component.fetcher.PurchasePaymentUrlFetcher;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * 订购付款链接拉取器工厂
 * <p>启动期收集所有 {@link PurchasePaymentUrlFetcher} bean，按 {@code supportedPlatform()} 入路由表。</p>
 * <p>路由策略：精确匹配履约平台；未命中或 platform 为空时<b>抛业务异常</b>——
 * 错路由会拉到错误付款页，必须显式失败、不做兜底。</p> */
@Slf4j
@Component
public class PurchasePaymentUrlFetcherFactory implements ApplicationContextAware, InitializingBean {

    private ApplicationContext applicationContext;

    private final Map<String, PurchasePaymentUrlFetcher> fetcherMap = Maps.newHashMap();

    @Override
    public void afterPropertiesSet() throws Exception {
        try {
            Map<String, PurchasePaymentUrlFetcher> beanMap = applicationContext.getBeansOfType(PurchasePaymentUrlFetcher.class);
            beanMap.values().forEach(fetcher -> {
                if (StringUtils.isBlank(fetcher.supportedPlatform())) {
                    log.warn("purchasePaymentUrlFetcher supportedPlatform 为空，已忽略，class={}",
                            fetcher.getClass().getName());
                    return;
                }
                fetcherMap.put(fetcher.supportedPlatform(), fetcher);
            });
        } catch (Exception e) {
            log.error("init purchasePaymentUrlFetcherFactory failed", e);
            throw e;
        }
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    /**
     * 根据履约平台获取付款链接拉取器；未命中时抛业务异常。
     *
     * @param platform 履约平台（对应 {@link com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseFulfillmentPlatformEnum} 的 code）
     * @return 拉取器实例
     * @throws PurchaseServiceException platform 为空或无匹配 fetcher 时抛出
     */
    public PurchasePaymentUrlFetcher getFetcher(String platform) {
        if (StringUtils.isBlank(platform)) {
            throw PurchaseServiceException.ofIllegalParam("履约平台不能为空");
        }
        PurchasePaymentUrlFetcher fetcher = fetcherMap.get(platform);
        if (fetcher == null) {
            throw PurchaseServiceException.ofIllegalParam("不支持的履约平台: " + platform);
        }
        return fetcher;
    }
}
