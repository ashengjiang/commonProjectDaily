package com.cainiao.tp.nm.plan.purchase.domain.repository;

import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseProductSku;

import java.util.List;

/**
 * 产品 SKU 仓储接口 */
public interface PurchaseProductSkuRepository {

    /**
     * 根据 SKU 主键 id 获取 SKU
     *
     * @param id SKU 表主键
     * @return SKU 信息（不存在时返回 null）
     */
    PurchaseProductSku getById(Long id);

    /**
     * 根据业务 skuId（字符串）获取 SKU
     *
     * @param skuId 业务 skuId（PurchaseProductSku.skuId）
     * @return SKU 信息（不存在时返回 null）
     */
    PurchaseProductSku getBySkuId(String skuId);

    /**
     * 根据 productId 列表批量查询其下所有 SKU
     *
     * @param productIds 商品 ID 列表
     * @return SKU 列表
     */
    List<PurchaseProductSku> listByProductIds(List<Long> productIds);

    /**
     * 保存 SKU（插入后回填 ID）
     *
     * @param productSku SKU 领域模型
     * @return 保存后的 SKU（含 ID）
     */
    PurchaseProductSku saveProductSku(PurchaseProductSku productSku);

    /**
     * 根据 productId 删除该商品下所有 SKU
     *
     * @param productId 商品 ID
     */
    void deleteSkusByProductId(Long productId);

    /**
     * 更新 SKU
     *
     * @param productSku SKU 领域模型
     * @return 更新后的 SKU
     */
    PurchaseProductSku updateSku(PurchaseProductSku productSku);

    /**
     * 根据 SKU ID 删除 SKU
     *
     * @param skuId SKU ID
     */
    void deleteSkuById(Long skuId);
}
