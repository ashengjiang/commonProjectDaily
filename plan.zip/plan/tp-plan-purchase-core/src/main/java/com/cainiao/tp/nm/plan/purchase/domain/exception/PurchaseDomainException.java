package com.cainiao.tp.nm.plan.purchase.domain.exception;

import com.cainiao.sutee.commons.base.MsgCode;
import com.cainiao.sutee.commons.base.MsgCodeException;

/**
 * 订购领域异常基类
 * <p>
 * 仅供 {@code purchase-core/domain} 层使用，避免领域层反向依赖 {@code infra-port}（违反 DDD 分层）。
 * 错误码与消息均自洽，继承自 {@link MsgCodeException}，可被框架层（Spring/Aladdin 等）统一处理。
 * 应用层无需额外翻译；如确有跨层语义转换需求，可在应用层 catch 后另抛 {@code PurchaseServiceException}。
 * </p>
 *
 * <h3>错误码约定</h3>
 * <ul>
 *   <li>{@code PURCHASE_DOMAIN_ILLEGAL_PARAM}：参数非法（如必填校验、枚举越界等）</li>
 *   <li>{@code PURCHASE_DOMAIN_BIZ_ERROR}：业务规则不通过（如状态机回退、规则未命中等）</li>
 * </ul> */
public class PurchaseDomainException extends MsgCodeException {

    /**
     * 参数非法错误码
     */
    public static final String CODE_ILLEGAL_PARAM = "PURCHASE_DOMAIN_ILLEGAL_PARAM";

    /**
     * 业务规则错误码
     */
    public static final String CODE_BIZ_ERROR = "PURCHASE_DOMAIN_BIZ_ERROR";

    public PurchaseDomainException(String code, String message) {
        super(code, message);
    }

    public PurchaseDomainException(String code, String message, Throwable cause) {
        super(code, message, cause);
    }

    public PurchaseDomainException(MsgCode mc) {
        super(mc);
    }

    public PurchaseDomainException(MsgCode mc, Throwable cause) {
        super(mc, cause);
    }

    /**
     * 参数非法快捷构造
     *
     * @param message 错误描述
     * @return 领域异常实例
     */
    public static PurchaseDomainException ofIllegalParam(String message) {
        return new PurchaseDomainException(CODE_ILLEGAL_PARAM, message);
    }

    /**
     * 业务规则错误快捷构造
     *
     * @param message 错误描述
     * @return 领域异常实例
     */
    public static PurchaseDomainException ofBizError(String message) {
        return new PurchaseDomainException(CODE_BIZ_ERROR, message);
    }
}
