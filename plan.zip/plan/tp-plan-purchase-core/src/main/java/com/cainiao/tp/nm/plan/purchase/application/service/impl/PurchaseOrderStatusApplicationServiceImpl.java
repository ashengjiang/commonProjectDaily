package com.cainiao.tp.nm.plan.purchase.application.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.tp.nm.plan.api.purchase.common.constants.ProductAttributeEnum;
import com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseOrderStatusEnum;
import com.cainiao.tp.nm.plan.api.purchase.common.constants.SnapshotFeatureKeyEnum;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.DuoNiuOrderDetailDTO;
import com.cainiao.tp.nm.plan.purchase.adaptor.metaq.event.PurchaseCustomerSnEvent;
import com.cainiao.tp.nm.plan.purchase.application.event.PurchaseAppEventPublisher;
import com.cainiao.tp.nm.plan.purchase.application.service.PurchaseOrderStatusApplicationService;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseOrder;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseProduct;
import com.cainiao.tp.nm.plan.purchase.domain.model.valobj.AttributeOption;
import com.cainiao.tp.nm.plan.purchase.domain.model.valobj.PurchaseOrderProductSnapshot;
import com.cainiao.tp.nm.plan.purchase.domain.repository.PurchaseOrderRepository;
import com.cainiao.tp.nm.plan.purchase.domain.repository.PurchaseProductRepository;
import com.cainiao.tp.nm.plan.purchase.domain.repository.PurchaseProductSkuRepository;
import com.cainiao.tp.nm.plan.purchase.domain.service.PurchaseOrderDomainService;
import com.cainiao.tp.nm.plan.purchase.domain.service.param.PurchaseOrderStatusUpdateParam;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 订购订单状态变更应用服务实现 */
@Slf4j
@Service
public class PurchaseOrderStatusApplicationServiceImpl implements PurchaseOrderStatusApplicationService {
    private static final String WAITSEND_CREATE = "1";
    private static final String DN_STATUS_WAITSEND = "2";
    private static final String DN_STATUS_SEND = "3";
    private static final String DN_STATUS_RECEIPT = "4";

    private static final Map<String, PurchaseOrderStatusEnum> STATUS_MAPPING = new HashMap<>();

    static {
        STATUS_MAPPING.put(DN_STATUS_WAITSEND, PurchaseOrderStatusEnum.PAID);
        STATUS_MAPPING.put(DN_STATUS_SEND, PurchaseOrderStatusEnum.SHIPPED);
        STATUS_MAPPING.put(DN_STATUS_RECEIPT, PurchaseOrderStatusEnum.RECEIVED);
    }

    @Resource
    private PurchaseOrderRepository purchaseOrderRepository;
    @Resource
    private PurchaseOrderDomainService purchaseOrderDomainService;
    @Resource
    private PurchaseProductRepository purchaseProductRepository;

    @Resource
    private PurchaseProductSkuRepository purchaseProductSkuRepository;

    @Resource
    private PurchaseAppEventPublisher purchaseAppEventPublisher;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean processStatusChange(Long planOrderId, String dnOrderId, String dnStatus,
                                       DuoNiuOrderDetailDTO orderDetail, String changeTime) {
        // 1. 查询本地订单
        PurchaseOrder purchaseOrder = purchaseOrderRepository.findById(planOrderId);
        if (purchaseOrder == null) {
            log.error("PurchaseOrderStatusChangeError 本地订单不存在, planOrderId={}", planOrderId);
            return false;
        }

        // 2. 校验/保存履约订单 ID
        String existingFulfillmentOrderId = purchaseOrder.getFulfillmentPlatformOrderId();
        if (StringUtils.isNotBlank(existingFulfillmentOrderId)) {
            if (!existingFulfillmentOrderId.equals(dnOrderId)) {
                log.error("PurchaseOrderStatusChangeError 履约订单ID不一致, planOrderId={}, 已有={}, 当前={}",
                        planOrderId, existingFulfillmentOrderId, dnOrderId);
                return false;
            }
        } else {
            purchaseOrder.setFulfillmentPlatformOrderId(dnOrderId);
            log.info("PurchaseOrderStatusChange 保存履约订单ID, planOrderId={}, fulfillmentOrderId={}",
                    planOrderId, dnOrderId);
        }

        // 3. 万里牛状态为1（已创建）时，仅关联履约订单 ID，不修改订单状态
        if (WAITSEND_CREATE.equals(dnStatus)) {
            purchaseOrderRepository.update(purchaseOrder);
            log.info("PurchaseOrderStatusChange 万里牛状态为1，仅关联履约订单ID, planOrderId={}, fulfillmentOrderId={}",
                    planOrderId, dnOrderId);
            return true;
        }

        // 4. 映射状态
        PurchaseOrderStatusEnum targetStatus = STATUS_MAPPING.get(dnStatus);
        if (targetStatus == null) {
            log.error("PurchaseOrderStatusChangeError 无法映射的万里牛状态, dnStatus={}", dnStatus);
            return false;
        }

        // 5. 构建更新参数，统一通过 DomainService 处理状态更新（含状态不可逆校验）
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime payTime = parseDateTime(orderDetail.getPayTime());
        LocalDateTime shippingTime = parseDateTime(orderDetail.getShippingTime());
        java.math.BigDecimal actualPaymentAmount = parseAmount(orderDetail.getPayment());

        PurchaseOrderStatusUpdateParam.PurchaseOrderStatusUpdateParamBuilder paramBuilder =
                PurchaseOrderStatusUpdateParam.builder()
                        .orderId(planOrderId)
                        .status(targetStatus.getCode())
                        .operateId("0")
                        .operateName("system").existingFulfillmentOrderId(dnOrderId);

        // 所有状态都带上付款信息（DomainService 内部会判断是否已存在，仅补充缺失的）
        paramBuilder.actualPaymentAmount(actualPaymentAmount);
        paramBuilder.paymentTime(payTime != null ? payTime : now);

        // 发货及以上状态带上发货时间
        if (PurchaseOrderStatusEnum.SHIPPED.equals(targetStatus)
                || PurchaseOrderStatusEnum.RECEIVED.equals(targetStatus)) {
            paramBuilder.shippingTime(shippingTime != null ? shippingTime : now);
        }

        // 签收状态带上签收时间
        if (PurchaseOrderStatusEnum.RECEIVED.equals(targetStatus)) {
            LocalDateTime parsedChangeTime = parseDateTime(changeTime);
            paramBuilder.signTime(parsedChangeTime != null ? parsedChangeTime : now);
        }

        purchaseOrderDomainService.updateOrderStatus(paramBuilder.build());

        // 6. 状态码 >= SHIPPED(30) 时处理 SN 码（已发货、已签收等终态都需要更新 SN 码）
        if (targetStatus.getCode() >= PurchaseOrderStatusEnum.SHIPPED.getCode()) {
            processSnCode(orderDetail, purchaseOrder, planOrderId);
        }

        log.info("PurchaseOrderStatusChange 处理完成, planOrderId={}, 新状态={}({})",
                planOrderId, targetStatus.getDesc(), targetStatus.getCode());
        return true;
    }

    @Override
    public List<String> checkSkuBelongsToUs(List<String> skuIds) {
        if (CollectionUtils.isEmpty(skuIds)) {
            return new ArrayList<>();
        }
        return skuIds.stream()
                .filter(StringUtils::isNotBlank)
                .filter(skuId -> purchaseProductSkuRepository.getBySkuId(skuId) != null)
                .collect(Collectors.toList());
    }

    /**
     * 发货状态时处理 SN 码：解析 snJson，将 SN 码分配到对应的快照 feature 中
     */
    private void processSnCode(DuoNiuOrderDetailDTO orderDetail, PurchaseOrder purchaseOrder, Long planOrderId) {
        String snJson = orderDetail.getSnJson();
        if (StringUtils.isBlank(snJson)) {
            log.error("PurchaseOrderStatusChange 发货状态但 snJson 为空, planOrderId={}, dnOrderId={}",
                    planOrderId, orderDetail.getTradeId());
            throw new AladdinBizException("PurchaseOrderStatusChangeError",
                    "snJson 解析后为空, planOrderId=" + planOrderId + ", snJson=" + snJson);
        }

        Map<String, List<String>> snMap;
        try {
            snMap = JSON.parseObject(snJson, new TypeReference<Map<String, List<String>>>() {});
        } catch (Exception e) {
            log.error("PurchaseOrderStatusChange snJson 解析失败, planOrderId={}, snJson={}",
                    planOrderId, snJson, e);
            return;
        }

        if (snMap == null || snMap.isEmpty()) {
            log.error("PurchaseOrderStatusChangeError snJson 解析后为空, planOrderId={}, snJson={}",
                    planOrderId, snJson);
            throw new AladdinBizException("PurchaseOrderStatusChangeError",
                    "snJson 解析后为空, planOrderId=" + planOrderId + ", snJson=" + snJson);
        }

        List<PurchaseOrderProductSnapshot> snapshotList = purchaseOrder.getProductSnapshotList();
        if (CollectionUtils.isEmpty(snapshotList)) {
            log.error("PurchaseOrderStatusChange 发货状态但订单快照列表为空, planOrderId={}", planOrderId);
            return;
        }

        // 批量收集快照中的 productId，一次性查询商品信息
        List<Long> productIds = snapshotList.stream()
                .map(PurchaseOrderProductSnapshot::getProductId)
                .filter(StringUtils::isNotBlank)
                .distinct()
                .map(Long::valueOf)
                .collect(Collectors.toList());

        Map<Long, PurchaseProduct> productMap = new HashMap<>();
        if (CollectionUtils.isNotEmpty(productIds)) {
            List<PurchaseProduct> products = purchaseProductRepository.getProductsByIds(productIds);
            if (CollectionUtils.isNotEmpty(products)) {
                productMap = products.stream()
                        .collect(Collectors.toMap(PurchaseProduct::getId, p -> p, (a, b) -> a));
            }
        }

        for (PurchaseOrderProductSnapshot snapshot : snapshotList) {
            if (snCodeAlreadyExists(snapshot)) {
                log.info("PurchaseOrderStatusChange 快照已存在 SN 码，跳过, snapshotId={}", snapshot.getId());
                continue;
            }

            String optionCode = resolveOptionCodeFromProduct(snapshot, productMap);
            if (StringUtils.isBlank(optionCode)) {
                log.warn("PurchaseOrderStatusChange 快照无法解析出 optionCode, snapshotId={}, productId={}",
                        snapshot.getId(), snapshot.getProductId());
                continue;
            }

            List<String> snCodes = snMap.get(optionCode);
            if (CollectionUtils.isEmpty(snCodes)) {
                log.warn("PurchaseOrderStatusChange snJson 中未找到 optionCode={} 对应的 SN 码, planOrderId={}",
                        optionCode, planOrderId);
                continue;
            }

            // 将 SN 码写入快照 feature
            updateSnapshotSnCode(snapshot.getId(), snCodes);
            log.info("PurchaseOrderStatusChange SN码已写入快照, planOrderId={}, snapshotId={}, optionCode={}, snCodes={}",
                    planOrderId, snapshot.getId(), optionCode, snCodes);

            // 发送 SN 码关联 MQ 消息
            sendSnRelationMessages(purchaseOrder, snCodes, orderDetail.getShippingTime(), planOrderId);
        }
    }

    private boolean snCodeAlreadyExists(PurchaseOrderProductSnapshot snapshot) {
        String feature = snapshot.getFeature();
        if (StringUtils.isBlank(feature)) {
            return false;
        }
        try {
            Map<String, String> featureMap = JSON.parseObject(feature, new TypeReference<Map<String, String>>() {});
            return featureMap != null && StringUtils.isNotBlank(featureMap.get(SnapshotFeatureKeyEnum.SN_CODE.getKey()));
        } catch (Exception e) {
            return false;
        }
    }

    private void updateSnapshotSnCode(Long snapshotId, List<String> snCodes) {
        Map<String, String> additionalFeature = new HashMap<>();
        additionalFeature.put(SnapshotFeatureKeyEnum.SN_CODE.getKey(), JSON.toJSONString(snCodes));
        purchaseOrderRepository.updateSnapshotFeature(snapshotId, additionalFeature);
    }

    private void sendSnRelationMessages(PurchaseOrder purchaseOrder, List<String> snCodes,
                                        String deliveryTime, Long planOrderId) {
        for (String snCode : snCodes) {
            PurchaseCustomerSnEvent snEvent = PurchaseCustomerSnEvent.builder()
                    .customId(purchaseOrder.getCustomId())
                    .customType(purchaseOrder.getCustomType())
                    .snCode(snCode)
                    .deliveryTime(deliveryTime)
                    .build();
            try {
                purchaseAppEventPublisher.publishCustomerSnRelation(snEvent);
                log.info("PurchaseOrderStatusChange SN关联消息发送成功, planOrderId={}, snCode={}", planOrderId, snCode);
            } catch (Exception e) {
                log.error("PurchaseOrderStatusChange SN关联消息发送失败, planOrderId={}, snCode={}", planOrderId, snCode, e);
            }
        }
    }

    private String resolveOptionCodeFromProduct(PurchaseOrderProductSnapshot snapshot, Map<Long, PurchaseProduct> productMap) {
        String productIdStr = snapshot.getProductId();
        if (StringUtils.isBlank(productIdStr)) {
            return null;
        }

        Long productId = Long.valueOf(productIdStr);
        PurchaseProduct product = productMap.get(productId);
        if (product == null || CollectionUtils.isEmpty(product.getAttributeOptionList())) {
            return null;
        }

        return product.getAttributeOptionList().stream()
                .filter(option -> ProductAttributeEnum.MODEL_CODE.getCode().equals(option.getCode()))
                .map(AttributeOption::getOptionCode)
                .findFirst()
                .orElse(null);
    }

    private LocalDateTime parseDateTime(String dateTimeStr) {
        if (StringUtils.isBlank(dateTimeStr)) {
            return null;
        }
        try {
            long timestamp = Long.parseLong(dateTimeStr);
            return LocalDateTime.ofInstant(
                    java.time.Instant.ofEpochMilli(timestamp),
                    java.time.ZoneId.systemDefault());
        } catch (Exception e) {
            log.warn("PurchaseOrderStatusChange 时间戳解析失败: {}", dateTimeStr, e);
            return null;
        }
    }

    private java.math.BigDecimal parseAmount(String amountStr) {
        if (StringUtils.isBlank(amountStr)) {
            return null;
        }
        try {
            return new java.math.BigDecimal(amountStr);
        } catch (Exception e) {
            log.warn("PurchaseOrderStatusChange 金额解析失败: {}", amountStr, e);
            return null;
        }
    }
}
