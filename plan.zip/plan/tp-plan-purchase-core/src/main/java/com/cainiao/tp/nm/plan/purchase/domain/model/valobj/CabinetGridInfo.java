package com.cainiao.tp.nm.plan.purchase.domain.model.valobj;

import lombok.Data;

/**
 * 柜子格口信息值对象 */
@Data
public class CabinetGridInfo {

    /**
     * 格口类型:大格口、中格口、小格口、微小格口
     */
    private String gridType;

    /**
     * 尺寸
     */
    private String size;

    /**
     * 格口数量
     */
    private Integer num;
}
