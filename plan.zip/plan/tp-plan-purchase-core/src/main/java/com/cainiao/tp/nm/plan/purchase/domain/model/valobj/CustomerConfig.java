package com.cainiao.tp.nm.plan.purchase.domain.model.valobj;

import com.cainiao.aladdin.domain.BaseBean;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * 客户配置值对象
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class CustomerConfig extends BaseBean {

    /**
     * 客户类型 1=站点 2=网点
     */
    private Integer customerType;

    /**
     * 客户白名单ID列表
     */
    private List<String> whiteList;

    /**
     * 客户黑名单ID列表
     */
    private List<String> blackList;

}
