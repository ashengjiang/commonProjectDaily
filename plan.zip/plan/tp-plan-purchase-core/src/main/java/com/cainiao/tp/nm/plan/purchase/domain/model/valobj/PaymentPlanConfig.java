package com.cainiao.tp.nm.plan.purchase.domain.model.valobj;

import com.cainiao.aladdin.domain.BaseBean;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 支付方案配置值对象
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class PaymentPlanConfig extends BaseBean {

    /**
     * 支付方案ID
     */
    private String paymentPlanId;
    /**
     * 支付模式
     */
    private Integer paymentMode;

    /**
     * 支付方案名称
     */
    private String paymentPlanName;

}
