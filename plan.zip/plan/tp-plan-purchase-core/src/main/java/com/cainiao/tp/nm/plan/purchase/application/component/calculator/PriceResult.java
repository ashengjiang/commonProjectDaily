package com.cainiao.tp.nm.plan.purchase.application.component.calculator;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.math.BigDecimal;

/**
 * 价格计算结果（不可变值对象）
 * <p>承载一行商品快照所需的价格三件套：单价、总金额、应付金额。</p> */
@Data
@AllArgsConstructor
public class PriceResult {

    /**
     * 商品单价
     */
    private final BigDecimal unitPrice;

    /**
     * 总金额（unitPrice × quantity，不含折扣/分期）
     */
    private final BigDecimal totalAmount;

    /**
     * 应付总金额（按支付方案计算后的真实付款金额）
     */
    private final BigDecimal payableAmount;
}
