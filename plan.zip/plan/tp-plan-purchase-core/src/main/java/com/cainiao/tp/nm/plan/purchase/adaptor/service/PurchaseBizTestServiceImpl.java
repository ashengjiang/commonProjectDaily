package com.cainiao.tp.nm.plan.purchase.adaptor.service;

import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.fastjson.JSON;
import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.aladdin.operation.SystemBizOperation;
import com.cainiao.sutee.commons.base.result.CnResult;
import com.cainiao.tp.nm.plan.api.purchase.adaptor.dto.CabinetOrderEntityDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.ProductInfoResultDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.*;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PlaceOrderParam;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PreCalculateOrderParam;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.ProductInfoParam;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.vo.CabinetProductInfoResultVO;
import com.cainiao.tp.nm.plan.api.purchase.common.constants.ProductAttributeEnum;
import com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseCategoryEnum;
import com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseCustomerTypeEnum;
import com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseFulfillmentPlatformEnum;
import com.cainiao.tp.nm.plan.infra.port.dto.AgreementInfoAndSignDTO;
import com.cainiao.tp.nm.plan.infra.port.dto.param.QueryAgreementParam;
import com.cainiao.tp.nm.plan.infra.port.manager.TpsStationAgreementManager;
import com.cainiao.tp.nm.plan.purchase.adaptor.metaq.DuoNiuNodeStatusChangeListener;
import com.cainiao.tp.nm.plan.purchase.application.component.AgreementComponent;
import com.cainiao.tp.nm.plan.purchase.application.service.CabinetPlaceOrderApplicationService;
import com.cainiao.tp.nm.plan.purchase.application.service.ProductionApplicationService;
import com.cainiao.tp.nm.plan.purchase.common.util.ProductSpecsParser;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseProduct;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseProductSku;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseRule;
import com.cainiao.tp.nm.plan.purchase.domain.model.valobj.AgreementConfig;
import com.cainiao.tp.nm.plan.purchase.domain.model.valobj.AttributeOption;
import com.cainiao.tp.nm.plan.purchase.domain.model.valobj.CabinetGridInfo;
import com.cainiao.tp.nm.plan.purchase.domain.repository.PurchaseOrderRepository;
import com.cainiao.tp.nm.plan.purchase.domain.repository.PurchaseProductRepository;
import com.cainiao.tp.nm.plan.purchase.domain.repository.PurchaseProductSkuRepository;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.DuoNiuOrderDetailDTO;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.ServiceProductInfoDTO;
import com.cainiao.tp.nm.plan.infra.port.purchase.DuoNiuQueryManager;
import com.cainiao.tp.nm.plan.infra.port.purchase.ServiceProductInfoManager;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 柜子订购测试工具 HSF 服务实现
 * <p>
 * 将 3 款柜机商品及对应 SKU 数据写入 purchase_product 和 purchase_product_sku 表。
 * 仅用于测试环境数据初始化，不对外暴露。
 * </p> */
@Slf4j
@HSFProvider(serviceInterface = PurchaseBizTestService.class)
public class PurchaseBizTestServiceImpl implements PurchaseBizTestService {

    private static final int CATEGORY_CABINET = 100;
    private static final int STATUS_ON = 1;

    @Resource
    private PurchaseProductRepository purchaseProductRepository;

    @Resource
    private PurchaseProductSkuRepository purchaseProductSkuRepository;

    @Resource
    private ProductionApplicationService productionApplicationService;

    @Resource
    private CabinetPlaceOrderApplicationService cabinetPlaceOrderApplicationService;

    @Resource
    private ServiceProductInfoManager serviceProductInfoManager;

    @Resource
    private PurchaseOrderRepository purchaseOrderRepository;

    @Resource
    private DuoNiuQueryManager duoNiuQueryManager;

    @Resource
    private DuoNiuNodeStatusChangeListener duoNiuNodeStatusChangeListener;

    @Resource
    private com.cainiao.tp.nm.plan.infra.port.purchase.PaymentSignManager paymentSignManager;

    @Resource
    private com.cainiao.tp.nm.plan.infra.port.manager.ExpressInfoManager expressInfoManager;

    @Resource
    private TpsStationAgreementManager tpsAgreementQueryManager;
    @Resource
    private AgreementComponent agreementComponent;

    @Override
    public CnResult<String> initCabinetProductData() {
        try {
            // 1. 删除旧的柜子类目商品和 SKU
//            List<PurchaseProduct> existingProducts = purchaseProductRepository.getProductsByCategoryId(CATEGORY_CABINET);
//            for (PurchaseProduct product : existingProducts) {
//                purchaseProductSkuRepository.deleteSkusByProductId(product.getId());
//                purchaseProductRepository.deleteProduct(product.getId());
//            }
//            log.info("initCabinetProductData 删除旧数据完成, 删除商品数={}", existingProducts.size());
//
//            // 2. 写入商品1: 智能柜-主柜(29格口)
//            String mainGridJson = buildGridJson("大格口", "300*160cm", 12, "中格口", "300*100cm", 17);
//            PurchaseProduct mainCabinet = buildProduct(
//                    "智能柜-主柜(29格口)", "主柜", new BigDecimal("0.01"),
//                    "https://gw.alicdn.com/imgextra/i2/O1CN01FVRfAT1KVuWp26t8k_!!6000000001170-0-tps-800-800.jpg",
//                    "https://gw.alicdn.com/imgextra/i3/O1CN01NkvGdA1FI6VbfuBv4_!!6000000000463-0-tps-1646-6698.jpg",
//                    buildAttributeOptions("主柜", mainGridJson)
//            );
//            purchaseProductRepository.saveProduct(mainCabinet);
//
//            PurchaseProductSku mainSku1 = buildSku(
//                    mainCabinet.getId(), "智能柜-主柜(29格口)", "ZNGZG", "17004010", new BigDecimal("0.01"),
//                    mainCabinet.getPictureUrl(), mainCabinet.getDetailPicUrl(),
//                    buildSkuFeature("15247939")
//            );
//            purchaseProductSkuRepository.saveProductSku(mainSku1);
//
//            PurchaseProductSku mainSku2 = buildSku(
//                    mainCabinet.getId(), "【自提】智能柜-主柜（29格口）", "ZNGZG", "17182061", new BigDecimal("0.01"),
//                    mainCabinet.getPictureUrl(), mainCabinet.getDetailPicUrl(),
//                    buildSkuFeature("15426048")
//            );
//            purchaseProductSkuRepository.saveProductSku(mainSku2);
//
//            // 3. 写入商品2: 智能柜-副柜(32格口)
//            String subAGridJson = buildGridJson("大格口", "300*160cm", 12, "中格口", "300*100cm", 20);
//            PurchaseProduct subCabinetA = buildProduct(
//                    "智能柜-副柜(32格口)", "副柜", new BigDecimal("0.01"),
//                    "https://gw.alicdn.com/imgextra/i2/O1CN016AQ4IW1rTyAb99lHz_!!6000000005633-0-tps-800-800.jpg",
//                    "https://gw.alicdn.com/imgextra/i3/O1CN01NkvGdA1FI6VbfuBv4_!!6000000000463-0-tps-1646-6698.jpg",
//                    buildAttributeOptions("副柜", subAGridJson)
//            );
//            purchaseProductRepository.saveProduct(subCabinetA);
//
//            PurchaseProductSku subASku1 = buildSku(
//                    subCabinetA.getId(), "智能柜-副柜(32格口)", "ZNGFGA", "17004011", new BigDecimal("0.01"),
//                    subCabinetA.getPictureUrl(), subCabinetA.getDetailPicUrl(),
//                    buildSkuFeature("15247940")
//            );
//            purchaseProductSkuRepository.saveProductSku(subASku1);
//
//            PurchaseProductSku subASku2 = buildSku(
//                    subCabinetA.getId(), "【自提】智能柜-副柜（32格口）", "ZNGFGA", "17182062", new BigDecimal("0.01"),
//                    subCabinetA.getPictureUrl(), subCabinetA.getDetailPicUrl(),
//                    buildSkuFeature("15426049")
//            );
//            purchaseProductSkuRepository.saveProductSku(subASku2);
//
//            // 4. 写入商品3: 智能柜-副柜(80格口)
//            String subBGridJson = buildGridJson("小格口", "160*200cm", 8, "微小格口", "160*75cm", 72);
//            PurchaseProduct subCabinetB = buildProduct(
//                    "智能柜-副柜(80格口)", "副柜", new BigDecimal("0.01"),
//                    "https://gw.alicdn.com/imgextra/i3/O1CN01BVPeKT1bXbSaNydSG_!!6000000003475-0-tps-800-800.jpg",
//                    "https://gw.alicdn.com/imgextra/i3/O1CN01NkvGdA1FI6VbfuBv4_!!6000000000463-0-tps-1646-6698.jpg",
//                    buildAttributeOptions("副柜", subBGridJson)
//            );
//            purchaseProductRepository.saveProduct(subCabinetB);
//
//            PurchaseProductSku subBSku1 = buildSku(
//                    subCabinetB.getId(), "智能柜-副柜(80格口)", "ZNGFGB", "17004012", new BigDecimal("0.01"),
//                    subCabinetB.getPictureUrl(), subCabinetB.getDetailPicUrl(),
//                    buildSkuFeature("15247941")
//            );
//            purchaseProductSkuRepository.saveProductSku(subBSku1);
//
//            PurchaseProductSku subBSku2 = buildSku(
//                    subCabinetB.getId(), "【自提】智能柜-副柜（80格口）", "ZNGFGB", "17182063", new BigDecimal("0.01"),
//                    subCabinetB.getPictureUrl(), subCabinetB.getDetailPicUrl(),
//                    buildSkuFeature("15426050")
//            );
//            purchaseProductSkuRepository.saveProductSku(subBSku2);
//
//            String resultMsg = String.format(
//                    "初始化成功: 主柜(productId=%d, sku=[%d,%d]), 副柜A(productId=%d, sku=[%d,%d]), 副柜B(productId=%d, sku=[%d,%d])",
//                    mainCabinet.getId(), mainSku1.getId(), mainSku2.getId(),
//                    subCabinetA.getId(), subASku1.getId(), subASku2.getId(),
//                    subCabinetB.getId(), subBSku1.getId(), subBSku2.getId()
//            );
//            log.info("initCabinetProductData {}", resultMsg);
//            return CnResult.succeed(resultMsg);
        } catch (Exception e) {
            log.error("initCabinetProductData 异常", e);
            return CnResult.fail("INIT_DATA_ERROR", e.getMessage());
        }
        return null;
    }

    @Override
    public CnResult<CabinetProductInfoResultVO> infoList(String customerId, Integer customerType) {
        try {
            AbstractOperation operation = buildSystemOperation();

            ProductInfoParam productInfoParam = new ProductInfoParam();
            productInfoParam.setCustomerId(customerId);
            productInfoParam.setCustomerType(customerType);
            productInfoParam.setCategoryId(PurchaseCategoryEnum.CABINET.getCode());

            ProductInfoResultDTO productInfoResult = productionApplicationService.getProductInfo(productInfoParam, operation);

            CabinetProductInfoResultVO resultVO = new CabinetProductInfoResultVO();
            if (productInfoResult == null || CollectionUtils.isEmpty(productInfoResult.getProductInfoList())) {
                resultVO.setProductInfoList(new ArrayList<>());
            } else {
                List<CabinetProductInfoDTO> cabinetProducts = productInfoResult.getProductInfoList().stream()
                        .map(this::convertToCabinetProductInfoDTO)
                        .collect(Collectors.toList());
                resultVO.setProductInfoList(cabinetProducts);
            }
            return CnResult.succeed(resultVO);
        } catch (Exception e) {
            log.error("infoList 异常, customerId={}, customerType={}", customerId, customerType, e);
            return CnResult.fail("INFO_LIST_ERROR", e.getMessage());
        }
    }

    @Override
    public CnResult<CabinetOrderDetailDTO> preCalculateOrder(PreCalculateOrderParam param) {
        try {
            AbstractOperation operation = buildSystemOperation();
            CabinetOrderDetailDTO result = cabinetPlaceOrderApplicationService.preCalculateOrder(param, operation);
            return CnResult.succeed(result);
        } catch (Exception e) {
            log.error("preCalculateOrder 异常, param={}", JSON.toJSONString(param), e);
            return CnResult.fail("PRE_CALCULATE_ORDER_ERROR", e.getMessage());
        }
    }

    @Override
    public CnResult<PlaceOrderResultDTO> placeOrder(PlaceOrderParam param) {
        try {
            AbstractOperation operation = buildSystemOperation();
            PlaceOrderResultDTO result = cabinetPlaceOrderApplicationService.placeOrder(param, operation);
            return CnResult.succeed(result);
        } catch (Exception e) {
            log.error("placeOrder 异常, param={}", JSON.toJSONString(param), e);
            return CnResult.fail("PLACE_ORDER_ERROR", e.getMessage());
        }
    }

    @Override
    public CnResult<ServiceProductInfoDTO> queryServiceProductInfoByCode(String serviceCode) {
        try {
            ServiceProductInfoDTO result = serviceProductInfoManager.queryServiceProductInfoByCode(serviceCode);
            String resultJson = JSON.toJSONString(result);
            log.info("queryServiceProductInfoByCode, serviceCode={}, result={}", serviceCode, resultJson);
            return CnResult.succeed(result);
        } catch (Exception e) {
            log.error("queryServiceProductInfoByCode 异常, serviceCode={}", serviceCode, e);
            return CnResult.fail("QUERY_SERVICE_PRODUCT_ERROR", e.getMessage());
        }
    }

    @Override
    public CnResult<String> deleteOrder(Long orderId) {
        try {
            purchaseOrderRepository.deleteOrder(orderId);
            log.info("deleteOrder 成功, orderId={}", orderId);
            return CnResult.succeed("删除订单成功，orderId=" + orderId);
        } catch (Exception e) {
            log.error("deleteOrder 异常, orderId={}", orderId, e);
            return CnResult.fail("DELETE_ORDER_ERROR", e.getMessage());
        }
    }

    @Override
    public CnResult<DuoNiuOrderDetailDTO> queryDuoNiuOrderDetail(String orderId, String supplierId) {
        try {
            DuoNiuOrderDetailDTO result = duoNiuQueryManager.queryOrderDetailById(orderId, supplierId);
            String resultJson = JSON.toJSONString(result);
            log.info("queryDuoNiuOrderDetail, orderId={}, supplierId={}, result={}", orderId, supplierId, resultJson);
            return CnResult.succeed(result);
        } catch (Exception e) {
            log.error("queryDuoNiuOrderDetail 异常, orderId={}, supplierId={}", orderId, supplierId, e);
            return CnResult.fail("QUERY_DUONIU_ORDER_DETAIL_ERROR", e.getMessage());
        }
    }

    @Override
    public CnResult<String> updateOrderStatusAndSnapshotFeature(Long orderId, Integer status, Long snapshotId, Map<String, String> additionalFeature) {
        try {
            purchaseOrderRepository.updateOrderStatusAndSnapshotFeature(orderId, status, snapshotId, additionalFeature);
            log.info("updateOrderStatusAndSnapshotFeature 成功, orderId={}, status={}, snapshotId={}", orderId, status, snapshotId);
            return CnResult.succeed("修改订单状态和追加快照feature成功，orderId=" + orderId + ", snapshotId=" + snapshotId);
        } catch (Exception e) {
            log.error("updateOrderStatusAndSnapshotFeature 异常, orderId={}, status={}, snapshotId={}", orderId, status, snapshotId, e);
            return CnResult.fail("UPDATE_ORDER_STATUS_ERROR", e.getMessage());
        }
    }

    private AbstractOperation buildSystemOperation() {
        return new SystemBizOperation(2218141292976L, "喵匠测试单");
    }

    /**
     * ProductInfoDTO → CabinetProductInfoDTO 转换
     * 解析 attributeOptionList 中的 cabinet_type 和 grid_info
     */
    private CabinetProductInfoDTO convertToCabinetProductInfoDTO(ProductInfoDTO productInfo) {
        CabinetProductInfoDTO cabinetDTO = new CabinetProductInfoDTO();
        cabinetDTO.setItemId(productInfo.getItemId());
        cabinetDTO.setItemTitle(productInfo.getItemTitle());
        cabinetDTO.setPictureUrl(productInfo.getPictureUrl());
        cabinetDTO.setDetailPicUrl(productInfo.getDetailPicUrl());
        cabinetDTO.setPrice(productInfo.getPrice());
        cabinetDTO.setHaveInventory(productInfo.getHaveInventory());

        if (CollectionUtils.isNotEmpty(productInfo.getAttributeOptionList())) {
            // 从 attributeOptionList 中提取 cabinet_type 作为 skuTitle
            productInfo.getAttributeOptionList().stream()
                    .filter(attr -> ProductAttributeEnum.CABINET_TYPE.getCode().equals(attr.getCode()))
                    .findFirst()
                    .ifPresent(attr -> cabinetDTO.setSkuTitle(attr.getValue()));

            // 从 attributeOptionList 中提取 grid_info JSON 并解析为 gridList
            String gridInfoJson = productInfo.getAttributeOptionList().stream()
                    .filter(attr -> ProductAttributeEnum.GRID_INFO.getCode().equals(attr.getCode()))
                    .map(AttributeOptionDTO::getValue)
                    .findFirst()
                    .orElse(null);

            List<CabinetGridInfo> gridInfoList = ProductSpecsParser.parseGridList(gridInfoJson);
            if (CollectionUtils.isNotEmpty(gridInfoList)) {
                List<CabinetProductInfoDTO.CabinetGridInfo> gridList = gridInfoList.stream()
                        .map(grid -> {
                            CabinetProductInfoDTO.CabinetGridInfo gridDTO = new CabinetProductInfoDTO.CabinetGridInfo();
                            gridDTO.setGridType(grid.getGridType());
                            gridDTO.setSize(grid.getSize());
                            gridDTO.setNum(grid.getNum());
                            return gridDTO;
                        })
                        .collect(Collectors.toList());
                cabinetDTO.setGridList(gridList);
            }
        }
        return cabinetDTO;
    }

    @Override
    public CnResult<String> addProductAttribute(Long productId, String attributeCode, String optionCode) {
        try {
            PurchaseProduct product = purchaseProductRepository.getProductById(productId);
            if (product == null) {
                return CnResult.fail("PRODUCT_NOT_FOUND", "商品不存在, productId=" + productId);
            }

            List<AttributeOption> attributeOptionList = product.getAttributeOptionList();
            if (attributeOptionList == null) {
                attributeOptionList = new ArrayList<>();
            }

            // 检查是否已存在同 code 的属性
            boolean alreadyExists = attributeOptionList.stream()
                    .anyMatch(attr -> attributeCode.equals(attr.getCode()));
            if (alreadyExists) {
                // 已存在则更新 optionCode
                attributeOptionList.stream()
                        .filter(attr -> attributeCode.equals(attr.getCode()))
                        .findFirst()
                        .ifPresent(attr -> {
                            attr.setOptionCode(optionCode);
                            attr.setValue(optionCode);
                        });
            } else {
                // 不存在则新增
                AttributeOption newOption = new AttributeOption();
                newOption.setCode(attributeCode);
                newOption.setValue(optionCode);
                newOption.setOptionCode(optionCode);
                newOption.setOptionName(attributeCode);
                attributeOptionList.add(newOption);
            }

            product.setAttributeOptionList(attributeOptionList);
            purchaseProductRepository.updateProduct(product);

            String resultMsg = String.format("商品属性更新成功, productId=%d, attributeCode=%s, optionCode=%s",
                    productId, attributeCode, optionCode);
            log.info("addProductAttribute {}", resultMsg);
            return CnResult.succeed(resultMsg);
        } catch (Exception e) {
            log.error("addProductAttribute 异常, productId={}, attributeCode={}, optionCode={}",
                    productId, attributeCode, optionCode, e);
            return CnResult.fail("ADD_ATTRIBUTE_ERROR", e.getMessage());
        }
    }

    @Override
    public CnResult<String> triggerDuoNiuStatusChange(String orderId, String orderStatus, String supplierID) {
        try {
            boolean result = duoNiuNodeStatusChangeListener.triggerConsume(orderId, orderStatus, supplierID);
            String resultMsg = String.format("触发完成, orderId=%s, orderStatus=%s, supplierID=%s, result=%s",
                    orderId, orderStatus, supplierID, result);
            log.info("triggerDuoNiuStatusChange {}", resultMsg);
            return CnResult.succeed(resultMsg);
        } catch (Exception e) {
            log.error("triggerDuoNiuStatusChange 异常, orderId={}, orderStatus={}, supplierID={}",
                    orderId, orderStatus, supplierID, e);
            return CnResult.fail("TRIGGER_STATUS_CHANGE_ERROR", e.getMessage());
        }
    }

    private PurchaseProduct buildProduct(String title, String subtitle, BigDecimal price,
                                         String pictureUrl, String detailPicUrl,
                                         List<AttributeOption> attributeOptionList) {
        PurchaseProduct product = new PurchaseProduct();
        product.setTitle(title);
        product.setSubtitle(subtitle);
        product.setStatus(STATUS_ON);
        product.setCategoryId(CATEGORY_CABINET);
        product.setPictureUrl(pictureUrl);
        product.setDetailPicUrl(detailPicUrl);
        product.setPrice(price);
        product.setAttributeOptionList(attributeOptionList);
        product.setSpecs("{}");
        return product;
    }

    private PurchaseProductSku buildSku(Long productId, String skuName, String skuCode,
                                        String skuId, BigDecimal price,
                                        String pictureUrl, String detailPicUrl,
                                        Map<String, String> feature) {
        PurchaseProductSku sku = new PurchaseProductSku();
        sku.setProductId(productId);
        sku.setSkuName(skuName);
        sku.setSkuCode(skuCode);
        sku.setSkuId(skuId);
        sku.setSkuSource(PurchaseFulfillmentPlatformEnum.WANLINIU.getCode());
        sku.setStatus(STATUS_ON);
        sku.setShowSalePrice(price);
        sku.setPaySalePrice(price);
        sku.setPictureUrl(pictureUrl);
        sku.setDetailPicUrl(detailPicUrl);
        sku.setSpecs("{}");
        sku.setFeature(feature);
        return sku;
    }

    /**
     * 构建 SKU feature，存放 sourItemId（万里牛平台商品 ID）
     */
    private Map<String, String> buildSkuFeature(String sourItemId) {
        Map<String, String> feature = new HashMap<>();
        feature.put("sourItemId", sourItemId);
        return feature;
    }

    /**
     * 构建商品属性标签列表
     *
     * @param cabinetType  柜子类型（主柜/副柜）
     * @param gridInfoJson 格口信息 JSON 字符串
     * @return 属性标签列表
     */
    private List<AttributeOption> buildAttributeOptions(String cabinetType, String gridInfoJson) {
        AttributeOption cabinetTypeOption = new AttributeOption();
        cabinetTypeOption.setCode(ProductAttributeEnum.CABINET_TYPE.getCode());
        cabinetTypeOption.setValue(cabinetType);
        cabinetTypeOption.setOptionCode(cabinetType);
        cabinetTypeOption.setOptionName(cabinetType);

        AttributeOption gridInfoOption = new AttributeOption();
        gridInfoOption.setCode(ProductAttributeEnum.GRID_INFO.getCode());
        gridInfoOption.setValue(gridInfoJson);
        gridInfoOption.setOptionCode("grid_info");
        gridInfoOption.setOptionName("格口信息");

        return Arrays.asList(cabinetTypeOption, gridInfoOption);
    }

    @Override
    public CnResult<Boolean> checkPaymentSigned(Long userId) {
        try {
            boolean signed = paymentSignManager.isSigned(userId);
            log.info("checkPaymentSigned userId={}, signed={}", userId, signed);
            return CnResult.succeed(signed);
        } catch (Exception e) {
            log.error("checkPaymentSigned 异常, userId={}", userId, e);
            return CnResult.fail("CHECK_SIGN_ERROR", e.getMessage());
        }
    }

    @Override
    public CnResult<com.cainiao.tp.nm.plan.infra.port.dto.PlanExpressDTO> getExpressDTO(String cpCode, String orgCode) {
        try {
            com.cainiao.tp.nm.plan.infra.port.dto.PlanExpressDTO expressDTO = expressInfoManager.getExpressDTO(cpCode, orgCode);
            log.info("getExpressDTO cpCode={}, orgCode={}, result={}", cpCode, orgCode, JSON.toJSONString(expressDTO));
            return CnResult.succeed(expressDTO);
        } catch (Exception e) {
            log.error("getExpressDTO 异常, cpCode={}, orgCode={}", cpCode, orgCode, e);
            return CnResult.fail("GET_EXPRESS_ERROR", e.getMessage());
        }
    }

    @Override
    public CnResult<com.cainiao.tp.nm.plan.infra.port.dto.purchase.TpsAgreementInfoDTO> queryAgreementDetail(Long agreementId) {
        try {
            com.cainiao.tp.nm.plan.infra.port.dto.purchase.TpsAgreementInfoDTO result = tpsAgreementQueryManager.queryDetail(agreementId);
            log.info("queryAgreementDetail agreementId={}, result={}", agreementId, JSON.toJSONString(result));
            return CnResult.succeed(result);
        } catch (Exception e) {
            log.error("queryAgreementDetail 异常, agreementId={}", agreementId, e);
            return CnResult.fail("QUERY_AGREEMENT_ERROR", e.getMessage());
        }
    }

    @Override
    public CnResult<com.cainiao.tp.nm.plan.infra.port.dto.purchase.TpsAgreementInfoDTO> queryAgreementByCode(String agreementCode) {
        try {
            com.cainiao.tp.nm.plan.infra.port.dto.purchase.TpsAgreementInfoDTO result = tpsAgreementQueryManager.queryByCode(agreementCode);
            log.info("queryAgreementByCode agreementCode={}, result={}", agreementCode, JSON.toJSONString(result));
            return CnResult.succeed(result);
        } catch (Exception e) {
            log.error("queryAgreementByCode 异常, agreementCode={}", agreementCode, e);
            return CnResult.fail("QUERY_AGREEMENT_ERROR", e.getMessage());
        }
    }

    @Override
    public CnResult<String> updateSkuFeature(Long skuId, String key, String value) {
        try {
            PurchaseProductSku sku = purchaseProductSkuRepository.getById(skuId);
            if (sku == null) {
                log.warn("updateSkuFeature sku 不存在, skuId={}", skuId);
                return CnResult.fail("SKU_NOT_FOUND", "SKU 不存在");
            }

            // 获取或创建 feature Map
            Map<String, String> feature = sku.getFeature();
            if (feature == null) {
                feature = new HashMap<>();
            }

            // 更新 feature
            feature.put(key, value);
            sku.setFeature(feature);

            // 更新 SKU
            purchaseProductSkuRepository.updateSku(sku);

            log.info("updateSkuFeature 成功, skuId={}, key={}, value={}, feature={}", skuId, key, value, JSON.toJSONString(feature));
            return CnResult.succeed("更新成功");
        } catch (Exception e) {
            log.error("updateSkuFeature 异常, skuId={}, key={}, value={}", skuId, key, value, e);
            return CnResult.fail("UPDATE_SKU_FEATURE_ERROR", e.getMessage());
        }
    }


    /**
     * 根据 SKU ID 删除 SKU（仅测试使用）
     *
     * @param skuId SKU ID
     * @return 执行结果
     */
    @Override
    public CnResult<String> deleteSku(Long skuId) {
        purchaseProductSkuRepository.deleteSkuById(skuId);
        return CnResult.succeed("删除成功");
    }


    public CnResult<AgreementInfoDTO> queryAgreementInfo(String customerId, Integer customerType) {
        AgreementInfoDTO agreementInfoDTO = new AgreementInfoDTO();
        if(PurchaseCustomerTypeEnum.OUTLET.getCode().equals(customerType)){
            return CnResult.succeed(agreementInfoDTO);
        }
        ProductInfoParam param=new ProductInfoParam();
        param.setCustomerId(customerId);
        param.setCustomerType(customerType);
        param.setCategoryId(PurchaseCategoryEnum.CABINET.getCode());
        List<PurchaseRule> productionRule = productionApplicationService.getProductionRule(param);
        if(org.apache.commons.collections.CollectionUtils.isEmpty(productionRule)){
            return CnResult.succeed(agreementInfoDTO);
        }
        List<AgreementConfig> agreementConfigs = productionRule.stream().map(PurchaseRule::getAgreementConfig).filter(org.apache.commons.collections.CollectionUtils::isNotEmpty).findFirst().orElse(null);
        if(org.apache.commons.collections.CollectionUtils.isEmpty(agreementConfigs)){
            return CnResult.succeed(agreementInfoDTO);
        }
        //现在逻辑只查询第一个
        AgreementConfig agreementConfig = agreementConfigs.get(0);
        agreementInfoDTO.setAgreementCode(agreementConfig.getAgreementCode());

        QueryAgreementParam agreementParam = new QueryAgreementParam();
        agreementParam.setAgreementCode(agreementConfig.getAgreementCode());
        agreementParam.setCustomerId(customerId);
        agreementParam.setCustomerCode("11");
        agreementParam.setCustomerType(customerType);

        AgreementInfoAndSignDTO agreementInfoAndSignDTO = agreementComponent.queryAgreementInfoAndSigned(agreementParam);
        if (agreementInfoAndSignDTO != null) {
            agreementInfoDTO.setAgreementCode(agreementInfoAndSignDTO.getAgreementCode());
            agreementInfoDTO.setAgreementName(agreementInfoAndSignDTO.getAgreementName());
            agreementInfoDTO.setAgreementUrl(agreementInfoAndSignDTO.getAgreementUrl());
            agreementInfoDTO.setAgreementId(agreementInfoAndSignDTO.getAgreementId() == null
                    ? null : String.valueOf(agreementInfoAndSignDTO.getAgreementId()));
            agreementInfoDTO.setSign(agreementInfoAndSignDTO.getSigned());
        }
        return CnResult.succeed(agreementInfoDTO);
    }

    /**
     * 构建格口信息 JSON 字符串
     */
    private String buildGridJson(String gridType1, String size1, int num1,
                                 String gridType2, String size2, int num2) {
        Map<String, Object> grid1 = new HashMap<>();
        grid1.put("gridType", gridType1);
        grid1.put("size", size1);
        grid1.put("num", num1);

        Map<String, Object> grid2 = new HashMap<>();
        grid2.put("gridType", gridType2);
        grid2.put("size", size2);
        grid2.put("num", num2);

        List<Map<String, Object>> gridList = Arrays.asList(grid1, grid2);
        return JSON.toJSONString(gridList);
    }
}
