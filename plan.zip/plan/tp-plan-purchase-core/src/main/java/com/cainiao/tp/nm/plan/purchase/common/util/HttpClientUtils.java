/*
 * Copyright 2018 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */

package com.cainiao.tp.nm.plan.purchase.common.util;

import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpEntity;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

/**
 * Http接口统一处理入口.
 *
 * @date 2018/7/25.
 */
@Slf4j
public class HttpClientUtils {

    /**编码格式。发送编码格式统一用UTF-8**/
    private static final String ENCODING = "UTF-8";
    /**SOCKET超时时间***/
    public static final int SOCKET_TIMEOUT = 15000;
    /**链接超时时间**/
    public static final int CONNECT_TIMEOUT = 15000;

    /**
     * 基于HttpClient 4.3的通用POST方法
     *
     * @param url       提交的URL
     * @param params    提交params
     * @return 提交响应
     */
    public static String submitPostUrlEncoded(String url, String params) {
        final CloseableHttpClient httpClient = HttpClients.createDefault();
        String responseText = "";
        CloseableHttpResponse response = null;
        try {
            log.info("submitPostUrl,url is {} params is {}", url,params);
            final HttpPost httpPost = new HttpPost(url);
            //设置请求和传输超时时间
            final RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(SOCKET_TIMEOUT).setConnectTimeout(CONNECT_TIMEOUT).build();
            httpPost.setConfig(requestConfig);
            httpPost.setHeader("Content-Type", "application/x-www-form-urlencoded");
            httpPost.setEntity(new StringEntity(params, ENCODING));
            response = httpClient.execute(httpPost);
            final HttpEntity entity = response.getEntity();
            if (entity != null) {
                responseText = EntityUtils.toString(entity);
            }
            log.info("submitPostUrl,url is {} params is {} return message is {}", url,params, responseText);
        } catch (Exception e) {
            log.error("submitPostUrl-occur-exception", e);
        } finally {
            try {
                response.close();
            } catch (Exception e) {
                log.error("submitPostUrl HttpClient close error", e);
            }
        }
        return responseText;
    }
    public static String submitPostUrlEncodedJSON(String url, String params) {
        final CloseableHttpClient httpClient = HttpClients.createDefault();
        String responseText = "";
        CloseableHttpResponse response = null;
        try {
            log.info("submitPostUrlJSON,url is {} params is {}", url, params);
            final HttpPost httpPost = new HttpPost(url);
            //设置请求和传输超时时间
            final RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(SOCKET_TIMEOUT).setConnectTimeout(CONNECT_TIMEOUT).build();
            httpPost.setConfig(requestConfig);
            httpPost.setHeader("Content-Type", "application/json");
            httpPost.setEntity(new StringEntity(params, ENCODING));
            response = httpClient.execute(httpPost);
            final HttpEntity entity = response.getEntity();
            if (entity != null) {
                responseText = EntityUtils.toString(entity);
            }
            log.info("submitPostUrlJSON,url is {} params is {} return message is {}", url, params, responseText);
        } catch (Exception e) {
            log.error("submitPostUrlJSON-occur-exception", e);
        } finally {
            try {
                response.close();
            } catch (Exception e) {
                log.error("submitPostUrlJSON HttpClient close error", e);
            }
        }
        return responseText;
    }

    public static String submitGetUrlEncoded(String url, String params) {
        final CloseableHttpClient httpClient = HttpClients.createDefault();
        String responseText = "";
        CloseableHttpResponse response = null;
        try {
            final HttpGet httpGet = new HttpGet(url+"?"+params);
            //设置请求和传输超时时间
            final RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(SOCKET_TIMEOUT).setConnectTimeout(CONNECT_TIMEOUT).build();
            httpGet.setConfig(requestConfig);
            httpGet.setHeader("Content-Type", "application/x-www-form-urlencoded");

            response = httpClient.execute(httpGet);
            final HttpEntity entity = response.getEntity();
            if (entity != null) {
                responseText = EntityUtils.toString(entity);
            }
            log.info("submitGetUrlEncoded,url is {} params is {} return message is {}", url, params, responseText);
        } catch (Exception e) {
            log.error("submitGetUrlEncoded url is {} params is {}", url, params, e);
        } finally {
            try {
                if (response != null){
                    response.close();
                }
            } catch (Exception e) {
                log.error("submitGetUrlEncoded HttpClient close error url is {} params is {}", url, params, e);
            }
        }
        return responseText;
    }
}
