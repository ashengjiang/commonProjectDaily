package com.cainiao.tp.nm.plan.purchase.domain.service;

import com.cainiao.tp.nm.plan.api.purchase.application.dto.PurchasePaymentPlanDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.PurchaseRuleDTO;
import lombok.Data;

import java.io.Serializable;
import java.util.Objects;

/**
 * 购买规则匹配器（领域服务）
 * <p>
 * 输入下单一行的关键维度（itemId/customerId/customerType/paymentMode/deliveryType），
 * 在规则池中筛选唯一一条规则，并返回与入参 paymentMode 对应的支付方案。
 * 命中规则的 {@code skuId} 即为本次购买所确认的 SKU。
 * </p> */
public interface PurchaseRuleMatcher {

    /**
     * 命中结果（规则 DTO + 解析出的真实支付方案 DTO），可直接 JSON 序列化做订单快照。
     */
    @Data
    class MatchResult implements Serializable {
        private final PurchaseRuleDTO rule;
        private final PurchasePaymentPlanDTO paymentPlan;

        public MatchResult(PurchaseRuleDTO rule, PurchasePaymentPlanDTO paymentPlan) {
            this.rule = Objects.requireNonNull(rule, "rule");
            this.paymentPlan = Objects.requireNonNull(paymentPlan, "paymentPlan");
        }
    }

    /**
     * 在 categoryId=CABINET 的购买规则池里，按下列维度筛选唯一一条规则并返回匹配的支付方案：
     * <ol>
     *   <li>{@code rule.productId == itemId}（必匹配）</li>
     *   <li>{@code rule.customerConfig.customerType == customerType}（必匹配）</li>
     *   <li>{@code customerId} 通过 whiteList/blackList 校验</li>
     *   <li>{@code rule.deliveryTypeList contains deliveryType}</li>
     *   <li>{@code rule.paymentPlanConfig} 中存在某 paymentPlanId 对应的 PurchasePaymentPlan.paymentMode == 入参 paymentMode</li>
     *   <li>当前时间 ∈ [{@code startTime}, {@code endTime}]</li>
     *   <li>多条命中按 {@code level} 倒序取首条；level 也并列时抛业务异常</li>
     * </ol>
     * 命中规则的 {@code rule.skuId} 即为本次购买所确认的 SKU。
     *
     * @param itemId       商品 ID（对应 PurchaseRule.productId，String 入参由调用方解析）
     * @param customerId   客户 ID
     * @param customerType 客户类型（"1"=站点 "10"=网点）
     * @param paymentMode  支付模式
     * @param deliveryType 提货类型
     * @return 匹配结果（规则 + 支付方案），永不为 null；未命中或多命中均抛业务异常
     */
    MatchResult match(String itemId, String customerId, Integer customerType,
                      Integer paymentMode, Integer deliveryType);
}
