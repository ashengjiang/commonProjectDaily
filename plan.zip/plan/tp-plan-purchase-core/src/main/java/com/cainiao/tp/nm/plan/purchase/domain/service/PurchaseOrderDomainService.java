package com.cainiao.tp.nm.plan.purchase.domain.service;

import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PurchaseOrderCreateParam;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseOrder;
import com.cainiao.tp.nm.plan.purchase.domain.service.param.PurchaseOrderStatusUpdateParam;

/**
 * 订购订单领域服务
 */
public interface PurchaseOrderDomainService {

    /**
     * 创建订购订单
     * @param param 创建参数
     * @return 订购订单实体
     */
    PurchaseOrder createOrder(PurchaseOrderCreateParam param);

    /**
     * 根据订单ID查询订单（包含商品快照）
     *
     * @param orderId 订单ID
     * @return 订单实体（含快照列表），不存在时返回 null
     */
    PurchaseOrder queryOrderById(Long orderId);

    /**
     * 更新订单
     *
     * @param param 更新参数
     * @return 更新后的订单
     */
    PurchaseOrder updateOrderStatus(PurchaseOrderStatusUpdateParam param);

}
