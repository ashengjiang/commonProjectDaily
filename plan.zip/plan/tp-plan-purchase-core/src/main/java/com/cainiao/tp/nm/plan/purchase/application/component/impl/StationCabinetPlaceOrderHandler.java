package com.cainiao.tp.nm.plan.purchase.application.component.impl;

import com.cainiao.tp.nm.plan.api.purchase.application.dto.AgreementInfoDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.PlaceOrderResultDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.PurchaseRuleDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PlaceOrderParam;
import com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseCustomerTypeEnum;
import com.cainiao.tp.nm.plan.infra.port.dto.AgreementInfoAndSignDTO;
import com.cainiao.tp.nm.plan.infra.port.dto.param.QueryAgreementParam;
import com.cainiao.tp.nm.plan.infra.port.dto.param.SignAgreementParam;
import com.cainiao.tp.nm.plan.purchase.application.component.AgreementComponent;
import com.cainiao.tp.nm.plan.purchase.application.component.CabinetPlaceOrderContext;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseOrder;
import com.cainiao.tp.nm.plan.purchase.domain.model.valobj.PurchaseOrderProductSnapshot;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * 站点柜子下单处理器
 * <p>
 * 站点下单前置门槛仅需「购买协议签署」一项：
 * <ol>
 *   <li>从订单快照取协议 code，查询站点签约状态；</li>
 *   <li>已签 → 通过，进入付款流程；</li>
 *   <li>未签 + 用户已勾选「同意签约」({@code param.sign=true}) → 调用 {@link AgreementComponent#sign} 签约，
 *       签约成功视为通过；</li>
 *   <li>未签 + 未勾选 → 不通过，订单落库为签约中(SIGNING)状态，前端引导用户完成签约后重新付款。</li>
 * </ol>
 * 不检查实名认证、资金账户、支付宝代扣协议（这些是网点专属的前置门槛）。
 * </p> */
@Slf4j
@Component
public class StationCabinetPlaceOrderHandler extends AbstractCabinetPlaceOrderHandler {

    /**
     * 签约用户类型：站点固定为 2（参考 {@code TpsAgreementCreateAndSignDTO.userType} 注释 "0:淘宝 1:菜鸟 2:站点"）
     */
    private static final Integer SIGN_USER_TYPE_STATION = 1;

    @Resource
    private AgreementComponent agreementComponent;

    @Override
    public Integer customerType() {
        return PurchaseCustomerTypeEnum.STATION.getCode();
    }

    @Override
    protected PlaceOrderResultDTO checkPreConditions(CabinetPlaceOrderContext context) {
        PlaceOrderParam param = context.getParam();
        PurchaseOrder order = context.getOrder();
        PlaceOrderResultDTO result = new PlaceOrderResultDTO();

        // 1. 从订单快照取协议 code（默认取第一个，与网点实现一致）
        String agreementCode = resolveAgreementCode(order);
        if (agreementCode == null) {
            // 规则未配置购买协议 → 视为无需签约，直接通过
            log.info("StationCabinetPlaceOrderHandler 未配置购买协议，跳过签约校验，customerId={}, orderId={}",
                    param.getCustomerId(), order.getId());
            AgreementInfoDTO passThrough = new AgreementInfoDTO();
            passThrough.setSign(Boolean.TRUE);
            result.setPurchaseAgreement(passThrough);
            return result;
        }

        // 2. 查询站点签约状态 + 协议详情
        AgreementInfoDTO agreementInfo = queryAgreementInfo(param, agreementCode);
        result.setPurchaseAgreement(agreementInfo);

        // 3. 已签约直接通过
        if (Boolean.TRUE.equals(agreementInfo.getSign())) {
            return result;
        }

        // 4. 未签 + 用户勾选了「同意签约」→ 调签约
        if (Boolean.TRUE.equals(param.getSign())) {
            boolean signSuccess = doSign(param, order, agreementCode);
            agreementInfo.setSign(signSuccess);
        } else {
            log.info("StationCabinetPlaceOrderHandler 未签约且用户未确认签约，customerId={}, orderId={}, agreementCode={}",
                    param.getCustomerId(), order.getId(), agreementCode);
        }
        return result;
    }

    @Override
    protected boolean isAllPreConditionsPassed(PlaceOrderResultDTO result) {
        return result.getPurchaseAgreement() != null
                && Boolean.TRUE.equals(result.getPurchaseAgreement().getSign());
    }

    /**
     * 从订单快照拿协议 code（与网点 {@code OutletCabinetPlaceOrderHandler#getExpressAgreementParam} 同源）
     * <p>当前默认只取第一个协议，后续支持多协议时调整。</p>
     */
    private String resolveAgreementCode(PurchaseOrder order) {
        List<PurchaseOrderProductSnapshot> snapshots = order.getProductSnapshotList();
        if (CollectionUtils.isEmpty(snapshots)) {
            return null;
        }
        PurchaseRuleDTO purchaseRule = snapshots.get(0).getPurchaseRule();
        if (purchaseRule == null || CollectionUtils.isEmpty(purchaseRule.getAgreementCodeList())) {
            return null;
        }
        return purchaseRule.getAgreementCodeList().get(0);
    }

    /**
     * 查询协议信息及站点签约状态
     */
    private AgreementInfoDTO queryAgreementInfo(PlaceOrderParam param, String agreementCode) {
        AgreementInfoDTO agreementInfo = new AgreementInfoDTO();
        agreementInfo.setAgreementCode(agreementCode);
        agreementInfo.setSign(Boolean.FALSE);
        try {
            QueryAgreementParam queryParam = new QueryAgreementParam();
            queryParam.setAgreementCode(agreementCode);
            queryParam.setCustomerId(param.getCustomerId());
            queryParam.setCustomerCode(param.getCustomerCode());
            queryParam.setCustomerType(param.getCustomerType());

            AgreementInfoAndSignDTO infoAndSign = agreementComponent.queryAgreementInfoAndSigned(queryParam);
            if (infoAndSign != null) {
                agreementInfo.setAgreementName(infoAndSign.getAgreementName());
                agreementInfo.setAgreementUrl(infoAndSign.getAgreementUrl());
                agreementInfo.setSign(Boolean.TRUE.equals(infoAndSign.getSigned()));
                if (infoAndSign.getAgreementId() != null) {
                    agreementInfo.setAgreementId(String.valueOf(infoAndSign.getAgreementId()));
                }
            }
        } catch (Exception e) {
            log.error("StationCabinetPlaceOrderHandler 查询协议异常，customerId={}, agreementCode={}",
                    param.getCustomerId(), agreementCode, e);
        }
        return agreementInfo;
    }

    /**
     * 站点签约
     * <p>签约失败不抛异常，返回 false，让前置检查不通过，订单走 SIGNING 状态。</p>
     */
    private boolean doSign(PlaceOrderParam param, PurchaseOrder order, String agreementCode) {
        try {
            SignAgreementParam signParam = new SignAgreementParam();
            signParam.setAgreementCode(agreementCode);
            signParam.setUserId(param.getCnUserAccountId()+"");
            signParam.setUserType(SIGN_USER_TYPE_STATION);
            signParam.setCustomerId(param.getCustomerId());
            signParam.setCustomerType(String.valueOf(PurchaseCustomerTypeEnum.STATION.getCode()));

            Long instanceId = agreementComponent.sign(signParam);
            boolean success = instanceId != null;
            log.info("StationCabinetPlaceOrderHandler 签约结果，customerId={}, orderId={}, agreementCode={}, "
                            + "instanceId={}, success={}",
                    param.getCustomerId(), order.getId(), agreementCode, instanceId, success);
            return success;
        } catch (Exception e) {
            log.error("StationCabinetPlaceOrderHandler 签约异常，customerId={}, orderId={}, agreementCode={}",
                    param.getCustomerId(), order.getId(), agreementCode, e);
            return false;
        }
    }
}
