package com.cainiao.tp.nm.plan.purchase.common.constants;

import com.cainiao.sutee.commons.base.MsgCode;
import lombok.Getter;

/**
 * 订购业务错误码
 * 按苏铁规范要求定义为4位字符串 */
@Getter
public enum PurchaseErrorCode implements MsgCode {

    /**
     * 服务异常
     */
    SERVICE_ERROR("0000", "服务异常"),

    /**
     * 参数校验异常
     */
    ILLEGAL_PARAM("0001", "参数校验异常"),

    /**
     * 订单不存在
     */
    ORDER_NOT_FOUND("1001", "订单不存在"),

    /**
     * 订单状态异常
     */
    ORDER_STATUS_ERROR("1002", "订单状态异常"),

    /**
     * 状态流转异常
     */
    STATUS_TRANSITION_ERROR("1003", "状态流转异常"),

    /**
     * 支付金额不足
     */
    PAYMENT_AMOUNT_INSUFFICIENT("1004", "支付金额不足"),

    /**
     * 商品快照不存在
     */
    PRODUCT_SNAPSHOT_NOT_FOUND("1005", "商品快照不存在"),

    /**
     * 支付模式不支持
     */
    PAYMENT_MODE_NOT_SUPPORTED("1006", "支付模式不支持"),

    /**
     * 发货类型不支持
     */
    DELIVERY_TYPE_NOT_SUPPORTED("1007", "发货类型不支持"),

    /**
     * 订单已取消
     */
    ORDER_CANCELLED("1008", "订单已取消"),

    /**
     * 订单已完成
     */
    ORDER_COMPLETED("1009", "订单已完成"),

    /**
     * 重复支付
     */
    DUPLICATE_PAYMENT("1010", "重复支付"),

    /**
     * 支付超时
     */
    PAYMENT_TIMEOUT("1011", "支付超时"),

    /**
     * 发货失败
     */
    SHIPPING_FAILED("1012", "发货失败"),

    /**
     * 签收失败
     */
    SIGN_FAILED("1013", "签收失败"),

    /**
     * 订单金额计算异常
     */
    ORDER_AMOUNT_CALCULATION_ERROR("1014", "订单金额计算异常"),

    /**
     * 商品快照数据异常
     */
    PRODUCT_SNAPSHOT_DATA_ERROR("1015", "商品快照数据异常"),

    /**
     * 支付信息异常
     */
    PAYMENT_INFO_ERROR("1016", "支付信息异常"),

    /**
     * 发货信息异常
     */
    SHIPPING_INFO_ERROR("1017", "发货信息异常"),

    /**
     * 签收信息异常
     */
    SIGN_INFO_ERROR("1018", "签收信息异常"),

    /**
     * 订单数据异常
     */
    ORDER_DATA_ERROR("1019", "订单数据异常"),

    /**
     * 订单操作失败
     */
    ORDER_OPERATION_FAILED("1020", "订单操作失败"),

    ;

    /**
     * code
     */
    private final String code;

    /**
     * 消息
     */
    private final String message;

    PurchaseErrorCode(String code, String message) {
        this.code = code;
        this.message = message;
    }
}
