package com.cainiao.tp.nm.plan.purchase.domain.service.impl;

import com.cainiao.tp.nm.plan.api.purchase.application.dto.PurchasePaymentPlanDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.PurchaseRuleDTO;
import com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseCategoryEnum;
import com.cainiao.tp.nm.plan.purchase.domain.exception.PurchaseDomainException;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchasePaymentPlan;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseRule;
import com.cainiao.tp.nm.plan.purchase.domain.model.valobj.AgreementConfig;
import com.cainiao.tp.nm.plan.purchase.domain.model.valobj.CustomerConfig;
import com.cainiao.tp.nm.plan.purchase.domain.model.valobj.PaymentPlanConfig;
import com.cainiao.tp.nm.plan.purchase.domain.repository.PurchasePaymentPlanRepository;
import com.cainiao.tp.nm.plan.purchase.domain.repository.PurchaseRuleRepository;
import com.cainiao.tp.nm.plan.purchase.domain.service.PurchaseRuleMatcher;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * 购买规则匹配器实现 */
@Slf4j
@Component
public class PurchaseRuleMatcherImpl implements PurchaseRuleMatcher {

    @Resource
    private PurchaseRuleRepository purchaseRuleRepository;

    @Resource
    private PurchasePaymentPlanRepository purchasePaymentPlanRepository;

    @Override
    public MatchResult match(String itemId, String customerId, Integer customerType,
                             Integer paymentMode, Integer deliveryType) {
        validateInput(itemId, customerId, customerType, paymentMode, deliveryType);

        Long productIdLong = parseLong(itemId, "itemId");

        // 1. 取出全部柜子规则
        List<PurchaseRule> allRules = purchaseRuleRepository
                .getRulesByCategoryId(PurchaseCategoryEnum.CABINET.getCode());
        if (CollectionUtils.isEmpty(allRules)) {
            throw PurchaseDomainException.ofIllegalParam("没有可用的柜子购买规则");
        }

        // 2. 按维度逐项过滤（含 paymentMode：PaymentPlanConfig 已带 paymentMode 字段，无需查库）
        //    命中规则的 rule.skuId 即购买的 SKU
        LocalDateTime now = LocalDateTime.now();
        List<PurchaseRule> matched = allRules.stream()
                .filter(rule -> matchProduct(rule, productIdLong))
                .filter(rule -> matchCustomer(rule, customerId, customerType))
                .filter(rule -> matchDeliveryType(rule, deliveryType))
                .filter(rule -> matchTimeWindow(rule, now))
                .filter(rule -> matchPaymentMode(rule, paymentMode))
                .collect(Collectors.toList());

        if (matched.isEmpty()) {
            throw PurchaseDomainException.ofIllegalParam(String.format(
                    "无匹配的购买规则请联系管理员，itemId=%s, customerType=%s, deliveryType=%s, paymentMode=%s",
                    itemId, customerType, deliveryType, paymentMode));
        }

        // 3. 已经过维度过滤的规则，直接查询其匹配 paymentMode 的 PurchasePaymentPlan 实体
        List<RulePlanPair> pairs = resolvePaymentPlans(matched, paymentMode);
        if (pairs.isEmpty()) {
            throw PurchaseDomainException.ofIllegalParam(String.format(
                    "支付方案实体缺失，itemId=%s, paymentMode=%s", itemId, paymentMode));
        }

        // 4. 按 level 倒序取首条；首位有并列则抛业务异常（运营须保证同一组合下 level 唯一）
        pairs.sort(Comparator.comparingInt((RulePlanPair p) -> p.rule.getLevel()).reversed());
        int topLevel = pairs.get(0).rule.getLevel();
        long topCount = pairs.stream().filter(p -> p.rule.getLevel() == topLevel).count();
        if (topCount > 1) {
            throw PurchaseDomainException.ofIllegalParam(String.format(
                    "命中多条 level=%d 的购买规则，请修正规则配置使 level 唯一，itemId=%s",
                    topLevel, itemId));
        }

        RulePlanPair top = pairs.get(0);
        log.info("规则匹配成功，itemId={}, ruleId={}, skuId={}, paymentPlanId={}, level={}",
                itemId, top.rule.getId(), top.rule.getSkuId(), top.plan.getId(), top.rule.getLevel());

        // 5. 领域模型转 DTO（避免 domain 层泄漏到 api 层；同时便于 JSON 快照序列化）
        PaymentPlanConfig matchedCfg = findMatchedCfg(top.rule, paymentMode);
        return new MatchResult(toRuleDTO(top.rule, matchedCfg), toPlanDTO(top.plan));
    }

    /* ============================== Model → DTO ============================== */

    private PaymentPlanConfig findMatchedCfg(PurchaseRule rule, Integer paymentMode) {
        for (PaymentPlanConfig cfg : rule.getPaymentPlanConfig()) {
            if (Objects.equals(cfg.getPaymentMode(), paymentMode)) {
                return cfg;
            }
        }
        return null;
    }

    private PurchaseRuleDTO toRuleDTO(PurchaseRule rule, PaymentPlanConfig matchedCfg) {
        PurchaseRuleDTO dto = new PurchaseRuleDTO();
        dto.setId(rule.getId());
        dto.setProductId(rule.getProductId());
        dto.setCategoryId(rule.getCategoryId());
        dto.setSkuId(rule.getSkuId());
        if (rule.getCustomerConfig() != null) {
            dto.setCustomerType(rule.getCustomerConfig().getCustomerType());
        }
        if (CollectionUtils.isNotEmpty(rule.getAgreementConfig())) {
            dto.setAgreementCodeList(rule.getAgreementConfig().stream()
                    .sorted(Comparator.comparing(
                            AgreementConfig::getSortOrder, Comparator.nullsLast(Comparator.naturalOrder())))
                    .map(AgreementConfig::getAgreementCode)
                    .collect(Collectors.toList()));
        }
        if (matchedCfg != null) {
            dto.setPaymentPlanId(matchedCfg.getPaymentPlanId());
            dto.setPaymentPlanName(matchedCfg.getPaymentPlanName());
            dto.setPaymentMode(matchedCfg.getPaymentMode());
        }
        dto.setDeliveryTypeList(rule.getDeliveryTypeList());
        dto.setStartTime(rule.getStartTime());
        dto.setEndTime(rule.getEndTime());
        dto.setLevel(rule.getLevel());
        return dto;
    }

    private PurchasePaymentPlanDTO toPlanDTO(PurchasePaymentPlan plan) {
        PurchasePaymentPlanDTO dto = new PurchasePaymentPlanDTO();
        dto.setId(plan.getId());
        dto.setPayCode(plan.getPayCode());
        dto.setPayName(plan.getPayName());
        dto.setPaymentMode(plan.getPaymentMode());
        dto.setPaymentConfig(plan.getPaymentConfig());
        return dto;
    }

    /* ============================== 维度匹配 ============================== */

    private boolean matchProduct(PurchaseRule rule, Long productId) {
        return Objects.equals(rule.getProductId(), productId);
    }

    private boolean matchCustomer(PurchaseRule rule, String customerId, Integer customerType) {
        CustomerConfig cc = rule.getCustomerConfig();
        if (cc == null) {
            return false;
        }
        if (!Objects.equals(cc.getCustomerType(), customerType)) {
            return false;
        }
        // 黑名单优先
        if (CollectionUtils.isNotEmpty(cc.getBlackList()) && cc.getBlackList().contains(customerId)) {
            return false;
        }
        // 白名单存在时必须命中；为空表示不限制
        if (CollectionUtils.isNotEmpty(cc.getWhiteList()) && !cc.getWhiteList().contains(customerId)) {
            return false;
        }
        return true;
    }

    private boolean matchDeliveryType(PurchaseRule rule, Integer deliveryType) {
        return CollectionUtils.isNotEmpty(rule.getDeliveryTypeList())
                && rule.getDeliveryTypeList().contains(deliveryType);
    }

    private boolean matchTimeWindow(PurchaseRule rule, LocalDateTime now) {
        if (rule.getStartTime() != null && now.isBefore(rule.getStartTime())) {
            return false;
        }
        if (rule.getEndTime() != null && now.isAfter(rule.getEndTime())) {
            return false;
        }
        return true;
    }

    /**
     * 规则的 paymentPlanConfig 中是否存在与入参 paymentMode 相同的项
     */
    private boolean matchPaymentMode(PurchaseRule rule, Integer paymentMode) {
        if (CollectionUtils.isEmpty(rule.getPaymentPlanConfig())) {
            return false;
        }
        for (PaymentPlanConfig cfg : rule.getPaymentPlanConfig()) {
            if (Objects.equals(cfg.getPaymentMode(), paymentMode)) {
                return true;
            }
        }
        return false;
    }

    /* ============================== 支付方案解析 ============================== */

    /**
     * 维度过滤已在上游完成（含 paymentMode）。本方法仅做：
     * 取每条规则中匹配 paymentMode 的 paymentPlanId → 批量查 PurchasePaymentPlan 实体（供上层算金额用） → 组装 (rule, plan) 对。
     */
    private List<RulePlanPair> resolvePaymentPlans(List<PurchaseRule> matched, Integer paymentMode) {
        // 1. 每条 rule 取出匹配 paymentMode 的那个 paymentPlanId
        Map<PurchaseRule, Long> ruleToPlanId = new LinkedHashMap<>();
        for (PurchaseRule rule : matched) {
            for (PaymentPlanConfig cfg : rule.getPaymentPlanConfig()) {
                if (Objects.equals(cfg.getPaymentMode(), paymentMode)) {
                    Long pid = parseLongQuiet(cfg.getPaymentPlanId());
                    if (pid != null) {
                        ruleToPlanId.put(rule, pid);
                    }
                    break;
                }
            }
        }
        if (ruleToPlanId.isEmpty()) {
            return new ArrayList<>();
        }

        // 2. 批量查询 PurchasePaymentPlan 实体（带 paymentConfig，供上层算金额用）
        List<Long> planIds = ruleToPlanId.values().stream().distinct().collect(Collectors.toList());
        List<PurchasePaymentPlan> plans = purchasePaymentPlanRepository.listByIds(planIds);
        Map<Long, PurchasePaymentPlan> planMap = plans.stream()
                .collect(Collectors.toMap(PurchasePaymentPlan::getId, p -> p, (a, b) -> a));

        // 3. 组装 (rule, plan) 对；查不到 plan 实体的 rule 直接丢弃
        List<RulePlanPair> result = new ArrayList<>();
        for (Map.Entry<PurchaseRule, Long> entry : ruleToPlanId.entrySet()) {
            PurchasePaymentPlan plan = planMap.get(entry.getValue());
            if (plan != null) {
                result.add(new RulePlanPair(entry.getKey(), plan));
            }
        }
        return result;
    }

    /* ============================== 工具方法 ============================== */

    private void validateInput(String itemId, String customerId, Integer customerType,
                               Integer paymentMode, Integer deliveryType) {
        if (StringUtils.isBlank(itemId)) {
            throw PurchaseDomainException.ofIllegalParam("itemId 不能为空");
        }
        if (StringUtils.isBlank(customerId)) {
            throw PurchaseDomainException.ofIllegalParam("customerId 不能为空");
        }
        if (customerType==null) {
            throw PurchaseDomainException.ofIllegalParam("customerType 不能为空");
        }
        if (paymentMode == null) {
            throw PurchaseDomainException.ofIllegalParam("paymentMode 不能为空");
        }
        if (deliveryType == null) {
            throw PurchaseDomainException.ofIllegalParam("deliveryType 不能为空");
        }
    }

    private Long parseLong(String s, String fieldName) {
        try {
            return Long.parseLong(s);
        } catch (NumberFormatException e) {
            throw PurchaseDomainException.ofIllegalParam(fieldName + " 必须是数字: " + s);
        }
    }

    private Long parseLongQuiet(String s) {
        if (StringUtils.isBlank(s)) {
            return null;
        }
        try {
            return Long.parseLong(s);
        } catch (NumberFormatException e) {
            return null;
        }
    }



    private static class RulePlanPair {
        final PurchaseRule rule;
        final PurchasePaymentPlan plan;

        RulePlanPair(PurchaseRule rule, PurchasePaymentPlan plan) {
            this.rule = rule;
            this.plan = plan;
        }
    }
}
