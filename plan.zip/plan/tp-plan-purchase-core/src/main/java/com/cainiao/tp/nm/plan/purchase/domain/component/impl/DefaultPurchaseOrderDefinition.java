package com.cainiao.tp.nm.plan.purchase.domain.component.impl;

import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PurchaseOrderCreateParam;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PurchaseOrderProductSnapshotCreateParam;
import com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseDeliveryTypeEnum;
import com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchasePaymentModeEnum;
import com.cainiao.tp.nm.plan.purchase.domain.component.PurchaseOrderDefinition;
import com.cainiao.tp.nm.plan.purchase.domain.exception.PurchaseDomainException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

/**
 * 默认订购订单定义实现 */
@Slf4j
@Component
public class DefaultPurchaseOrderDefinition implements PurchaseOrderDefinition {

    @Override
    public String bizType() {
        return "default";
    }

    @Override
    public String customType() {
        return "default";
    }

    @Override
    public void validCreate(PurchaseOrderCreateParam param) {
        // 1. 校验参数不为空
        if (null == param) {
            throw PurchaseDomainException.ofIllegalParam("创建参数不能为空");
        }

        // 2. 校验客户ID
        if (StringUtils.isBlank(param.getCustomId())) {
            throw PurchaseDomainException.ofIllegalParam("客户ID不能为空");
        }

        // 3. 校验客户类型
        if (param.getCustomType()==null) {
            throw PurchaseDomainException.ofIllegalParam("客户类型不能为空");
        }

        // 4. 校验支付模式
        if (null == param.getPaymentMode()) {
            throw PurchaseDomainException.ofIllegalParam("支付模式不能为空");
        }
        validatePaymentMode(param.getPaymentMode());

        // 5. 校验发货类型
        if (null == param.getDeliveryType()) {
            throw PurchaseDomainException.ofIllegalParam("发货类型不能为空");
        }
        validateDeliveryType(param.getDeliveryType());

        // 6. 校验履约平台
        if (StringUtils.isBlank(param.getFulfillmentPlatform())) {
            throw PurchaseDomainException.ofIllegalParam("履约平台不能为空");
        }

        // 7. 校验下单人ID
        if (StringUtils.isBlank(param.getOwnerId())) {
            throw PurchaseDomainException.ofIllegalParam("下单人ID不能为空");
        }

        // 8. 校验下单人名称
        if (StringUtils.isBlank(param.getOwnerName())) {
            throw PurchaseDomainException.ofIllegalParam("下单人名称不能为空");
        }

        // 9. 校验商品快照列表
        if (CollectionUtils.isEmpty(param.getProductSnapshotList())) {
            throw PurchaseDomainException.ofIllegalParam("商品快照列表不能为空");
        }

        // 10. 校验每个商品快照
        List<PurchaseOrderProductSnapshotCreateParam> snapshotList = param.getProductSnapshotList();
        for (int i = 0; i < snapshotList.size(); i++) {
            PurchaseOrderProductSnapshotCreateParam snapshot = snapshotList.get(i);
            validateProductSnapshot(snapshot, i);
        }
    }

    /**
     * 校验商品快照
     * @param snapshot 商品快照
     * @param index 索引
     */
    private void validateProductSnapshot(PurchaseOrderProductSnapshotCreateParam snapshot, int index) {
        if (null == snapshot) {
            throw PurchaseDomainException.ofIllegalParam("商品快照不能为空，索引: " + index);
        }

        if (StringUtils.isBlank(snapshot.getProductId())) {
            throw PurchaseDomainException.ofIllegalParam("商品ID不能为空，索引: " + index);
        }

        if (StringUtils.isBlank(snapshot.getProductSkuId())) {
            throw PurchaseDomainException.ofIllegalParam("商品SKUID不能为空，索引: " + index);
        }

        if (null == snapshot.getQuantity() || snapshot.getQuantity() <= 0) {
            throw PurchaseDomainException.ofIllegalParam("购买数量必须大于0，索引: " + index);
        }

        if (null == snapshot.getUnitPrice() || snapshot.getUnitPrice().compareTo(BigDecimal.ZERO) <= 0) {
            throw PurchaseDomainException.ofIllegalParam("商品单价必须大于0，索引: " + index);
        }

        if (null == snapshot.getTotalAmount() || snapshot.getTotalAmount().compareTo(BigDecimal.ZERO) <= 0) {
            throw PurchaseDomainException.ofIllegalParam("商品总金额必须大于0，索引: " + index);
        }

        if (null == snapshot.getPayableAmount() || snapshot.getPayableAmount().compareTo(BigDecimal.ZERO) <= 0) {
            throw PurchaseDomainException.ofIllegalParam("商品应付金额必须大于0，索引: " + index);
        }
    }

    /**
     * 校验支付模式
     * @param paymentMode 支付模式
     */
    private void validatePaymentMode(Integer paymentMode) {
        boolean isValid = Arrays.stream(PurchasePaymentModeEnum.values())
                .anyMatch(mode -> mode.getCode().equals(paymentMode));
        if (!isValid) {
            throw PurchaseDomainException.ofIllegalParam("支付模式不合法: " + paymentMode);
        }
    }

    /**
     * 校验发货类型
     * @param deliveryType 发货类型
     */
    private void validateDeliveryType(Integer deliveryType) {
        boolean isValid = Arrays.stream(PurchaseDeliveryTypeEnum.values())
                .anyMatch(type -> type.getCode().equals(deliveryType));
        if (!isValid) {
            throw PurchaseDomainException.ofIllegalParam("发货类型不合法: " + deliveryType);
        }
    }
}
