package com.cainiao.tp.nm.plan.purchase.application.service;

import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.CabinetOrderDetailDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.PlaceOrderResultDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PlaceOrderParam;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PreCalculateOrderParam;


/**
 * 下单
 */
public interface CabinetPlaceOrderApplicationService {

    /**
     * 预计算下单
     * @param param pram
     * @param operation 操作人
     * @return return
     */
    CabinetOrderDetailDTO preCalculateOrder(PreCalculateOrderParam param, AbstractOperation operation);



    /**
     * 下单
     * @param param 下单
     * @param operation 操作人
     * @return return
     */
    PlaceOrderResultDTO placeOrder(PlaceOrderParam param, AbstractOperation operation);



}
