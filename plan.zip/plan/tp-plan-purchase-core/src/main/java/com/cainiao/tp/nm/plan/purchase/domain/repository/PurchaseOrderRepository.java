package com.cainiao.tp.nm.plan.purchase.domain.repository;

import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseOrder;

import java.util.Map;

/**
 * 订购订单仓储接口
 */
public interface PurchaseOrderRepository {

    /**
     * 根据ID查询订单
     * @param orderId 订单ID
     * @return 订单实体
     */
    PurchaseOrder findById(Long orderId);

    /**
     * 根据履约平台订单 ID 反查本地订单（兜底场景：MQ 上下文丢失 planOrderId 时通过已落库的关联关系反查）
     * @param fulfillmentPlatformOrderId 履约平台订单 ID
     * @return 订单实体，未找到返回 null
     */
    PurchaseOrder findByFulfillmentPlatformOrderId(String fulfillmentPlatformOrderId);

    /**
     * 保存订单
     * @param order 订单实体
     */
    void save(PurchaseOrder order);

    /**
     * 更新订单
     * @param order 订单实体
     */
    void update(PurchaseOrder order);

    /**
     * 删除订单及其关联的商品快照
     * @param orderId 订单ID
     */
    void deleteOrder(Long orderId);

    /**
     * 修改订单状态，并追加指定快照的 feature 内容
     * @param orderId 订单ID
     * @param status  新状态
     * @param snapshotId 要更新的快照ID
     * @param additionalFeature 要追加的 feature 内容（会合并到已有 feature Map 中）
     */
    void updateOrderStatusAndSnapshotFeature(Long orderId, Integer status, Long snapshotId, Map<String, String> additionalFeature);

    /**
     * 独立更新快照的 feature 内容（追加合并模式）
     * @param snapshotId 快照ID
     * @param additionalFeature 要追加的 feature 内容（会合并到已有 feature Map 中）
     */
    void updateSnapshotFeature(Long snapshotId, Map<String, String> additionalFeature);

}
