package com.cainiao.tp.nm.plan.purchase.common.util;

import com.cainiao.aladdin.lock.Lock;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import org.apache.commons.lang3.StringUtils;

/**
 * 采购下单相关的分布式锁工具类
 * <p>
 * 锁基础设施使用 Tair（{@link com.cainiao.tp.nm.plan.infra.port.policy.PolicyTairLockManager}）
 * 参考：http://tiddo.alibaba-inc.com/saas-tair/#/InstanceDetail?username=d72d7419535d4881 */
public class PurchasePlaceOrderLockUtils {

    /**
     * 分布式锁超时时间（单位：秒）
     */
    public static final int LOCK_EXPIRE_SECONDS = 30;

    /**
     * Tair namespace，与 PolicyLockUtils 保持一致
     */
    public static final int CNM_PLAN_LDB_NAMESPACE = 5783;

    /**
     * 柜子下单 - 人维度锁 key 前缀
     */
    public static final String CABINET_PLACE_ORDER_USER_LOCK_PREFIX = "tp_cnm_plan_cabinet_place_order_user_lock_";

    /**
     * 构造柜子下单的人维度分布式锁
     *
     * @param userKey 人维度标识（优先使用菜鸟账号ID，缺失时回退到 customerType:customerId）
     * @return Tair 分布式锁对象
     */
    public static Lock getCabinetPlaceOrderUserLock(String userKey) {
        AssertUtil.isTrue(StringUtils.isNotBlank(userKey), "下单加锁的人维度标识不能为空");
        Lock lock = new Lock(CABINET_PLACE_ORDER_USER_LOCK_PREFIX + userKey);
        lock.setNamespace(CNM_PLAN_LDB_NAMESPACE);
        lock.setExpire(LOCK_EXPIRE_SECONDS);
        return lock;
    }
}
