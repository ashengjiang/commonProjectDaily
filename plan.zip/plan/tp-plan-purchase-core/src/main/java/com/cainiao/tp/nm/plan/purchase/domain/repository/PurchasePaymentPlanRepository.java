package com.cainiao.tp.nm.plan.purchase.domain.repository;

import com.cainiao.tp.nm.plan.purchase.domain.model.PurchasePaymentPlan;

import java.util.List;

/**
 * 支付方案仓储接口 */
public interface PurchasePaymentPlanRepository {

    /**
     * 根据主键 id 获取支付方案
     *
     * @param id 主键
     * @return 支付方案（不存在时返回 null）
     */
    PurchasePaymentPlan getById(Long id);

    /**
     * 根据 id 列表批量查询支付方案
     *
     * @param ids id 列表
     * @return 支付方案列表
     */
    List<PurchasePaymentPlan> listByIds(List<Long> ids);
}
