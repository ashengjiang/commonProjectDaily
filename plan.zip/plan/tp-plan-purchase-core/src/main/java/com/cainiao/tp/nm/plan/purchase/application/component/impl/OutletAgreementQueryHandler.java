package com.cainiao.tp.nm.plan.purchase.application.component.impl;

import com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseCustomerTypeEnum;
import com.cainiao.tp.nm.plan.infra.port.dto.AgreementInfoAndSignDTO;
import com.cainiao.tp.nm.plan.infra.port.dto.param.ExpressAgreementParam;
import com.cainiao.tp.nm.plan.infra.port.dto.param.QueryAgreementParam;
import com.cainiao.tp.nm.plan.infra.port.dto.param.SignAgreementParam;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.TpsAgreementInfoDTO;
import com.cainiao.tp.nm.plan.infra.port.manager.TpsStationAgreementManager;
import com.cainiao.tp.nm.plan.infra.port.purchase.PurchaseAgreementManager;
import com.cainiao.tp.nm.plan.purchase.application.component.AgreementQueryHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * 网点协议查询处理器
 * <p>
 * 1. 通过 {@link TpsStationAgreementManager#queryByCode(String)} 拿协议详情（title/url）；
 * 2. 通过 {@link PurchaseAgreementManager#queryPurchaseAgreement(ExpressAgreementParam)} 判断签约状态。
 * 参数映射：QueryAgreementParam.customerId → expressId，customerCode → expressCode。
 * </p> */
@Slf4j
@Component
public class OutletAgreementQueryHandler implements AgreementQueryHandler {

    @Resource
    private TpsStationAgreementManager tpsStationAgreementManager;

    @Resource
    private PurchaseAgreementManager purchaseAgreementManager;

    @Override
    public Integer customerType() {
        return PurchaseCustomerTypeEnum.OUTLET.getCode();
    }

    @Override
    public AgreementInfoAndSignDTO query(QueryAgreementParam param) {
        log.info("OutletAgreementQueryHandler#query, param={}", param);
        // 网点协议查询暂未实现，避免下游 NPE，统一抛 UnsupportedOperationException
        throw new UnsupportedOperationException("网点协议查询暂未支持，customerType=" + customerType());
    }

    @Override
    public Long sign(SignAgreementParam param) {
        log.info("OutletAgreementQueryHandler#sign, param={}", param);
        // 网点签约逻辑暂未实现，避免下游静默失败，统一抛 UnsupportedOperationException
        throw new UnsupportedOperationException("网点协议签约暂未支持，customerType=" + customerType());
    }
}
