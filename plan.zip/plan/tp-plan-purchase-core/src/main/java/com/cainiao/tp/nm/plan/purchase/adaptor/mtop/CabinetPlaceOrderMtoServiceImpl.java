package com.cainiao.tp.nm.plan.purchase.adaptor.mtop;

import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.fastjson.JSON;
import com.cainiao.aladdin.env.SystemEnvEnum;
import com.cainiao.aladdin.env.SystemEnvUtil;
import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.aladdin.operation.SystemBizOperation;
import com.cainiao.aladdin.validate.utils.ValidateUtil;
import com.cainiao.sutee.commons.base.result.CnResult;
import com.cainiao.tp.nm.plan.api.purchase.adaptor.dto.CabinetMallConfigDTO;
import com.cainiao.tp.nm.plan.api.purchase.adaptor.dto.CabinetOrderEntityDTO;
import com.cainiao.tp.nm.plan.api.purchase.adaptor.service.CabinetPlaceOrderMtoService;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.*;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.ProductInfoResultDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.*;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.vo.CabinetProductInfoResultVO;
import com.cainiao.tp.nm.plan.api.purchase.common.constants.ProductAttributeEnum;
import com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseCategoryEnum;
import com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseCustomerTypeEnum;
import com.cainiao.tp.nm.plan.infra.port.common.constants.LoginEntityTypeEnum;
import com.cainiao.tp.nm.plan.infra.port.common.exception.PurchaseServiceException;
import com.cainiao.tp.nm.plan.infra.port.dto.AgreementInfoAndSignDTO;
import com.cainiao.tp.nm.plan.infra.port.dto.context.BasePermissionContext;
import com.cainiao.tp.nm.plan.infra.port.dto.context.ExpressPermissionContext;
import com.cainiao.tp.nm.plan.infra.port.dto.context.PermissionContext;
import com.cainiao.tp.nm.plan.infra.port.dto.context.StationPermissionContext;
import com.cainiao.tp.nm.plan.infra.port.dto.param.QueryAgreementParam;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.EntityLaunchEditParam;
import com.cainiao.tp.nm.plan.infra.port.purchase.MixContractManager;
import com.cainiao.tp.nm.plan.purchase.adaptor.component.login.MtopLogin;
import com.cainiao.tp.nm.plan.purchase.adaptor.component.login.MtopLoginContext;
import com.cainiao.tp.nm.plan.purchase.application.component.AgreementComponent;
import com.cainiao.tp.nm.plan.purchase.application.service.CabinetPlaceOrderApplicationService;
import com.cainiao.tp.nm.plan.purchase.application.service.ProductionApplicationService;
import com.cainiao.tp.nm.plan.purchase.common.util.ProductSpecsParser;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseRule;
import com.cainiao.tp.nm.plan.purchase.domain.model.valobj.AgreementConfig;
import com.cainiao.tp.nm.plan.purchase.domain.model.valobj.CabinetGridInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.ArrayList;
import java.util.stream.Collectors;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 柜子下单对外 MTOP 服务实现
 * <p>
 * 入口处统一处理登录态解析与权限校验，将客户身份信息回填到业务参数后委托 application service 处理。
 * 登录态解析逻辑参考 MTOPSessionUtil 的实现，封装为独立方法。
 * </p> */
@Slf4j
@HSFProvider(serviceInterface = CabinetPlaceOrderMtoService.class)
public class CabinetPlaceOrderMtoServiceImpl implements CabinetPlaceOrderMtoService {

    @Resource
    private CabinetPlaceOrderApplicationService cabinetPlaceOrderApplicationService;
    @Resource
    private ProductionApplicationService productionApplicationService;
    @Resource
    private MixContractManager mixContractManager;
    @Resource
    private AgreementComponent agreementComponent;


    @Override
    @MtopLogin
    public CnResult<CabinetProductInfoResultVO> infoList() {
        try{
            CabinetOrderEntityDTO loginEntity = getLoginEntity();
            log.info("CabinetPlaceOrderMtoServiceImpl.infoList, loginEntity={}", JSON.toJSONString(loginEntity));
            ProductInfoParam productInfoParam = new ProductInfoParam();
            productInfoParam.setCustomerId(loginEntity.getEntityId());
            productInfoParam.setCustomerType(loginEntity.getEntityType());
            productInfoParam.setCategoryId(PurchaseCategoryEnum.CABINET.getCode());

            AbstractOperation operation = buildOperation(loginEntity);
            ProductInfoResultDTO productInfoResult = productionApplicationService.getProductInfo(productInfoParam, operation);

            CabinetProductInfoResultVO resultVO = new CabinetProductInfoResultVO();
            if (productInfoResult == null || CollectionUtils.isEmpty(productInfoResult.getProductInfoList())) {
                resultVO.setProductInfoList(new ArrayList<>());
                return CnResult.succeed(resultVO);
            }
            List<CabinetProductInfoDTO> cabinetProductInfoList = productInfoResult.getProductInfoList().stream()
                    .map(this::convertToCabinetProductInfo)
                    .collect(Collectors.toList());
            resultVO.setProductInfoList(cabinetProductInfoList);
            return CnResult.succeed(resultVO);
        }catch (Exception e){
            log.error("placeOrder infoList error", e);
            return CnResult.fail("PLACE_ORDER_ERROR", e.getMessage());
        }
    }

    private CabinetProductInfoDTO convertToCabinetProductInfo(ProductInfoDTO productInfo) {
        CabinetProductInfoDTO cabinetProductInfo = new CabinetProductInfoDTO();
        cabinetProductInfo.setItemId(productInfo.getItemId());
        cabinetProductInfo.setItemTitle(productInfo.getItemTitle());
        cabinetProductInfo.setPictureUrl(productInfo.getPictureUrl());
        cabinetProductInfo.setDetailPicUrl(productInfo.getDetailPicUrl());
        cabinetProductInfo.setPrice(productInfo.getPrice());
        cabinetProductInfo.setHaveInventory(true);

        if (org.apache.commons.collections4.CollectionUtils.isNotEmpty(productInfo.getAttributeOptionList())) {
            // 从 attributeOptionList 中提取 cabinet_type 作为 skuTitle
            productInfo.getAttributeOptionList().stream()
                    .filter(attr -> ProductAttributeEnum.CABINET_TYPE.getCode().equals(attr.getCode()))
                    .findFirst()
                    .ifPresent(attr -> cabinetProductInfo.setSkuTitle(attr.getValue()));

            // 从 attributeOptionList 中提取 grid_info JSON 并解析为 gridList
            String gridInfoJson = productInfo.getAttributeOptionList().stream()
                    .filter(attr -> ProductAttributeEnum.GRID_INFO.getCode().equals(attr.getCode()))
                    .map(AttributeOptionDTO::getValue)
                    .findFirst()
                    .orElse(null);

            List<CabinetGridInfo> gridInfoList = ProductSpecsParser.parseGridList(gridInfoJson);
            if (org.apache.commons.collections4.CollectionUtils.isNotEmpty(gridInfoList)) {
                List<CabinetProductInfoDTO.CabinetGridInfo> gridList = gridInfoList.stream()
                        .map(grid -> {
                            CabinetProductInfoDTO.CabinetGridInfo gridDTO = new CabinetProductInfoDTO.CabinetGridInfo();
                            gridDTO.setGridType(grid.getGridType());
                            gridDTO.setSize(grid.getSize());
                            gridDTO.setNum(grid.getNum());
                            return gridDTO;
                        })
                        .collect(Collectors.toList());
                cabinetProductInfo.setGridList(gridList);
            }
        }
        return cabinetProductInfo;
    }



    @Override
    @MtopLogin
    public CnResult<PlaceOrderResultDTO> placeOrder(PlaceOrderParam param) {
        try {
            ValidateUtil.validate(param);
            checkUserPro();
            Long orderId = param.getOrderId();
            if(orderId<=0){
                param.setOrderId(null);
            }
            CabinetOrderEntityDTO loginEntity = getLoginEntity();
            log.info("placeOrder placeOrder,param={},userInfo={}",JSON.toJSONString(param),JSON.toJSONString(loginEntity));
            param.setCustomerId(loginEntity.getEntityId());
            param.setCustomerType(loginEntity.getEntityType());
            param.setCustomerCode(loginEntity.getEntityCode());
            param.setCnUserAccountId(loginEntity.getCnUserAccountId());
            param.setSign(true);
            AbstractOperation operation = buildOperation(loginEntity);
            PlaceOrderResultDTO placeOrderResultDTO = cabinetPlaceOrderApplicationService.placeOrder(param, operation);
            placeOrderResultDTO.setEmployeeId(loginEntity.getEmployeeId());
            return CnResult.succeed(placeOrderResultDTO);
        } catch (Exception e) {
            log.error("placeOrder placeOrder error,param={}",JSON.toJSONString(param), e);
            return CnResult.fail("PLACE_ORDER_ERROR", e.getMessage());
        }
    }


    private AbstractOperation buildOperation( CabinetOrderEntityDTO loginEntity ){
        return new SystemBizOperation(loginEntity.getUserId(), loginEntity.getUserName());
    }

    @Override
    @MtopLogin
    public CnResult<CabinetOrderDetailDTO> preCalculateOrder(PreCalculateOrderParam param) {
        try {
            CabinetOrderEntityDTO loginEntity = getLoginEntity();
            param.setCustomerId(loginEntity.getEntityId());
            param.setCustomerType(loginEntity.getEntityType());
            param.setCustomerCode(loginEntity.getEntityCode());
            AbstractOperation operation = buildOperation(loginEntity);
            CabinetOrderDetailDTO result = cabinetPlaceOrderApplicationService.preCalculateOrder(param, operation);
            return CnResult.succeed(result);
        } catch (Exception e) {
            log.error("preCalculateOrder 异常, param={}", JSON.toJSONString(param), e);
            return CnResult.fail("PRE_CALCULATE_ORDER_ERROR", e.getMessage());
        }
    }


    @Override
    @MtopLogin
    public CnResult<Boolean> expressAgreementSubscription(ExpressAgreementSubscriptionParam param) {
        try {
            ValidateUtil.validate(param);
            CabinetOrderEntityDTO loginEntity = getLoginEntity();
            Integer entityType = loginEntity.getEntityType();
            if(LoginEntityTypeEnum.EXPRESS.getType().equals(entityType)){
                throw new RuntimeException("非网点登录,无法调用该服务");
            }
            EntityLaunchEditParam editParam = new EntityLaunchEditParam();
            editParam.setServiceCode(param.getAgreementCode());
            editParam.setLaunchEntityType("EXPRESS_OUT_ID");
            editParam.setLaunchEntityCode(loginEntity.getEntityCode());
            SystemEnvEnum env = SystemEnvUtil.getEnv();
            editParam.setEnv(env.getEnv());
            editParam.setStatus(1);

            mixContractManager.editEntityLaunchRelation(Collections.singletonList(editParam));
            log.info("expressAgreementSubscription 成功, agreementCode={}, expressId={}",
                    param.getAgreementCode(), loginEntity.getEntityId());
            return CnResult.succeed(true);
        } catch (Exception e) {
            log.error("expressAgreementSubscription 异常, agreementCode={}", param.getAgreementCode(), e);
            return CnResult.fail("EXPRESS_AGREEMENT_SUBSCRIPTION_ERROR", e.getMessage());
        }
    }

    @Override
    @MtopLogin
    public CnResult<AgreementInfoDTO> queryAgreementInfo() {
        CabinetOrderEntityDTO loginEntity = getLoginEntity();
        AgreementInfoDTO agreementInfoDTO = new AgreementInfoDTO();
        if(PurchaseCustomerTypeEnum.OUTLET.getCode().equals(loginEntity.getEntityType())){
            return CnResult.succeed(agreementInfoDTO);
        }
        ProductInfoParam param=new ProductInfoParam();
        param.setCustomerId(loginEntity.getEntityId());
        param.setCustomerType(loginEntity.getEntityType());
        param.setCategoryId(PurchaseCategoryEnum.CABINET.getCode());
        List<PurchaseRule> productionRule = productionApplicationService.getProductionRule(param);
        if(CollectionUtils.isEmpty(productionRule)){
            return CnResult.succeed(agreementInfoDTO);
        }
        List<AgreementConfig> agreementConfigs = productionRule.stream().map(PurchaseRule::getAgreementConfig).filter(CollectionUtils::isNotEmpty).findFirst().orElse(null);
        if(CollectionUtils.isEmpty(agreementConfigs)){
            return CnResult.succeed(agreementInfoDTO);
        }
        //现在逻辑只查询第一个
        AgreementConfig agreementConfig = agreementConfigs.get(0);
        agreementInfoDTO.setAgreementCode(agreementConfig.getAgreementCode());

        QueryAgreementParam agreementParam = new QueryAgreementParam();
        agreementParam.setAgreementCode(agreementConfig.getAgreementCode());
        agreementParam.setCustomerId(loginEntity.getEntityId());
        agreementParam.setCustomerCode(loginEntity.getEntityCode());
        agreementParam.setCustomerType(loginEntity.getEntityType());

        AgreementInfoAndSignDTO agreementInfoAndSignDTO = agreementComponent.queryAgreementInfoAndSigned(agreementParam);
        if (agreementInfoAndSignDTO != null) {
            agreementInfoDTO.setAgreementCode(agreementInfoAndSignDTO.getAgreementCode());
            agreementInfoDTO.setAgreementName(agreementInfoAndSignDTO.getAgreementName());
            agreementInfoDTO.setAgreementUrl(agreementInfoAndSignDTO.getAgreementUrl());
            agreementInfoDTO.setAgreementId(agreementInfoAndSignDTO.getAgreementId() == null
                    ? null : String.valueOf(agreementInfoAndSignDTO.getAgreementId()));
            agreementInfoDTO.setSign(agreementInfoAndSignDTO.getSigned());
        }
        return CnResult.succeed(agreementInfoDTO);
    }

    public void checkUserPro(){
        CabinetOrderEntityDTO loginEntity = getLoginEntity();
        Boolean canBuy = loginEntity.getCanBuy();
        if(!canBuy){
            throw PurchaseServiceException.ofIllegalParam("无权限，无法购买");
        }
    }




    private CabinetOrderEntityDTO getLoginEntity(){
        PermissionContext<BasePermissionContext> context = MtopLoginContext.getContext();

        CabinetOrderEntityDTO cabinetOrderEntityDTO = new CabinetOrderEntityDTO();

        //判断是网点登录还是站点登录
        boolean isExpress = LoginEntityTypeEnum.EXPRESS.getType().equals(context.getLoginType());

        List<Long> greyCityList = CabinetMallConfigDTO.getINSTANCE().getGreyCityList();
        List<String> greyEntityIdList = CabinetMallConfigDTO.getINSTANCE().getGreyEntityIdList();
        if(isExpress) {
            //网点登录
            ExpressPermissionContext expressContext =(ExpressPermissionContext) context.getContext();

            boolean cabinetBuyer = expressContext.isExpressCabinetBuyer();
            cabinetOrderEntityDTO.setEntityId(expressContext.getExpressId().toString());
            boolean inGreyCity = org.apache.commons.collections.CollectionUtils.isEmpty(greyCityList) || greyCityList.contains(expressContext.getCityCode());
            boolean inGreyEntity = org.apache.commons.collections.CollectionUtils.isEmpty(greyEntityIdList) || greyEntityIdList.contains(expressContext.getExpressId().toString());
            boolean inGrey = inGreyCity && inGreyEntity;
            cabinetOrderEntityDTO.setCanView(inGrey && cabinetBuyer);
            cabinetOrderEntityDTO.setCanBuy(inGrey && cabinetBuyer);
            cabinetOrderEntityDTO.setEntityCode(expressContext.getExpressCode());
            cabinetOrderEntityDTO.setUserId(expressContext.getUserId());
            cabinetOrderEntityDTO.setUserName(expressContext.getUserName());
            cabinetOrderEntityDTO.setEmployeeId(expressContext.getCnEmployeeId());
        }else{
            StationPermissionContext stationContext =(StationPermissionContext) context.getContext();
            Integer authType = stationContext.getAuthType();
            boolean isCorporation = stationContext.getCorporation();

            boolean isAdmin = authType == 2;
            //仅负责人与管理员可查看

            boolean inGreyCity = org.apache.commons.collections.CollectionUtils.isEmpty(greyCityList) || greyCityList.contains(Long.valueOf(stationContext.getCityCode()));
            boolean inGreyEntity = CollectionUtils.isEmpty(greyEntityIdList) || greyEntityIdList.contains(stationContext.getStationId());
            boolean inGrey = inGreyCity && inGreyEntity;

            cabinetOrderEntityDTO.setCanView(inGrey && (isCorporation || isAdmin));
            //仅负责人可购买
            cabinetOrderEntityDTO.setCanBuy(inGrey && isCorporation);
            cabinetOrderEntityDTO.setEntityId(stationContext.getStationId());
            cabinetOrderEntityDTO.setUserId(stationContext.getUserId());
            cabinetOrderEntityDTO.setUserName(stationContext.getUserName());
            cabinetOrderEntityDTO.setEmployeeId(stationContext.getEmployeeId()+"");
            cabinetOrderEntityDTO.setUserType(stationContext.getUserType()+"");
            cabinetOrderEntityDTO.setCnUserAccountId(stationContext.getCnAccountId());
        }

        cabinetOrderEntityDTO.setEntityType(isExpress ? LoginEntityTypeEnum.EXPRESS.getType() : LoginEntityTypeEnum.STATION.getType());
        return cabinetOrderEntityDTO;
    }




}
