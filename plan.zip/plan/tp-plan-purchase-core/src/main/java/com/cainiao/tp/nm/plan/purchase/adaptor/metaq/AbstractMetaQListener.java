package com.cainiao.tp.nm.plan.purchase.adaptor.metaq;

import com.alibaba.rocketmq.client.consumer.listener.ConsumeConcurrentlyContext;
import com.alibaba.rocketmq.client.consumer.listener.ConsumeConcurrentlyStatus;
import com.alibaba.rocketmq.client.consumer.listener.MessageListenerConcurrently;
import com.alibaba.rocketmq.common.message.MessageExt;
import com.cainiao.aladdin.log.AladdinMapLog;
import com.cainiao.aladdin.log.BizType;
import com.cainiao.aladdin.log.utils.AladdinLogUtil;
import com.taobao.eagleeye.EagleEye;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.List;

/**
 * metaq接收基类
 */
@Slf4j
public abstract class AbstractMetaQListener<T> implements MessageListenerConcurrently {


    @Override
    public ConsumeConcurrentlyStatus consumeMessage(List<MessageExt> msgs, ConsumeConcurrentlyContext context) {
        if (CollectionUtils.isEmpty(msgs)) {
            return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
        }

        //对于压测链路不作处理
        final boolean isTestMode = StringUtils.equals("1", EagleEye.getUserData("t"));
        if (isTestMode) {
            return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
        }

        AladdinMapLog mapLog = AladdinLogUtil.newMapLog(getClass().getSimpleName() + ".consumeMessage", BizType.DEFAULT);
        mapLog.addParam("topic", msgs.get(0).getTopic());

        for (MessageExt msgExt : msgs) {
            mapLog.addParam("tag", msgExt.getTags());
            mapLog.addParam("messageId", msgExt.getMsgId());
            mapLog.addParam("data", new String(msgExt.getBody()));
            try {
                //1.获取消息实体
                T event = this.convert(msgExt);
                if (null == event) {
                    return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
                }

                //2.消息直接过滤掉
                if (!this.filter(event, msgExt)) {
                    mapLog.addParam("filterResult", false);
                    return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
                }

                //3.处理逻辑
                boolean success = doConsume(event, msgExt);
                mapLog.addParam("doConsume", success);
                mapLog.setReturnVal(success);

                if (!success) {
                    AladdinLogUtil.log(log, mapLog);
                    return ConsumeConcurrentlyStatus.RECONSUME_LATER;
                }

                AladdinLogUtil.log(log, mapLog);
            } catch (Throwable aladdinBizException) {
                mapLog.setReturnVal("consumer_error");
                AladdinLogUtil.log(log, aladdinBizException, mapLog);
                return ConsumeConcurrentlyStatus.RECONSUME_LATER;
            }
        }
        return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
    }

    /**
     * 消息转换为实体
     *
     * @param message
     * @return
     */
    protected abstract T convert(MessageExt message);

    /**
     * 消息过滤
     *
     * @param event
     * @param message
     * @return
     */
    protected abstract boolean filter(T event, MessageExt message);

    /**
     * 业务逻辑
     *
     * @param event
     * @param message
     * @return
     */
    protected abstract boolean doConsume(T event, MessageExt message);

}
