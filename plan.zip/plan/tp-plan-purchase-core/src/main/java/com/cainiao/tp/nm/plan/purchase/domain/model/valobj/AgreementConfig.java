package com.cainiao.tp.nm.plan.purchase.domain.model.valobj;

import com.cainiao.aladdin.domain.BaseBean;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 协议配置值对象
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class AgreementConfig extends BaseBean {

    /**
     * 协议code
     */
    private String agreementCode;

    /**
     * 顺序
     */
    private Integer sortOrder;

    /**
     * 是否需要审批
     */
    private Boolean needApproval;

}
