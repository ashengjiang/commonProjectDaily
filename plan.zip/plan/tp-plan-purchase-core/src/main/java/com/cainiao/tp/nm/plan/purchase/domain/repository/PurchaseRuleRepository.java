package com.cainiao.tp.nm.plan.purchase.domain.repository;

import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseRule;

import java.util.List;

/**
 * 订购规则仓储接口
 * 数据来源于 Diamond 配置 */
public interface PurchaseRuleRepository {

    /**
     * 获取所有订购规则
     *
     * @return 订购规则列表
     */
    List<PurchaseRule> getAllRules();

    /**
     * 根据类目 ID 获取订购规则列表
     *
     * @param categoryId 类目 ID
     * @return 订购规则列表
     */
    List<PurchaseRule> getRulesByCategoryId(Integer categoryId);
}
