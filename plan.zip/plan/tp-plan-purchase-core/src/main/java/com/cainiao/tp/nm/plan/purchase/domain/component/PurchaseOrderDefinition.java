package com.cainiao.tp.nm.plan.purchase.domain.component;

import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PurchaseOrderCreateParam;

/**
 * 订购订单定义扩展点 */
public interface PurchaseOrderDefinition {

    /**
     * 业务类型
     */
    String bizType();

    /**
     * 客户类型
     */
    String customType();

    /**
     * 创建前校验
     * @param param 创建参数
     */
    void validCreate(PurchaseOrderCreateParam param);

}
