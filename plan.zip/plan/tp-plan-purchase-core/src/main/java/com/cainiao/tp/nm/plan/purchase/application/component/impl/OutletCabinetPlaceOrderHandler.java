package com.cainiao.tp.nm.plan.purchase.application.component.impl;

import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.AgreementInfoDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.CertifiedEnterpriseInfoDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.PlaceOrderResultDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.PurchaseRuleDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PlaceOrderParam;
import com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseCustomerTypeEnum;
import com.cainiao.tp.nm.plan.infra.port.common.exception.PurchaseServiceException;
import com.cainiao.tp.nm.plan.infra.port.dto.param.ExpressAgreementParam;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.PlatContractSimpleInfoDTO;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.ServiceProductInfoDTO;
import com.cainiao.tp.nm.plan.infra.port.purchase.*;
import com.cainiao.tp.nm.plan.purchase.application.component.CabinetPlaceOrderContext;
import com.cainiao.tp.nm.plan.purchase.common.util.PurchaseThreadPoolUtil;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseOrder;
import com.cainiao.tp.nm.plan.purchase.domain.model.valobj.PurchaseOrderProductSnapshot;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * 网点柜子下单处理器
 * <p>
 * 网点下单需通过 4 项前置门槛（任一未通过即不创建订单，直接返回 4 项检查结果给前端引导用户补足）：
 * <ol>
 *   <li>企业实名认证（{@link EnterpriseCertifyManager}）</li>
 *   <li>资金账户绑定（{@link StationExpressManager}）</li>
 *   <li>购买协议签署（{@link PurchaseAgreementManager}）</li>
 *   <li>支付宝代扣协议签署（{@link PaymentSignManager}）</li>
 * </ol>
 * 4 项检查通过 {@link CompletableFuture} 并行执行以降低 RT。
 * </p> */
@Slf4j
@Component
public class OutletCabinetPlaceOrderHandler extends AbstractCabinetPlaceOrderHandler {

    @Resource
    private EnterpriseCertifyManager enterpriseCertifyManager;

    @Resource
    private StationExpressManager stationExpressManager;

    @Resource
    private PaymentSignManager paymentSignManager;

    @Resource
    private PurchaseAgreementManager purchaseAgreementManager;

    @Resource
    private PurchaseThreadPoolUtil purchaseThreadPoolUtil;
    @Resource
    private ServiceProductInfoManager serviceProductInfoManager;
    @Resource
    private PlatContractReadManager platContractReadManager;

    @Override
    public Integer customerType() {
        return PurchaseCustomerTypeEnum.OUTLET.getCode();
    }


    @Override
    protected PlaceOrderResultDTO checkPreConditions(CabinetPlaceOrderContext context) {
        PlaceOrderParam param = context.getParam();
        PlaceOrderResultDTO result = new PlaceOrderResultDTO();
        AbstractOperation operation = context.getOperation();
        PurchaseOrder order = context.getOrder();

        //实名认证
        CompletableFuture<Boolean> identityFuture = CompletableFuture
                .supplyAsync(() -> safeCheckIdentityVerification(param), purchaseThreadPoolUtil.getExecutor());
        //资金账户绑定
        CompletableFuture<Boolean> fundAccountFuture = CompletableFuture
                .supplyAsync(() -> safeCheckBindFundingAccount(param), purchaseThreadPoolUtil.getExecutor());
        //购买协议
        CompletableFuture<AgreementInfoDTO> purchaseAgreementFuture = CompletableFuture
                .supplyAsync(() -> safeCheckPurchaseAgreement(param,order), purchaseThreadPoolUtil.getExecutor());

        //支付宝代扣协议
        CompletableFuture<AgreementInfoDTO> alipayAgreementFuture = CompletableFuture
                .supplyAsync(() -> safeCheckAlipayWithholdingAgreement(param, operation), purchaseThreadPoolUtil.getExecutor());

        try {
            CompletableFuture.allOf(identityFuture, fundAccountFuture,
                    purchaseAgreementFuture, alipayAgreementFuture).join();
            result.setIdentityVerification(identityFuture.get());
            result.setBindFundingAccount(fundAccountFuture.get());
            result.setPurchaseAgreement(purchaseAgreementFuture.get());
            result.setAlipayWithholdingAgreement(alipayAgreementFuture.get());
        } catch (Exception e) {
            log.error("placeOrder 前置条件检查异常，customerId={}", param.getCustomerId(), e);
            throw PurchaseServiceException.of("前置条件检查异常: " + e.getMessage(), e);
        }
        return result;
    }

    @Override
    protected boolean isAllPreConditionsPassed(PlaceOrderResultDTO result) {
        return Boolean.TRUE.equals(result.getIdentityVerification())
                && Boolean.TRUE.equals(result.getBindFundingAccount())
                && result.getPurchaseAgreement() != null
                && Boolean.TRUE.equals(result.getPurchaseAgreement().getSign())
                && result.getAlipayWithholdingAgreement() != null
                && Boolean.TRUE.equals(result.getAlipayWithholdingAgreement().getSign());
    }

    /**
     * 实名认证检查：调用 EnterpriseCertifyManager
     * 任一前置依赖缺失（如 customerCode 为空、cpCode 反查未对接）时视为未认证。</p>
     */
    private boolean safeCheckIdentityVerification(PlaceOrderParam param) {
        if (StringUtils.isBlank(param.getCustomerCode())) {
            log.warn("实名认证检查跳过：customerCode 为空，customerId={}", param.getCustomerId());
            return false;
        }
        try {
            String customerCode = param.getCustomerCode();
            if (StringUtils.isBlank(customerCode)) {
                log.warn("实名认证检查跳过：cpCode 查询为空，customerId={}", param.getCustomerId());
                return false;
            }
            CertifiedEnterpriseInfoDTO certified = enterpriseCertifyManager
                    .queryCertifiedEnterprise(customerCode);
            return certified != null && StringUtils.isNotBlank(certified.getRegCode());
        } catch (Exception e) {
            log.error("实名认证检查异常，customerId={}, customerCode={}",
                    param.getCustomerId(), param.getCustomerCode(), e);
            return false;
        }
    }

    /**
     * 资金账户绑定检查：customerId 即网点 expressId
     */
    private boolean safeCheckBindFundingAccount(PlaceOrderParam param) {
        try {
            com.cainiao.tp.nm.plan.infra.port.dto.purchase.StationExpressInfoDTO expressInfo =
                    stationExpressManager.queryExpressInfo(Long.parseLong(param.getCustomerId()));
            return expressInfo != null
                    && org.apache.commons.lang3.StringUtils.isNotBlank(expressInfo.getCorporationAlipayId());
        } catch (Exception e) {
            log.error("资金账户绑定检查异常，customerId={}", param.getCustomerId(), e);
            return false;
        }
    }

    /**
     * 当前仅解析出来一个协议code
     * 购买协议签署检查：调用 {@link PurchaseAgreementManager}
     * <p>下游若未对接，会抛 {@link UnsupportedOperationException}；本方法将其降级为「未签署」，
     * 保证 placeOrder 主流程不会因占位实现而冒泡崩溃。</p>
     */
    private AgreementInfoDTO safeCheckPurchaseAgreement(PlaceOrderParam param, PurchaseOrder order) {
        try {
            ExpressAgreementParam agreementParam = getExpressAgreementParam(param, order);

            boolean sign = purchaseAgreementManager.queryPurchaseAgreement(agreementParam);
            AgreementInfoDTO agreementInfoDTO=new AgreementInfoDTO();
            agreementInfoDTO.setSign(sign);
            ServiceProductInfoDTO serviceProductInfoDTO = serviceProductInfoManager.queryServiceProductInfoByCode(agreementParam.getAgreementCode());
            agreementInfoDTO.setAgreementCode(agreementParam.getAgreementCode());
            agreementInfoDTO.setAgreementName(serviceProductInfoDTO.getServiceName());
            agreementInfoDTO.setAgreementUrl(serviceProductInfoDTO.getServiceContent());
            PlatContractSimpleInfoDTO simplePlatContract = platContractReadManager.getSimplePlatContract(agreementParam.getAgreementCode());
            if(simplePlatContract==null){
                throw PurchaseServiceException.ofIllegalParam("购买协议检查无法签署请联系管理员" );
            }
            agreementInfoDTO.setAgreementId(simplePlatContract.getContractId()+"");
            return agreementInfoDTO;
        } catch (Exception e) {
            log.error("购买协议检查异常，customerId={}, customerType={}",
                    param.getCustomerId(), param.getCustomerType(), e);
          throw PurchaseServiceException.ofIllegalParam("购买协议检查异常" );
        }
    }

    private  ExpressAgreementParam getExpressAgreementParam(PlaceOrderParam param, PurchaseOrder order) {
        List<PurchaseOrderProductSnapshot> productSnapshotList = order.getProductSnapshotList();
        PurchaseOrderProductSnapshot purchaseOrderProductSnapshot = productSnapshotList.get(0);
        PurchaseRuleDTO purchaseRule = purchaseOrderProductSnapshot.getPurchaseRule();

        //默认只有一个协议，后续在修改这段代码
        List<String> agreementCodeList = purchaseRule.getAgreementCodeList();
        String agreementCode = agreementCodeList.get(0);

        ExpressAgreementParam agreementParam = new ExpressAgreementParam();
        agreementParam.setExpressId(param.getCustomerId());
        agreementParam.setExpressCode(param.getCustomerCode());
        agreementParam.setAgreementCode(agreementCode);
        return agreementParam;
    }

    /**
     * 支付宝代扣协议签署检查
     */
    private AgreementInfoDTO safeCheckAlipayWithholdingAgreement(PlaceOrderParam param, AbstractOperation operation) {
        AgreementInfoDTO agreement = new AgreementInfoDTO();
        try {
            com.cainiao.tp.nm.plan.infra.port.dto.purchase.StationExpressInfoDTO expressInfo =
                    stationExpressManager.queryExpressInfo(Long.parseLong(param.getCustomerId()));
            if (expressInfo == null||expressInfo.getCorporationCnuserId()==null) {
                log.warn("支付宝代扣协议检查跳过：网点信息查询为空，customerId={}", param.getCustomerId());
                agreement.setSign(Boolean.FALSE);
                return agreement;
            }
            boolean signed = paymentSignManager.isSigned(expressInfo.getCorporationCnuserId());
            agreement.setSign(signed);
        } catch (Exception e) {
            log.error("支付宝代扣协议检查异常，customerId={}", param.getCustomerId(), e);
            agreement.setSign(Boolean.FALSE);
        }
        return agreement;
    }
}
