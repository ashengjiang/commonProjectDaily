package com.cainiao.tp.nm.plan.purchase.adaptor.component.login;

import com.cainiao.tp.nm.plan.infra.port.dto.context.BasePermissionContext;
import com.cainiao.tp.nm.plan.infra.port.dto.context.PermissionContext;

/**
 * MTOP 登录态 ThreadLocal 上下文工具类
 * <p>
 * 由 {@link MtopLoginAspect} 在方法执行前设置，方法执行后清除。
 * 业务代码通过 {@link #getContext()} 获取当前请求的登录态信息。
 * </p>
 */
public class MtopLoginContext {

    private static final ThreadLocal<PermissionContext<BasePermissionContext>> CONTEXT_HOLDER = new ThreadLocal<>();

    public static void setContext(PermissionContext<BasePermissionContext> context) {
        CONTEXT_HOLDER.set(context);
    }

    public static PermissionContext<BasePermissionContext> getContext() {
        return CONTEXT_HOLDER.get();
    }

    public static void remove() {
        CONTEXT_HOLDER.remove();
    }
}
