package com.cainiao.tp.nm.plan.purchase.adaptor.metaq.event;

import lombok.Data;

import java.io.Serializable;

/**
 * 万里牛节点状态变更 MQ 消息体
 * <p>
 * 消息示例：{"changeTime":"2026-05-13 21:36:35","orderId":"260513860832421432284247","orderStatus":"1","supplierID":"13854003"}
 * </p> */
@Data
public class DuoNiuNodeStatusChangeEvent implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 状态变更时间
     */
    private String changeTime;

    /**
     * 万里牛订单 ID
     */
    private String orderId;

    /**
     * 万里牛订单状态：
     */
    private String orderStatus;

    /**
     * 供应商 ID
     */
    private String supplierID;
}
