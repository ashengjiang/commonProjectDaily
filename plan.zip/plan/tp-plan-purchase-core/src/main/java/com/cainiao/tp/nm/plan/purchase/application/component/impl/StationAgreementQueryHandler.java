package com.cainiao.tp.nm.plan.purchase.application.component.impl;

import com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseCustomerTypeEnum;
import com.cainiao.tp.nm.plan.infra.port.common.exception.PurchaseServiceException;
import com.cainiao.tp.nm.plan.infra.port.dto.AgreementInfoAndSignDTO;
import com.cainiao.tp.nm.plan.infra.port.dto.param.QueryAgreementParam;
import com.cainiao.tp.nm.plan.infra.port.dto.param.SignAgreementParam;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.TpsAgreementCreateAndSignDTO;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.TpsAgreementInfoDTO;
import com.cainiao.tp.nm.plan.infra.port.manager.TpsStationAgreementManager;
import com.cainiao.tp.nm.plan.purchase.application.component.AgreementQueryHandler;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * 站点协议查询处理器
 * <p>
 * 1. 通过 {@link TpsStationAgreementManager#queryByCode(String)} 拿协议详情；
 * 2. 通过 {@link TpsStationAgreementManager#isSigned(String, Long)} 判断站点签约状态。
 * 参数映射：QueryAgreementParam.customerId（站点 ID 字符串）→ stationId（Long）。
 * </p> */
@Slf4j
@Component
public class StationAgreementQueryHandler implements AgreementQueryHandler {

    @Resource
    private TpsStationAgreementManager tpsStationAgreementManager;

    @Override
    public Integer customerType() {
        return PurchaseCustomerTypeEnum.STATION.getCode();
    }

    @Override
    public AgreementInfoAndSignDTO query(QueryAgreementParam param) {
        log.info("StationAgreementQueryHandler#query, param={}", param);

        AgreementInfoAndSignDTO result = new AgreementInfoAndSignDTO();
        result.setAgreementCode(param.getAgreementCode());

        // 1. 协议详情
        TpsAgreementInfoDTO agreementInfo = tpsStationAgreementManager.queryByCode(param.getAgreementCode());
        if (agreementInfo != null) {
            result.setAgreementId(agreementInfo.getId());
            result.setAgreementName(agreementInfo.getTitle());
            result.setAgreementUrl(agreementInfo.getContentUrl());
        }

        // 2. 签约状态（站点签约校验需要 agreementCode + stationId）
        Long stationId = parseStationId(param.getCustomerId());
        boolean signed = stationId != null
                && tpsStationAgreementManager.isSigned(param.getAgreementCode(), stationId);
        result.setSigned(signed);

        return result;
    }

    @Override
    public Long sign(SignAgreementParam param) {
        log.info("StationAgreementQueryHandler#sign, param={}", param);
        if (param == null) {
            throw PurchaseServiceException.ofIllegalParam("param 不能为空");
        }
        if (StringUtils.isBlank(param.getAgreementCode())) {
            throw PurchaseServiceException.ofIllegalParam("agreementCode 不能为空");
        }
        if (StringUtils.isBlank(param.getUserId())) {
            throw PurchaseServiceException.ofIllegalParam("userId 不能为空");
        }
        if (param.getUserType() == null) {
            throw PurchaseServiceException.ofIllegalParam("userType 不能为空");
        }
        if (StringUtils.isBlank(param.getCustomerId())) {
            throw PurchaseServiceException.ofIllegalParam("customerId（stationId）不能为空");
        }

        // 先用 agreementCode 查询协议详情，拿到 agreementId
        TpsAgreementInfoDTO agreementInfo = tpsStationAgreementManager.queryByCode(param.getAgreementCode());
        if (agreementInfo == null || agreementInfo.getId() == null) {
            log.warn("StationAgreementQueryHandler#sign 协议不存在, agreementCode={}", param.getAgreementCode());
            throw PurchaseServiceException.ofIllegalParam("协议不存在: " + param.getAgreementCode());
        }

        TpsAgreementCreateAndSignDTO signDTO = new TpsAgreementCreateAndSignDTO();
        signDTO.setAgreementId(agreementInfo.getId());
        signDTO.setUserId(param.getUserId());
        signDTO.setUserType(param.getUserType());
        signDTO.setStationId(param.getCustomerId());
        signDTO.setOutBizId(param.getOutBizId());
        signDTO.setFeature(param.getFeature());

        return tpsStationAgreementManager.createAndSign(signDTO);
    }

    private Long parseStationId(String customerId) {
        if (StringUtils.isBlank(customerId)) {
            log.warn("StationAgreementQueryHandler#query customerId 为空");
            return null;
        }
        try {
            return Long.valueOf(customerId);
        } catch (NumberFormatException e) {
            log.warn("StationAgreementQueryHandler#query customerId 非法 Long, customerId={}", customerId);
            return null;
        }
    }
}
