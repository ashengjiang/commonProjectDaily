package com.cainiao.tp.nm.plan.purchase.adaptor.metaq.event;

import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

/**
 * 订购客户 SN 码关联 MQ 消息体
 * <p>
 * topic: purchase_customer_sn, tag: relation
 * </p> */
@Data
@Builder
public class PurchaseCustomerSnEvent implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 客户 ID
     */
    private String customId;

    /**
     * 客户类型：1=站点，10=网点
     */
    private Integer customType;

    /**
     * SN 码
     */
    private String snCode;

    /**
     * 发货时间，格式：yyyy-MM-dd HH:mm:ss
     */
    private String deliveryTime;
}
