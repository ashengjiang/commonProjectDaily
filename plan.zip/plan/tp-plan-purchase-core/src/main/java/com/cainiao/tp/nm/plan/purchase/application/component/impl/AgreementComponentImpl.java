package com.cainiao.tp.nm.plan.purchase.application.component.impl;

import com.cainiao.tp.nm.plan.infra.port.common.exception.PurchaseServiceException;
import com.cainiao.tp.nm.plan.infra.port.dto.AgreementInfoAndSignDTO;
import com.cainiao.tp.nm.plan.infra.port.dto.param.QueryAgreementParam;
import com.cainiao.tp.nm.plan.infra.port.dto.param.SignAgreementParam;
import com.cainiao.tp.nm.plan.purchase.application.component.AgreementComponent;
import com.cainiao.tp.nm.plan.purchase.application.component.AgreementQueryHandler;
import com.cainiao.tp.nm.plan.purchase.application.component.factory.AgreementQueryHandlerFactory;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Component
public class AgreementComponentImpl implements AgreementComponent {

    @Resource
    private AgreementQueryHandlerFactory agreementQueryHandlerFactory;

    @Override
    public AgreementInfoAndSignDTO queryAgreementInfoAndSigned(QueryAgreementParam param) {
        if (param == null) {
            throw PurchaseServiceException.ofIllegalParam("param 不能为空");
        }
        if (param.getCustomerType() == null) {
            throw PurchaseServiceException.ofIllegalParam("customerType 不能为空");
        }
        AgreementQueryHandler handler = agreementQueryHandlerFactory.getHandler(param.getCustomerType());
        return handler.query(param);
    }

    @Override
    public Long sign(SignAgreementParam param) {
        if (param == null) {
            throw PurchaseServiceException.ofIllegalParam("param 不能为空");
        }
        if (StringUtils.isBlank(param.getCustomerType())) {
            throw PurchaseServiceException.ofIllegalParam("customerType 不能为空");
        }
        Integer customerType;
        try {
            customerType = Integer.valueOf(param.getCustomerType());
        } catch (NumberFormatException e) {
            throw PurchaseServiceException.ofIllegalParam("customerType 非法: " + param.getCustomerType());
        }
        AgreementQueryHandler handler = agreementQueryHandlerFactory.getHandler(customerType);
        return handler.sign(param);
    }
}
