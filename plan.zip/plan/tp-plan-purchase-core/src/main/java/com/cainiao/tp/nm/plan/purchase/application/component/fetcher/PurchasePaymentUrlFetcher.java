package com.cainiao.tp.nm.plan.purchase.application.component.fetcher;

import com.cainiao.tp.nm.plan.purchase.application.component.CabinetPlaceOrderContext;

/**
 * 订购付款链接拉取策略（按履约平台路由）。
 * <p>每个实现类声明自己负责的 {@code platform}（与 {@link com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseFulfillmentPlatformEnum#getCode()}
 * 一致），由 {@link com.cainiao.tp.nm.plan.purchase.application.component.factory.PurchasePaymentUrlFetcherFactory}
 * 在启动期收集入路由表；下单流程按订单行的 {@code productSkuSource} 聚合后逐组路由。</p> */
public interface PurchasePaymentUrlFetcher {

    /**
     * 当前策略支持的履约平台
     * （对应 {@link com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseFulfillmentPlatformEnum} 的 code）
     */
    String supportedPlatform();

    /**
     * 按当前平台拉取付款链接。
     *
     * @param context 下单上下文（含订单实体、入参、操作人等完整信息，便于实现类按需提取所需数据）
     * @return 付款链接拉取结果
     */
    PaymentUrlFetchResult fetch(CabinetPlaceOrderContext context);
}
