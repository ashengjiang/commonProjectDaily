package com.cainiao.tp.nm.plan.purchase.domain.service.impl;

import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PurchaseOrderCreateParam;
import com.cainiao.tp.nm.plan.purchase.domain.component.PurchaseOrderDefinition;
import com.cainiao.tp.nm.plan.purchase.domain.component.factory.PurchaseOrderDefinitionFactory;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseOrder;
import com.cainiao.tp.nm.plan.purchase.domain.repository.PurchaseOrderRepository;
import com.cainiao.tp.nm.plan.purchase.domain.service.PurchaseOrderDomainService;
import com.cainiao.tp.nm.plan.purchase.domain.service.param.PurchaseOrderStatusUpdateParam;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * 订购订单领域服务实现 */
@Slf4j
@Component
public class PurchaseOrderDomainServiceImpl implements PurchaseOrderDomainService {

    @Resource
    private PurchaseOrderRepository purchaseOrderRepository;

    @Resource
    private PurchaseOrderDefinitionFactory purchaseOrderDefinitionFactory;

    @Override
    public PurchaseOrder createOrder(PurchaseOrderCreateParam param) {
        // 1. 获取定义扩展点
        PurchaseOrderDefinition definition = purchaseOrderDefinitionFactory.getDefinition(
                "default", param.getCustomType());

        // 2. 创建前校验
        definition.validCreate(param);

        // 3. 创建订单实体
        PurchaseOrder order = PurchaseOrder.create(param);

        // 4. 保存订单
        purchaseOrderRepository.save(order);

        log.info("创建订购订单成功，orderId: {}", order.getId());
        return order;
    }

    @Override
    public PurchaseOrder queryOrderById(Long orderId) {
        PurchaseOrder order = purchaseOrderRepository.findById(orderId);
        if (order == null) {
            log.info("订单不存在，orderId: {}", orderId);
        }
        return order;
    }

    @Override
    public PurchaseOrder updateOrderStatus(PurchaseOrderStatusUpdateParam param) {
        PurchaseOrder order = purchaseOrderRepository.findById(param.getOrderId());
        if (order == null) {
            throw new IllegalArgumentException("订单不存在，orderId: " + param.getOrderId());
        }

        // 状态机校验（状态不可逆）
        if (null != param.getStatus()) {
            validateStatusTransition(order.getStatus(), param.getStatus());
        }

        // 更新支付信息（付款金额 + 付款时间），支持在高状态时补充缺失的付款信息
        if (null != param.getPaymentTime()) {
            if (order.getPaymentTime() == null) {
                order.updatePayment(param.getActualPaymentAmount(), param.getPaymentTime());
            }
        }

        // 更新发货信息，支持在高状态时补充缺失的发货时间
        if (null != param.getShippingTime()) {
            if (order.getShippingTime() == null) {
                order.updateShipping(param.getShippingTime());
            }
        }

        // 更新签收信息
        if (null != param.getSignTime()) {
            if (order.getSignTime() == null) {
                order.updateSign(param.getSignTime());
            }
        }

        // 最后更新状态（放在时间更新之后，确保时间字段先填充）
        if (null != param.getStatus()) {
            order.updateStatus(param.getStatus());
        }
        String existingFulfillmentOrderId = param.getExistingFulfillmentOrderId();
        if (StringUtils.isNotBlank(existingFulfillmentOrderId)) {
            String fulfillmentPlatformOrderId = order.getFulfillmentPlatformOrderId();
            if (StringUtils.isBlank(fulfillmentPlatformOrderId)) {
                order.setFulfillmentPlatformOrderId(existingFulfillmentOrderId);
            }
        }

        purchaseOrderRepository.update(order);

        log.info("更新订单成功，orderId: {}, status: {}, actualPaymentAmount: {}, paymentTime: {}, shippingTime: {}, signTime: {}",
                param.getOrderId(), param.getStatus(), param.getActualPaymentAmount(), param.getPaymentTime(),
                param.getShippingTime(), param.getSignTime());
        return order;
    }

    /**
     * 状态机校验：状态不可逆，目标状态码必须 >= 当前状态码，否则视为非法回退
     *
     * <p>合法的状态流转路径：
     * <ul>
     *   <li>CREATE → SIGNING / PAYING</li>
     *   <li>SIGNING → SIGNED</li>
     *   <li>SIGNED → PAYING</li>
     *   <li>PAYING → PAID</li>
     *   <li>PAID → SHIPPED</li>
     *   <li>SHIPPED → RECEIVED</li>
     * </ul>
     *
     * @param currentStatus 当前状态码
     * @param targetStatus  目标状态码
     */
    private void validateStatusTransition(Integer currentStatus, Integer targetStatus) {
        if (currentStatus == null || targetStatus == null) {
            return;
        }
        // 状态不可逆：目标状态码必须大于等于当前状态码
        if (targetStatus < currentStatus) {
            throw new IllegalStateException(
                    "状态流转异常（状态不可逆），当前状态: " + currentStatus + ", 目标状态: " + targetStatus);
        }
    }

}
