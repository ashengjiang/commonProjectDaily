package com.cainiao.tp.nm.plan.purchase.domain.model;

import com.cainiao.aladdin.domain.BaseBean;
import lombok.Builder;
import lombok.Getter;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Map;

/**
 * 订购支付单实体
 */
@Getter
@Builder
public class PurchasePaymentOrder extends BaseBean {

    /**
     * 主键
     */
    private Long id;

    /**
     * 订购订单ID
     */
    private Long orderId;

    /**
     * 支付模式：1=全款、10=贷款、20=租赁
     */
    private Integer paymentMode;

    /**
     * 支付状态 {@link com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchasePaymentOrderStatusEnum}
     */
    private Integer status;

    /**
     * 应付金额/元
     */
    private BigDecimal payableAmount;

    /**
     * 实际已支付金额/元
     */
    private BigDecimal actualPaymentAmount;

    /**
     * 首次支付时间
     */
    private LocalDateTime firstPaymentTime;

    /**
     * 最终支付完成时间
     */
    private LocalDateTime paymentCompletedTime;

    /**
     * 支付计划
     */
    private String payPlan;

    /**
     * 扩展字段
     */
    private Map<String, String> feature;

    /**
     * 创建时间
     */
    private LocalDateTime gmtCreate;

    /**
     * 修改时间
     */
    private LocalDateTime gmtModified;

}
