package com.cainiao.tp.nm.plan.purchase.adaptor.service;

import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.sutee.commons.base.result.CnResult;
import com.cainiao.tp.nm.plan.api.purchase.adaptor.dto.HashOrderDTO;
import com.cainiao.tp.nm.plan.api.purchase.adaptor.dto.HashOrderParam;
import com.cainiao.tp.nm.plan.api.purchase.adaptor.service.PurchaseOrderForOutService;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.PurchaseOrderInfoDTO;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.PurchaseOrderQueryDTO;
import com.cainiao.tp.nm.plan.infra.port.purchase.PurchaseOrderManager;
import org.apache.commons.lang3.StringUtils;

import javax.annotation.Resource;
import java.util.List;

@HSFProvider(serviceInterface = PurchaseOrderForOutService.class)
public class PurchaseOrderForOutServiceImpl implements PurchaseOrderForOutService {


    @Resource
    private PurchaseOrderManager purchaseOrderManager;

    @Override
    public CnResult<HashOrderDTO> hashOrder(HashOrderParam hashOrderParam, AbstractOperation operation) {
        if (hashOrderParam == null) {
            return CnResult.fail("PARAM_NULL", "hashOrderParam 不能为空");
        }
        if (StringUtils.isBlank(hashOrderParam.getCustomerId()) || StringUtils.isBlank(hashOrderParam.getCustomerType())) {
            return CnResult.fail("PARAM_INVALID", "customerId 和 customerType 不能为空");
        }
        PurchaseOrderQueryDTO purchaseOrderQueryDTO = new PurchaseOrderQueryDTO();
        purchaseOrderQueryDTO.setCustomId(hashOrderParam.getCustomerId());
        purchaseOrderQueryDTO.setCustomType(hashOrderParam.getCustomerType());
        List<PurchaseOrderInfoDTO> purchaseOrderInfoDTOList = purchaseOrderManager.queryList(purchaseOrderQueryDTO);
        HashOrderDTO hashOrderDTO = new HashOrderDTO();
        if (purchaseOrderInfoDTOList.isEmpty()) {
            hashOrderDTO.setHashOrder(false);
            return CnResult.succeed(hashOrderDTO);
        }
        PurchaseOrderInfoDTO purchaseOrderInfoDTO = purchaseOrderInfoDTOList.stream().filter(dto -> StringUtils.isNotBlank(dto.getFulfillmentPlatformOrderId())).findFirst().orElse(null);
        hashOrderDTO.setHashOrder(purchaseOrderInfoDTO != null);
        return CnResult.succeed(hashOrderDTO);
    }
}
