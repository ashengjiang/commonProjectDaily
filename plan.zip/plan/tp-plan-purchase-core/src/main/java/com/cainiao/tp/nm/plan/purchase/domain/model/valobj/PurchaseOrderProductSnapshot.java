package com.cainiao.tp.nm.plan.purchase.domain.model.valobj;

import com.alibaba.fastjson.JSON;
import com.cainiao.aladdin.domain.BaseBean;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.PurchasePaymentPlanDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.PurchaseRuleDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PurchaseOrderProductSnapshotCreateParam;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;

/**
 * 订购订单商品快照值对象
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class PurchaseOrderProductSnapshot extends BaseBean {

    /**
     * 主键
     */
    private Long id;

    /**
     * 订单ID
     */
    private Long orderId;

    /**
     * 商品ID
     */
    private String productId;

    /**
     * 商品SKUID
     */
    private String productSkuId;

    /**
     * 商品SKU来源
     */
    private String productSkuSource;

    /**
     * 商品标题
     */
    private String productTitle;

    /**
     * 商品说明
     */
    private String remake;

    /**
     * 商品规格说明
     */
    private String productSpecification;

    /**
     * 购买数量
     */
    private Integer quantity;

    /**
     * 商品单价/元
     */
    private BigDecimal unitPrice;

    /**
     * 总金额
     */
    private BigDecimal totalAmount;

    /**
     * 应付金额
     */
    private BigDecimal payableAmount;

    /**
     * 订购规则（命中规则的 DTO 快照）
     */
    private PurchaseRuleDTO purchaseRule;

    /**
     * 订购支付方案（命中规则下匹配的支付方案 DTO 快照）
     */
    private PurchasePaymentPlanDTO purchasePaymentPlan;

    /**
     * 扩展字段
     */
    private String feature;

    /**
     * 创建商品快照
     * @param param 创建参数
     * @return 商品快照值对象
     */
    public static PurchaseOrderProductSnapshot create(PurchaseOrderProductSnapshotCreateParam param) {
        PurchaseOrderProductSnapshot snapshot = new PurchaseOrderProductSnapshot();
        snapshot.setProductId(param.getProductId());
        snapshot.setProductSkuId(param.getProductSkuId());
        snapshot.setProductSkuSource(param.getProductSkuSource());
        snapshot.setProductTitle(param.getProductTitle());
        snapshot.setRemake(param.getRemake());
        snapshot.setProductSpecification(param.getProductSpecification());
        snapshot.setQuantity(param.getQuantity());
        snapshot.setUnitPrice(param.getUnitPrice());
        snapshot.setTotalAmount(param.getTotalAmount());
        snapshot.setPayableAmount(param.getPayableAmount());
        snapshot.setPurchaseRule(param.getPurchaseRule());
        snapshot.setPurchasePaymentPlan(param.getPurchasePaymentPlan());
        snapshot.setFeature(JSON.toJSONString(param.getFeature()));
        return snapshot;
    }

}
