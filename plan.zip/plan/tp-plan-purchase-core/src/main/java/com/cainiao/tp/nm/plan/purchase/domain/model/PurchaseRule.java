package com.cainiao.tp.nm.plan.purchase.domain.model;

import com.cainiao.aladdin.domain.BaseBean;
import com.cainiao.tp.nm.plan.purchase.domain.model.valobj.AgreementConfig;
import com.cainiao.tp.nm.plan.purchase.domain.model.valobj.CustomerConfig;
import com.cainiao.tp.nm.plan.purchase.domain.model.valobj.PaymentPlanConfig;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * 订购规则值对象
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class PurchaseRule extends BaseBean {

    /**
     * 主键
     */
    private Long id;

    /**
     * 产品ID
     */
    private Long productId;

    /**
     * 类目
     */
    private Integer categoryId;

    /**
     * 产品sku
     */
    private Long skuId;

    /**
     * 客户配置
     */
    private CustomerConfig customerConfig;

    /**
     * 协议信息
     */
    private List<AgreementConfig> agreementConfig;

    /**
     * 支付信息
     */
    private List<PaymentPlanConfig> paymentPlanConfig;

    /**
     * 提货类型 1=自提 10=商家物流
     */
    private List<Integer> deliveryTypeList;

    /**
     * 开始时间
     */
    private LocalDateTime startTime;

    /**
     * 结束时间
     */
    private LocalDateTime endTime;

    /**
     * 优先级
     */
    private int level;
}
