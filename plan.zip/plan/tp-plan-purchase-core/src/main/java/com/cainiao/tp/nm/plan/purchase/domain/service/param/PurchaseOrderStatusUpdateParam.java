package com.cainiao.tp.nm.plan.purchase.domain.service.param;

import com.cainiao.aladdin.validate.annotations.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Map;

/**
 * 更新订单参数
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PurchaseOrderStatusUpdateParam {

    /**
     * 订单ID
     */
    @NotNull
    private Long orderId;

    /**
     * 新状态
     */
    @NotNull
    private Integer status;

    /**
     * 操作人ID
     */
    @NotNull
    private String operateId;
    /**
     * 操作人名称
     */
    @NotNull
    private String operateName;

    /**
     * 实际支付金额
     */
    private BigDecimal actualPaymentAmount;

    /**
     * 支付时间
     */
    private LocalDateTime paymentTime;

    /**
     * 发货时间
     */
    private LocalDateTime shippingTime;

    /**
     * 签收时间
     */
    private LocalDateTime signTime;

    /**
     * 履约订单ID
     */
    private String existingFulfillmentOrderId;


    /**
     * 扩展字段
     */
    Map<String, String> feature;



}
