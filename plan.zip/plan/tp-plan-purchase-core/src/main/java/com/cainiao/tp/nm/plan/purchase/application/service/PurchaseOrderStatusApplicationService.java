package com.cainiao.tp.nm.plan.purchase.application.service;

import com.cainiao.tp.nm.plan.infra.port.dto.purchase.DuoNiuOrderDetailDTO;

import java.util.List;

/**
 * 订购订单状态变更应用服务
 * <p>
 * 封装万里牛状态变更相关的订单查询、状态更新、SN 码处理等操作
 * </p> */
public interface PurchaseOrderStatusApplicationService {

    /**
     * 处理万里牛订单状态变更
     * <p>
     * 包含：校验履约订单 ID、映射状态、更新时间、处理 SN 码、发送 MQ 消息
     * </p>
     *
     * @param planOrderId 本地订单 ID
     * @param dnOrderId   万里牛订单 ID
     * @param dnStatus    万里牛订单状态（2=待发货, 3=已发货, 4=已收货）
     * @param orderDetail 万里牛订单详情
     * @param changeTime  状态变更时间（yyyy-MM-dd HH:mm:ss）
     * @return true=处理成功, false=处理失败
     */
    boolean processStatusChange(Long planOrderId, String dnOrderId, String dnStatus,
                                DuoNiuOrderDetailDTO orderDetail, String changeTime);

    /**
     * 检查万里牛订单商品是否属于我们的 SKU
     *
     * @param skuIds 万里牛订单商品的 skuId 列表
     * @return 匹配到的 skuId 列表（空列表表示不属于我们）
     */
    List<String> checkSkuBelongsToUs(List<String> skuIds);
}
