package com.cainiao.tp.nm.plan.purchase.application.component.impl;

import com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseCustomerTypeEnum;
import com.cainiao.tp.nm.plan.infra.port.dto.param.QueryAgreementParam;
import com.cainiao.tp.nm.plan.infra.port.dto.param.SignAgreementParam;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;

/**
 * OutletAgreementQueryHandler 单元测试
 * <p>
 * 当前网点协议查询/签约能力未上线，要求两个方法均抛 UnsupportedOperationException，避免下游 NPE 或静默失败。
 * </p> */
@RunWith(MockitoJUnitRunner.class)
public class OutletAgreementQueryHandlerTest {

    @InjectMocks
    private OutletAgreementQueryHandler handler;

    @Test
    public void customerType_shouldReturnOutletCode() {
        assertEquals(PurchaseCustomerTypeEnum.OUTLET.getCode(), handler.customerType());
    }

    @Test(expected = UnsupportedOperationException.class)
    public void query_shouldThrowUnsupportedOperationException() {
        QueryAgreementParam param = new QueryAgreementParam();
        param.setAgreementCode("EXP_AGR_001");
        param.setCustomerId("100001");
        param.setCustomerType(PurchaseCustomerTypeEnum.OUTLET.getCode());

        handler.query(param);
    }

    @Test(expected = UnsupportedOperationException.class)
    public void sign_shouldThrowUnsupportedOperationException() {
        SignAgreementParam param = new SignAgreementParam();
        param.setAgreementCode("EXP_AGR_001");
        param.setCustomerId("100001");
        param.setUserId("U001");
        param.setUserType(1);

        handler.sign(param);
    }
}
