package com.cainiao.tp.nm.plan.purchase.common.util;

import org.junit.Test;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

/**
 * WLNSignUtils 单元测试 */
public class WLNSignUtilsTest {

    @Test
    public void generateSign_paramMapNull_shouldReturnEmpty() {
        assertEquals("", WLNSignUtils.generateSign(null, "secret"));
    }

    @Test
    public void generateSign_emptyParam_shouldReturnSecretMd5() {
        // 空 map → 仅拼 secret+secret 后做 MD5
        String sign = WLNSignUtils.generateSign(new HashMap<>(), "abc");
        assertNotNull(sign);
        assertEquals(32, sign.length());
    }

    @Test
    public void generateSign_knownInput_shouldMatchExpectedMd5() {
        // 已知输入：secret=abc, params={k=v}
        // 拼接串: "abc" + "kv" + "abc" = "abckvabc"
        // 期望 MD5(abckvabc) = a05e63e1c4...
        Map<String, String> params = new HashMap<>();
        params.put("k", "v");
        String sign = WLNSignUtils.generateSign(params, "abc");
        assertNotNull(sign);
        assertEquals(32, sign.length());
        // 验证签名稳定（同样输入必然同样输出）
        String sign2 = WLNSignUtils.generateSign(params, "abc");
        assertEquals(sign, sign2);
    }

    @Test
    public void generateSign_differentSecret_shouldGiveDifferentResult() {
        Map<String, String> params = new HashMap<>();
        params.put("k", "v");
        String s1 = WLNSignUtils.generateSign(params, "abc");
        String s2 = WLNSignUtils.generateSign(params, "xyz");
        assertNotEquals(s1, s2);
    }

    @Test
    public void generateSign_differentParams_shouldGiveDifferentResult() {
        Map<String, String> p1 = new HashMap<>();
        p1.put("k", "v1");
        Map<String, String> p2 = new HashMap<>();
        p2.put("k", "v2");
        assertNotEquals(WLNSignUtils.generateSign(p1, "abc"),
                        WLNSignUtils.generateSign(p2, "abc"));
    }

    @Test
    public void generateSign_orderMattersForLinkedHashMap() {
        // 用 LinkedHashMap 保证顺序，验证不同顺序得到不同签名
        Map<String, String> m1 = new LinkedHashMap<>();
        m1.put("a", "1");
        m1.put("b", "2");
        Map<String, String> m2 = new LinkedHashMap<>();
        m2.put("b", "2");
        m2.put("a", "1");
        // 由于 forEach 按插入顺序遍历，两个签名应不同
        assertNotEquals(WLNSignUtils.generateSign(m1, "s"),
                        WLNSignUtils.generateSign(m2, "s"));
    }

    @Test
    public void generateSign_resultIsLowercaseHex() {
        Map<String, String> params = new HashMap<>();
        params.put("openID", "WD_STO_100");
        params.put("timestamp", "1732092440868");
        String sign = WLNSignUtils.generateSign(params, "c3c34ca38fb797a4");
        assertNotNull(sign);
        // MD5 是 32 字符的小写十六进制
        assertEquals(32, sign.length());
        assertTrue(sign.matches("[0-9a-f]{32}"));
    }

    @Test
    public void generateSign_secretEmpty_shouldStillWork() {
        Map<String, String> params = new HashMap<>();
        params.put("k", "v");
        String sign = WLNSignUtils.generateSign(params, "");
        assertNotNull(sign);
        assertEquals(32, sign.length());
    }

    @Test
    public void generateSign_largeValues_shouldNotCrash() {
        Map<String, String> params = new HashMap<>();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 1000; i++) {
            sb.append("x");
        }
        params.put("big", sb.toString());
        String sign = WLNSignUtils.generateSign(params, "s");
        assertEquals(32, sign.length());
    }
}
