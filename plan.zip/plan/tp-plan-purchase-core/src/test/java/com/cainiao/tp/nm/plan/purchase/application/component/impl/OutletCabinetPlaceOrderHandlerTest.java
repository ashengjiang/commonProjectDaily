package com.cainiao.tp.nm.plan.purchase.application.component.impl;

import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.aladdin.operation.SystemBizOperation;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.AgreementInfoDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.CertifiedEnterpriseInfoDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.PlaceOrderResultDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.PurchaseRuleDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PlaceOrderParam;
import com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseCustomerTypeEnum;
import com.cainiao.tp.nm.plan.infra.port.common.exception.PurchaseServiceException;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.PlatContractSimpleInfoDTO;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.ServiceProductInfoDTO;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.StationExpressInfoDTO;
import com.cainiao.tp.nm.plan.infra.port.purchase.EnterpriseCertifyManager;
import com.cainiao.tp.nm.plan.infra.port.purchase.PaymentSignManager;
import com.cainiao.tp.nm.plan.infra.port.purchase.PlatContractReadManager;
import com.cainiao.tp.nm.plan.infra.port.purchase.PurchaseAgreementManager;
import com.cainiao.tp.nm.plan.infra.port.purchase.ServiceProductInfoManager;
import com.cainiao.tp.nm.plan.infra.port.purchase.StationExpressManager;
import com.cainiao.tp.nm.plan.purchase.application.component.CabinetPlaceOrderContext;
import com.cainiao.tp.nm.plan.purchase.common.util.PurchaseThreadPoolUtil;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseOrder;
import com.cainiao.tp.nm.plan.purchase.domain.model.valobj.PurchaseOrderProductSnapshot;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Collections;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

/**
 * OutletCabinetPlaceOrderHandler 单元测试
 * <p>
 * 验证网点专属的 4 项并行前置校验逻辑：
 * 1. customerType 返回 OUTLET
 * 2. 4 项检查的全部组合（全通过 / 个别失败 / 全失败）
 * 3. 各项检查的异常降级行为
 * 4. customerCode 为空时 → 实名/资金账户检查直接 false
 * 5. isAllPreConditionsPassed 4 项与逻辑
 * </p> */
@RunWith(MockitoJUnitRunner.class)
public class OutletCabinetPlaceOrderHandlerTest {

    @InjectMocks
    private OutletCabinetPlaceOrderHandler handler;

    @Mock private EnterpriseCertifyManager enterpriseCertifyManager;
    @Mock private StationExpressManager stationExpressManager;
    @Mock private PaymentSignManager paymentSignManager;
    @Mock private PurchaseAgreementManager purchaseAgreementManager;
    @Mock private PurchaseThreadPoolUtil purchaseThreadPoolUtil;
    @Mock private ServiceProductInfoManager serviceProductInfoManager;
    @Mock private PlatContractReadManager platContractReadManager;

    private AbstractOperation operation;
    private Executor executor;

    private static final String CUSTOMER_ID = "100";
    private static final String CUSTOMER_CODE = "OUTLET_001";
    private static final String AGREEMENT_CODE = "AGR_001";

    @Before
    public void setUp() {
        operation = new SystemBizOperation(1L, "tester");
        // 用同步 / 单线程池避免测试不稳定
        executor = Executors.newFixedThreadPool(4);
        when(purchaseThreadPoolUtil.getExecutor()).thenReturn(executor);
    }

    /* ============================== customerType ============================== */

    @Test
    public void customerType_shouldReturnOutlet() {
        assertEquals(PurchaseCustomerTypeEnum.OUTLET.getCode(), handler.customerType());
    }

    /* ============================== isAllPreConditionsPassed ============================== */

    @Test
    public void isAllPreConditionsPassed_allTrue_shouldReturnTrue() {
        PlaceOrderResultDTO r = buildResult(true, true, true, true);
        assertTrue(handler.isAllPreConditionsPassed(r));
    }

    @Test
    public void isAllPreConditionsPassed_identityFalse_shouldReturnFalse() {
        PlaceOrderResultDTO r = buildResult(false, true, true, true);
        assertFalse(handler.isAllPreConditionsPassed(r));
    }

    @Test
    public void isAllPreConditionsPassed_fundAccountFalse_shouldReturnFalse() {
        PlaceOrderResultDTO r = buildResult(true, false, true, true);
        assertFalse(handler.isAllPreConditionsPassed(r));
    }

    @Test
    public void isAllPreConditionsPassed_purchaseAgreementFalse_shouldReturnFalse() {
        PlaceOrderResultDTO r = buildResult(true, true, false, true);
        assertFalse(handler.isAllPreConditionsPassed(r));
    }

    @Test
    public void isAllPreConditionsPassed_alipayWithholdingFalse_shouldReturnFalse() {
        PlaceOrderResultDTO r = buildResult(true, true, true, false);
        assertFalse(handler.isAllPreConditionsPassed(r));
    }

    @Test
    public void isAllPreConditionsPassed_purchaseAgreementNull_shouldReturnFalse() {
        PlaceOrderResultDTO r = buildResult(true, true, true, true);
        r.setPurchaseAgreement(null);
        assertFalse(handler.isAllPreConditionsPassed(r));
    }

    @Test
    public void isAllPreConditionsPassed_alipayWithholdingNull_shouldReturnFalse() {
        PlaceOrderResultDTO r = buildResult(true, true, true, true);
        r.setAlipayWithholdingAgreement(null);
        assertFalse(handler.isAllPreConditionsPassed(r));
    }

    /* ============================== checkPreConditions：全通过 ============================== */

    @Test
    public void checkPreConditions_allChecksPass() {
        mockIdentityPass();
        mockFundAccountPass();
        mockAlipayWithholdingPass();
        mockPurchaseAgreementPass(true);

        PlaceOrderResultDTO result = handler.checkPreConditions(buildContext());

        assertTrue(result.getIdentityVerification());
        assertTrue(result.getBindFundingAccount());
        assertTrue(result.getPurchaseAgreement().getSign());
        assertTrue(result.getAlipayWithholdingAgreement().getSign());
        assertTrue(handler.isAllPreConditionsPassed(result));
    }

    /* ============================== 实名认证 ============================== */

    @Test
    public void checkPreConditions_customerCodeBlank_identityFalse() {
        PlaceOrderParam param = buildParam();
        param.setCustomerCode("");
        mockFundAccountPass();
        mockAlipayWithholdingPass();
        mockPurchaseAgreementPass(true);

        PlaceOrderResultDTO result = handler.checkPreConditions(buildContext(param));
        assertFalse(result.getIdentityVerification());
    }

    @Test
    public void checkPreConditions_certifyManagerReturnNull_identityFalse() {
        when(enterpriseCertifyManager.queryCertifiedEnterprise(anyString())).thenReturn(null);
        mockFundAccountPass();
        mockAlipayWithholdingPass();
        mockPurchaseAgreementPass(true);

        PlaceOrderResultDTO result = handler.checkPreConditions(buildContext());
        assertFalse(result.getIdentityVerification());
    }

    @Test
    public void checkPreConditions_certifyRegCodeBlank_identityFalse() {
        CertifiedEnterpriseInfoDTO info = new CertifiedEnterpriseInfoDTO();
        info.setRegCode("");
        when(enterpriseCertifyManager.queryCertifiedEnterprise(anyString())).thenReturn(info);
        mockFundAccountPass();
        mockAlipayWithholdingPass();
        mockPurchaseAgreementPass(true);

        PlaceOrderResultDTO result = handler.checkPreConditions(buildContext());
        assertFalse(result.getIdentityVerification());
    }

    @Test
    public void checkPreConditions_certifyThrows_identityFalse() {
        when(enterpriseCertifyManager.queryCertifiedEnterprise(anyString()))
                .thenThrow(new RuntimeException("RPC failed"));
        mockFundAccountPass();
        mockAlipayWithholdingPass();
        mockPurchaseAgreementPass(true);

        PlaceOrderResultDTO result = handler.checkPreConditions(buildContext());
        assertFalse(result.getIdentityVerification());
    }

    /* ============================== 资金账户绑定 ============================== */

    @Test
    public void checkPreConditions_expressInfoNull_fundAccountFalse() {
        mockIdentityPass();
        when(stationExpressManager.queryExpressInfo(anyLong())).thenReturn(null);
        // alipay 也会调 queryExpressInfo，干脆都 null → alipay 也走 sign=false
        mockPurchaseAgreementPass(true);

        PlaceOrderResultDTO result = handler.checkPreConditions(buildContext());
        assertFalse(result.getBindFundingAccount());
        // alipay 也会受影响
        assertFalse(result.getAlipayWithholdingAgreement().getSign());
    }

    @Test
    public void checkPreConditions_corporationAlipayIdBlank_fundAccountFalse() {
        mockIdentityPass();
        StationExpressInfoDTO info = new StationExpressInfoDTO();
        info.setCorporationAlipayId(""); // 空 alipayId
        info.setCorporationCnuserId(null);
        when(stationExpressManager.queryExpressInfo(anyLong())).thenReturn(info);
        mockPurchaseAgreementPass(true);

        PlaceOrderResultDTO result = handler.checkPreConditions(buildContext());
        assertFalse(result.getBindFundingAccount());
    }

    @Test
    public void checkPreConditions_expressInfoThrows_fundAccountFalse() {
        mockIdentityPass();
        when(stationExpressManager.queryExpressInfo(anyLong()))
                .thenThrow(new RuntimeException("RPC failed"));
        mockPurchaseAgreementPass(true);

        PlaceOrderResultDTO result = handler.checkPreConditions(buildContext());
        assertFalse(result.getBindFundingAccount());
    }

    /* ============================== 购买协议 ============================== */

    @Test
    public void checkPreConditions_purchaseAgreementNotSigned_resultFalse() {
        mockIdentityPass();
        mockFundAccountPass();
        mockAlipayWithholdingPass();
        mockPurchaseAgreementPass(false);

        PlaceOrderResultDTO result = handler.checkPreConditions(buildContext());
        assertFalse(result.getPurchaseAgreement().getSign());
        assertEquals(AGREEMENT_CODE, result.getPurchaseAgreement().getAgreementCode());
    }

    @Test
    public void checkPreConditions_purchaseAgreementThrows_shouldBubbleUp() {
        // safeCheckPurchaseAgreement 抛 PurchaseServiceException 时会被 CompletableFuture 包裹，
        // 顶层 checkPreConditions 应包成 PurchaseServiceException 重新抛出
        mockIdentityPass();
        mockFundAccountPass();
        mockAlipayWithholdingPass();
        // 模拟 purchaseAgreementManager 查询异常 → 内部抛 PurchaseServiceException
        when(purchaseAgreementManager.queryPurchaseAgreement(any()))
                .thenThrow(new RuntimeException("query failed"));

        try {
            handler.checkPreConditions(buildContext());
            fail("期望抛出 PurchaseServiceException");
        } catch (PurchaseServiceException e) {
            // expected
        }
    }

    @Test
    public void checkPreConditions_purchaseAgreementPlatContractNull_shouldBubble() {
        // 协议查询通过、但 platContract 为 null → 内部抛 PurchaseServiceException
        mockIdentityPass();
        mockFundAccountPass();
        mockAlipayWithholdingPass();
        when(purchaseAgreementManager.queryPurchaseAgreement(any())).thenReturn(true);
        when(serviceProductInfoManager.queryServiceProductInfoByCode(anyString()))
                .thenReturn(new ServiceProductInfoDTO());
        when(platContractReadManager.getSimplePlatContract(anyString())).thenReturn(null);

        try {
            handler.checkPreConditions(buildContext());
            fail("期望抛出 PurchaseServiceException");
        } catch (PurchaseServiceException e) {
            // expected
        }
    }

    /* ============================== 支付宝代扣 ============================== */

    @Test
    public void checkPreConditions_alipayWithholdingExpressInfoNull_signFalse() {
        mockIdentityPass();
        // queryExpressInfo 第一次 / 第二次都返回 null（影响 fundAccount + alipay）
        when(stationExpressManager.queryExpressInfo(anyLong())).thenReturn(null);
        mockPurchaseAgreementPass(true);

        PlaceOrderResultDTO result = handler.checkPreConditions(buildContext());
        assertFalse(result.getAlipayWithholdingAgreement().getSign());
    }

    @Test
    public void checkPreConditions_alipayWithholdingCnuserIdNull_signFalse() {
        mockIdentityPass();
        StationExpressInfoDTO info = new StationExpressInfoDTO();
        info.setCorporationAlipayId("alipay-1");
        info.setCorporationCnuserId(null); // Long 类型，null 时 alipay 走 false
        when(stationExpressManager.queryExpressInfo(anyLong())).thenReturn(info);
        mockPurchaseAgreementPass(true);

        PlaceOrderResultDTO result = handler.checkPreConditions(buildContext());
        // fundAccount 仍然通过（alipayId 非空）
        assertTrue(result.getBindFundingAccount());
        // alipay 因 cnuserId 为空走 false
        assertFalse(result.getAlipayWithholdingAgreement().getSign());
    }

    @Test
    public void checkPreConditions_alipayWithholdingNotSigned_signFalse() {
        mockIdentityPass();
        mockFundAccountPass();
        // 已绑卡但未签代扣
        when(paymentSignManager.isSigned(anyLong())).thenReturn(false);
        mockPurchaseAgreementPass(true);

        PlaceOrderResultDTO result = handler.checkPreConditions(buildContext());
        assertFalse(result.getAlipayWithholdingAgreement().getSign());
    }

    @Test
    public void checkPreConditions_paymentSignThrows_signFalse() {
        mockIdentityPass();
        mockFundAccountPass();
        when(paymentSignManager.isSigned(anyLong()))
                .thenThrow(new RuntimeException("RPC failed"));
        mockPurchaseAgreementPass(true);

        PlaceOrderResultDTO result = handler.checkPreConditions(buildContext());
        assertFalse(result.getAlipayWithholdingAgreement().getSign());
    }

    /* ============================== helpers ============================== */

    private PlaceOrderResultDTO buildResult(boolean identity, boolean fund, boolean purchase, boolean alipay) {
        PlaceOrderResultDTO r = new PlaceOrderResultDTO();
        r.setIdentityVerification(identity);
        r.setBindFundingAccount(fund);
        AgreementInfoDTO p = new AgreementInfoDTO();
        p.setSign(purchase);
        r.setPurchaseAgreement(p);
        AgreementInfoDTO a = new AgreementInfoDTO();
        a.setSign(alipay);
        r.setAlipayWithholdingAgreement(a);
        return r;
    }

    private PlaceOrderParam buildParam() {
        PlaceOrderParam p = new PlaceOrderParam();
        p.setCustomerId(CUSTOMER_ID);
        p.setCustomerCode(CUSTOMER_CODE);
        p.setCustomerType(PurchaseCustomerTypeEnum.OUTLET.getCode());
        return p;
    }

    private CabinetPlaceOrderContext buildContext() {
        return buildContext(buildParam());
    }

    private CabinetPlaceOrderContext buildContext(PlaceOrderParam param) {
        // 网点要从订单快照取协议码
        PurchaseRuleDTO rule = new PurchaseRuleDTO();
        rule.setAgreementCodeList(Collections.singletonList(AGREEMENT_CODE));
        PurchaseOrderProductSnapshot snapshot = new PurchaseOrderProductSnapshot();
        snapshot.setPurchaseRule(rule);
        PurchaseOrder order = new PurchaseOrder();
        order.setId(100L);
        order.setProductSnapshotList(Collections.singletonList(snapshot));
        return CabinetPlaceOrderContext.builder()
                .param(param)
                .order(order)
                .operation(operation)
                .build();
    }

    private void mockIdentityPass() {
        CertifiedEnterpriseInfoDTO info = new CertifiedEnterpriseInfoDTO();
        info.setRegCode("REG123");
        when(enterpriseCertifyManager.queryCertifiedEnterprise(anyString())).thenReturn(info);
    }

    private void mockFundAccountPass() {
        StationExpressInfoDTO info = new StationExpressInfoDTO();
        info.setCorporationAlipayId("alipay-id-1");
        info.setCorporationCnuserId(1001L);
        when(stationExpressManager.queryExpressInfo(anyLong())).thenReturn(info);
    }

    private void mockAlipayWithholdingPass() {
        // 复用 fundAccount 的 mock，并补 paymentSignManager
        StationExpressInfoDTO info = new StationExpressInfoDTO();
        info.setCorporationAlipayId("alipay-id-1");
        info.setCorporationCnuserId(1001L);
        when(stationExpressManager.queryExpressInfo(anyLong())).thenReturn(info);
        when(paymentSignManager.isSigned(anyLong())).thenReturn(true);
    }

    private void mockPurchaseAgreementPass(boolean signed) {
        when(purchaseAgreementManager.queryPurchaseAgreement(any())).thenReturn(signed);
        ServiceProductInfoDTO product = new ServiceProductInfoDTO();
        product.setServiceName("企业购买协议");
        product.setServiceContent("https://t.cn/contract");
        when(serviceProductInfoManager.queryServiceProductInfoByCode(anyString())).thenReturn(product);
        PlatContractSimpleInfoDTO contract = new PlatContractSimpleInfoDTO();
        contract.setContractId(666L);
        when(platContractReadManager.getSimplePlatContract(anyString())).thenReturn(contract);
    }
}
