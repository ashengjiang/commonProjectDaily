package com.cainiao.tp.nm.plan.purchase.adaptor.component.login;

import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.tp.nm.plan.infra.port.dto.context.BasePermissionContext;
import com.cainiao.tp.nm.plan.infra.port.dto.context.ExpressPermissionContext;
import com.cainiao.tp.nm.plan.infra.port.dto.context.PermissionContext;
import com.cainiao.tp.nm.plan.infra.port.manager.PermissionLoginManager;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.lang.reflect.Method;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * MtopLoginAspect 单元测试 */
@RunWith(MockitoJUnitRunner.class)
public class MtopLoginAspectTest {

    @InjectMocks
    private MtopLoginAspect aspect;

    @Mock
    private PermissionLoginManager permissionLoginManager;

    @Mock
    private ProceedingJoinPoint joinPoint;

    @Mock
    private MethodSignature methodSignature;

    @After
    public void tearDown() {
        MtopLoginContext.remove();
    }

    /* ============================== 用一个内部类持有带 @MtopLogin 注解的方法供反射 ============================== */

    static class FakeService {
        @MtopLogin
        public String annotated() {
            return "ok";
        }

        public String notAnnotated() {
            return "ok";
        }
    }

    @Before
    public void setUp() throws Exception {
        when(joinPoint.getSignature()).thenReturn(methodSignature);
    }

    /* ============================== 正常成功路径 ============================== */

    @Test
    public void around_success_shouldSetContextThenInvokeAndClear() throws Throwable {
        Method method = FakeService.class.getMethod("annotated");
        when(methodSignature.getMethod()).thenReturn(method);
        when(methodSignature.getReturnType()).thenAnswer(inv -> String.class);
        PermissionContext<BasePermissionContext> ctx = buildContext();
        when(permissionLoginManager.loginPermission()).thenReturn(ctx);
        when(joinPoint.proceed()).thenAnswer(inv -> {
            // 验证 proceed 期间能拿到登录态
            assertSame(ctx, MtopLoginContext.getContext());
            return "ok";
        });

        Object result = aspect.around(joinPoint);

        assertEquals("ok", result);
        // 方法结束后上下文应被清除
        assertNull(MtopLoginContext.getContext());
        verify(permissionLoginManager, times(1)).loginPermission();
        verify(joinPoint, times(1)).proceed();
    }

    /* ============================== 未标注 @MtopLogin → 直接 proceed ============================== */

    @Test
    public void around_methodWithoutAnnotation_shouldDirectlyProceed() throws Throwable {
        Method method = FakeService.class.getMethod("notAnnotated");
        when(methodSignature.getMethod()).thenReturn(method);
        when(methodSignature.getReturnType()).thenAnswer(inv -> String.class);
        when(joinPoint.proceed()).thenReturn("ok");

        Object result = aspect.around(joinPoint);

        assertEquals("ok", result);
        // 不应该调用登录态解析
        verify(permissionLoginManager, times(0)).loginPermission();
    }

    /* ============================== 登录态解析异常 → 包装成 AladdinBizException ============================== */

    @Test
    public void around_loginManagerThrows_shouldWrapAsAladdinBizException() throws Throwable {
        Method method = FakeService.class.getMethod("annotated");
        when(methodSignature.getMethod()).thenReturn(method);
        when(methodSignature.getReturnType()).thenAnswer(inv -> String.class);
        when(permissionLoginManager.loginPermission())
                .thenThrow(new RuntimeException("login failed"));

        try {
            aspect.around(joinPoint);
            fail("应该抛 AladdinBizException");
        } catch (AladdinBizException e) {
            // expected
            assertNull(MtopLoginContext.getContext());
        }
    }

    @Test
    public void around_loginManagerThrowsAladdinBiz_shouldRethrowWithSameMessage() throws Throwable {
        Method method = FakeService.class.getMethod("annotated");
        when(methodSignature.getMethod()).thenReturn(method);
        when(methodSignature.getReturnType()).thenAnswer(inv -> String.class);
        AladdinBizException biz = new AladdinBizException("login.error", "自定义错误");
        when(permissionLoginManager.loginPermission()).thenThrow(biz);

        try {
            aspect.around(joinPoint);
            fail();
        } catch (AladdinBizException e) {
            // 保留原始错误消息
            assertEquals("自定义错误", e.getMessage());
        }
    }

    /* ============================== proceed 抛业务异常 → 应原样抛出（不被切面吞掉） ============================== */

    @Test
    public void around_proceedThrowsException_shouldBeWrappedAsAladdinBizException() throws Throwable {
        // 注意：当前实现 catch 的是 Exception，所以业务方法抛 RuntimeException 也会被包成 AladdinBizException
        Method method = FakeService.class.getMethod("annotated");
        when(methodSignature.getMethod()).thenReturn(method);
        when(methodSignature.getReturnType()).thenAnswer(inv -> String.class);
        when(permissionLoginManager.loginPermission()).thenReturn(buildContext());
        when(joinPoint.proceed()).thenThrow(new RuntimeException("biz fail"));

        try {
            aspect.around(joinPoint);
            fail();
        } catch (AladdinBizException e) {
            // expected - 切面统一包装
            assertNull(MtopLoginContext.getContext());
        }
    }

    /* ============================== finally 必然清理上下文 ============================== */

    @Test
    public void around_finallyShouldAlwaysCleanContext() throws Throwable {
        Method method = FakeService.class.getMethod("annotated");
        when(methodSignature.getMethod()).thenReturn(method);
        when(methodSignature.getReturnType()).thenAnswer(inv -> String.class);
        when(permissionLoginManager.loginPermission()).thenReturn(buildContext());
        when(joinPoint.proceed()).thenReturn("ok");

        aspect.around(joinPoint);

        // 即便正常返回，也应已清理
        assertNull(MtopLoginContext.getContext());
    }

    @Test
    public void around_loginSuccessThenProceedSuccess_shouldReturnProceedResult() throws Throwable {
        Method method = FakeService.class.getMethod("annotated");
        when(methodSignature.getMethod()).thenReturn(method);
        when(methodSignature.getReturnType()).thenAnswer(inv -> String.class);
        when(permissionLoginManager.loginPermission()).thenReturn(buildContext());
        when(joinPoint.proceed()).thenReturn(123);

        Object result = aspect.around(joinPoint);
        assertEquals(123, result);
    }

    @Test
    public void around_multipleInvocations_shouldNotLeakContext() throws Throwable {
        Method method = FakeService.class.getMethod("annotated");
        when(methodSignature.getMethod()).thenReturn(method);
        when(methodSignature.getReturnType()).thenAnswer(inv -> String.class);
        when(permissionLoginManager.loginPermission()).thenReturn(buildContext());
        when(joinPoint.proceed()).thenReturn("ok");

        for (int i = 0; i < 3; i++) {
            aspect.around(joinPoint);
            assertNull("第 " + i + " 次调用后上下文应清空", MtopLoginContext.getContext());
        }
        verify(permissionLoginManager, times(3)).loginPermission();
    }

    /* ============================== helpers ============================== */

    @SuppressWarnings({"rawtypes", "unchecked"})
    private PermissionContext<BasePermissionContext> buildContext() {
        PermissionContext ctx = new PermissionContext();
        ExpressPermissionContext ec = new ExpressPermissionContext();
        ec.setExpressId(200L);
        ctx.setContext(ec);
        ctx.setLoginType(2);
        return ctx;
    }
}
