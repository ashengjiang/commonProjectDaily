package com.cainiao.tp.nm.plan.purchase.application.component.factory;

import com.cainiao.tp.nm.plan.infra.port.common.exception.PurchaseServiceException;
import com.cainiao.tp.nm.plan.purchase.application.component.calculator.PurchasePriceCalculator;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.ApplicationContext;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.when;

/**
 * PurchasePriceCalculatorFactory 单元测试 */
@RunWith(MockitoJUnitRunner.class)
public class PurchasePriceCalculatorFactoryTest {

    @InjectMocks
    private PurchasePriceCalculatorFactory factory;

    @Mock
    private ApplicationContext applicationContext;

    @Mock
    private PurchasePriceCalculator fullPayCalculator;

    @Mock
    private PurchasePriceCalculator loanCalculator;

    @Mock
    private PurchasePriceCalculator nullModeCalculator;

    @Before
    public void setUp() {
        when(fullPayCalculator.supportedPaymentMode()).thenReturn(1);
        when(loanCalculator.supportedPaymentMode()).thenReturn(10);
        when(nullModeCalculator.supportedPaymentMode()).thenReturn(null);
    }

    @Test
    public void afterPropertiesSet_emptyBeans_shouldNotCrash() throws Exception {
        when(applicationContext.getBeansOfType(PurchasePriceCalculator.class)).thenReturn(new HashMap<>());
        factory.afterPropertiesSet();

        try {
            factory.getCalculator(1);
            fail();
        } catch (PurchaseServiceException e) {
            // expected
        }
    }

    @Test
    public void afterPropertiesSet_normalBeans_shouldBuildRouter() throws Exception {
        Map<String, PurchasePriceCalculator> beanMap = new HashMap<>();
        beanMap.put("full", fullPayCalculator);
        beanMap.put("loan", loanCalculator);
        when(applicationContext.getBeansOfType(PurchasePriceCalculator.class)).thenReturn(beanMap);

        factory.afterPropertiesSet();
        assertSame(fullPayCalculator, factory.getCalculator(1));
        assertSame(loanCalculator, factory.getCalculator(10));
    }

    @Test
    public void afterPropertiesSet_nullModeCalculator_shouldBeIgnored() throws Exception {
        Map<String, PurchasePriceCalculator> beanMap = new HashMap<>();
        beanMap.put("full", fullPayCalculator);
        beanMap.put("nullMode", nullModeCalculator);
        when(applicationContext.getBeansOfType(PurchasePriceCalculator.class)).thenReturn(beanMap);

        factory.afterPropertiesSet();
        assertSame(fullPayCalculator, factory.getCalculator(1));
    }

    @Test
    public void afterPropertiesSet_contextThrows_shouldRethrow() {
        when(applicationContext.getBeansOfType(PurchasePriceCalculator.class))
                .thenThrow(new RuntimeException("ctx fail"));
        try {
            factory.afterPropertiesSet();
            fail();
        } catch (Exception e) {
            assertEquals("ctx fail", e.getMessage());
        }
    }

    @Test
    public void getCalculator_paymentModeNull_shouldThrow() {
        try {
            factory.getCalculator(null);
            fail();
        } catch (PurchaseServiceException e) {
            // expected
        }
    }

    @Test
    public void getCalculator_unknownMode_shouldThrow() throws Exception {
        Map<String, PurchasePriceCalculator> beanMap = new HashMap<>();
        beanMap.put("full", fullPayCalculator);
        when(applicationContext.getBeansOfType(PurchasePriceCalculator.class)).thenReturn(beanMap);
        factory.afterPropertiesSet();

        try {
            factory.getCalculator(999);
            fail();
        } catch (PurchaseServiceException e) {
            // expected
        }
    }

    @Test
    public void getCalculator_hit_shouldReturnSameInstance() throws Exception {
        Map<String, PurchasePriceCalculator> beanMap = new HashMap<>();
        beanMap.put("full", fullPayCalculator);
        when(applicationContext.getBeansOfType(PurchasePriceCalculator.class)).thenReturn(beanMap);
        factory.afterPropertiesSet();

        assertSame(fullPayCalculator, factory.getCalculator(1));
        assertSame(fullPayCalculator, factory.getCalculator(1));
    }
}
