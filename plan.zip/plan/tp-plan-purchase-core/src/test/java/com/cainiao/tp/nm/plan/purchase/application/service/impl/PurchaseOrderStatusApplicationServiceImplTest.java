package com.cainiao.tp.nm.plan.purchase.application.service.impl;

import com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseOrderStatusEnum;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.DuoNiuOrderDetailDTO;
import com.cainiao.tp.nm.plan.purchase.application.event.PurchaseAppEventPublisher;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseOrder;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseProduct;
import com.cainiao.tp.nm.plan.purchase.domain.model.valobj.PurchaseOrderProductSnapshot;
import com.cainiao.tp.nm.plan.purchase.domain.repository.PurchaseOrderRepository;
import com.cainiao.tp.nm.plan.purchase.domain.repository.PurchaseProductRepository;
import com.cainiao.tp.nm.plan.purchase.domain.repository.PurchaseProductSkuRepository;
import com.cainiao.tp.nm.plan.purchase.domain.service.PurchaseOrderDomainService;
import com.cainiao.tp.nm.plan.purchase.domain.service.param.PurchaseOrderStatusUpdateParam;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * PurchaseOrderStatusApplicationServiceImpl 单元测试
 * <p>
 * 覆盖：本地订单查询、履约订单ID冲突校验、万里牛 dnStatus="1"（仅关联ID）、状态映射（"2"=PAID/"3"=SHIPPED/"4"=RECEIVED）、未知状态拒绝、checkSkuBelongsToUs 筛选。
 * SN 码处理（snJson 解析 + 写入快照 feature + 发 MQ）由 processStatusChange 间接覆盖。
 * </p> */
@RunWith(MockitoJUnitRunner.class)
public class PurchaseOrderStatusApplicationServiceImplTest {

    @InjectMocks
    private PurchaseOrderStatusApplicationServiceImpl service;

    @Mock
    private PurchaseOrderRepository purchaseOrderRepository;

    @Mock
    private PurchaseOrderDomainService purchaseOrderDomainService;

    @Mock
    private PurchaseProductRepository purchaseProductRepository;

    @Mock
    private PurchaseProductSkuRepository purchaseProductSkuRepository;

    @Mock
    private PurchaseAppEventPublisher purchaseAppEventPublisher;

    /* ============================== processStatusChange ============================== */

    @Test
    public void processStatusChange_localOrderNotFound_shouldReturnFalse() {
        when(purchaseOrderRepository.findById(999L)).thenReturn(null);

        boolean ok = service.processStatusChange(999L, "DN001", "2",
                new DuoNiuOrderDetailDTO(), null);

        assertFalse(ok);
        verify(purchaseOrderDomainService, never()).updateOrderStatus(any());
    }

    @Test
    public void processStatusChange_fulfillmentIdConflict_shouldReturnFalse() {
        PurchaseOrder order = PurchaseOrder.builder()
                .id(1L)
                .fulfillmentPlatformOrderId("OLD_DN")
                .build();
        when(purchaseOrderRepository.findById(1L)).thenReturn(order);

        boolean ok = service.processStatusChange(1L, "NEW_DN", "2",
                new DuoNiuOrderDetailDTO(), null);

        assertFalse(ok);
        verify(purchaseOrderDomainService, never()).updateOrderStatus(any());
    }

    @Test
    public void processStatusChange_dnStatus1_shouldOnlySaveFulfillmentId_andNotChangeStatus() {
        PurchaseOrder order = PurchaseOrder.builder()
                .id(1L)
                .status(PurchaseOrderStatusEnum.CREATE.getCode())
                .build();
        when(purchaseOrderRepository.findById(1L)).thenReturn(order);

        boolean ok = service.processStatusChange(1L, "DN001", "1",
                new DuoNiuOrderDetailDTO(), null);

        assertTrue(ok);
        assertEquals("DN001", order.getFulfillmentPlatformOrderId());
        // 仅持久化，不调状态变更
        verify(purchaseOrderRepository).update(order);
        verify(purchaseOrderDomainService, never()).updateOrderStatus(any());
    }

    @Test
    public void processStatusChange_unknownDnStatus_shouldReturnFalse() {
        PurchaseOrder order = PurchaseOrder.builder()
                .id(1L)
                .status(PurchaseOrderStatusEnum.CREATE.getCode())
                .build();
        when(purchaseOrderRepository.findById(1L)).thenReturn(order);

        boolean ok = service.processStatusChange(1L, "DN001", "99",
                new DuoNiuOrderDetailDTO(), null);

        assertFalse(ok);
        verify(purchaseOrderDomainService, never()).updateOrderStatus(any());
    }

    @Test
    public void processStatusChange_dnStatus2_shouldMapToPaid_andCarryPaymentInfo() {
        PurchaseOrder order = PurchaseOrder.builder()
                .id(1L)
                .status(PurchaseOrderStatusEnum.CREATE.getCode())
                .build();
        when(purchaseOrderRepository.findById(1L)).thenReturn(order);

        DuoNiuOrderDetailDTO detail = new DuoNiuOrderDetailDTO();
        detail.setPayment("199.99");
        // 不传 payTime，由当前时间兜底

        boolean ok = service.processStatusChange(1L, "DN001", "2", detail, null);

        assertTrue(ok);
        ArgumentCaptor<PurchaseOrderStatusUpdateParam> captor =
                ArgumentCaptor.forClass(PurchaseOrderStatusUpdateParam.class);
        verify(purchaseOrderDomainService).updateOrderStatus(captor.capture());
        PurchaseOrderStatusUpdateParam actual = captor.getValue();
        assertEquals(Long.valueOf(1L), actual.getOrderId());
        assertEquals(PurchaseOrderStatusEnum.PAID.getCode(), actual.getStatus());
        assertEquals("DN001", actual.getExistingFulfillmentOrderId());
        assertEquals(0, new java.math.BigDecimal("199.99").compareTo(actual.getActualPaymentAmount()));
        // 未带发货/签收时间
        assertEquals(null, actual.getShippingTime());
        assertEquals(null, actual.getSignTime());
    }

    @Test
    public void processStatusChange_dnStatus3_shouldMapToShipped_andCarryShippingTime() {
        PurchaseOrder order = PurchaseOrder.builder()
                .id(1L)
                .status(PurchaseOrderStatusEnum.PAID.getCode())
                .build();
        when(purchaseOrderRepository.findById(1L)).thenReturn(order);

        DuoNiuOrderDetailDTO detail = new DuoNiuOrderDetailDTO();
        // 不带 snJson 时，processSnCode 会 log.error 但不抛异常，不影响返回值

        boolean ok = service.processStatusChange(1L, "DN001", "3", detail, null);

        assertTrue(ok);
        ArgumentCaptor<PurchaseOrderStatusUpdateParam> captor =
                ArgumentCaptor.forClass(PurchaseOrderStatusUpdateParam.class);
        verify(purchaseOrderDomainService).updateOrderStatus(captor.capture());
        PurchaseOrderStatusUpdateParam actual = captor.getValue();
        assertEquals(PurchaseOrderStatusEnum.SHIPPED.getCode(), actual.getStatus());
        // 发货状态必须带 shippingTime（兜底为当前时间）
        assertTrue(actual.getShippingTime() != null);
        assertEquals(null, actual.getSignTime());
    }

    @Test
    public void processStatusChange_dnStatus4_shouldMapToReceived_andCarrySignTime() {
        PurchaseOrder order = PurchaseOrder.builder()
                .id(1L)
                .status(PurchaseOrderStatusEnum.SHIPPED.getCode())
                .build();
        when(purchaseOrderRepository.findById(1L)).thenReturn(order);

        boolean ok = service.processStatusChange(1L, "DN001", "4",
                new DuoNiuOrderDetailDTO(), null);

        assertTrue(ok);
        ArgumentCaptor<PurchaseOrderStatusUpdateParam> captor =
                ArgumentCaptor.forClass(PurchaseOrderStatusUpdateParam.class);
        verify(purchaseOrderDomainService).updateOrderStatus(captor.capture());
        PurchaseOrderStatusUpdateParam actual = captor.getValue();
        assertEquals(PurchaseOrderStatusEnum.RECEIVED.getCode(), actual.getStatus());
        assertTrue(actual.getShippingTime() != null);
        assertTrue(actual.getSignTime() != null);
    }

    @Test
    public void processStatusChange_fulfillmentIdAlreadyMatched_shouldKeepIt() {
        PurchaseOrder order = PurchaseOrder.builder()
                .id(1L)
                .status(PurchaseOrderStatusEnum.CREATE.getCode())
                .fulfillmentPlatformOrderId("DN001")
                .build();
        when(purchaseOrderRepository.findById(1L)).thenReturn(order);

        boolean ok = service.processStatusChange(1L, "DN001", "1",
                new DuoNiuOrderDetailDTO(), null);

        assertTrue(ok);
        assertEquals("DN001", order.getFulfillmentPlatformOrderId());
        verify(purchaseOrderRepository).update(order);
    }

    @Test
    public void processStatusChange_shipped_withSnJson_shouldWriteSnapshotAndSendMq() {
        PurchaseOrderProductSnapshot snapshot = new PurchaseOrderProductSnapshot();
        snapshot.setId(10L);
        snapshot.setProductId("100");

        PurchaseOrder order = PurchaseOrder.builder()
                .id(1L)
                .customId("CUST_001")
                .customType(1)
                .status(PurchaseOrderStatusEnum.PAID.getCode())
                .productSnapshotList(Collections.singletonList(snapshot))
                .build();
        when(purchaseOrderRepository.findById(1L)).thenReturn(order);

        // 商品携带 attributeOption 中的 model_code (= ProductAttributeEnum.MODEL_CODE.getCode())
        PurchaseProduct product = new PurchaseProduct();
        product.setId(100L);
        com.cainiao.tp.nm.plan.purchase.domain.model.valobj.AttributeOption opt =
                new com.cainiao.tp.nm.plan.purchase.domain.model.valobj.AttributeOption();
        opt.setCode(com.cainiao.tp.nm.plan.api.purchase.common.constants.ProductAttributeEnum.MODEL_CODE.getCode());
        opt.setOptionCode("MODEL_A");
        product.setAttributeOptionList(Collections.singletonList(opt));
        when(purchaseProductRepository.getProductsByIds(anyList()))
                .thenReturn(Collections.singletonList(product));

        DuoNiuOrderDetailDTO detail = new DuoNiuOrderDetailDTO();
        detail.setSnJson("{\"MODEL_A\":[\"SN001\",\"SN002\"]}");

        boolean ok = service.processStatusChange(1L, "DN001", "3", detail, null);

        assertTrue(ok);
        // 校验快照 feature 被更新
        verify(purchaseOrderRepository).updateSnapshotFeature(eq(10L), any());
        // 校验发送了 2 条 MQ
        verify(purchaseAppEventPublisher, org.mockito.Mockito.times(2))
                .publishCustomerSnRelation(any());
    }

    @Test
    public void processStatusChange_shipped_snJsonInvalid_shouldNotWriteSnapshot() {
        PurchaseOrderProductSnapshot snapshot = new PurchaseOrderProductSnapshot();
        snapshot.setId(10L);
        snapshot.setProductId("100");

        PurchaseOrder order = PurchaseOrder.builder()
                .id(1L)
                .status(PurchaseOrderStatusEnum.PAID.getCode())
                .productSnapshotList(Collections.singletonList(snapshot))
                .build();
        when(purchaseOrderRepository.findById(1L)).thenReturn(order);

        DuoNiuOrderDetailDTO detail = new DuoNiuOrderDetailDTO();
        detail.setSnJson("not-a-json");

        boolean ok = service.processStatusChange(1L, "DN001", "3", detail, null);

        assertTrue(ok);
        verify(purchaseOrderRepository, never()).updateSnapshotFeature(any(), any());
        verify(purchaseAppEventPublisher, never()).publishCustomerSnRelation(any());
    }

    /* ============================== checkSkuBelongsToUs ============================== */

    @Test
    public void checkSkuBelongsToUs_emptyInput_shouldReturnEmpty() {
        List<String> result = service.checkSkuBelongsToUs(Collections.emptyList());
        assertTrue(result.isEmpty());
    }

    @Test
    public void checkSkuBelongsToUs_shouldFilterOutMissing_andBlank() {
        // SKU_1 存在; SKU_2 不存在; 空白串过滤
        com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseProductSku sku =
                new com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseProductSku();
        when(purchaseProductSkuRepository.getBySkuId("SKU_1")).thenReturn(sku);
        when(purchaseProductSkuRepository.getBySkuId("SKU_2")).thenReturn(null);

        List<String> result = service.checkSkuBelongsToUs(Arrays.asList("SKU_1", "SKU_2", " ", null));

        assertEquals(1, result.size());
        assertEquals("SKU_1", result.get(0));
    }

    /* ============================== helpers ============================== */

    private static org.mockito.ArgumentMatcher<Long> longEq(long expected) {
        return argument -> argument != null && argument == expected;
    }

    // 让静态导入 eq() 可用
    private static <T> T eq(T expected) {
        return org.mockito.ArgumentMatchers.eq(expected);
    }
}
