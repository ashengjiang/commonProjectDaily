package com.cainiao.tp.nm.plan.purchase.adaptor.service;

import com.cainiao.sutee.commons.base.result.CnResult;
import com.cainiao.tp.nm.plan.api.purchase.adaptor.dto.HashOrderDTO;
import com.cainiao.tp.nm.plan.api.purchase.adaptor.dto.HashOrderParam;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.PurchaseOrderInfoDTO;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.PurchaseOrderQueryDTO;
import com.cainiao.tp.nm.plan.infra.port.purchase.PurchaseOrderManager;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.Collections;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * PurchaseOrderForOutServiceImpl 单元测试
 * <p>
 * 覆盖：
 * 1. 入参校验：null、customerId blank、customerType blank
 * 2. 业务分支：
 *    - 查询无订单 → hashOrder=false
 *    - 查询有订单但都无履约平台订单 ID → hashOrder=false
 *    - 至少一笔订单有 fulfillmentPlatformOrderId → hashOrder=true
 * 3. 入参回写：customerId/customerType 是否正确传递给 manager
 * </p> */
@RunWith(MockitoJUnitRunner.class)
public class PurchaseOrderForOutServiceImplTest {

    @InjectMocks
    private PurchaseOrderForOutServiceImpl service;

    @Mock
    private PurchaseOrderManager purchaseOrderManager;

    private static final String CUSTOMER_ID = "100";
    private static final String CUSTOMER_TYPE = "1";

    /* ============================== 入参校验 ============================== */

    @Test
    public void hashOrder_paramNull_shouldReturnParamNullFail() {
        CnResult<HashOrderDTO> result = service.hashOrder(null, null);

        assertFalse(result.isSuccess());
        assertEquals("PARAM_NULL", result.getCode());
        verify(purchaseOrderManager, never()).queryList(any(PurchaseOrderQueryDTO.class));
    }

    @Test
    public void hashOrder_customerIdNull_shouldReturnParamInvalid() {
        HashOrderParam param = new HashOrderParam();
        param.setCustomerId(null);
        param.setCustomerType(CUSTOMER_TYPE);

        CnResult<HashOrderDTO> result = service.hashOrder(param, null);

        assertFalse(result.isSuccess());
        assertEquals("PARAM_INVALID", result.getCode());
        verify(purchaseOrderManager, never()).queryList(any(PurchaseOrderQueryDTO.class));
    }

    @Test
    public void hashOrder_customerIdBlank_shouldReturnParamInvalid() {
        HashOrderParam param = new HashOrderParam();
        param.setCustomerId("");
        param.setCustomerType(CUSTOMER_TYPE);

        CnResult<HashOrderDTO> result = service.hashOrder(param, null);
        assertFalse(result.isSuccess());
        assertEquals("PARAM_INVALID", result.getCode());
    }

    @Test
    public void hashOrder_customerIdSpaces_shouldReturnParamInvalid() {
        HashOrderParam param = new HashOrderParam();
        param.setCustomerId("   ");
        param.setCustomerType(CUSTOMER_TYPE);

        CnResult<HashOrderDTO> result = service.hashOrder(param, null);
        assertFalse(result.isSuccess());
        assertEquals("PARAM_INVALID", result.getCode());
    }

    @Test
    public void hashOrder_customerTypeNull_shouldReturnParamInvalid() {
        HashOrderParam param = new HashOrderParam();
        param.setCustomerId(CUSTOMER_ID);
        param.setCustomerType(null);

        CnResult<HashOrderDTO> result = service.hashOrder(param, null);
        assertFalse(result.isSuccess());
        assertEquals("PARAM_INVALID", result.getCode());
    }

    @Test
    public void hashOrder_customerTypeBlank_shouldReturnParamInvalid() {
        HashOrderParam param = new HashOrderParam();
        param.setCustomerId(CUSTOMER_ID);
        param.setCustomerType("");

        CnResult<HashOrderDTO> result = service.hashOrder(param, null);
        assertFalse(result.isSuccess());
        assertEquals("PARAM_INVALID", result.getCode());
    }

    /* ============================== 业务分支 ============================== */

    @Test
    public void hashOrder_emptyOrderList_shouldReturnFalse() {
        when(purchaseOrderManager.queryList(any(PurchaseOrderQueryDTO.class)))
                .thenReturn(Collections.emptyList());

        CnResult<HashOrderDTO> result = service.hashOrder(buildParam(), null);

        assertTrue(result.isSuccess());
        assertNotNull(result.getData());
        assertFalse(result.getData().getHashOrder());
    }

    @Test
    public void hashOrder_allOrdersNoFulfillmentId_shouldReturnFalse() {
        PurchaseOrderInfoDTO o1 = new PurchaseOrderInfoDTO();
        o1.setFulfillmentPlatformOrderId(null);
        PurchaseOrderInfoDTO o2 = new PurchaseOrderInfoDTO();
        o2.setFulfillmentPlatformOrderId("");
        when(purchaseOrderManager.queryList(any(PurchaseOrderQueryDTO.class)))
                .thenReturn(Arrays.asList(o1, o2));

        CnResult<HashOrderDTO> result = service.hashOrder(buildParam(), null);
        assertTrue(result.isSuccess());
        assertFalse(result.getData().getHashOrder());
    }

    @Test
    public void hashOrder_allOrdersBlankFulfillmentId_shouldReturnFalse() {
        PurchaseOrderInfoDTO o1 = new PurchaseOrderInfoDTO();
        o1.setFulfillmentPlatformOrderId("   ");
        when(purchaseOrderManager.queryList(any(PurchaseOrderQueryDTO.class)))
                .thenReturn(Collections.singletonList(o1));

        CnResult<HashOrderDTO> result = service.hashOrder(buildParam(), null);
        assertTrue(result.isSuccess());
        assertFalse(result.getData().getHashOrder());
    }

    @Test
    public void hashOrder_atLeastOneOrderWithFulfillmentId_shouldReturnTrue() {
        PurchaseOrderInfoDTO o1 = new PurchaseOrderInfoDTO();
        o1.setFulfillmentPlatformOrderId(null);
        PurchaseOrderInfoDTO o2 = new PurchaseOrderInfoDTO();
        o2.setFulfillmentPlatformOrderId("DN12345");
        when(purchaseOrderManager.queryList(any(PurchaseOrderQueryDTO.class)))
                .thenReturn(Arrays.asList(o1, o2));

        CnResult<HashOrderDTO> result = service.hashOrder(buildParam(), null);
        assertTrue(result.isSuccess());
        assertTrue(result.getData().getHashOrder());
    }

    @Test
    public void hashOrder_singleOrderWithFulfillmentId_shouldReturnTrue() {
        PurchaseOrderInfoDTO o1 = new PurchaseOrderInfoDTO();
        o1.setFulfillmentPlatformOrderId("DN-001");
        when(purchaseOrderManager.queryList(any(PurchaseOrderQueryDTO.class)))
                .thenReturn(Collections.singletonList(o1));

        CnResult<HashOrderDTO> result = service.hashOrder(buildParam(), null);
        assertTrue(result.isSuccess());
        assertTrue(result.getData().getHashOrder());
    }

    /* ============================== 入参回写 ============================== */

    @Test
    public void hashOrder_paramShouldBeMappedToQueryDTO() {
        when(purchaseOrderManager.queryList(any(PurchaseOrderQueryDTO.class)))
                .thenReturn(Collections.emptyList());

        service.hashOrder(buildParam(), null);

        ArgumentCaptor<PurchaseOrderQueryDTO> captor = ArgumentCaptor.forClass(PurchaseOrderQueryDTO.class);
        verify(purchaseOrderManager).queryList(captor.capture());
        PurchaseOrderQueryDTO queryDTO = captor.getValue();
        assertEquals(CUSTOMER_ID, queryDTO.getCustomId());
        assertEquals(CUSTOMER_TYPE, queryDTO.getCustomType());
    }

    @Test
    public void hashOrder_customerTypeOutlet_shouldStillWork() {
        // 验证不同 customerType 值都能正确传递
        HashOrderParam param = new HashOrderParam();
        param.setCustomerId("9999");
        param.setCustomerType("2");
        when(purchaseOrderManager.queryList(any(PurchaseOrderQueryDTO.class)))
                .thenReturn(Collections.emptyList());

        CnResult<HashOrderDTO> result = service.hashOrder(param, null);
        assertTrue(result.isSuccess());

        ArgumentCaptor<PurchaseOrderQueryDTO> captor = ArgumentCaptor.forClass(PurchaseOrderQueryDTO.class);
        verify(purchaseOrderManager).queryList(captor.capture());
        assertEquals("9999", captor.getValue().getCustomId());
        assertEquals("2", captor.getValue().getCustomType());
    }

    @Test
    public void hashOrder_managerThrows_shouldNotBeSwallowed() {
        // 当前实现没有 catch 异常 → 应该冒泡
        when(purchaseOrderManager.queryList(any(PurchaseOrderQueryDTO.class)))
                .thenThrow(new RuntimeException("DB error"));

        try {
            service.hashOrder(buildParam(), null);
            org.junit.Assert.fail("期望异常冒泡");
        } catch (RuntimeException e) {
            assertEquals("DB error", e.getMessage());
        }
    }

    /* ============================== helpers ============================== */

    private HashOrderParam buildParam() {
        HashOrderParam p = new HashOrderParam();
        p.setCustomerId(CUSTOMER_ID);
        p.setCustomerType(CUSTOMER_TYPE);
        return p;
    }
}
