package com.cainiao.tp.nm.plan.purchase.application.service.impl;

import com.cainiao.tp.nm.plan.api.purchase.application.dto.AttributeOptionDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.CabinetOrderDetailDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.PlaceOrderResultDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.ProductInfoDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.ProductInfoResultDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PlaceOrderParam;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PreCalculateOrderParam;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PurchaseProductParam;
import com.cainiao.tp.nm.plan.api.purchase.common.constants.CabinetInfoConstants;
import com.cainiao.tp.nm.plan.api.purchase.common.constants.ProductAttributeEnum;
import com.cainiao.tp.nm.plan.infra.port.common.constants.ErrorCode;
import com.cainiao.tp.nm.plan.infra.port.common.exception.PurchaseServiceException;
import com.cainiao.tp.nm.plan.purchase.application.component.CabinetPlaceOrderHandler;
import com.cainiao.tp.nm.plan.purchase.application.component.factory.CabinetPlaceOrderHandlerFactory;
import com.cainiao.tp.nm.plan.purchase.application.service.ProductionApplicationService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * CabinetPlaceOrderApplicationServiceImpl 单元测试 */
@RunWith(MockitoJUnitRunner.class)
public class CabinetPlaceOrderApplicationServiceImplTest {

    @InjectMocks
    private CabinetPlaceOrderApplicationServiceImpl service;

    @Mock
    private ProductionApplicationService productionApplicationService;

    @Mock
    private CabinetPlaceOrderHandlerFactory cabinetPlaceOrderHandlerFactory;

    @Mock
    private CabinetPlaceOrderHandler handler;

    /* ============================== preCalculateOrder ============================== */

    @Test
    public void preCalculateOrder_paramNull_shouldReturnNull() {
        assertNull(service.preCalculateOrder(null, null));
    }

    @Test
    public void preCalculateOrder_productListEmpty_shouldReturnNull() {
        PreCalculateOrderParam param = new PreCalculateOrderParam();
        param.setCustomerId("C001");
        param.setCustomerType(1);
        param.setProductInfoParamListStr("[]");
        assertNull(service.preCalculateOrder(param, null));
    }

    @Test
    public void preCalculateOrder_productInfoResultEmpty_shouldReturnNull() {
        PreCalculateOrderParam param = buildPreCalcParam(buildProductParam("100", 1));
        ProductInfoResultDTO emptyResult = new ProductInfoResultDTO();
        emptyResult.setProductInfoList(new ArrayList<>());
        when(productionApplicationService.getProductInfo(any(), any())).thenReturn(emptyResult);

        assertNull(service.preCalculateOrder(param, null));
    }

    @Test
    public void preCalculateOrder_productNotInRules_shouldThrow() {
        // 前端传 itemId=100，但规则里只有 200
        PreCalculateOrderParam param = buildPreCalcParam(buildProductParam("100", 1));
        ProductInfoResultDTO result = new ProductInfoResultDTO();
        result.setProductInfoList(Collections.singletonList(buildProductInfo(200, null, null)));
        when(productionApplicationService.getProductInfo(any(), any())).thenReturn(result);

        try {
            service.preCalculateOrder(param, null);
            fail("期望抛出 PurchaseServiceException");
        } catch (PurchaseServiceException e) {
            assertEquals(ErrorCode.ILLEGAL_PARAM.getCode(), e.getCode());
        }
    }

    @Test
    public void preCalculateOrder_mainCabinetLabel_shouldAccumulate() {
        PreCalculateOrderParam param = buildPreCalcParam(buildProductParam("100", 2));

        ProductInfoDTO productInfo = buildProductInfo(100, 1000.0,
                Collections.singletonList(buildAttr("cabinet_type", null, "MAIN_CABINET", CabinetInfoConstants.MAIN_CABINET)));

        ProductInfoResultDTO result = new ProductInfoResultDTO();
        result.setProductInfoList(Collections.singletonList(productInfo));
        when(productionApplicationService.getProductInfo(any(), any())).thenReturn(result);

        CabinetOrderDetailDTO detail = service.preCalculateOrder(param, null);

        assertEquals(Integer.valueOf(2), detail.getMainCabinetNum());
        assertEquals(Integer.valueOf(0), detail.getSubCabinetNum());
        assertEquals(Double.valueOf(2000.0), detail.getTotalPrice());
    }

    @Test
    public void preCalculateOrder_subCabinetLabel_shouldAccumulate() {
        PreCalculateOrderParam param = buildPreCalcParam(buildProductParam("100", 3));

        ProductInfoDTO productInfo = buildProductInfo(100, 500.0,
                Collections.singletonList(buildAttr("cabinet_type", null, "SUB_CABINET", CabinetInfoConstants.SUB_CABINET)));

        ProductInfoResultDTO result = new ProductInfoResultDTO();
        result.setProductInfoList(Collections.singletonList(productInfo));
        when(productionApplicationService.getProductInfo(any(), any())).thenReturn(result);

        CabinetOrderDetailDTO detail = service.preCalculateOrder(param, null);

        assertEquals(Integer.valueOf(0), detail.getMainCabinetNum());
        assertEquals(Integer.valueOf(3), detail.getSubCabinetNum());
        assertEquals(Double.valueOf(1500.0), detail.getTotalPrice());
    }

    @Test
    public void preCalculateOrder_purchaseNumNull_shouldDefaultToOne() {
        // purchaseNum=null 时默认 1
        PreCalculateOrderParam param = buildPreCalcParam(buildProductParam("100", null));

        ProductInfoDTO productInfo = buildProductInfo(100, 100.0, new ArrayList<>());

        ProductInfoResultDTO result = new ProductInfoResultDTO();
        result.setProductInfoList(Collections.singletonList(productInfo));
        when(productionApplicationService.getProductInfo(any(), any())).thenReturn(result);

        CabinetOrderDetailDTO detail = service.preCalculateOrder(param, null);

        assertEquals(Double.valueOf(100.0), detail.getTotalPrice());
    }

    @Test
    public void preCalculateOrder_priceNull_shouldKeepZero() {
        PreCalculateOrderParam param = buildPreCalcParam(buildProductParam("100", 5));
        ProductInfoDTO productInfo = buildProductInfo(100, null, new ArrayList<>());

        ProductInfoResultDTO result = new ProductInfoResultDTO();
        result.setProductInfoList(Collections.singletonList(productInfo));
        when(productionApplicationService.getProductInfo(any(), any())).thenReturn(result);

        CabinetOrderDetailDTO detail = service.preCalculateOrder(param, null);

        assertEquals(Double.valueOf(0.0), detail.getTotalPrice());
    }

    @Test
    public void preCalculateOrder_attributeListEmpty_shouldReturnAllZeros() {
        PreCalculateOrderParam param = buildPreCalcParam(buildProductParam("100", 2));
        ProductInfoDTO productInfo = buildProductInfo(100, 100.0, new ArrayList<>());

        ProductInfoResultDTO result = new ProductInfoResultDTO();
        result.setProductInfoList(Collections.singletonList(productInfo));
        when(productionApplicationService.getProductInfo(any(), any())).thenReturn(result);

        CabinetOrderDetailDTO detail = service.preCalculateOrder(param, null);

        assertEquals(Integer.valueOf(0), detail.getTotalGridNum());
        assertEquals(Integer.valueOf(0), detail.getMainCabinetNum());
        assertEquals(Integer.valueOf(0), detail.getSubCabinetNum());
        assertEquals(Double.valueOf(200.0), detail.getTotalPrice());
    }

    @Test
    public void preCalculateOrder_attributeNullEntry_shouldBeIgnored() {
        PreCalculateOrderParam param = buildPreCalcParam(buildProductParam("100", 1));

        ProductInfoDTO productInfo = buildProductInfo(100, 100.0, Arrays.asList(
                null,
                buildAttr("cabinet_type", null, "MAIN_CABINET", CabinetInfoConstants.MAIN_CABINET)));

        ProductInfoResultDTO result = new ProductInfoResultDTO();
        result.setProductInfoList(Collections.singletonList(productInfo));
        when(productionApplicationService.getProductInfo(any(), any())).thenReturn(result);

        CabinetOrderDetailDTO detail = service.preCalculateOrder(param, null);

        assertEquals(Integer.valueOf(1), detail.getMainCabinetNum());
    }

    /* ============================== placeOrder ============================== */

    @Test
    public void placeOrder_paramNull_shouldThrow() {
        try {
            service.placeOrder(null, null);
            fail("期望抛出 PurchaseServiceException");
        } catch (PurchaseServiceException e) {
            assertEquals(ErrorCode.ILLEGAL_PARAM.getCode(), e.getCode());
        }
    }

    @Test
    public void placeOrder_shouldFilterZeroQuantityItems_andDispatchToHandler() {
        PlaceOrderParam param = new PlaceOrderParam();
        param.setCustomerId("C001");
        param.setCustomerType(1);
        // 直接给 purchaseSkuInfoList（绕过 JSON 反序列化）
        PurchaseProductParam valid = buildProductParam("100", 2);
        PurchaseProductParam zero = buildProductParam("200", 0);
        PurchaseProductParam nullQty = buildProductParam("300", null);
        param.setPurchaseSkuInfoList(new ArrayList<>(Arrays.asList(valid, zero, nullQty)));

        PlaceOrderResultDTO expected = new PlaceOrderResultDTO();
        when(cabinetPlaceOrderHandlerFactory.getHandler(1)).thenReturn(handler);
        when(handler.placeOrder(eq(param), any())).thenReturn(expected);

        PlaceOrderResultDTO actual = service.placeOrder(param, null);

        assertSame(expected, actual);
        // 过滤后只剩 1 条
        assertEquals(1, param.getPurchaseSkuInfoList().size());
        assertEquals("100", param.getPurchaseSkuInfoList().get(0).getItemId());
        verify(cabinetPlaceOrderHandlerFactory).getHandler(1);
        verify(handler).placeOrder(eq(param), any());
    }

    @Test
    public void placeOrder_emptyList_shouldStillDispatch() {
        PlaceOrderParam param = new PlaceOrderParam();
        param.setCustomerId("C001");
        param.setCustomerType(1);
        param.setPurchaseSkuInfoList(new ArrayList<>());

        when(cabinetPlaceOrderHandlerFactory.getHandler(1)).thenReturn(handler);

        service.placeOrder(param, null);

        verify(handler).placeOrder(eq(param), any());
    }

    /* ============================== helpers ============================== */

    private PreCalculateOrderParam buildPreCalcParam(PurchaseProductParam... products) {
        PreCalculateOrderParam param = new PreCalculateOrderParam();
        param.setCustomerId("C001");
        param.setCustomerType(1);
        // 用 JSON 反序列化构造（PreCalculateOrderParam.getProductInfoParamList() 解析 productInfoParamListStr）
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < products.length; i++) {
            if (i > 0) {
                sb.append(",");
            }
            sb.append("{\"itemId\":\"").append(products[i].getItemId()).append("\"");
            if (products[i].getPurchaseNum() != null) {
                sb.append(",\"purchaseNum\":").append(products[i].getPurchaseNum());
            }
            sb.append("}");
        }
        sb.append("]");
        param.setProductInfoParamListStr(sb.toString());
        return param;
    }

    private PurchaseProductParam buildProductParam(String itemId, Integer purchaseNum) {
        PurchaseProductParam p = new PurchaseProductParam();
        p.setItemId(itemId);
        p.setPurchaseNum(purchaseNum);
        return p;
    }

    private ProductInfoDTO buildProductInfo(Integer itemId, Double price, List<AttributeOptionDTO> attrs) {
        ProductInfoDTO dto = new ProductInfoDTO();
        dto.setItemId(itemId);
        dto.setPrice(price);
        dto.setAttributeOptionList(attrs);
        return dto;
    }

    private AttributeOptionDTO buildAttr(String code, String value, String optionCode, String optionName) {
        AttributeOptionDTO attr = new AttributeOptionDTO();
        attr.setCode(code);
        attr.setValue(value);
        attr.setOptionCode(optionCode);
        attr.setOptionName(optionName);
        return attr;
    }
}
