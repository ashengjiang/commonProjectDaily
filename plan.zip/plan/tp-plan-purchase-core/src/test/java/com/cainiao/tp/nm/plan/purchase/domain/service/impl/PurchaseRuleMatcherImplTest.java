package com.cainiao.tp.nm.plan.purchase.domain.service.impl;

import com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseCategoryEnum;
import com.cainiao.tp.nm.plan.purchase.domain.exception.PurchaseDomainException;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchasePaymentPlan;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseRule;
import com.cainiao.tp.nm.plan.purchase.domain.model.valobj.AgreementConfig;
import com.cainiao.tp.nm.plan.purchase.domain.model.valobj.CustomerConfig;
import com.cainiao.tp.nm.plan.purchase.domain.model.valobj.PaymentPlanConfig;
import com.cainiao.tp.nm.plan.purchase.domain.repository.PurchasePaymentPlanRepository;
import com.cainiao.tp.nm.plan.purchase.domain.repository.PurchaseRuleRepository;
import com.cainiao.tp.nm.plan.purchase.domain.service.PurchaseRuleMatcher;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.when;

/**
 * PurchaseRuleMatcherImpl 单元测试 */
@RunWith(MockitoJUnitRunner.class)
public class PurchaseRuleMatcherImplTest {

    @InjectMocks
    private PurchaseRuleMatcherImpl matcher;

    @Mock
    private PurchaseRuleRepository purchaseRuleRepository;

    @Mock
    private PurchasePaymentPlanRepository purchasePaymentPlanRepository;

    private static final Long PRODUCT_ID = 100L;
    private static final String ITEM_ID = "100";
    private static final String CUSTOMER_ID = "C001";
    private static final Integer CUSTOMER_TYPE = 1;
    private static final Integer PAYMENT_MODE = 1;
    private static final Integer DELIVERY_TYPE = 1;

    /* ============================== 入参校验 ============================== */

    @Test
    public void match_itemIdBlank_shouldThrow() {
        assertIllegalParam(() -> matcher.match("", CUSTOMER_ID, CUSTOMER_TYPE, PAYMENT_MODE, DELIVERY_TYPE));
    }

    @Test
    public void match_customerIdBlank_shouldThrow() {
        assertIllegalParam(() -> matcher.match(ITEM_ID, " ", CUSTOMER_TYPE, PAYMENT_MODE, DELIVERY_TYPE));
    }

    @Test
    public void match_customerTypeNull_shouldThrow() {
        assertIllegalParam(() -> matcher.match(ITEM_ID, CUSTOMER_ID, null, PAYMENT_MODE, DELIVERY_TYPE));
    }

    @Test
    public void match_paymentModeNull_shouldThrow() {
        assertIllegalParam(() -> matcher.match(ITEM_ID, CUSTOMER_ID, CUSTOMER_TYPE, null, DELIVERY_TYPE));
    }

    @Test
    public void match_deliveryTypeNull_shouldThrow() {
        assertIllegalParam(() -> matcher.match(ITEM_ID, CUSTOMER_ID, CUSTOMER_TYPE, PAYMENT_MODE, null));
    }

    @Test
    public void match_itemIdNotNumber_shouldThrow() {
        assertIllegalParam(() -> matcher.match("abc", CUSTOMER_ID, CUSTOMER_TYPE, PAYMENT_MODE, DELIVERY_TYPE));
    }

    /* ============================== 规则匹配 ============================== */

    @Test
    public void match_noRules_shouldThrow() {
        when(purchaseRuleRepository.getRulesByCategoryId(PurchaseCategoryEnum.CABINET.getCode()))
                .thenReturn(Collections.emptyList());
        assertIllegalParam(() -> matcher.match(ITEM_ID, CUSTOMER_ID, CUSTOMER_TYPE, PAYMENT_MODE, DELIVERY_TYPE));
    }

    @Test
    public void match_allRulesFiltered_shouldThrow() {
        // productId 不匹配
        PurchaseRule mismatch = buildRule(1L, 999L, 1);
        when(purchaseRuleRepository.getRulesByCategoryId(PurchaseCategoryEnum.CABINET.getCode()))
                .thenReturn(Collections.singletonList(mismatch));
        assertIllegalParam(() -> matcher.match(ITEM_ID, CUSTOMER_ID, CUSTOMER_TYPE, PAYMENT_MODE, DELIVERY_TYPE));
    }

    @Test
    public void match_customerInBlackList_shouldFilterOut() {
        PurchaseRule rule = buildRule(1L, PRODUCT_ID, 1);
        rule.getCustomerConfig().setBlackList(Collections.singletonList(CUSTOMER_ID));
        when(purchaseRuleRepository.getRulesByCategoryId(PurchaseCategoryEnum.CABINET.getCode()))
                .thenReturn(Collections.singletonList(rule));
        assertIllegalParam(() -> matcher.match(ITEM_ID, CUSTOMER_ID, CUSTOMER_TYPE, PAYMENT_MODE, DELIVERY_TYPE));
    }

    @Test
    public void match_customerNotInWhiteList_shouldFilterOut() {
        PurchaseRule rule = buildRule(1L, PRODUCT_ID, 1);
        rule.getCustomerConfig().setWhiteList(Collections.singletonList("OTHER_USER"));
        when(purchaseRuleRepository.getRulesByCategoryId(PurchaseCategoryEnum.CABINET.getCode()))
                .thenReturn(Collections.singletonList(rule));
        assertIllegalParam(() -> matcher.match(ITEM_ID, CUSTOMER_ID, CUSTOMER_TYPE, PAYMENT_MODE, DELIVERY_TYPE));
    }

    @Test
    public void match_deliveryTypeNotInList_shouldFilterOut() {
        PurchaseRule rule = buildRule(1L, PRODUCT_ID, 1);
        rule.setDeliveryTypeList(Collections.singletonList(99));
        when(purchaseRuleRepository.getRulesByCategoryId(PurchaseCategoryEnum.CABINET.getCode()))
                .thenReturn(Collections.singletonList(rule));
        assertIllegalParam(() -> matcher.match(ITEM_ID, CUSTOMER_ID, CUSTOMER_TYPE, PAYMENT_MODE, DELIVERY_TYPE));
    }

    @Test
    public void match_outsideTimeWindow_shouldFilterOut() {
        PurchaseRule rule = buildRule(1L, PRODUCT_ID, 1);
        // 未来才生效
        rule.setStartTime(LocalDateTime.now().plusYears(10));
        when(purchaseRuleRepository.getRulesByCategoryId(PurchaseCategoryEnum.CABINET.getCode()))
                .thenReturn(Collections.singletonList(rule));
        assertIllegalParam(() -> matcher.match(ITEM_ID, CUSTOMER_ID, CUSTOMER_TYPE, PAYMENT_MODE, DELIVERY_TYPE));
    }

    @Test
    public void match_paymentModeNotMatchAnyConfig_shouldFilterOut() {
        PurchaseRule rule = buildRule(1L, PRODUCT_ID, 1);
        // 改成不匹配的 paymentMode
        rule.getPaymentPlanConfig().get(0).setPaymentMode(99);
        when(purchaseRuleRepository.getRulesByCategoryId(PurchaseCategoryEnum.CABINET.getCode()))
                .thenReturn(Collections.singletonList(rule));
        assertIllegalParam(() -> matcher.match(ITEM_ID, CUSTOMER_ID, CUSTOMER_TYPE, PAYMENT_MODE, DELIVERY_TYPE));
    }

    @Test
    public void match_paymentPlanNotFoundInRepo_shouldThrow() {
        PurchaseRule rule = buildRule(1L, PRODUCT_ID, 1);
        when(purchaseRuleRepository.getRulesByCategoryId(PurchaseCategoryEnum.CABINET.getCode()))
                .thenReturn(Collections.singletonList(rule));
        // 仓库查不到方案
        when(purchasePaymentPlanRepository.listByIds(anyList())).thenReturn(Collections.emptyList());

        assertIllegalParam(() -> matcher.match(ITEM_ID, CUSTOMER_ID, CUSTOMER_TYPE, PAYMENT_MODE, DELIVERY_TYPE));
    }

    @Test
    public void match_multipleRulesWithSameTopLevel_shouldThrow() {
        PurchaseRule r1 = buildRule(1L, PRODUCT_ID, 10);
        PurchaseRule r2 = buildRule(2L, PRODUCT_ID, 10);
        when(purchaseRuleRepository.getRulesByCategoryId(PurchaseCategoryEnum.CABINET.getCode()))
                .thenReturn(Arrays.asList(r1, r2));
        when(purchasePaymentPlanRepository.listByIds(anyList()))
                .thenReturn(Collections.singletonList(buildPaymentPlan(500L)));

        assertIllegalParam(() -> matcher.match(ITEM_ID, CUSTOMER_ID, CUSTOMER_TYPE, PAYMENT_MODE, DELIVERY_TYPE));
    }

    @Test
    public void match_success_shouldReturnTopLevelRuleAndPlan() {
        PurchaseRule lower = buildRule(1L, PRODUCT_ID, 1);
        PurchaseRule top = buildRule(2L, PRODUCT_ID, 99);
        when(purchaseRuleRepository.getRulesByCategoryId(PurchaseCategoryEnum.CABINET.getCode()))
                .thenReturn(Arrays.asList(lower, top));

        PurchasePaymentPlan plan = buildPaymentPlan(500L);
        when(purchasePaymentPlanRepository.listByIds(anyList()))
                .thenReturn(Collections.singletonList(plan));

        PurchaseRuleMatcher.MatchResult result = matcher.match(
                ITEM_ID, CUSTOMER_ID, CUSTOMER_TYPE, PAYMENT_MODE, DELIVERY_TYPE);

        assertNotNull(result);
        // 返回 level 最高的 rule
        assertEquals(Long.valueOf(2L), result.getRule().getId());
        assertEquals(Integer.valueOf(99), Integer.valueOf(result.getRule().getLevel()));
        // 协议码列表按 sortOrder 升序（buildRule 中只设了一个）
        assertEquals(1, result.getRule().getAgreementCodeList().size());
        // 命中的支付方案带回
        assertEquals(Long.valueOf(500L), result.getPaymentPlan().getId());
        assertEquals(PAYMENT_MODE, result.getPaymentPlan().getPaymentMode());
    }

    @Test
    public void match_agreementConfigSortedByOrder() {
        PurchaseRule rule = buildRule(1L, PRODUCT_ID, 1);
        AgreementConfig a1 = new AgreementConfig();
        a1.setAgreementCode("A1");
        a1.setSortOrder(2);
        AgreementConfig a2 = new AgreementConfig();
        a2.setAgreementCode("A2");
        a2.setSortOrder(1);
        rule.setAgreementConfig(Arrays.asList(a1, a2));

        when(purchaseRuleRepository.getRulesByCategoryId(PurchaseCategoryEnum.CABINET.getCode()))
                .thenReturn(Collections.singletonList(rule));
        when(purchasePaymentPlanRepository.listByIds(anyList()))
                .thenReturn(Collections.singletonList(buildPaymentPlan(500L)));

        PurchaseRuleMatcher.MatchResult result = matcher.match(
                ITEM_ID, CUSTOMER_ID, CUSTOMER_TYPE, PAYMENT_MODE, DELIVERY_TYPE);

        List<String> codes = result.getRule().getAgreementCodeList();
        assertEquals(Arrays.asList("A2", "A1"), codes);
    }

    /* ============================== helpers ============================== */

    private interface ThrowingCall {
        void call();
    }

    private void assertIllegalParam(ThrowingCall call) {
        try {
            call.call();
            fail("期望抛出 PurchaseDomainException");
        } catch (PurchaseDomainException e) {
            assertEquals(PurchaseDomainException.CODE_ILLEGAL_PARAM, e.getCode());
        }
    }

    private PurchaseRule buildRule(Long ruleId, Long productId, int level) {
        PurchaseRule rule = new PurchaseRule();
        rule.setId(ruleId);
        rule.setProductId(productId);
        rule.setSkuId(productId * 10);
        rule.setCategoryId(PurchaseCategoryEnum.CABINET.getCode());
        rule.setLevel(level);
        rule.setDeliveryTypeList(Collections.singletonList(DELIVERY_TYPE));

        CustomerConfig cc = new CustomerConfig();
        cc.setCustomerType(CUSTOMER_TYPE);
        rule.setCustomerConfig(cc);

        AgreementConfig agreement = new AgreementConfig();
        agreement.setAgreementCode("AGR_" + ruleId);
        agreement.setSortOrder(1);
        rule.setAgreementConfig(Collections.singletonList(agreement));

        PaymentPlanConfig planCfg = new PaymentPlanConfig();
        planCfg.setPaymentMode(PAYMENT_MODE);
        planCfg.setPaymentPlanId("500");
        planCfg.setPaymentPlanName("默认支付方案");
        rule.setPaymentPlanConfig(Collections.singletonList(planCfg));
        return rule;
    }

    private PurchasePaymentPlan buildPaymentPlan(Long id) {
        PurchasePaymentPlan plan = new PurchasePaymentPlan();
        plan.setId(id);
        plan.setPayCode("PAY_CODE");
        plan.setPayName("默认支付");
        plan.setPaymentMode(PAYMENT_MODE);
        plan.setPaymentConfig("{}");
        return plan;
    }
}
