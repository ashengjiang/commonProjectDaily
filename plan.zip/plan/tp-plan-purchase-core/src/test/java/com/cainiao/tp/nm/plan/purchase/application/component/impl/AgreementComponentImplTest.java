package com.cainiao.tp.nm.plan.purchase.application.component.impl;

import com.cainiao.tp.nm.plan.infra.port.common.constants.ErrorCode;
import com.cainiao.tp.nm.plan.infra.port.common.exception.PurchaseServiceException;
import com.cainiao.tp.nm.plan.infra.port.dto.AgreementInfoAndSignDTO;
import com.cainiao.tp.nm.plan.infra.port.dto.param.QueryAgreementParam;
import com.cainiao.tp.nm.plan.infra.port.dto.param.SignAgreementParam;
import com.cainiao.tp.nm.plan.purchase.application.component.AgreementQueryHandler;
import com.cainiao.tp.nm.plan.purchase.application.component.factory.AgreementQueryHandlerFactory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * AgreementComponentImpl 单元测试
 * <p>
 * 校验：
 * 1. 入参校验（param/customerType 必填）；
 * 2. 按 customerType 路由到对应 handler；
 * 3. sign 方法对 customerType 字符串转 Integer 的容错。
 * </p> */
@RunWith(MockitoJUnitRunner.class)
public class AgreementComponentImplTest {

    @InjectMocks
    private AgreementComponentImpl component;

    @Mock
    private AgreementQueryHandlerFactory factory;

    @Mock
    private AgreementQueryHandler handler;

    /* ============================== queryAgreementInfoAndSigned ============================== */

    @Test
    public void queryAgreementInfoAndSigned_paramNull_shouldThrow() {
        try {
            component.queryAgreementInfoAndSigned(null);
            fail("期望抛出 PurchaseServiceException");
        } catch (PurchaseServiceException e) {
            assertEquals(ErrorCode.ILLEGAL_PARAM.getCode(), e.getCode());
        }
    }

    @Test
    public void queryAgreementInfoAndSigned_customerTypeNull_shouldThrow() {
        QueryAgreementParam param = new QueryAgreementParam();
        param.setAgreementCode("CODE");
        try {
            component.queryAgreementInfoAndSigned(param);
            fail("期望抛出 PurchaseServiceException");
        } catch (PurchaseServiceException e) {
            assertEquals(ErrorCode.ILLEGAL_PARAM.getCode(), e.getCode());
        }
    }

    @Test
    public void queryAgreementInfoAndSigned_shouldDispatchToHandler() {
        QueryAgreementParam param = new QueryAgreementParam();
        param.setCustomerType(1);
        param.setAgreementCode("CODE");

        AgreementInfoAndSignDTO expected = new AgreementInfoAndSignDTO();
        expected.setAgreementCode("CODE");
        when(factory.getHandler(1)).thenReturn(handler);
        when(handler.query(param)).thenReturn(expected);

        AgreementInfoAndSignDTO actual = component.queryAgreementInfoAndSigned(param);

        assertSame(expected, actual);
        verify(factory).getHandler(1);
        verify(handler).query(param);
    }

    /* ============================== sign ============================== */

    @Test
    public void sign_paramNull_shouldThrow() {
        try {
            component.sign(null);
            fail("期望抛出 PurchaseServiceException");
        } catch (PurchaseServiceException e) {
            assertEquals(ErrorCode.ILLEGAL_PARAM.getCode(), e.getCode());
        }
    }

    @Test
    public void sign_customerTypeBlank_shouldThrow() {
        SignAgreementParam param = new SignAgreementParam();
        param.setCustomerType("  ");
        try {
            component.sign(param);
            fail("期望抛出 PurchaseServiceException");
        } catch (PurchaseServiceException e) {
            assertEquals(ErrorCode.ILLEGAL_PARAM.getCode(), e.getCode());
        }
    }

    @Test
    public void sign_customerTypeNotInt_shouldThrow() {
        SignAgreementParam param = new SignAgreementParam();
        param.setCustomerType("abc");
        try {
            component.sign(param);
            fail("期望抛出 PurchaseServiceException");
        } catch (PurchaseServiceException e) {
            assertEquals(ErrorCode.ILLEGAL_PARAM.getCode(), e.getCode());
        }
    }

    @Test
    public void sign_shouldDispatchToHandlerWithParsedCustomerType() {
        SignAgreementParam param = new SignAgreementParam();
        param.setCustomerType("1");
        when(factory.getHandler(1)).thenReturn(handler);
        when(handler.sign(param)).thenReturn(123L);

        Long agreementId = component.sign(param);

        assertEquals(Long.valueOf(123L), agreementId);
        verify(factory).getHandler(1);
        verify(handler).sign(param);
    }

    /**
     * 工厂找不到 handler 时（旧版返回 null/抛错由工厂决定），本组件仅做参数校验，不做兜底。
     */
    @Test(expected = NullPointerException.class)
    public void queryAgreementInfoAndSigned_factoryReturnNull_shouldNPE() {
        QueryAgreementParam param = new QueryAgreementParam();
        param.setCustomerType(99);
        when(factory.getHandler(anyInt())).thenReturn(null);
        component.queryAgreementInfoAndSigned(param);
    }
}
