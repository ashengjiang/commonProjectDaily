package com.cainiao.tp.nm.plan.purchase.application.component.factory;

import com.cainiao.tp.nm.plan.infra.port.common.exception.PurchaseServiceException;
import com.cainiao.tp.nm.plan.purchase.application.component.AgreementQueryHandler;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.ApplicationContext;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.when;

/**
 * AgreementQueryHandlerFactory 单元测试 */
@RunWith(MockitoJUnitRunner.class)
public class AgreementQueryHandlerFactoryTest {

    @InjectMocks
    private AgreementQueryHandlerFactory factory;

    @Mock
    private ApplicationContext applicationContext;

    @Mock
    private AgreementQueryHandler stationHandler;

    @Mock
    private AgreementQueryHandler outletHandler;

    @Mock
    private AgreementQueryHandler nullTypeHandler;

    @Before
    public void setUp() throws Exception {
        when(stationHandler.customerType()).thenReturn(1);
        when(outletHandler.customerType()).thenReturn(2);
        when(nullTypeHandler.customerType()).thenReturn(null);
    }

    /* ============================== afterPropertiesSet ============================== */

    @Test
    public void afterPropertiesSet_emptyBeans_shouldInitEmptyRouter() throws Exception {
        when(applicationContext.getBeansOfType(AgreementQueryHandler.class)).thenReturn(new HashMap<>());
        factory.afterPropertiesSet();

        try {
            factory.getHandler(1);
            fail("空路由表应该抛异常");
        } catch (PurchaseServiceException e) {
            // expected
        }
    }

    @Test
    public void afterPropertiesSet_normalBeans_shouldBuildRouter() throws Exception {
        Map<String, AgreementQueryHandler> beanMap = new HashMap<>();
        beanMap.put("stationHandler", stationHandler);
        beanMap.put("outletHandler", outletHandler);
        when(applicationContext.getBeansOfType(AgreementQueryHandler.class)).thenReturn(beanMap);

        factory.afterPropertiesSet();

        assertSame(stationHandler, factory.getHandler(1));
        assertSame(outletHandler, factory.getHandler(2));
    }

    @Test
    public void afterPropertiesSet_handlerWithNullType_shouldBeIgnored() throws Exception {
        Map<String, AgreementQueryHandler> beanMap = new HashMap<>();
        beanMap.put("station", stationHandler);
        beanMap.put("nullType", nullTypeHandler);
        when(applicationContext.getBeansOfType(AgreementQueryHandler.class)).thenReturn(beanMap);

        factory.afterPropertiesSet();
        // 正常 handler 仍能拿到
        assertSame(stationHandler, factory.getHandler(1));
    }

    @Test
    public void afterPropertiesSet_contextThrows_shouldRethrow() {
        when(applicationContext.getBeansOfType(AgreementQueryHandler.class))
                .thenThrow(new RuntimeException("ctx init failed"));

        try {
            factory.afterPropertiesSet();
            fail("应该抛异常");
        } catch (Exception e) {
            assertEquals("ctx init failed", e.getMessage());
        }
    }

    /* ============================== getHandler ============================== */

    @Test
    public void getHandler_customerTypeNull_shouldThrow() {
        try {
            factory.getHandler(null);
            fail("应该抛异常");
        } catch (PurchaseServiceException e) {
            // expected
        }
    }

    @Test
    public void getHandler_unknownCustomerType_shouldThrow() throws Exception {
        Map<String, AgreementQueryHandler> beanMap = new HashMap<>();
        beanMap.put("stationHandler", stationHandler);
        when(applicationContext.getBeansOfType(AgreementQueryHandler.class)).thenReturn(beanMap);
        factory.afterPropertiesSet();

        try {
            factory.getHandler(999);
            fail("应该抛异常");
        } catch (PurchaseServiceException e) {
            // expected
        }
    }

    @Test
    public void getHandler_hit_shouldReturnSameInstance() throws Exception {
        Map<String, AgreementQueryHandler> beanMap = new HashMap<>();
        beanMap.put("station", stationHandler);
        beanMap.put("outlet", outletHandler);
        when(applicationContext.getBeansOfType(AgreementQueryHandler.class)).thenReturn(beanMap);
        factory.afterPropertiesSet();

        AgreementQueryHandler h1 = factory.getHandler(1);
        AgreementQueryHandler h2 = factory.getHandler(1);
        assertSame(h1, h2);
    }
}
