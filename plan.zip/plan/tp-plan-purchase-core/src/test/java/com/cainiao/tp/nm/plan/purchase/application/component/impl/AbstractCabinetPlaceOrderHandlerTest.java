package com.cainiao.tp.nm.plan.purchase.application.component.impl;

import com.alibaba.fastjson.JSON;
import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.aladdin.operation.SystemBizOperation;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.AgreementInfoDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.PlaceOrderResultDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.ProductInfoDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.ProductInfoResultDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.PurchasePaymentPlanDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.PurchaseRuleDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PlaceOrderParam;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PurchaseOrderCreateParam;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PurchaseProductParam;
import com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseOrderStatusEnum;
import com.cainiao.tp.nm.plan.api.purchase.common.constants.SnapshotFeatureKeyEnum;
import com.cainiao.tp.nm.plan.infra.port.common.constants.ErrorCode;
import com.cainiao.tp.nm.plan.infra.port.common.exception.PurchaseServiceException;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.DuoNiuSkuDetailDTO;
import com.cainiao.tp.nm.plan.infra.port.purchase.DuoNiuQueryManager;
import com.cainiao.tp.nm.plan.purchase.application.component.CabinetPlaceOrderContext;
import com.cainiao.tp.nm.plan.purchase.application.component.calculator.PriceResult;
import com.cainiao.tp.nm.plan.purchase.application.component.calculator.PurchasePriceCalculator;
import com.cainiao.tp.nm.plan.purchase.application.component.factory.PurchasePaymentUrlFetcherFactory;
import com.cainiao.tp.nm.plan.purchase.application.component.factory.PurchasePriceCalculatorFactory;
import com.cainiao.tp.nm.plan.purchase.application.component.fetcher.PaymentUrlFetchResult;
import com.cainiao.tp.nm.plan.purchase.application.component.fetcher.PurchasePaymentUrlFetcher;
import com.cainiao.tp.nm.plan.purchase.application.service.ProductionApplicationService;
import com.cainiao.tp.nm.plan.purchase.common.util.PurchaseThreadPoolUtil;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseOrder;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseProductSku;
import com.cainiao.tp.nm.plan.purchase.domain.model.valobj.PurchaseOrderProductSnapshot;
import com.cainiao.tp.nm.plan.purchase.domain.repository.PurchaseProductSkuRepository;
import com.cainiao.tp.nm.plan.purchase.domain.service.PurchaseOrderDomainService;
import com.cainiao.tp.nm.plan.purchase.domain.service.PurchaseRuleMatcher;
import com.cainiao.tp.nm.plan.purchase.domain.service.param.PurchaseOrderStatusUpdateParam;
import org.junit.Before;
import org.junit.Test;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * AbstractCabinetPlaceOrderHandler 单元测试
 * <p>
 * 通过测试专用子类 {@link TestableHandler} 走 placeOrder 主流程，覆盖：
 * 1. 入参校验（首次下单 vs 重新付款 互斥）
 * 2. 商品规则校验（商品不在规则池 / SKU 不存在 / SKU 停用）
 * 3. 库存校验（库存不足 / sourItemId 缺失 / 万里牛查不到）
 * 4. 算价
 * 5. 前置条件结果驱动状态机：通过→PAYING，未通过→SIGNING
 * 6. 多履约平台拦截
 * 7. 重新付款分支
 * </p> */
public class AbstractCabinetPlaceOrderHandlerTest {

    // ============= mocks =============
    private ProductionApplicationService productionApplicationService;
    private PurchaseOrderDomainService purchaseOrderDomainService;
    private PurchaseRuleMatcher purchaseRuleMatcher;
    private PurchaseProductSkuRepository purchaseProductSkuRepository;
    private PurchasePriceCalculatorFactory purchasePriceCalculatorFactory;
    private PurchasePaymentUrlFetcherFactory purchasePaymentUrlFetcherFactory;
    private DuoNiuQueryManager duoNiuQueryManager;
    private PurchaseThreadPoolUtil purchaseThreadPoolUtil;

    private TestableHandler handler;
    private AbstractOperation operation;

    private static final String CUSTOMER_ID = "C001";
    private static final Integer CUSTOMER_TYPE = 1;
    private static final Integer PAYMENT_MODE = 1;
    private static final Integer DELIVERY_TYPE = 1;
    private static final String ITEM_ID = "100";
    private static final Long SKU_ID = 555L;
    private static final String SOUR_ITEM_ID = "999";
    private static final String PLATFORM = "WANLINIU";

    @Before
    public void setUp() throws Exception {
        productionApplicationService = mock(ProductionApplicationService.class);
        purchaseOrderDomainService = mock(PurchaseOrderDomainService.class);
        purchaseRuleMatcher = mock(PurchaseRuleMatcher.class);
        purchaseProductSkuRepository = mock(PurchaseProductSkuRepository.class);
        purchasePriceCalculatorFactory = mock(PurchasePriceCalculatorFactory.class);
        purchasePaymentUrlFetcherFactory = mock(PurchasePaymentUrlFetcherFactory.class);
        duoNiuQueryManager = mock(DuoNiuQueryManager.class);
        purchaseThreadPoolUtil = mock(PurchaseThreadPoolUtil.class);

        // 让线程池 submit 同步执行
        when(purchaseThreadPoolUtil.submit(any())).thenAnswer(inv -> {
            java.util.concurrent.Callable<?> task = inv.getArgument(0);
            FutureTask<?> ft = new FutureTask<>(task);
            ft.run();
            return ft;
        });
        when(purchaseThreadPoolUtil.getExecutor()).thenReturn((Executor) Executors.newSingleThreadExecutor());

        handler = new TestableHandler();
        injectField(handler, "productionApplicationService", productionApplicationService);
        injectField(handler, "purchaseOrderDomainService", purchaseOrderDomainService);
        injectField(handler, "purchaseRuleMatcher", purchaseRuleMatcher);
        injectField(handler, "purchaseProductSkuRepository", purchaseProductSkuRepository);
        injectField(handler, "purchasePriceCalculatorFactory", purchasePriceCalculatorFactory);
        injectField(handler, "purchasePaymentUrlFetcherFactory", purchasePaymentUrlFetcherFactory);
        injectField(handler, "duoNiuQueryManager", duoNiuQueryManager);
        injectField(handler, "purchaseThreadPoolUtil", purchaseThreadPoolUtil);

        operation = new SystemBizOperation(1L, "tester");
    }

    /* ============================== 入参校验 ============================== */

    @Test
    public void placeOrder_paramNull_shouldThrow() {
        assertIllegalParam(() -> handler.placeOrder(null, operation));
    }

    @Test
    public void placeOrder_firstOrder_skuListEmpty_shouldThrow() {
        PlaceOrderParam param = buildBaseParam();
        param.setPurchaseSkuInfoList(Collections.emptyList());
        assertIllegalParam(() -> handler.placeOrder(param, operation));
    }

    @Test
    public void placeOrder_firstOrder_paymentModeNull_shouldThrow() {
        PlaceOrderParam param = buildBaseParam();
        param.setPaymentMode(null);
        assertIllegalParam(() -> handler.placeOrder(param, operation));
    }

    @Test
    public void placeOrder_firstOrder_deliveryTypeNull_shouldThrow() {
        PlaceOrderParam param = buildBaseParam();
        param.setDeliveryType(null);
        assertIllegalParam(() -> handler.placeOrder(param, operation));
    }

    @Test
    public void placeOrder_firstOrder_skuItemIdBlank_shouldThrow() {
        PlaceOrderParam param = buildBaseParam();
        PurchaseProductParam bad = new PurchaseProductParam();
        bad.setItemId("");
        bad.setPurchaseNum(1);
        param.setPurchaseSkuInfoList(Collections.singletonList(bad));
        assertIllegalParam(() -> handler.placeOrder(param, operation));
    }

    @Test
    public void placeOrder_firstOrder_skuItemNull_shouldThrow() {
        PlaceOrderParam param = buildBaseParam();
        param.setPurchaseSkuInfoList(Collections.singletonList(null));
        assertIllegalParam(() -> handler.placeOrder(param, operation));
    }

    /* ============================== 商品规则校验 ============================== */

    @Test
    public void placeOrder_noAvailableProduct_shouldThrow() {
        PlaceOrderParam param = buildBaseParam();
        when(productionApplicationService.getProductInfo(any(), any())).thenReturn(null);
        assertIllegalParam(() -> handler.placeOrder(param, operation));
    }

    @Test
    public void placeOrder_productNotInRule_shouldThrow() {
        PlaceOrderParam param = buildBaseParam();
        // 商品池里只有 200，下单 100 -> 不在规则范围
        ProductInfoResultDTO infoResult = new ProductInfoResultDTO();
        ProductInfoDTO p = new ProductInfoDTO();
        p.setItemId(200);
        p.setItemTitle("其他商品");
        infoResult.setProductInfoList(Collections.singletonList(p));
        when(productionApplicationService.getProductInfo(any(), any())).thenReturn(infoResult);

        assertIllegalParam(() -> handler.placeOrder(param, operation));
    }

    @Test
    public void placeOrder_ruleMatchedButSkuIdNull_shouldThrow() {
        PlaceOrderParam param = buildBaseParam();
        mockProductInfo();
        // 规则命中但 skuId 为 null
        PurchaseRuleDTO rule = new PurchaseRuleDTO();
        rule.setId(1L);
        rule.setSkuId(null);
        when(purchaseRuleMatcher.match(anyString(), anyString(), anyInt(), anyInt(), anyInt()))
                .thenReturn(new PurchaseRuleMatcher.MatchResult(rule, buildPaymentPlan()));

        assertIllegalParam(() -> handler.placeOrder(param, operation));
    }

    @Test
    public void placeOrder_skuNotFound_shouldThrow() {
        PlaceOrderParam param = buildBaseParam();
        mockProductInfo();
        mockRuleMatched();
        when(purchaseProductSkuRepository.getById(SKU_ID)).thenReturn(null);
        assertIllegalParam(() -> handler.placeOrder(param, operation));
    }

    @Test
    public void placeOrder_skuDisabled_shouldThrow() {
        PlaceOrderParam param = buildBaseParam();
        mockProductInfo();
        mockRuleMatched();
        PurchaseProductSku sku = buildSku();
        sku.setStatus(0); // 停用
        when(purchaseProductSkuRepository.getById(SKU_ID)).thenReturn(sku);
        assertIllegalParam(() -> handler.placeOrder(param, operation));
    }

    /* ============================== 库存校验 ============================== */

    @Test
    public void placeOrder_skuNoSourItemId_shouldThrow() {
        PlaceOrderParam param = buildBaseParam();
        mockProductInfo();
        mockRuleMatched();
        PurchaseProductSku sku = buildSku();
        sku.setFeature(new HashMap<>()); // 没有 sourItemId
        when(purchaseProductSkuRepository.getById(SKU_ID)).thenReturn(sku);
        assertIllegalParam(() -> handler.placeOrder(param, operation));
    }

    @Test
    public void placeOrder_duoNiuSkuNotFound_shouldThrow() {
        PlaceOrderParam param = buildBaseParam();
        mockProductInfo();
        mockRuleMatched();
        when(purchaseProductSkuRepository.getById(SKU_ID)).thenReturn(buildSku());
        when(duoNiuQueryManager.querySkuByItemId(anyInt())).thenReturn(null);
        assertIllegalParam(() -> handler.placeOrder(param, operation));
    }

    @Test
    public void placeOrder_inventoryQuantityBlank_shouldThrow() {
        PlaceOrderParam param = buildBaseParam();
        mockProductInfo();
        mockRuleMatched();
        when(purchaseProductSkuRepository.getById(SKU_ID)).thenReturn(buildSku());
        DuoNiuSkuDetailDTO dn = new DuoNiuSkuDetailDTO();
        dn.setQuantity("");
        when(duoNiuQueryManager.querySkuByItemId(anyInt())).thenReturn(dn);
        assertIllegalParam(() -> handler.placeOrder(param, operation));
    }

    @Test
    public void placeOrder_inventoryNotEnough_shouldThrow() {
        PlaceOrderParam param = buildBaseParam();
        // 购买 10 件，库存只有 5
        param.getPurchaseSkuInfoList().get(0).setPurchaseNum(10);
        mockProductInfo();
        mockRuleMatched();
        when(purchaseProductSkuRepository.getById(SKU_ID)).thenReturn(buildSku());
        DuoNiuSkuDetailDTO dn = new DuoNiuSkuDetailDTO();
        dn.setQuantity("5");
        when(duoNiuQueryManager.querySkuByItemId(anyInt())).thenReturn(dn);
        assertIllegalParam(() -> handler.placeOrder(param, operation));
    }

    /* ============================== 主流程：成功 ============================== */

    @Test
    public void placeOrder_firstOrderHappyPath_shouldSucceedAndReturnPaymentUrl() {
        PlaceOrderParam param = buildBaseParam();
        mockProductInfo();
        mockRuleMatched();
        when(purchaseProductSkuRepository.getById(SKU_ID)).thenReturn(buildSku());
        mockInventoryEnough();
        mockCalculatorOK();
        // mock 订单创建：返回带 PAYING 状态、单平台的订单
        PurchaseOrder order = buildOrderWithSinglePlatform(99L, PurchaseOrderStatusEnum.PAYING.getCode());
        when(purchaseOrderDomainService.createOrder(any(PurchaseOrderCreateParam.class))).thenReturn(order);
        mockFetcherOK();

        // 子类前置条件全通过
        handler.preConditionResult = new PlaceOrderResultDTO();
        handler.allPassed = true;

        PlaceOrderResultDTO result = handler.placeOrder(param, operation);

        assertNotNull(result);
        assertEquals(Long.valueOf(99L), result.getOrderId());
        assertEquals("https://pay.example.com/abc", result.getItemBuyUrl());
        // 由于订单已经是 PAYING，不应再次更新状态
        verify(purchaseOrderDomainService, never()).updateOrderStatus(any(PurchaseOrderStatusUpdateParam.class));
    }

    @Test
    public void placeOrder_preConditionPassed_orderInOtherStatus_shouldUpdateToPaying() {
        PlaceOrderParam param = buildBaseParam();
        mockProductInfo();
        mockRuleMatched();
        when(purchaseProductSkuRepository.getById(SKU_ID)).thenReturn(buildSku());
        mockInventoryEnough();
        mockCalculatorOK();
        // 订单初始状态为 CREATE
        PurchaseOrder order = buildOrderWithSinglePlatform(100L, PurchaseOrderStatusEnum.CREATE.getCode());
        when(purchaseOrderDomainService.createOrder(any(PurchaseOrderCreateParam.class))).thenReturn(order);
        mockFetcherOK();

        handler.preConditionResult = new PlaceOrderResultDTO();
        handler.allPassed = true;

        PlaceOrderResultDTO result = handler.placeOrder(param, operation);
        assertEquals(Long.valueOf(100L), result.getOrderId());
        // 应该被推进到 PAYING
        verify(purchaseOrderDomainService).updateOrderStatus(any(PurchaseOrderStatusUpdateParam.class));
    }

    /* ============================== 主流程：前置不通过 ============================== */

    @Test
    public void placeOrder_preConditionNotPassed_shouldSetSigningAndSkipFetch() {
        PlaceOrderParam param = buildBaseParam();
        mockProductInfo();
        mockRuleMatched();
        when(purchaseProductSkuRepository.getById(SKU_ID)).thenReturn(buildSku());
        mockInventoryEnough();
        mockCalculatorOK();
        PurchaseOrder order = buildOrderWithSinglePlatform(200L, PurchaseOrderStatusEnum.CREATE.getCode());
        when(purchaseOrderDomainService.createOrder(any(PurchaseOrderCreateParam.class))).thenReturn(order);

        // 前置不通过
        PlaceOrderResultDTO pre = new PlaceOrderResultDTO();
        AgreementInfoDTO agreement = new AgreementInfoDTO();
        agreement.setSign(Boolean.FALSE);
        pre.setPurchaseAgreement(agreement);
        handler.preConditionResult = pre;
        handler.allPassed = false;

        PlaceOrderResultDTO result = handler.placeOrder(param, operation);

        assertEquals(Long.valueOf(200L), result.getOrderId());
        // 没拉付款链接
        assertNull(result.getItemBuyUrl());
        // 订单状态推进到 SIGNING
        verify(purchaseOrderDomainService).updateOrderStatus(any(PurchaseOrderStatusUpdateParam.class));
        // fetcher 工厂不会被调用
        verify(purchasePaymentUrlFetcherFactory, never()).getFetcher(anyString());
    }

    /* ============================== 多履约平台 ============================== */

    @Test
    public void placeOrder_multiplePlatform_shouldThrow() {
        PlaceOrderParam param = buildBaseParam();
        mockProductInfo();
        mockRuleMatched();
        when(purchaseProductSkuRepository.getById(SKU_ID)).thenReturn(buildSku());
        mockInventoryEnough();
        mockCalculatorOK();
        // 订单两行：一行 WANLINIU，另一行 OTHER 平台
        PurchaseOrder order = new PurchaseOrder();
        order.setId(300L);
        order.setStatus(PurchaseOrderStatusEnum.PAYING.getCode());
        PurchaseOrderProductSnapshot s1 = new PurchaseOrderProductSnapshot();
        s1.setProductId(ITEM_ID);
        s1.setProductSkuSource("WANLINIU");
        PurchaseOrderProductSnapshot s2 = new PurchaseOrderProductSnapshot();
        s2.setProductId(ITEM_ID);
        s2.setProductSkuSource("OTHER");
        order.setProductSnapshotList(Arrays.asList(s1, s2));
        when(purchaseOrderDomainService.createOrder(any(PurchaseOrderCreateParam.class))).thenReturn(order);

        handler.preConditionResult = new PlaceOrderResultDTO();
        handler.allPassed = true;

        assertIllegalParam(() -> handler.placeOrder(param, operation));
    }

    @Test
    public void placeOrder_emptySnapshot_shouldThrow() {
        PlaceOrderParam param = buildBaseParam();
        mockProductInfo();
        mockRuleMatched();
        when(purchaseProductSkuRepository.getById(SKU_ID)).thenReturn(buildSku());
        mockInventoryEnough();
        mockCalculatorOK();
        PurchaseOrder order = new PurchaseOrder();
        order.setId(400L);
        order.setStatus(PurchaseOrderStatusEnum.PAYING.getCode());
        order.setProductSnapshotList(Collections.emptyList());
        when(purchaseOrderDomainService.createOrder(any(PurchaseOrderCreateParam.class))).thenReturn(order);

        handler.preConditionResult = new PlaceOrderResultDTO();
        handler.allPassed = true;

        assertIllegalParam(() -> handler.placeOrder(param, operation));
    }

    @Test
    public void placeOrder_blankPlatform_shouldThrow() {
        PlaceOrderParam param = buildBaseParam();
        mockProductInfo();
        mockRuleMatched();
        when(purchaseProductSkuRepository.getById(SKU_ID)).thenReturn(buildSku());
        mockInventoryEnough();
        mockCalculatorOK();
        PurchaseOrder order = new PurchaseOrder();
        order.setId(500L);
        order.setStatus(PurchaseOrderStatusEnum.PAYING.getCode());
        PurchaseOrderProductSnapshot s = new PurchaseOrderProductSnapshot();
        s.setProductId(ITEM_ID);
        s.setProductSkuSource(""); // 空 platform
        order.setProductSnapshotList(Collections.singletonList(s));
        when(purchaseOrderDomainService.createOrder(any(PurchaseOrderCreateParam.class))).thenReturn(order);

        handler.preConditionResult = new PlaceOrderResultDTO();
        handler.allPassed = true;

        assertIllegalParam(() -> handler.placeOrder(param, operation));
    }

    /* ============================== 重新付款分支 ============================== */

    @Test
    public void placeOrder_repay_shouldQueryByIdAndSkipCreate() {
        PlaceOrderParam param = new PlaceOrderParam();
        param.setOrderId(888L);
        param.setCustomerId(CUSTOMER_ID);
        param.setCustomerType(CUSTOMER_TYPE);

        // 已存在的订单（PAYING 状态、单平台）
        PurchaseOrder order = buildOrderWithSinglePlatform(888L, PurchaseOrderStatusEnum.PAYING.getCode());
        when(purchaseOrderDomainService.queryOrderById(888L)).thenReturn(order);
        mockFetcherOK();

        handler.preConditionResult = new PlaceOrderResultDTO();
        handler.allPassed = true;

        PlaceOrderResultDTO result = handler.placeOrder(param, operation);

        assertEquals(Long.valueOf(888L), result.getOrderId());
        assertEquals("https://pay.example.com/abc", result.getItemBuyUrl());
        // 不应触发新建
        verify(purchaseOrderDomainService, never()).createOrder(any(PurchaseOrderCreateParam.class));
        // 不应触发规则匹配/库存查询
        verify(purchaseRuleMatcher, never()).match(anyString(), anyString(), anyInt(), anyInt(), anyInt());
    }

    /* ============================== helpers ============================== */

    private interface ThrowingCall { void call(); }

    private void assertIllegalParam(ThrowingCall call) {
        try {
            call.call();
            fail("期望抛出 PurchaseServiceException");
        } catch (PurchaseServiceException e) {
            assertEquals(ErrorCode.ILLEGAL_PARAM.getCode(), e.getCode());
        }
    }

    private static void injectField(Object target, String name, Object value) throws Exception {
        Class<?> clazz = target.getClass();
        while (clazz != null) {
            try {
                Field f = clazz.getDeclaredField(name);
                f.setAccessible(true);
                f.set(target, value);
                return;
            } catch (NoSuchFieldException e) {
                clazz = clazz.getSuperclass();
            }
        }
        throw new NoSuchFieldException(name);
    }

    private PlaceOrderParam buildBaseParam() {
        PlaceOrderParam p = new PlaceOrderParam();
        p.setCustomerId(CUSTOMER_ID);
        p.setCustomerType(CUSTOMER_TYPE);
        p.setPaymentMode(PAYMENT_MODE);
        p.setDeliveryType(DELIVERY_TYPE);
        PurchaseProductParam sku = new PurchaseProductParam();
        sku.setItemId(ITEM_ID);
        sku.setPurchaseNum(1);
        p.setPurchaseSkuInfoList(new ArrayList<>(Collections.singletonList(sku)));
        return p;
    }

    private void mockProductInfo() {
        ProductInfoResultDTO infoResult = new ProductInfoResultDTO();
        ProductInfoDTO p = new ProductInfoDTO();
        p.setItemId(Integer.parseInt(ITEM_ID));
        p.setItemTitle("柜子A");
        infoResult.setProductInfoList(Collections.singletonList(p));
        when(productionApplicationService.getProductInfo(any(), any())).thenReturn(infoResult);
    }

    private void mockRuleMatched() {
        PurchaseRuleDTO rule = new PurchaseRuleDTO();
        rule.setId(1L);
        rule.setSkuId(SKU_ID);
        when(purchaseRuleMatcher.match(anyString(), anyString(), anyInt(), anyInt(), anyInt()))
                .thenReturn(new PurchaseRuleMatcher.MatchResult(rule, buildPaymentPlan()));
    }

    private PurchasePaymentPlanDTO buildPaymentPlan() {
        PurchasePaymentPlanDTO plan = new PurchasePaymentPlanDTO();
        plan.setId(500L);
        plan.setPaymentMode(PAYMENT_MODE);
        return plan;
    }

    private PurchaseProductSku buildSku() {
        PurchaseProductSku sku = new PurchaseProductSku();
        sku.setId(SKU_ID);
        sku.setSkuId(String.valueOf(SKU_ID));
        sku.setSkuName("默认SKU");
        sku.setSpecs("规格A");
        sku.setSkuSource(PLATFORM);
        sku.setStatus(1);
        Map<String, String> feature = new HashMap<>();
        feature.put(SnapshotFeatureKeyEnum.SOUR_ITEM_ID.getKey(), SOUR_ITEM_ID);
        sku.setFeature(feature);
        return sku;
    }

    private void mockInventoryEnough() {
        DuoNiuSkuDetailDTO dn = new DuoNiuSkuDetailDTO();
        dn.setQuantity("9999");
        when(duoNiuQueryManager.querySkuByItemId(anyInt())).thenReturn(dn);
    }

    private void mockCalculatorOK() {
        PurchasePriceCalculator calc = mock(PurchasePriceCalculator.class);
        when(calc.calculate(any(), any(), any())).thenReturn(
                new PriceResult(new BigDecimal("99.00"), new BigDecimal("99.00"), new BigDecimal("99.00")));
        when(purchasePriceCalculatorFactory.getCalculator(PAYMENT_MODE)).thenReturn(calc);
    }

    private void mockFetcherOK() {
        PurchasePaymentUrlFetcher fetcher = mock(PurchasePaymentUrlFetcher.class);
        when(fetcher.fetch(any(CabinetPlaceOrderContext.class))).thenReturn(
                PaymentUrlFetchResult.builder().itemBuyUrl("https://pay.example.com/abc").build());
        when(purchasePaymentUrlFetcherFactory.getFetcher(eq(PLATFORM))).thenReturn(fetcher);
    }

    private PurchaseOrder buildOrderWithSinglePlatform(Long orderId, Integer status) {
        PurchaseOrder order = new PurchaseOrder();
        order.setId(orderId);
        order.setStatus(status);
        PurchaseOrderProductSnapshot snapshot = new PurchaseOrderProductSnapshot();
        snapshot.setProductId(ITEM_ID);
        snapshot.setProductSkuSource(PLATFORM);
        order.setProductSnapshotList(Collections.singletonList(snapshot));
        return order;
    }

    /**
     * 测试专用子类：把抽象方法行为参数化，便于驱动各种前置条件分支
     */
    static class TestableHandler extends AbstractCabinetPlaceOrderHandler {
        PlaceOrderResultDTO preConditionResult = new PlaceOrderResultDTO();
        boolean allPassed = true;

        @Override
        public Integer customerType() {
            return 1;
        }

        @Override
        protected PlaceOrderResultDTO checkPreConditions(CabinetPlaceOrderContext context) {
            return preConditionResult;
        }

        @Override
        protected boolean isAllPreConditionsPassed(PlaceOrderResultDTO result) {
            return allPassed;
        }
    }
}
