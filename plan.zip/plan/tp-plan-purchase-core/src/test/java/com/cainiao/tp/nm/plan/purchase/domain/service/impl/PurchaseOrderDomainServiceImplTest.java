package com.cainiao.tp.nm.plan.purchase.domain.service.impl;

import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PurchaseOrderCreateParam;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PurchaseOrderProductSnapshotCreateParam;
import com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseOrderStatusEnum;
import com.cainiao.tp.nm.plan.purchase.domain.component.PurchaseOrderDefinition;
import com.cainiao.tp.nm.plan.purchase.domain.component.factory.PurchaseOrderDefinitionFactory;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseOrder;
import com.cainiao.tp.nm.plan.purchase.domain.repository.PurchaseOrderRepository;
import com.cainiao.tp.nm.plan.purchase.domain.service.param.PurchaseOrderStatusUpdateParam;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Collections;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * PurchaseOrderDomainServiceImpl 单元测试 */
@RunWith(MockitoJUnitRunner.class)
public class PurchaseOrderDomainServiceImplTest {

    @InjectMocks
    private PurchaseOrderDomainServiceImpl domainService;

    @Mock
    private PurchaseOrderRepository purchaseOrderRepository;

    @Mock
    private PurchaseOrderDefinitionFactory purchaseOrderDefinitionFactory;

    @Mock
    private PurchaseOrderDefinition definition;

    @Before
    public void setUp() {
        // 默认任意 definition 调用都通过校验
        when(purchaseOrderDefinitionFactory.getDefinition(anyString(), anyInt())).thenReturn(definition);
    }

    /* ============================== createOrder ============================== */

    @Test
    public void createOrder_shouldInvokeValidate_andSave_andReturnOrder() {
        PurchaseOrderCreateParam param = buildCreateParam();

        PurchaseOrder created = domainService.createOrder(param);

        assertNotNull(created);
        assertEquals("CUST_001", created.getCustomId());
        assertEquals(Integer.valueOf(1), created.getCustomType());
        assertEquals(PurchaseOrderStatusEnum.CREATE.getCode(), created.getStatus());
        verify(definition).validCreate(param);
        verify(purchaseOrderRepository).save(created);
    }

    /* ============================== queryOrderById ============================== */

    @Test
    public void queryOrderById_existing_shouldReturnIt() {
        PurchaseOrder order = PurchaseOrder.builder().id(100L).build();
        when(purchaseOrderRepository.findById(100L)).thenReturn(order);

        PurchaseOrder result = domainService.queryOrderById(100L);

        assertSame(order, result);
    }

    @Test
    public void queryOrderById_notFound_shouldReturnNull() {
        when(purchaseOrderRepository.findById(999L)).thenReturn(null);
        assertNull(domainService.queryOrderById(999L));
    }

    /* ============================== updateOrderStatus ============================== */

    @Test(expected = IllegalArgumentException.class)
    public void updateOrderStatus_orderNotFound_shouldThrow() {
        when(purchaseOrderRepository.findById(404L)).thenReturn(null);

        PurchaseOrderStatusUpdateParam param = PurchaseOrderStatusUpdateParam.builder()
                .orderId(404L)
                .status(PurchaseOrderStatusEnum.PAID.getCode())
                .operateId("0")
                .operateName("sys")
                .build();
        domainService.updateOrderStatus(param);
    }

    @Test
    public void updateOrderStatus_legalForwardTransition_shouldUpdateStatus() {
        PurchaseOrder order = PurchaseOrder.builder()
                .id(1L)
                .status(PurchaseOrderStatusEnum.CREATE.getCode())
                .build();
        when(purchaseOrderRepository.findById(1L)).thenReturn(order);

        PurchaseOrderStatusUpdateParam param = PurchaseOrderStatusUpdateParam.builder()
                .orderId(1L)
                .status(PurchaseOrderStatusEnum.PAID.getCode())
                .operateId("0")
                .operateName("sys")
                .build();

        domainService.updateOrderStatus(param);

        assertEquals(PurchaseOrderStatusEnum.PAID.getCode(), order.getStatus());
        verify(purchaseOrderRepository).update(order);
    }

    @Test(expected = IllegalStateException.class)
    public void updateOrderStatus_backwardTransition_shouldThrow() {
        PurchaseOrder order = PurchaseOrder.builder()
                .id(1L)
                .status(PurchaseOrderStatusEnum.SHIPPED.getCode())
                .build();
        when(purchaseOrderRepository.findById(1L)).thenReturn(order);

        // 试图从 SHIPPED 回退到 PAID，应抛 IllegalStateException
        PurchaseOrderStatusUpdateParam param = PurchaseOrderStatusUpdateParam.builder()
                .orderId(1L)
                .status(PurchaseOrderStatusEnum.PAID.getCode())
                .operateId("0")
                .operateName("sys")
                .build();
        domainService.updateOrderStatus(param);
    }

    @Test
    public void updateOrderStatus_sameStatus_shouldBeAllowed() {
        PurchaseOrder order = PurchaseOrder.builder()
                .id(1L)
                .status(PurchaseOrderStatusEnum.PAID.getCode())
                .build();
        when(purchaseOrderRepository.findById(1L)).thenReturn(order);

        PurchaseOrderStatusUpdateParam param = PurchaseOrderStatusUpdateParam.builder()
                .orderId(1L)
                .status(PurchaseOrderStatusEnum.PAID.getCode())
                .operateId("0")
                .operateName("sys")
                .build();
        domainService.updateOrderStatus(param);

        assertEquals(PurchaseOrderStatusEnum.PAID.getCode(), order.getStatus());
        verify(purchaseOrderRepository).update(order);
    }

    @Test
    public void updateOrderStatus_supplementPaymentTime_whenAbsent() {
        PurchaseOrder order = PurchaseOrder.builder()
                .id(1L)
                .status(PurchaseOrderStatusEnum.CREATE.getCode())
                .build();
        when(purchaseOrderRepository.findById(1L)).thenReturn(order);

        LocalDateTime payTime = LocalDateTime.of(2026, 1, 1, 10, 0);
        PurchaseOrderStatusUpdateParam param = PurchaseOrderStatusUpdateParam.builder()
                .orderId(1L)
                .status(PurchaseOrderStatusEnum.PAID.getCode())
                .actualPaymentAmount(new BigDecimal("100.00"))
                .paymentTime(payTime)
                .operateId("0")
                .operateName("sys")
                .build();

        domainService.updateOrderStatus(param);

        assertEquals(0, new BigDecimal("100.00").compareTo(order.getActualPaymentAmount()));
        assertEquals(payTime, order.getPaymentTime());
    }

    @Test
    public void updateOrderStatus_paymentAlreadyExists_shouldNotOverwrite() {
        LocalDateTime existingPayTime = LocalDateTime.of(2025, 12, 1, 9, 0);
        PurchaseOrder order = PurchaseOrder.builder()
                .id(1L)
                .status(PurchaseOrderStatusEnum.PAID.getCode())
                .actualPaymentAmount(new BigDecimal("88.88"))
                .paymentTime(existingPayTime)
                .build();
        when(purchaseOrderRepository.findById(1L)).thenReturn(order);

        PurchaseOrderStatusUpdateParam param = PurchaseOrderStatusUpdateParam.builder()
                .orderId(1L)
                .status(PurchaseOrderStatusEnum.SHIPPED.getCode())
                .actualPaymentAmount(new BigDecimal("200.00"))
                .paymentTime(LocalDateTime.now())
                .operateId("0")
                .operateName("sys")
                .build();

        domainService.updateOrderStatus(param);

        // 已存在的付款信息不应被覆盖
        assertEquals(0, new BigDecimal("88.88").compareTo(order.getActualPaymentAmount()));
        assertEquals(existingPayTime, order.getPaymentTime());
    }

    @Test
    public void updateOrderStatus_supplementShippingAndSignTime() {
        PurchaseOrder order = PurchaseOrder.builder()
                .id(1L)
                .status(PurchaseOrderStatusEnum.PAID.getCode())
                .build();
        when(purchaseOrderRepository.findById(1L)).thenReturn(order);

        LocalDateTime shipTime = LocalDateTime.of(2026, 1, 2, 10, 0);
        LocalDateTime signTime = LocalDateTime.of(2026, 1, 3, 10, 0);
        PurchaseOrderStatusUpdateParam param = PurchaseOrderStatusUpdateParam.builder()
                .orderId(1L)
                .status(PurchaseOrderStatusEnum.RECEIVED.getCode())
                .shippingTime(shipTime)
                .signTime(signTime)
                .operateId("0")
                .operateName("sys")
                .build();

        domainService.updateOrderStatus(param);

        assertEquals(shipTime, order.getShippingTime());
        assertEquals(signTime, order.getSignTime());
    }

    @Test
    public void updateOrderStatus_existingFulfillmentOrderId_shouldFillWhenBlank() {
        PurchaseOrder order = PurchaseOrder.builder()
                .id(1L)
                .status(PurchaseOrderStatusEnum.PAID.getCode())
                .build();
        when(purchaseOrderRepository.findById(1L)).thenReturn(order);

        PurchaseOrderStatusUpdateParam param = PurchaseOrderStatusUpdateParam.builder()
                .orderId(1L)
                .status(PurchaseOrderStatusEnum.SHIPPED.getCode())
                .existingFulfillmentOrderId("DN_ORD_001")
                .operateId("0")
                .operateName("sys")
                .build();

        domainService.updateOrderStatus(param);

        assertEquals("DN_ORD_001", order.getFulfillmentPlatformOrderId());
    }

    @Test
    public void updateOrderStatus_existingFulfillmentOrderId_shouldNotOverwriteWhenAlreadySet() {
        PurchaseOrder order = PurchaseOrder.builder()
                .id(1L)
                .status(PurchaseOrderStatusEnum.PAID.getCode())
                .fulfillmentPlatformOrderId("OLD_001")
                .build();
        when(purchaseOrderRepository.findById(1L)).thenReturn(order);

        PurchaseOrderStatusUpdateParam param = PurchaseOrderStatusUpdateParam.builder()
                .orderId(1L)
                .status(PurchaseOrderStatusEnum.SHIPPED.getCode())
                .existingFulfillmentOrderId("NEW_001")
                .operateId("0")
                .operateName("sys")
                .build();

        domainService.updateOrderStatus(param);

        assertEquals("OLD_001", order.getFulfillmentPlatformOrderId());
    }

    @Test
    public void updateOrderStatus_statusNull_shouldSkipTransitionCheck() {
        PurchaseOrder order = PurchaseOrder.builder()
                .id(1L)
                .status(PurchaseOrderStatusEnum.PAID.getCode())
                .build();
        when(purchaseOrderRepository.findById(1L)).thenReturn(order);

        // 只补付款时间，不带 status
        PurchaseOrderStatusUpdateParam param = PurchaseOrderStatusUpdateParam.builder()
                .orderId(1L)
                .paymentTime(LocalDateTime.of(2026, 1, 1, 10, 0))
                .actualPaymentAmount(new BigDecimal("66.66"))
                .operateId("0")
                .operateName("sys")
                .build();

        domainService.updateOrderStatus(param);

        // 状态不变
        assertEquals(PurchaseOrderStatusEnum.PAID.getCode(), order.getStatus());
        verify(purchaseOrderRepository).update(order);
    }

    /* ============================== helpers ============================== */

    private PurchaseOrderCreateParam buildCreateParam() {
        PurchaseOrderCreateParam param = new PurchaseOrderCreateParam();
        param.setCustomId("CUST_001");
        param.setCustomType(1);
        param.setPaymentMode(1);
        param.setDeliveryType(1);

        PurchaseOrderProductSnapshotCreateParam snapshot = new PurchaseOrderProductSnapshotCreateParam();
        snapshot.setProductId("100");
        snapshot.setProductSkuId("SKU_1");
        snapshot.setProductTitle("商品1");
        snapshot.setQuantity(1);
        snapshot.setUnitPrice(new BigDecimal("100.00"));
        snapshot.setTotalAmount(new BigDecimal("100.00"));
        snapshot.setPayableAmount(new BigDecimal("100.00"));
        param.setProductSnapshotList(Collections.singletonList(snapshot));
        return param;
    }
}
