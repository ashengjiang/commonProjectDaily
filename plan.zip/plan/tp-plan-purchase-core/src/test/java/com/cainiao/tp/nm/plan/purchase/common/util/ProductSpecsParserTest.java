package com.cainiao.tp.nm.plan.purchase.common.util;

import com.cainiao.tp.nm.plan.purchase.domain.model.valobj.CabinetGridInfo;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * ProductSpecsParser 单元测试 */
public class ProductSpecsParserTest {

    @Test
    public void parseGridList_null_shouldReturnEmpty() {
        List<CabinetGridInfo> list = ProductSpecsParser.parseGridList(null);
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    public void parseGridList_empty_shouldReturnEmpty() {
        assertTrue(ProductSpecsParser.parseGridList("").isEmpty());
    }

    @Test
    public void parseGridList_blank_shouldReturnEmpty() {
        assertTrue(ProductSpecsParser.parseGridList("   ").isEmpty());
    }

    @Test
    public void parseGridList_invalidJson_shouldReturnEmpty() {
        List<CabinetGridInfo> list = ProductSpecsParser.parseGridList("not a json");
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    public void parseGridList_singleItem_shouldParse() {
        String json = "[{\"gridType\":\"BIG\",\"size\":\"L\",\"num\":10}]";
        List<CabinetGridInfo> list = ProductSpecsParser.parseGridList(json);
        assertEquals(1, list.size());
        assertEquals("BIG", list.get(0).getGridType());
        assertEquals("L", list.get(0).getSize());
        assertEquals(Integer.valueOf(10), list.get(0).getNum());
    }

    @Test
    public void parseGridList_multipleItems_shouldParseAll() {
        String json = "[{\"gridType\":\"BIG\",\"num\":10},{\"gridType\":\"SMALL\",\"num\":20}]";
        List<CabinetGridInfo> list = ProductSpecsParser.parseGridList(json);
        assertEquals(2, list.size());
        assertEquals("BIG", list.get(0).getGridType());
        assertEquals("SMALL", list.get(1).getGridType());
    }

    @Test
    public void parseGridList_emptyArray_shouldReturnEmptyList() {
        List<CabinetGridInfo> list = ProductSpecsParser.parseGridList("[]");
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    public void parseGridList_malformedJson_shouldReturnEmpty() {
        List<CabinetGridInfo> list = ProductSpecsParser.parseGridList("[{not valid}]");
        assertTrue(list.isEmpty());
    }
}
