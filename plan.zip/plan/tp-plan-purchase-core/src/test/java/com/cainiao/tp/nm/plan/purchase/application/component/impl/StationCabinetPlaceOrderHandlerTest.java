package com.cainiao.tp.nm.plan.purchase.application.component.impl;

import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.aladdin.operation.SystemBizOperation;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.AgreementInfoDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.PlaceOrderResultDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.PurchaseRuleDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PlaceOrderParam;
import com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseCustomerTypeEnum;
import com.cainiao.tp.nm.plan.infra.port.dto.AgreementInfoAndSignDTO;
import com.cainiao.tp.nm.plan.infra.port.dto.param.QueryAgreementParam;
import com.cainiao.tp.nm.plan.infra.port.dto.param.SignAgreementParam;
import com.cainiao.tp.nm.plan.purchase.application.component.AgreementComponent;
import com.cainiao.tp.nm.plan.purchase.application.component.CabinetPlaceOrderContext;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseOrder;
import com.cainiao.tp.nm.plan.purchase.domain.model.valobj.PurchaseOrderProductSnapshot;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.Collections;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * StationCabinetPlaceOrderHandler 单元测试
 * <p>
 * 重点验证站点专属的前置校验差异点：
 * 1. customerType 返回 STATION
 * 2. 协议解析：无快照 / 快照协议为空 / 快照协议正常
 * 3. 协议查询：成功带回 sign / 已签直接通过 / 协议查询异常降级为未签
 * 4. 自动签约：未签 + param.sign=true → 走签约；签约成功 / 失败 / 抛异常分支
 * 5. isAllPreConditionsPassed：仅看 purchaseAgreement.sign
 * </p> */
@RunWith(MockitoJUnitRunner.class)
public class StationCabinetPlaceOrderHandlerTest {

    @InjectMocks
    private StationCabinetPlaceOrderHandler handler;

    @Mock
    private AgreementComponent agreementComponent;

    private static final String CUSTOMER_ID = "C001";
    private static final String CUSTOMER_CODE = "CODE_001";
    private static final String AGREEMENT_CODE = "AGR_001";
    private static final Long ORDER_ID = 100L;
    private AbstractOperation operation;

    @Before
    public void setUp() {
        operation = new SystemBizOperation(1L, "tester");
    }

    /* ============================== customerType ============================== */

    @Test
    public void customerType_shouldReturnStation() {
        assertEquals(PurchaseCustomerTypeEnum.STATION.getCode(), handler.customerType());
    }

    /* ============================== checkPreConditions ============================== */

    @Test
    public void checkPreConditions_orderNoSnapshot_shouldPassThrough() {
        // 无快照 → 视为无需签约 → 自动通过
        CabinetPlaceOrderContext ctx = buildContext(buildParam(false), buildOrderWithoutSnapshot());

        PlaceOrderResultDTO result = handler.checkPreConditions(ctx);

        assertNotNull(result.getPurchaseAgreement());
        assertTrue(result.getPurchaseAgreement().getSign());
        verify(agreementComponent, never()).queryAgreementInfoAndSigned(any(QueryAgreementParam.class));
    }

    @Test
    public void checkPreConditions_snapshotRuleNull_shouldPassThrough() {
        // 快照有但 rule 为空 → 视为无需签约
        PurchaseOrder order = buildOrderWithSnapshot(null);
        CabinetPlaceOrderContext ctx = buildContext(buildParam(false), order);

        PlaceOrderResultDTO result = handler.checkPreConditions(ctx);

        assertTrue(result.getPurchaseAgreement().getSign());
        verify(agreementComponent, never()).queryAgreementInfoAndSigned(any(QueryAgreementParam.class));
    }

    @Test
    public void checkPreConditions_agreementCodeListEmpty_shouldPassThrough() {
        // 规则里没有协议码 → 视为无需签约
        PurchaseRuleDTO rule = new PurchaseRuleDTO();
        rule.setAgreementCodeList(Collections.emptyList());
        PurchaseOrder order = buildOrderWithSnapshot(rule);
        CabinetPlaceOrderContext ctx = buildContext(buildParam(false), order);

        PlaceOrderResultDTO result = handler.checkPreConditions(ctx);

        assertTrue(result.getPurchaseAgreement().getSign());
        verify(agreementComponent, never()).queryAgreementInfoAndSigned(any(QueryAgreementParam.class));
    }

    @Test
    public void checkPreConditions_alreadySigned_shouldReturnSignTrue() {
        // 已签约 → 直接通过，不再调签约
        CabinetPlaceOrderContext ctx = buildContext(buildParam(false), buildOrderWithAgreement());

        AgreementInfoAndSignDTO signed = new AgreementInfoAndSignDTO();
        signed.setAgreementId(99L);
        signed.setAgreementName("服务协议");
        signed.setAgreementUrl("https://t.cn/x");
        signed.setSigned(Boolean.TRUE);
        when(agreementComponent.queryAgreementInfoAndSigned(any(QueryAgreementParam.class))).thenReturn(signed);

        PlaceOrderResultDTO result = handler.checkPreConditions(ctx);

        AgreementInfoDTO agreement = result.getPurchaseAgreement();
        assertTrue(agreement.getSign());
        assertEquals("99", agreement.getAgreementId());
        assertEquals("服务协议", agreement.getAgreementName());
        verify(agreementComponent, never()).sign(any(SignAgreementParam.class));
    }

    @Test
    public void checkPreConditions_queryReturnNull_shouldFallbackUnsigned() {
        // 协议查询返回 null → sign=false
        CabinetPlaceOrderContext ctx = buildContext(buildParam(false), buildOrderWithAgreement());
        when(agreementComponent.queryAgreementInfoAndSigned(any(QueryAgreementParam.class))).thenReturn(null);

        PlaceOrderResultDTO result = handler.checkPreConditions(ctx);

        assertFalse(result.getPurchaseAgreement().getSign());
        assertEquals(AGREEMENT_CODE, result.getPurchaseAgreement().getAgreementCode());
        verify(agreementComponent, never()).sign(any(SignAgreementParam.class));
    }

    @Test
    public void checkPreConditions_queryThrowsException_shouldFallbackUnsigned() {
        // 协议查询异常 → 降级为未签
        CabinetPlaceOrderContext ctx = buildContext(buildParam(false), buildOrderWithAgreement());
        when(agreementComponent.queryAgreementInfoAndSigned(any(QueryAgreementParam.class)))
                .thenThrow(new RuntimeException("RPC failed"));

        PlaceOrderResultDTO result = handler.checkPreConditions(ctx);

        assertFalse(result.getPurchaseAgreement().getSign());
        verify(agreementComponent, never()).sign(any(SignAgreementParam.class));
    }

    @Test
    public void checkPreConditions_notSigned_userNotConfirm_shouldSkipSign() {
        // 未签 + 未确认 → 不签约，sign 保持 false
        CabinetPlaceOrderContext ctx = buildContext(buildParam(false), buildOrderWithAgreement());
        when(agreementComponent.queryAgreementInfoAndSigned(any(QueryAgreementParam.class)))
                .thenReturn(unsignedInfo());

        PlaceOrderResultDTO result = handler.checkPreConditions(ctx);

        assertFalse(result.getPurchaseAgreement().getSign());
        verify(agreementComponent, never()).sign(any(SignAgreementParam.class));
    }

    @Test
    public void checkPreConditions_notSigned_userConfirm_signSuccess() {
        // 未签 + 用户已确认 + 签约成功 → sign 被改成 true
        CabinetPlaceOrderContext ctx = buildContext(buildParam(true), buildOrderWithAgreement());
        when(agreementComponent.queryAgreementInfoAndSigned(any(QueryAgreementParam.class)))
                .thenReturn(unsignedInfo());
        when(agreementComponent.sign(any(SignAgreementParam.class))).thenReturn(123L);

        PlaceOrderResultDTO result = handler.checkPreConditions(ctx);

        assertTrue(result.getPurchaseAgreement().getSign());
        verify(agreementComponent).sign(any(SignAgreementParam.class));
    }

    @Test
    public void checkPreConditions_notSigned_userConfirm_signReturnNull_shouldRemainUnsigned() {
        // 未签 + 用户已确认 + 签约接口返回 null（视为失败）→ sign 仍为 false
        CabinetPlaceOrderContext ctx = buildContext(buildParam(true), buildOrderWithAgreement());
        when(agreementComponent.queryAgreementInfoAndSigned(any(QueryAgreementParam.class)))
                .thenReturn(unsignedInfo());
        when(agreementComponent.sign(any(SignAgreementParam.class))).thenReturn(null);

        PlaceOrderResultDTO result = handler.checkPreConditions(ctx);

        assertFalse(result.getPurchaseAgreement().getSign());
    }

    @Test
    public void checkPreConditions_notSigned_userConfirm_signThrows_shouldRemainUnsigned() {
        // 签约异常 → 降级为 false
        CabinetPlaceOrderContext ctx = buildContext(buildParam(true), buildOrderWithAgreement());
        when(agreementComponent.queryAgreementInfoAndSigned(any(QueryAgreementParam.class)))
                .thenReturn(unsignedInfo());
        when(agreementComponent.sign(any(SignAgreementParam.class)))
                .thenThrow(new RuntimeException("sign failed"));

        PlaceOrderResultDTO result = handler.checkPreConditions(ctx);

        assertFalse(result.getPurchaseAgreement().getSign());
    }

    @Test
    public void checkPreConditions_signParam_shouldCarryStationFields() {
        // 校验签约入参字段映射
        PlaceOrderParam param = buildParam(true);
        param.setCnUserAccountId(666L);
        CabinetPlaceOrderContext ctx = buildContext(param, buildOrderWithAgreement());
        when(agreementComponent.queryAgreementInfoAndSigned(any(QueryAgreementParam.class)))
                .thenReturn(unsignedInfo());
        when(agreementComponent.sign(any(SignAgreementParam.class))).thenReturn(1L);

        handler.checkPreConditions(ctx);

        ArgumentCaptor<SignAgreementParam> captor = ArgumentCaptor.forClass(SignAgreementParam.class);
        verify(agreementComponent).sign(captor.capture());
        SignAgreementParam signParam = captor.getValue();
        assertEquals(AGREEMENT_CODE, signParam.getAgreementCode());
        assertEquals(CUSTOMER_ID, signParam.getCustomerId());
        assertEquals("666", signParam.getUserId());
        // STATION code 字符串
        assertEquals(String.valueOf(PurchaseCustomerTypeEnum.STATION.getCode()), signParam.getCustomerType());
    }

    @Test
    public void checkPreConditions_queryParam_shouldCarryAllCustomerFields() {
        CabinetPlaceOrderContext ctx = buildContext(buildParam(false), buildOrderWithAgreement());
        when(agreementComponent.queryAgreementInfoAndSigned(any(QueryAgreementParam.class)))
                .thenReturn(unsignedInfo());

        handler.checkPreConditions(ctx);

        ArgumentCaptor<QueryAgreementParam> captor = ArgumentCaptor.forClass(QueryAgreementParam.class);
        verify(agreementComponent).queryAgreementInfoAndSigned(captor.capture());
        QueryAgreementParam queryParam = captor.getValue();
        assertEquals(AGREEMENT_CODE, queryParam.getAgreementCode());
        assertEquals(CUSTOMER_ID, queryParam.getCustomerId());
        assertEquals(CUSTOMER_CODE, queryParam.getCustomerCode());
        assertEquals(PurchaseCustomerTypeEnum.STATION.getCode(), queryParam.getCustomerType());
    }

    @Test
    public void checkPreConditions_multipleAgreementCodes_shouldOnlyUseFirst() {
        // 规则里配了 2 个协议码，按当前实现只取第一个
        PurchaseRuleDTO rule = new PurchaseRuleDTO();
        rule.setAgreementCodeList(Arrays.asList("AGR_A", "AGR_B"));
        PurchaseOrder order = buildOrderWithSnapshot(rule);
        CabinetPlaceOrderContext ctx = buildContext(buildParam(false), order);
        when(agreementComponent.queryAgreementInfoAndSigned(any(QueryAgreementParam.class)))
                .thenReturn(unsignedInfo());

        handler.checkPreConditions(ctx);

        ArgumentCaptor<QueryAgreementParam> captor = ArgumentCaptor.forClass(QueryAgreementParam.class);
        verify(agreementComponent).queryAgreementInfoAndSigned(captor.capture());
        assertEquals("AGR_A", captor.getValue().getAgreementCode());
    }

    /* ============================== isAllPreConditionsPassed ============================== */

    @Test
    public void isAllPreConditionsPassed_purchaseAgreementNull_shouldReturnFalse() {
        PlaceOrderResultDTO result = new PlaceOrderResultDTO();
        result.setPurchaseAgreement(null);
        assertFalse(handler.isAllPreConditionsPassed(result));
    }

    @Test
    public void isAllPreConditionsPassed_signFalse_shouldReturnFalse() {
        PlaceOrderResultDTO result = new PlaceOrderResultDTO();
        AgreementInfoDTO a = new AgreementInfoDTO();
        a.setSign(Boolean.FALSE);
        result.setPurchaseAgreement(a);
        assertFalse(handler.isAllPreConditionsPassed(result));
    }

    @Test
    public void isAllPreConditionsPassed_signNull_shouldReturnFalse() {
        PlaceOrderResultDTO result = new PlaceOrderResultDTO();
        AgreementInfoDTO a = new AgreementInfoDTO();
        a.setSign(null);
        result.setPurchaseAgreement(a);
        assertFalse(handler.isAllPreConditionsPassed(result));
    }

    @Test
    public void isAllPreConditionsPassed_signTrue_shouldReturnTrue() {
        PlaceOrderResultDTO result = new PlaceOrderResultDTO();
        AgreementInfoDTO a = new AgreementInfoDTO();
        a.setSign(Boolean.TRUE);
        result.setPurchaseAgreement(a);
        assertTrue(handler.isAllPreConditionsPassed(result));
    }

    @Test
    public void isAllPreConditionsPassed_ignoresOtherFields() {
        // 站点不关心实名 / 资金账户 / 支付宝代扣 → 即使这些为空也不影响
        PlaceOrderResultDTO result = new PlaceOrderResultDTO();
        AgreementInfoDTO a = new AgreementInfoDTO();
        a.setSign(Boolean.TRUE);
        result.setPurchaseAgreement(a);
        result.setIdentityVerification(null);
        result.setBindFundingAccount(null);
        result.setAlipayWithholdingAgreement(null);
        assertTrue(handler.isAllPreConditionsPassed(result));
    }

    /* ============================== helpers ============================== */

    private PlaceOrderParam buildParam(boolean sign) {
        PlaceOrderParam p = new PlaceOrderParam();
        p.setCustomerId(CUSTOMER_ID);
        p.setCustomerCode(CUSTOMER_CODE);
        p.setCustomerType(PurchaseCustomerTypeEnum.STATION.getCode());
        p.setSign(sign);
        return p;
    }

    private CabinetPlaceOrderContext buildContext(PlaceOrderParam param, PurchaseOrder order) {
        return CabinetPlaceOrderContext.builder()
                .param(param)
                .order(order)
                .operation(operation)
                .build();
    }

    private PurchaseOrder buildOrderWithoutSnapshot() {
        PurchaseOrder order = new PurchaseOrder();
        order.setId(ORDER_ID);
        order.setProductSnapshotList(Collections.emptyList());
        return order;
    }

    private PurchaseOrder buildOrderWithSnapshot(PurchaseRuleDTO rule) {
        PurchaseOrder order = new PurchaseOrder();
        order.setId(ORDER_ID);
        PurchaseOrderProductSnapshot snapshot = new PurchaseOrderProductSnapshot();
        snapshot.setPurchaseRule(rule);
        order.setProductSnapshotList(Collections.singletonList(snapshot));
        return order;
    }

    private PurchaseOrder buildOrderWithAgreement() {
        PurchaseRuleDTO rule = new PurchaseRuleDTO();
        rule.setAgreementCodeList(Collections.singletonList(AGREEMENT_CODE));
        return buildOrderWithSnapshot(rule);
    }

    private AgreementInfoAndSignDTO unsignedInfo() {
        AgreementInfoAndSignDTO info = new AgreementInfoAndSignDTO();
        info.setAgreementCode(AGREEMENT_CODE);
        info.setAgreementName("服务协议");
        info.setAgreementUrl("https://t.cn/x");
        info.setSigned(Boolean.FALSE);
        return info;
    }
}
