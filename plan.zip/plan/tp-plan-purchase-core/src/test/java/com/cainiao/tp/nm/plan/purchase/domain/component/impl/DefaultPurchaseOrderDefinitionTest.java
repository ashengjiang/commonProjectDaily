package com.cainiao.tp.nm.plan.purchase.domain.component.impl;

import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PurchaseOrderCreateParam;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PurchaseOrderProductSnapshotCreateParam;
import com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseDeliveryTypeEnum;
import com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchasePaymentModeEnum;
import com.cainiao.tp.nm.plan.purchase.domain.exception.PurchaseDomainException;
import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

/**
 * DefaultPurchaseOrderDefinition 单元测试 */
public class DefaultPurchaseOrderDefinitionTest {

    private DefaultPurchaseOrderDefinition definition;

    @Before
    public void setUp() {
        definition = new DefaultPurchaseOrderDefinition();
    }

    /* ============================== bizType / customType ============================== */

    @Test
    public void bizType_shouldReturnDefault() {
        assertEquals("default", definition.bizType());
    }

    @Test
    public void customType_shouldReturnDefault() {
        assertEquals("default", definition.customType());
    }

    /* ============================== validCreate：参数为空 ============================== */

    @Test
    public void validCreate_paramNull_shouldThrow() {
        try {
            definition.validCreate(null);
            fail();
        } catch (PurchaseDomainException e) {
            // expected
        }
    }

    @Test
    public void validCreate_customIdBlank_shouldThrow() {
        PurchaseOrderCreateParam p = buildValidParam();
        p.setCustomId("");
        assertThrowDomain(p);
    }

    @Test
    public void validCreate_customIdNull_shouldThrow() {
        PurchaseOrderCreateParam p = buildValidParam();
        p.setCustomId(null);
        assertThrowDomain(p);
    }

    @Test
    public void validCreate_customTypeNull_shouldThrow() {
        PurchaseOrderCreateParam p = buildValidParam();
        p.setCustomType(null);
        assertThrowDomain(p);
    }

    /* ============================== validCreate：支付模式 ============================== */

    @Test
    public void validCreate_paymentModeNull_shouldThrow() {
        PurchaseOrderCreateParam p = buildValidParam();
        p.setPaymentMode(null);
        assertThrowDomain(p);
    }

    @Test
    public void validCreate_paymentModeInvalid_shouldThrow() {
        PurchaseOrderCreateParam p = buildValidParam();
        p.setPaymentMode(999);
        assertThrowDomain(p);
    }

    @Test
    public void validCreate_paymentModeFullPayment_shouldPass() {
        PurchaseOrderCreateParam p = buildValidParam();
        p.setPaymentMode(PurchasePaymentModeEnum.FULL_PAYMENT.getCode());
        definition.validCreate(p);
    }

    @Test
    public void validCreate_paymentModeLoan_shouldPass() {
        PurchaseOrderCreateParam p = buildValidParam();
        p.setPaymentMode(PurchasePaymentModeEnum.LOAN.getCode());
        definition.validCreate(p);
    }

    @Test
    public void validCreate_paymentModeRental_shouldPass() {
        PurchaseOrderCreateParam p = buildValidParam();
        p.setPaymentMode(PurchasePaymentModeEnum.RENTAL.getCode());
        definition.validCreate(p);
    }

    /* ============================== validCreate：发货类型 ============================== */

    @Test
    public void validCreate_deliveryTypeNull_shouldThrow() {
        PurchaseOrderCreateParam p = buildValidParam();
        p.setDeliveryType(null);
        assertThrowDomain(p);
    }

    @Test
    public void validCreate_deliveryTypeInvalid_shouldThrow() {
        PurchaseOrderCreateParam p = buildValidParam();
        p.setDeliveryType(999);
        assertThrowDomain(p);
    }

    @Test
    public void validCreate_deliveryTypeSelfPickup_shouldPass() {
        PurchaseOrderCreateParam p = buildValidParam();
        p.setDeliveryType(PurchaseDeliveryTypeEnum.SELF_PICKUP.getCode());
        definition.validCreate(p);
    }

    @Test
    public void validCreate_deliveryTypeMerchantLogistics_shouldPass() {
        PurchaseOrderCreateParam p = buildValidParam();
        p.setDeliveryType(PurchaseDeliveryTypeEnum.MERCHANT_LOGISTICS.getCode());
        definition.validCreate(p);
    }

    /* ============================== validCreate：履约/下单人 ============================== */

    @Test
    public void validCreate_fulfillmentPlatformBlank_shouldThrow() {
        PurchaseOrderCreateParam p = buildValidParam();
        p.setFulfillmentPlatform("");
        assertThrowDomain(p);
    }

    @Test
    public void validCreate_ownerIdBlank_shouldThrow() {
        PurchaseOrderCreateParam p = buildValidParam();
        p.setOwnerId("");
        assertThrowDomain(p);
    }

    @Test
    public void validCreate_ownerNameBlank_shouldThrow() {
        PurchaseOrderCreateParam p = buildValidParam();
        p.setOwnerName("");
        assertThrowDomain(p);
    }

    /* ============================== validCreate：商品快照列表 ============================== */

    @Test
    public void validCreate_snapshotListEmpty_shouldThrow() {
        PurchaseOrderCreateParam p = buildValidParam();
        p.setProductSnapshotList(new ArrayList<>());
        assertThrowDomain(p);
    }

    @Test
    public void validCreate_snapshotListNull_shouldThrow() {
        PurchaseOrderCreateParam p = buildValidParam();
        p.setProductSnapshotList(null);
        assertThrowDomain(p);
    }

    @Test
    public void validCreate_snapshotItemNull_shouldThrow() {
        PurchaseOrderCreateParam p = buildValidParam();
        List<PurchaseOrderProductSnapshotCreateParam> list = new ArrayList<>();
        list.add(null);
        p.setProductSnapshotList(list);
        assertThrowDomain(p);
    }

    @Test
    public void validCreate_snapshotProductIdBlank_shouldThrow() {
        PurchaseOrderCreateParam p = buildValidParam();
        p.getProductSnapshotList().get(0).setProductId("");
        assertThrowDomain(p);
    }

    @Test
    public void validCreate_snapshotProductSkuIdBlank_shouldThrow() {
        PurchaseOrderCreateParam p = buildValidParam();
        p.getProductSnapshotList().get(0).setProductSkuId("");
        assertThrowDomain(p);
    }

    @Test
    public void validCreate_snapshotQuantityZero_shouldThrow() {
        PurchaseOrderCreateParam p = buildValidParam();
        p.getProductSnapshotList().get(0).setQuantity(0);
        assertThrowDomain(p);
    }

    @Test
    public void validCreate_snapshotQuantityNegative_shouldThrow() {
        PurchaseOrderCreateParam p = buildValidParam();
        p.getProductSnapshotList().get(0).setQuantity(-1);
        assertThrowDomain(p);
    }

    @Test
    public void validCreate_snapshotUnitPriceZero_shouldThrow() {
        PurchaseOrderCreateParam p = buildValidParam();
        p.getProductSnapshotList().get(0).setUnitPrice(BigDecimal.ZERO);
        assertThrowDomain(p);
    }

    @Test
    public void validCreate_snapshotTotalAmountNegative_shouldThrow() {
        PurchaseOrderCreateParam p = buildValidParam();
        p.getProductSnapshotList().get(0).setTotalAmount(new BigDecimal("-1"));
        assertThrowDomain(p);
    }

    @Test
    public void validCreate_snapshotPayableAmountZero_shouldThrow() {
        PurchaseOrderCreateParam p = buildValidParam();
        p.getProductSnapshotList().get(0).setPayableAmount(BigDecimal.ZERO);
        assertThrowDomain(p);
    }

    /* ============================== validCreate：完整通过 ============================== */

    @Test
    public void validCreate_fullValidParam_shouldPass() {
        PurchaseOrderCreateParam p = buildValidParam();
        definition.validCreate(p);
    }

    /* ============================== helpers ============================== */

    private void assertThrowDomain(PurchaseOrderCreateParam p) {
        try {
            definition.validCreate(p);
            fail("应该抛出 PurchaseDomainException");
        } catch (PurchaseDomainException e) {
            // expected
        }
    }

    private PurchaseOrderCreateParam buildValidParam() {
        PurchaseOrderCreateParam p = new PurchaseOrderCreateParam();
        p.setCustomId("CUST-001");
        p.setCustomType(1);
        p.setPaymentMode(PurchasePaymentModeEnum.FULL_PAYMENT.getCode());
        p.setDeliveryType(PurchaseDeliveryTypeEnum.SELF_PICKUP.getCode());
        p.setFulfillmentPlatform("DUO_NIU");
        p.setOwnerId("USR-001");
        p.setOwnerName("张三");

        PurchaseOrderProductSnapshotCreateParam s = new PurchaseOrderProductSnapshotCreateParam();
        s.setProductId("P001");
        s.setProductSkuId("SKU001");
        s.setQuantity(2);
        s.setUnitPrice(new BigDecimal("100"));
        s.setTotalAmount(new BigDecimal("200"));
        s.setPayableAmount(new BigDecimal("200"));
        p.setProductSnapshotList(new ArrayList<>(Collections.singletonList(s)));
        return p;
    }
}
