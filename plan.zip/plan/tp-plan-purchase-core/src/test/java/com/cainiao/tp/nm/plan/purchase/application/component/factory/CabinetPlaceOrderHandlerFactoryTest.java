package com.cainiao.tp.nm.plan.purchase.application.component.factory;

import com.cainiao.tp.nm.plan.infra.port.common.exception.PurchaseServiceException;
import com.cainiao.tp.nm.plan.purchase.application.component.CabinetPlaceOrderHandler;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.ApplicationContext;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.when;

/**
 * CabinetPlaceOrderHandlerFactory 单元测试 */
@RunWith(MockitoJUnitRunner.class)
public class CabinetPlaceOrderHandlerFactoryTest {

    @InjectMocks
    private CabinetPlaceOrderHandlerFactory factory;

    @Mock
    private ApplicationContext applicationContext;

    @Mock
    private CabinetPlaceOrderHandler stationHandler;

    @Mock
    private CabinetPlaceOrderHandler outletHandler;

    @Mock
    private CabinetPlaceOrderHandler nullTypeHandler;

    @Before
    public void setUp() {
        when(stationHandler.customerType()).thenReturn(1);
        when(outletHandler.customerType()).thenReturn(10);
        when(nullTypeHandler.customerType()).thenReturn(null);
    }

    @Test
    public void afterPropertiesSet_emptyBeans_shouldInitEmptyRouter() throws Exception {
        when(applicationContext.getBeansOfType(CabinetPlaceOrderHandler.class)).thenReturn(new HashMap<>());
        factory.afterPropertiesSet();

        try {
            factory.getHandler(1);
            fail();
        } catch (PurchaseServiceException e) {
            // expected
        }
    }

    @Test
    public void afterPropertiesSet_normalBeans_shouldBuildRouter() throws Exception {
        Map<String, CabinetPlaceOrderHandler> beanMap = new HashMap<>();
        beanMap.put("station", stationHandler);
        beanMap.put("outlet", outletHandler);
        when(applicationContext.getBeansOfType(CabinetPlaceOrderHandler.class)).thenReturn(beanMap);

        factory.afterPropertiesSet();

        assertSame(stationHandler, factory.getHandler(1));
        assertSame(outletHandler, factory.getHandler(10));
    }

    @Test
    public void afterPropertiesSet_handlerWithNullType_shouldBeIgnored() throws Exception {
        Map<String, CabinetPlaceOrderHandler> beanMap = new HashMap<>();
        beanMap.put("station", stationHandler);
        beanMap.put("nullType", nullTypeHandler);
        when(applicationContext.getBeansOfType(CabinetPlaceOrderHandler.class)).thenReturn(beanMap);

        factory.afterPropertiesSet();
        assertSame(stationHandler, factory.getHandler(1));
    }

    @Test
    public void afterPropertiesSet_contextThrows_shouldRethrow() {
        when(applicationContext.getBeansOfType(CabinetPlaceOrderHandler.class))
                .thenThrow(new RuntimeException("ctx fail"));
        try {
            factory.afterPropertiesSet();
            fail();
        } catch (Exception e) {
            assertEquals("ctx fail", e.getMessage());
        }
    }

    @Test
    public void getHandler_customerTypeNull_shouldThrow() {
        try {
            factory.getHandler(null);
            fail();
        } catch (PurchaseServiceException e) {
            // expected
        }
    }

    @Test
    public void getHandler_unknownCustomerType_shouldThrow() throws Exception {
        Map<String, CabinetPlaceOrderHandler> beanMap = new HashMap<>();
        beanMap.put("station", stationHandler);
        when(applicationContext.getBeansOfType(CabinetPlaceOrderHandler.class)).thenReturn(beanMap);
        factory.afterPropertiesSet();

        try {
            factory.getHandler(999);
            fail();
        } catch (PurchaseServiceException e) {
            // expected
        }
    }

    @Test
    public void getHandler_hit_shouldReturnSameInstance() throws Exception {
        Map<String, CabinetPlaceOrderHandler> beanMap = new HashMap<>();
        beanMap.put("outlet", outletHandler);
        when(applicationContext.getBeansOfType(CabinetPlaceOrderHandler.class)).thenReturn(beanMap);
        factory.afterPropertiesSet();

        assertSame(outletHandler, factory.getHandler(10));
        assertSame(outletHandler, factory.getHandler(10));
    }
}
