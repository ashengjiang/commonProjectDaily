package com.cainiao.tp.nm.plan.purchase.adaptor.metaq;

import com.alibaba.fastjson.JSON;
import com.alibaba.rocketmq.common.message.MessageExt;
import com.cainiao.tp.nm.plan.api.purchase.common.constants.SiteAppExtParamKeyEnum;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.DuoNiuOrderDetailDTO;
import com.cainiao.tp.nm.plan.infra.port.purchase.DuoNiuQueryManager;
import com.cainiao.tp.nm.plan.purchase.adaptor.metaq.event.DuoNiuNodeStatusChangeEvent;
import com.cainiao.tp.nm.plan.purchase.application.service.PurchaseOrderStatusApplicationService;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseOrder;
import com.cainiao.tp.nm.plan.purchase.domain.repository.PurchaseOrderRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * DuoNiuNodeStatusChangeListener 单元测试
 * <p>
 * 覆盖：
 * 1. convert：正常 JSON / 异常 / null body
 * 2. filter：orderId blank / supplierID blank / 非关注状态 / 关注状态
 * 3. doConsume：
 *    - 万里牛订单详情 null → false
 *    - siteAppExtParam 中有 planOrderId → 委托 application service
 *    - siteAppExtParam 无、extParam 有 planOrderId → 兜底走 extParam
 *    - siteAppExtParam/extParam 都无 → 查 SKU 表
 *       * SKU 不属于我们 → 返回 false（跳过）
 *       * SKU 属于我们 → 返回 true（要重试）
 *       * orders 为空 → 返回 false
 * 4. triggerConsume 测试入口
 * </p> */
@RunWith(MockitoJUnitRunner.class)
public class DuoNiuNodeStatusChangeListenerTest {

    @InjectMocks
    private DuoNiuNodeStatusChangeListener listener;

    @Mock
    private DuoNiuQueryManager duoNiuQueryManager;

    @Mock
    private PurchaseOrderStatusApplicationService purchaseOrderStatusApplicationService;

    @Mock
    private PurchaseOrderRepository purchaseOrderRepository;

    private static final String DN_ORDER_ID = "260513860832421432284247";
    private static final String SUPPLIER_ID = "13854003";
    private static final String CHANGE_TIME = "2026-05-13 21:36:35";

    private DuoNiuNodeStatusChangeEvent baseEvent;

    @Before
    public void setUp() {
        baseEvent = new DuoNiuNodeStatusChangeEvent();
        baseEvent.setChangeTime(CHANGE_TIME);
        baseEvent.setOrderId(DN_ORDER_ID);
        baseEvent.setSupplierID(SUPPLIER_ID);
        baseEvent.setOrderStatus("2");
    }

    /* ============================== convert ============================== */

    @Test
    public void convert_validJson_shouldReturnEvent() {
        DuoNiuNodeStatusChangeEvent expected = new DuoNiuNodeStatusChangeEvent();
        expected.setChangeTime(CHANGE_TIME);
        expected.setOrderId(DN_ORDER_ID);
        expected.setOrderStatus("3");
        expected.setSupplierID(SUPPLIER_ID);
        String body = JSON.toJSONString(expected);

        MessageExt msg = new MessageExt();
        msg.setBody(body.getBytes(StandardCharsets.UTF_8));

        DuoNiuNodeStatusChangeEvent actual = listener.convert(msg);
        assertNotNull(actual);
        assertEquals(DN_ORDER_ID, actual.getOrderId());
        assertEquals("3", actual.getOrderStatus());
        assertEquals(SUPPLIER_ID, actual.getSupplierID());
    }

    @Test
    public void convert_invalidJson_shouldReturnNull() {
        MessageExt msg = new MessageExt();
        msg.setBody("not a json".getBytes(StandardCharsets.UTF_8));

        DuoNiuNodeStatusChangeEvent actual = listener.convert(msg);
        assertNull(actual);
    }

    /* ============================== filter ============================== */

    @Test
    public void filter_orderIdBlank_shouldReturnFalse() {
        DuoNiuNodeStatusChangeEvent event = new DuoNiuNodeStatusChangeEvent();
        event.setOrderId("");
        event.setSupplierID(SUPPLIER_ID);
        event.setOrderStatus("2");
        assertFalse(listener.filter(event, null));
    }

    @Test
    public void filter_supplierIdBlank_shouldReturnFalse() {
        DuoNiuNodeStatusChangeEvent event = new DuoNiuNodeStatusChangeEvent();
        event.setOrderId(DN_ORDER_ID);
        event.setSupplierID(" ");
        event.setOrderStatus("2");
        assertFalse(listener.filter(event, null));
    }

    @Test
    public void filter_uninterestedStatus_shouldReturnFalse() {
        baseEvent.setOrderStatus("99");
        assertFalse(listener.filter(baseEvent, null));
    }

    @Test
    public void filter_status1_shouldReturnTrue() {
        baseEvent.setOrderStatus("1");
        assertTrue(listener.filter(baseEvent, null));
    }

    @Test
    public void filter_status2_shouldReturnTrue() {
        baseEvent.setOrderStatus("2");
        assertTrue(listener.filter(baseEvent, null));
    }

    @Test
    public void filter_status3_shouldReturnTrue() {
        baseEvent.setOrderStatus("3");
        assertTrue(listener.filter(baseEvent, null));
    }

    @Test
    public void filter_status4_shouldReturnTrue() {
        baseEvent.setOrderStatus("4");
        assertTrue(listener.filter(baseEvent, null));
    }

    /* ============================== doConsume：万里牛订单详情为空 ============================== */

    @Test
    public void triggerConsume_orderDetailNull_shouldReturnFalse() {
        when(duoNiuQueryManager.queryOrderDetailById(DN_ORDER_ID, SUPPLIER_ID)).thenReturn(null);

        boolean result = listener.triggerConsume(DN_ORDER_ID, "2", SUPPLIER_ID);

        assertFalse(result);
        verify(purchaseOrderStatusApplicationService, never())
                .processStatusChange(any(), any(), any(), any(), any());
    }

    /* ============================== doConsume：siteAppExtParam 路径 ============================== */

    @Test
    public void triggerConsume_siteAppExtParam_hasPlanOrderId_shouldDelegateService() {
        DuoNiuOrderDetailDTO detail = new DuoNiuOrderDetailDTO();
        Map<String, Object> ext = new HashMap<>();
        ext.put(SiteAppExtParamKeyEnum.PLAN_ORDER_ID.getKey(), "1001");
        detail.setSiteAppExtParam(JSON.toJSONString(ext));
        when(duoNiuQueryManager.queryOrderDetailById(DN_ORDER_ID, SUPPLIER_ID)).thenReturn(detail);
        when(purchaseOrderStatusApplicationService.processStatusChange(
                eq(1001L), eq(DN_ORDER_ID), eq("2"), eq(detail), eq(CHANGE_TIME))).thenReturn(true);

        boolean result = listener.triggerConsume(DN_ORDER_ID, "2", SUPPLIER_ID);

        assertTrue(result);
        verify(purchaseOrderStatusApplicationService).processStatusChange(
                eq(1001L), eq(DN_ORDER_ID), eq("2"), eq(detail), any());
    }

    /* ============================== doConsume：extParam 兜底路径 ============================== */

    @Test
    public void triggerConsume_extParam_hasPlanOrderId_shouldDelegateService() {
        DuoNiuOrderDetailDTO detail = new DuoNiuOrderDetailDTO();
        detail.setSiteAppExtParam(null);
        Map<String, Object> ext = new HashMap<>();
        ext.put(SiteAppExtParamKeyEnum.PLAN_ORDER_ID.getKey(), "2002");
        detail.setExtParam(JSON.toJSONString(ext));
        when(duoNiuQueryManager.queryOrderDetailById(DN_ORDER_ID, SUPPLIER_ID)).thenReturn(detail);
        when(purchaseOrderStatusApplicationService.processStatusChange(
                eq(2002L), any(), any(), any(), any())).thenReturn(true);

        boolean result = listener.triggerConsume(DN_ORDER_ID, "2", SUPPLIER_ID);

        assertTrue(result);
        ArgumentCaptor<Long> planOrderIdCaptor = ArgumentCaptor.forClass(Long.class);
        verify(purchaseOrderStatusApplicationService).processStatusChange(
                planOrderIdCaptor.capture(), any(), any(), any(), any());
        assertEquals(Long.valueOf(2002L), planOrderIdCaptor.getValue());
    }

    @Test
    public void triggerConsume_siteAppExtParamBlankString_shouldFallbackToExtParam() {
        DuoNiuOrderDetailDTO detail = new DuoNiuOrderDetailDTO();
        detail.setSiteAppExtParam("");
        Map<String, Object> ext = new HashMap<>();
        ext.put(SiteAppExtParamKeyEnum.PLAN_ORDER_ID.getKey(), "3003");
        detail.setExtParam(JSON.toJSONString(ext));
        when(duoNiuQueryManager.queryOrderDetailById(DN_ORDER_ID, SUPPLIER_ID)).thenReturn(detail);
        when(purchaseOrderStatusApplicationService.processStatusChange(eq(3003L), any(), any(), any(), any()))
                .thenReturn(true);

        assertTrue(listener.triggerConsume(DN_ORDER_ID, "2", SUPPLIER_ID));
    }

    /* ============================== doConsume：fulfillmentPlatformOrderId 反查兜底 ============================== */

    @Test
    public void triggerConsume_noPlanOrderId_repoFallbackHit_shouldDelegateService() {
        // 两次 ext 解析都拿不到 planOrderId，但本地订单已绑定了履约单号 → 反查命中，走 processStatusChange
        DuoNiuOrderDetailDTO detail = new DuoNiuOrderDetailDTO();
        detail.setSiteAppExtParam(null);
        detail.setExtParam(null);
        when(duoNiuQueryManager.queryOrderDetailById(DN_ORDER_ID, SUPPLIER_ID)).thenReturn(detail);

        PurchaseOrder localOrder = PurchaseOrder.builder().id(5005L).build();
        when(purchaseOrderRepository.findByFulfillmentPlatformOrderId(DN_ORDER_ID)).thenReturn(localOrder);
        when(purchaseOrderStatusApplicationService.processStatusChange(
                eq(5005L), eq(DN_ORDER_ID), eq("2"), eq(detail), any())).thenReturn(true);

        boolean result = listener.triggerConsume(DN_ORDER_ID, "2", SUPPLIER_ID);

        assertTrue(result);
        verify(purchaseOrderRepository).findByFulfillmentPlatformOrderId(DN_ORDER_ID);
        verify(purchaseOrderStatusApplicationService).processStatusChange(
                eq(5005L), eq(DN_ORDER_ID), eq("2"), eq(detail), any());
        // 反查命中后不应再走 SKU 校验
        verify(purchaseOrderStatusApplicationService, never()).checkSkuBelongsToUs(anyList());
    }

    @Test
    public void triggerConsume_noPlanOrderId_repoFallbackNull_shouldFallbackToSkuCheck() {
        // 两次 ext 解析失败 + 反查返回 null → 兜底走 SKU 校验
        DuoNiuOrderDetailDTO detail = buildDetailWithSku("SKU-001");
        detail.setSiteAppExtParam(null);
        detail.setExtParam(null);
        when(duoNiuQueryManager.queryOrderDetailById(DN_ORDER_ID, SUPPLIER_ID)).thenReturn(detail);
        when(purchaseOrderRepository.findByFulfillmentPlatformOrderId(DN_ORDER_ID)).thenReturn(null);
        when(purchaseOrderStatusApplicationService.checkSkuBelongsToUs(anyList()))
                .thenReturn(Collections.emptyList());

        boolean result = listener.triggerConsume(DN_ORDER_ID, "2", SUPPLIER_ID);

        assertFalse(result);
        verify(purchaseOrderRepository).findByFulfillmentPlatformOrderId(DN_ORDER_ID);
        verify(purchaseOrderStatusApplicationService).checkSkuBelongsToUs(anyList());
        verify(purchaseOrderStatusApplicationService, never())
                .processStatusChange(any(), any(), any(), any(), any());
    }

    @Test
    public void triggerConsume_noPlanOrderId_repoFallbackOrderIdNull_shouldFallbackToSkuCheck() {
        // 反查返回了 PurchaseOrder 但 id 为 null（防御性场景）→ 仍兜底走 SKU 校验
        DuoNiuOrderDetailDTO detail = buildDetailWithSku("SKU-001");
        detail.setSiteAppExtParam(null);
        detail.setExtParam(null);
        when(duoNiuQueryManager.queryOrderDetailById(DN_ORDER_ID, SUPPLIER_ID)).thenReturn(detail);
        PurchaseOrder localOrder = PurchaseOrder.builder().build(); // id == null
        when(purchaseOrderRepository.findByFulfillmentPlatformOrderId(DN_ORDER_ID)).thenReturn(localOrder);
        when(purchaseOrderStatusApplicationService.checkSkuBelongsToUs(anyList()))
                .thenReturn(Collections.emptyList());

        boolean result = listener.triggerConsume(DN_ORDER_ID, "2", SUPPLIER_ID);

        assertFalse(result);
        verify(purchaseOrderStatusApplicationService, never())
                .processStatusChange(any(), any(), any(), any(), any());
    }

    @Test
    public void triggerConsume_siteAppExtParamHasPlanOrderId_shouldNotInvokeRepoFallback() {
        // 命中第一道 ext 解析 → 不应触发反查
        DuoNiuOrderDetailDTO detail = new DuoNiuOrderDetailDTO();
        Map<String, Object> ext = new HashMap<>();
        ext.put(SiteAppExtParamKeyEnum.PLAN_ORDER_ID.getKey(), "9001");
        detail.setSiteAppExtParam(JSON.toJSONString(ext));
        when(duoNiuQueryManager.queryOrderDetailById(DN_ORDER_ID, SUPPLIER_ID)).thenReturn(detail);
        when(purchaseOrderStatusApplicationService.processStatusChange(
                eq(9001L), any(), any(), any(), any())).thenReturn(true);

        assertTrue(listener.triggerConsume(DN_ORDER_ID, "2", SUPPLIER_ID));
        verify(purchaseOrderRepository, never()).findByFulfillmentPlatformOrderId(any());
    }

    /* ============================== doConsume：SKU 表兜底校验 ============================== */

    @Test
    public void triggerConsume_noPlanOrderId_emptyOrders_shouldReturnFalse() {
        DuoNiuOrderDetailDTO detail = new DuoNiuOrderDetailDTO();
        detail.setSiteAppExtParam("{}");
        detail.setOrders(Collections.emptyList());
        when(duoNiuQueryManager.queryOrderDetailById(DN_ORDER_ID, SUPPLIER_ID)).thenReturn(detail);

        boolean result = listener.triggerConsume(DN_ORDER_ID, "2", SUPPLIER_ID);
        assertFalse(result);
        verify(purchaseOrderStatusApplicationService, never())
                .processStatusChange(any(), any(), any(), any(), any());
        verify(purchaseOrderStatusApplicationService, never()).checkSkuBelongsToUs(anyList());
    }

    @Test
    public void triggerConsume_noPlanOrderId_skuNotBelongs_shouldReturnFalse() {
        DuoNiuOrderDetailDTO detail = buildDetailWithSku("SKU-001", "SKU-002");
        when(duoNiuQueryManager.queryOrderDetailById(DN_ORDER_ID, SUPPLIER_ID)).thenReturn(detail);
        when(purchaseOrderStatusApplicationService.checkSkuBelongsToUs(anyList()))
                .thenReturn(Collections.emptyList());

        boolean result = listener.triggerConsume(DN_ORDER_ID, "2", SUPPLIER_ID);
        assertFalse(result);
        verify(purchaseOrderStatusApplicationService, never())
                .processStatusChange(any(), any(), any(), any(), any());
    }

    @Test
    public void triggerConsume_noPlanOrderId_skuBelongsToUs_shouldReturnTrueForRetry() {
        // 万里牛订单缺少 planOrderId 但 SKU 属于我们 → 异常情况，返回 true 让 MQ 重试
        DuoNiuOrderDetailDTO detail = buildDetailWithSku("SKU-001", "SKU-002");
        when(duoNiuQueryManager.queryOrderDetailById(DN_ORDER_ID, SUPPLIER_ID)).thenReturn(detail);
        when(purchaseOrderStatusApplicationService.checkSkuBelongsToUs(anyList()))
                .thenReturn(Arrays.asList("SKU-001"));

        boolean result = listener.triggerConsume(DN_ORDER_ID, "2", SUPPLIER_ID);
        assertTrue(result);
    }

    @Test
    public void triggerConsume_noPlanOrderId_filtersBlankSkuIds() {
        // skuId blank 的不应被传给 checkSkuBelongsToUs
        DuoNiuOrderDetailDTO detail = new DuoNiuOrderDetailDTO();
        detail.setSiteAppExtParam("{}");
        DuoNiuOrderDetailDTO.OrderItemDTO i1 = new DuoNiuOrderDetailDTO.OrderItemDTO();
        i1.setSkuId("SKU-OK");
        DuoNiuOrderDetailDTO.OrderItemDTO i2 = new DuoNiuOrderDetailDTO.OrderItemDTO();
        i2.setSkuId(""); // blank
        DuoNiuOrderDetailDTO.OrderItemDTO i3 = new DuoNiuOrderDetailDTO.OrderItemDTO();
        i3.setSkuId(null);
        detail.setOrders(Arrays.asList(i1, i2, i3));

        when(duoNiuQueryManager.queryOrderDetailById(DN_ORDER_ID, SUPPLIER_ID)).thenReturn(detail);
        when(purchaseOrderStatusApplicationService.checkSkuBelongsToUs(anyList()))
                .thenReturn(Collections.emptyList());

        listener.triggerConsume(DN_ORDER_ID, "2", SUPPLIER_ID);

        ArgumentCaptor<java.util.List> captor = ArgumentCaptor.forClass(java.util.List.class);
        verify(purchaseOrderStatusApplicationService).checkSkuBelongsToUs(captor.capture());
        assertEquals(1, captor.getValue().size());
        assertEquals("SKU-OK", captor.getValue().get(0));
    }

    /* ============================== triggerConsume 入参映射 ============================== */

    @Test
    public void triggerConsume_passesAllArgsToQuery() {
        when(duoNiuQueryManager.queryOrderDetailById(DN_ORDER_ID, SUPPLIER_ID)).thenReturn(null);
        listener.triggerConsume(DN_ORDER_ID, "2", SUPPLIER_ID);
        verify(duoNiuQueryManager, times(1)).queryOrderDetailById(DN_ORDER_ID, SUPPLIER_ID);
    }

    /* ============================== helpers ============================== */

    private DuoNiuOrderDetailDTO buildDetailWithSku(String... skuIds) {
        DuoNiuOrderDetailDTO detail = new DuoNiuOrderDetailDTO();
        detail.setSiteAppExtParam("{}");
        java.util.List<DuoNiuOrderDetailDTO.OrderItemDTO> orders = new java.util.ArrayList<>();
        for (String skuId : skuIds) {
            DuoNiuOrderDetailDTO.OrderItemDTO item = new DuoNiuOrderDetailDTO.OrderItemDTO();
            item.setSkuId(skuId);
            orders.add(item);
        }
        detail.setOrders(orders);
        return detail;
    }
}
