package com.cainiao.tp.nm.plan.purchase.application.component.factory;

import com.cainiao.tp.nm.plan.infra.port.common.exception.PurchaseServiceException;
import com.cainiao.tp.nm.plan.purchase.application.component.fetcher.PurchasePaymentUrlFetcher;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.ApplicationContext;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.when;

/**
 * PurchasePaymentUrlFetcherFactory 单元测试 */
@RunWith(MockitoJUnitRunner.class)
public class PurchasePaymentUrlFetcherFactoryTest {

    @InjectMocks
    private PurchasePaymentUrlFetcherFactory factory;

    @Mock
    private ApplicationContext applicationContext;

    @Mock
    private PurchasePaymentUrlFetcher duoNiuFetcher;

    @Mock
    private PurchasePaymentUrlFetcher tbFetcher;

    @Mock
    private PurchasePaymentUrlFetcher blankFetcher;

    @Before
    public void setUp() {
        when(duoNiuFetcher.supportedPlatform()).thenReturn("DUO_NIU");
        when(tbFetcher.supportedPlatform()).thenReturn("TAOBAO");
        when(blankFetcher.supportedPlatform()).thenReturn("");
    }

    @Test
    public void afterPropertiesSet_emptyBeans_shouldNotCrash() throws Exception {
        when(applicationContext.getBeansOfType(PurchasePaymentUrlFetcher.class)).thenReturn(new HashMap<>());
        factory.afterPropertiesSet();

        try {
            factory.getFetcher("DUO_NIU");
            fail();
        } catch (PurchaseServiceException e) {
            // expected
        }
    }

    @Test
    public void afterPropertiesSet_normalBeans_shouldBuildRouter() throws Exception {
        Map<String, PurchasePaymentUrlFetcher> beanMap = new HashMap<>();
        beanMap.put("dn", duoNiuFetcher);
        beanMap.put("tb", tbFetcher);
        when(applicationContext.getBeansOfType(PurchasePaymentUrlFetcher.class)).thenReturn(beanMap);

        factory.afterPropertiesSet();
        assertSame(duoNiuFetcher, factory.getFetcher("DUO_NIU"));
        assertSame(tbFetcher, factory.getFetcher("TAOBAO"));
    }

    @Test
    public void afterPropertiesSet_blankPlatformFetcher_shouldBeIgnored() throws Exception {
        Map<String, PurchasePaymentUrlFetcher> beanMap = new HashMap<>();
        beanMap.put("dn", duoNiuFetcher);
        beanMap.put("blank", blankFetcher);
        when(applicationContext.getBeansOfType(PurchasePaymentUrlFetcher.class)).thenReturn(beanMap);

        factory.afterPropertiesSet();
        assertSame(duoNiuFetcher, factory.getFetcher("DUO_NIU"));
    }

    @Test
    public void afterPropertiesSet_contextThrows_shouldRethrow() {
        when(applicationContext.getBeansOfType(PurchasePaymentUrlFetcher.class))
                .thenThrow(new RuntimeException("ctx fail"));
        try {
            factory.afterPropertiesSet();
            fail();
        } catch (Exception e) {
            assertEquals("ctx fail", e.getMessage());
        }
    }

    @Test
    public void getFetcher_platformNull_shouldThrow() {
        try {
            factory.getFetcher(null);
            fail();
        } catch (PurchaseServiceException e) {
            // expected
        }
    }

    @Test
    public void getFetcher_platformBlank_shouldThrow() {
        try {
            factory.getFetcher("   ");
            fail();
        } catch (PurchaseServiceException e) {
            // expected
        }
    }

    @Test
    public void getFetcher_unknownPlatform_shouldThrow() throws Exception {
        Map<String, PurchasePaymentUrlFetcher> beanMap = new HashMap<>();
        beanMap.put("dn", duoNiuFetcher);
        when(applicationContext.getBeansOfType(PurchasePaymentUrlFetcher.class)).thenReturn(beanMap);
        factory.afterPropertiesSet();

        try {
            factory.getFetcher("UNKNOWN");
            fail();
        } catch (PurchaseServiceException e) {
            // expected
        }
    }

    @Test
    public void getFetcher_hit_shouldReturnSameInstance() throws Exception {
        Map<String, PurchasePaymentUrlFetcher> beanMap = new HashMap<>();
        beanMap.put("dn", duoNiuFetcher);
        when(applicationContext.getBeansOfType(PurchasePaymentUrlFetcher.class)).thenReturn(beanMap);
        factory.afterPropertiesSet();

        assertSame(duoNiuFetcher, factory.getFetcher("DUO_NIU"));
        assertSame(duoNiuFetcher, factory.getFetcher("DUO_NIU"));
    }
}
