package com.cainiao.tp.nm.plan.purchase.application.component.impl;

import com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseCustomerTypeEnum;
import com.cainiao.tp.nm.plan.infra.port.common.constants.ErrorCode;
import com.cainiao.tp.nm.plan.infra.port.common.exception.PurchaseServiceException;
import com.cainiao.tp.nm.plan.infra.port.dto.AgreementInfoAndSignDTO;
import com.cainiao.tp.nm.plan.infra.port.dto.param.QueryAgreementParam;
import com.cainiao.tp.nm.plan.infra.port.dto.param.SignAgreementParam;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.TpsAgreementCreateAndSignDTO;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.TpsAgreementInfoDTO;
import com.cainiao.tp.nm.plan.infra.port.manager.TpsStationAgreementManager;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * StationAgreementQueryHandler 单元测试 */
@RunWith(MockitoJUnitRunner.class)
public class StationAgreementQueryHandlerTest {

    @InjectMocks
    private StationAgreementQueryHandler handler;

    @Mock
    private TpsStationAgreementManager tpsStationAgreementManager;

    @Test
    public void customerType_shouldReturnStationCode() {
        assertEquals(PurchaseCustomerTypeEnum.STATION.getCode(), handler.customerType());
    }

    /* ============================== query ============================== */

    @Test
    public void query_agreementInfoExists_andSigned() {
        QueryAgreementParam param = buildQueryParam("AGR_001", "10086");
        TpsAgreementInfoDTO info = buildAgreementInfo(99L, "服务协议", "https://t.cn/x");

        when(tpsStationAgreementManager.queryByCode("AGR_001")).thenReturn(info);
        when(tpsStationAgreementManager.isSigned("AGR_001", 10086L)).thenReturn(true);

        AgreementInfoAndSignDTO result = handler.query(param);

        assertEquals("AGR_001", result.getAgreementCode());
        assertEquals(Long.valueOf(99L), result.getAgreementId());
        assertEquals("服务协议", result.getAgreementName());
        assertEquals("https://t.cn/x", result.getAgreementUrl());
        assertTrue(result.getSigned());
    }

    @Test
    public void query_agreementInfoMissing_shouldOnlyReturnCodeAndUnsigned() {
        QueryAgreementParam param = buildQueryParam("AGR_001", "10086");
        when(tpsStationAgreementManager.queryByCode("AGR_001")).thenReturn(null);
        when(tpsStationAgreementManager.isSigned(anyString(), anyLong())).thenReturn(false);

        AgreementInfoAndSignDTO result = handler.query(param);

        assertEquals("AGR_001", result.getAgreementCode());
        assertNull(result.getAgreementId());
        assertNull(result.getAgreementName());
        assertFalse(result.getSigned());
    }

    @Test
    public void query_customerIdNotLong_shouldReturnUnsignedAndSkipSignedQuery() {
        QueryAgreementParam param = buildQueryParam("AGR_001", "abc-not-long");
        when(tpsStationAgreementManager.queryByCode("AGR_001")).thenReturn(null);

        AgreementInfoAndSignDTO result = handler.query(param);

        assertFalse(result.getSigned());
        verify(tpsStationAgreementManager, never()).isSigned(anyString(), anyLong());
    }

    @Test
    public void query_customerIdBlank_shouldReturnUnsignedAndSkipSignedQuery() {
        QueryAgreementParam param = buildQueryParam("AGR_001", "");
        when(tpsStationAgreementManager.queryByCode("AGR_001")).thenReturn(null);

        AgreementInfoAndSignDTO result = handler.query(param);

        assertFalse(result.getSigned());
        verify(tpsStationAgreementManager, never()).isSigned(anyString(), anyLong());
    }

    /* ============================== sign ============================== */

    @Test
    public void sign_paramNull_shouldThrow() {
        assertSignThrows(null);
    }

    @Test
    public void sign_agreementCodeBlank_shouldThrow() {
        SignAgreementParam param = buildSignParam(" ", "U001", "10086", 1);
        assertSignThrows(param);
    }

    @Test
    public void sign_userIdBlank_shouldThrow() {
        SignAgreementParam param = buildSignParam("AGR", "", "10086", 1);
        assertSignThrows(param);
    }

    @Test
    public void sign_userTypeNull_shouldThrow() {
        SignAgreementParam param = buildSignParam("AGR", "U001", "10086", null);
        assertSignThrows(param);
    }

    @Test
    public void sign_customerIdBlank_shouldThrow() {
        SignAgreementParam param = buildSignParam("AGR", "U001", " ", 1);
        assertSignThrows(param);
    }

    @Test
    public void sign_agreementNotFound_shouldThrow() {
        SignAgreementParam param = buildSignParam("AGR", "U001", "10086", 1);
        when(tpsStationAgreementManager.queryByCode("AGR")).thenReturn(null);
        assertSignThrows(param);
    }

    @Test
    public void sign_agreementIdNull_shouldThrow() {
        SignAgreementParam param = buildSignParam("AGR", "U001", "10086", 1);
        TpsAgreementInfoDTO info = new TpsAgreementInfoDTO();
        // 故意不设置 id
        when(tpsStationAgreementManager.queryByCode("AGR")).thenReturn(info);
        assertSignThrows(param);
    }

    @Test
    public void sign_success_shouldBuildSignDTOAndReturnId() {
        SignAgreementParam param = buildSignParam("AGR", "U001", "10086", 1);
        param.setOutBizId("BIZ-1");

        TpsAgreementInfoDTO info = buildAgreementInfo(99L, "T", "U");
        when(tpsStationAgreementManager.queryByCode("AGR")).thenReturn(info);
        when(tpsStationAgreementManager.createAndSign(org.mockito.ArgumentMatchers.any())).thenReturn(888L);

        Long signedId = handler.sign(param);

        assertEquals(Long.valueOf(888L), signedId);
        ArgumentCaptor<TpsAgreementCreateAndSignDTO> captor =
                ArgumentCaptor.forClass(TpsAgreementCreateAndSignDTO.class);
        verify(tpsStationAgreementManager).createAndSign(captor.capture());
        TpsAgreementCreateAndSignDTO actual = captor.getValue();
        assertEquals(Long.valueOf(99L), actual.getAgreementId());
        assertEquals("U001", actual.getUserId());
        assertEquals(Integer.valueOf(1), actual.getUserType());
        assertEquals("10086", actual.getStationId());
        assertEquals("BIZ-1", actual.getOutBizId());
    }

    /* ============================== helpers ============================== */

    private void assertSignThrows(SignAgreementParam param) {
        try {
            handler.sign(param);
            fail("期望抛出 PurchaseServiceException");
        } catch (PurchaseServiceException e) {
            assertEquals(ErrorCode.ILLEGAL_PARAM.getCode(), e.getCode());
        }
    }

    private QueryAgreementParam buildQueryParam(String agreementCode, String customerId) {
        QueryAgreementParam p = new QueryAgreementParam();
        p.setAgreementCode(agreementCode);
        p.setCustomerId(customerId);
        p.setCustomerType(PurchaseCustomerTypeEnum.STATION.getCode());
        return p;
    }

    private SignAgreementParam buildSignParam(String agreementCode, String userId, String customerId, Integer userType) {
        SignAgreementParam p = new SignAgreementParam();
        p.setAgreementCode(agreementCode);
        p.setUserId(userId);
        p.setCustomerId(customerId);
        p.setUserType(userType);
        return p;
    }

    private TpsAgreementInfoDTO buildAgreementInfo(Long id, String title, String url) {
        TpsAgreementInfoDTO info = new TpsAgreementInfoDTO();
        info.setId(id);
        info.setTitle(title);
        info.setContentUrl(url);
        return info;
    }
}
