package com.cainiao.tp.nm.plan.purchase.adaptor.mtop;

import com.cainiao.aladdin.env.SystemEnvUtil;
import com.cainiao.sutee.commons.base.result.CnResult;
import com.cainiao.tp.nm.plan.api.purchase.adaptor.dto.CabinetMallConfigDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.AgreementInfoDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.AttributeOptionDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.CabinetOrderDetailDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.PlaceOrderResultDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.ProductInfoDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.ProductInfoResultDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.ExpressAgreementSubscriptionParam;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PlaceOrderParam;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PreCalculateOrderParam;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.vo.CabinetProductInfoResultVO;
import com.cainiao.tp.nm.plan.api.purchase.common.constants.ProductAttributeEnum;
import com.cainiao.tp.nm.plan.infra.port.common.constants.LoginEntityTypeEnum;
import com.cainiao.tp.nm.plan.infra.port.dto.AgreementInfoAndSignDTO;
import com.cainiao.tp.nm.plan.infra.port.dto.context.BasePermissionContext;
import com.cainiao.tp.nm.plan.infra.port.dto.context.ExpressPermissionContext;
import com.cainiao.tp.nm.plan.infra.port.dto.context.PermissionContext;
import com.cainiao.tp.nm.plan.infra.port.dto.context.StationPermissionContext;
import com.cainiao.tp.nm.plan.infra.port.purchase.MixContractManager;
import com.cainiao.tp.nm.plan.purchase.adaptor.component.login.MtopLoginContext;
import com.cainiao.tp.nm.plan.purchase.application.component.AgreementComponent;
import com.cainiao.tp.nm.plan.purchase.application.service.CabinetPlaceOrderApplicationService;
import com.cainiao.tp.nm.plan.purchase.application.service.ProductionApplicationService;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseRule;
import com.cainiao.tp.nm.plan.purchase.domain.model.valobj.AgreementConfig;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.Collections;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * CabinetPlaceOrderMtoServiceImpl 单元测试
 * <p>
 * 通过直接向 {@link MtopLoginContext} 写入登录态来模拟切面注入效果，
 * 验证业务编排逻辑、登录态映射、异常包装、灰度判断等核心行为。
 * </p> */
@RunWith(MockitoJUnitRunner.class)
public class CabinetPlaceOrderMtoServiceImplTest {

    @InjectMocks
    private CabinetPlaceOrderMtoServiceImpl service;

    @Mock private CabinetPlaceOrderApplicationService cabinetPlaceOrderApplicationService;
    @Mock private ProductionApplicationService productionApplicationService;
    @Mock private MixContractManager mixContractManager;
    @Mock private AgreementComponent agreementComponent;

    private CabinetMallConfigDTO originalConfig;

    @Before
    public void setUp() {
        // 单测环境下初始化 SystemEnvUtil，避免业务代码调用 SystemEnvUtil.getEnv() 触发 NPE
        if (!SystemEnvUtil.hasInited()) {
            SystemEnvUtil.initEnv("daily");
        }
        // 保存原配置，测试结束后还原
        originalConfig = CabinetMallConfigDTO.getINSTANCE();
        CabinetMallConfigDTO emptyConfig = new CabinetMallConfigDTO();
        // 灰度名单为空 → 默认全部放过（按代码逻辑：empty 视为通过）
        CabinetMallConfigDTO.setINSTANCE(emptyConfig);
    }

    @After
    public void tearDown() {
        MtopLoginContext.remove();
        CabinetMallConfigDTO.setINSTANCE(originalConfig);
    }

    /* ============================== infoList ============================== */

    @Test
    public void infoList_emptyProductList_shouldReturnEmptyList() {
        setExpressLogin();
        ProductInfoResultDTO result = new ProductInfoResultDTO();
        result.setProductInfoList(Collections.emptyList());
        when(productionApplicationService.getProductInfo(any(), any())).thenReturn(result);

        CnResult<CabinetProductInfoResultVO> cn = service.infoList();
        assertTrue(cn.isSuccess());
        assertNotNull(cn.getData());
        assertTrue(cn.getData().getProductInfoList().isEmpty());
    }

    @Test
    public void infoList_productInfoNull_shouldReturnEmptyList() {
        setExpressLogin();
        when(productionApplicationService.getProductInfo(any(), any())).thenReturn(null);

        CnResult<CabinetProductInfoResultVO> cn = service.infoList();
        assertTrue(cn.isSuccess());
        assertTrue(cn.getData().getProductInfoList().isEmpty());
    }

    @Test
    public void infoList_singleProduct_shouldConvertCabinetTypeAttr() {
        setExpressLogin();
        ProductInfoDTO product = new ProductInfoDTO();
        product.setItemId(100);
        product.setItemTitle("智能柜A");
        product.setPictureUrl("http://pic");
        product.setPrice(1999.0);
        AttributeOptionDTO attr = new AttributeOptionDTO();
        attr.setCode(ProductAttributeEnum.CABINET_TYPE.getCode());
        attr.setValue("36格");
        product.setAttributeOptionList(Collections.singletonList(attr));
        ProductInfoResultDTO result = new ProductInfoResultDTO();
        result.setProductInfoList(Collections.singletonList(product));
        when(productionApplicationService.getProductInfo(any(), any())).thenReturn(result);

        CnResult<CabinetProductInfoResultVO> cn = service.infoList();
        assertTrue(cn.isSuccess());
        assertEquals(1, cn.getData().getProductInfoList().size());
        assertEquals("36格", cn.getData().getProductInfoList().get(0).getSkuTitle());
        assertEquals(Integer.valueOf(100), cn.getData().getProductInfoList().get(0).getItemId());
    }

    @Test
    public void infoList_exceptionShouldBeWrappedAsFail() {
        setExpressLogin();
        when(productionApplicationService.getProductInfo(any(), any()))
                .thenThrow(new RuntimeException("oops"));

        CnResult<CabinetProductInfoResultVO> cn = service.infoList();
        assertFalse(cn.isSuccess());
        assertEquals("PLACE_ORDER_ERROR", cn.getCode());
    }

    /* ============================== placeOrder ============================== */

    @Test
    public void placeOrder_success_shouldDelegateAndFillEmployeeId() {
        setExpressLogin();
        PlaceOrderParam param = new PlaceOrderParam();
        param.setOrderId(0L);
        PlaceOrderResultDTO mockResult = new PlaceOrderResultDTO();
        when(cabinetPlaceOrderApplicationService.placeOrder(any(), any())).thenReturn(mockResult);

        CnResult<PlaceOrderResultDTO> cn = service.placeOrder(param);

        assertTrue(cn.isSuccess());
        assertNotNull(cn.getData());
        assertEquals("EMP-001", cn.getData().getEmployeeId());
        // orderId<=0 应被清空
        assertNull(param.getOrderId());
        // 登录态字段被回填
        assertEquals("200", param.getCustomerId());
        assertEquals(LoginEntityTypeEnum.EXPRESS.getType(), param.getCustomerType());
    }

    @Test
    public void placeOrder_orderIdGreaterThanZero_shouldKeepOriginalValue() {
        setExpressLogin();
        PlaceOrderParam param = new PlaceOrderParam();
        param.setOrderId(999L);
        PlaceOrderResultDTO mockResult = new PlaceOrderResultDTO();
        when(cabinetPlaceOrderApplicationService.placeOrder(any(), any())).thenReturn(mockResult);

        service.placeOrder(param);
        assertEquals(Long.valueOf(999L), param.getOrderId());
    }

    @Test
    public void placeOrder_userNotInGrey_shouldReturnFailDueToCanBuyFalse() {
        // 设置 grey city 仅包含某个 cityCode，登录用户不在其中 → canBuy=false
        CabinetMallConfigDTO config = new CabinetMallConfigDTO();
        config.setGreyCityList(Collections.singletonList(99L));
        CabinetMallConfigDTO.setINSTANCE(config);
        setExpressLogin();
        PlaceOrderParam param = new PlaceOrderParam();
        param.setOrderId(0L);

        CnResult<PlaceOrderResultDTO> cn = service.placeOrder(param);
        assertFalse(cn.isSuccess());
        assertEquals("PLACE_ORDER_ERROR", cn.getCode());
        verify(cabinetPlaceOrderApplicationService, never()).placeOrder(any(), any());
    }

    @Test
    public void placeOrder_innerThrows_shouldReturnFail() {
        setExpressLogin();
        PlaceOrderParam param = new PlaceOrderParam();
        param.setOrderId(1L);
        when(cabinetPlaceOrderApplicationService.placeOrder(any(), any()))
                .thenThrow(new RuntimeException("biz error"));

        CnResult<PlaceOrderResultDTO> cn = service.placeOrder(param);
        assertFalse(cn.isSuccess());
        assertEquals("PLACE_ORDER_ERROR", cn.getCode());
    }

    /* ============================== preCalculateOrder ============================== */

    @Test
    public void preCalculateOrder_success_shouldDelegateAndFillLoginInfo() {
        setExpressLogin();
        PreCalculateOrderParam param = new PreCalculateOrderParam();
        CabinetOrderDetailDTO mock = new CabinetOrderDetailDTO();
        when(cabinetPlaceOrderApplicationService.preCalculateOrder(any(), any())).thenReturn(mock);

        CnResult<CabinetOrderDetailDTO> cn = service.preCalculateOrder(param);
        assertTrue(cn.isSuccess());
        assertEquals("200", param.getCustomerId());
        assertEquals(LoginEntityTypeEnum.EXPRESS.getType(), param.getCustomerType());
    }

    @Test
    public void preCalculateOrder_innerThrows_shouldReturnFail() {
        setExpressLogin();
        when(cabinetPlaceOrderApplicationService.preCalculateOrder(any(), any()))
                .thenThrow(new RuntimeException("calc error"));

        CnResult<CabinetOrderDetailDTO> cn = service.preCalculateOrder(new PreCalculateOrderParam());
        assertFalse(cn.isSuccess());
        assertEquals("PRE_CALCULATE_ORDER_ERROR", cn.getCode());
    }

    /* ============================== expressAgreementSubscription ============================== */

    @Test
    public void expressAgreementSubscription_success_shouldCallMixContractManager() {
        // 注意：源码里的判断是 EXPRESS.equals(entityType) → 抛异常（看起来反了，但要按代码逻辑测）
        // 因此非网点登录才能走通
        setStationLogin();
        ExpressAgreementSubscriptionParam p = new ExpressAgreementSubscriptionParam();
        p.setAgreementCode("AGR-001");

        CnResult<Boolean> cn = service.expressAgreementSubscription(p);
        assertTrue(cn.isSuccess());
        assertTrue(cn.getData());
        verify(mixContractManager, times(1)).editEntityLaunchRelation(anyList());
    }

    @Test
    public void expressAgreementSubscription_expressLogin_shouldReturnFail() {
        // 源码: EXPRESS.equals(entityType) → throw → catch → fail
        setExpressLogin();
        ExpressAgreementSubscriptionParam p = new ExpressAgreementSubscriptionParam();
        p.setAgreementCode("AGR-001");

        CnResult<Boolean> cn = service.expressAgreementSubscription(p);
        assertFalse(cn.isSuccess());
        assertEquals("EXPRESS_AGREEMENT_SUBSCRIPTION_ERROR", cn.getCode());
        verify(mixContractManager, never()).editEntityLaunchRelation(anyList());
    }

    @Test
    public void expressAgreementSubscription_managerThrows_shouldReturnFail() {
        setStationLogin();
        org.mockito.Mockito.doThrow(new RuntimeException("rpc error"))
                .when(mixContractManager).editEntityLaunchRelation(anyList());
        ExpressAgreementSubscriptionParam p = new ExpressAgreementSubscriptionParam();
        p.setAgreementCode("AGR-001");

        CnResult<Boolean> cn = service.expressAgreementSubscription(p);
        assertFalse(cn.isSuccess());
        assertEquals("EXPRESS_AGREEMENT_SUBSCRIPTION_ERROR", cn.getCode());
    }

    /* ============================== queryAgreementInfo ============================== */

    @Test
    public void queryAgreementInfo_outletLogin_shouldReturnEmpty() {
        // 网点登录 → entityType=EXPRESS → 源码用 PurchaseCustomerTypeEnum.OUTLET 判断
        // OUTLET.code=2, EXPRESS.type=2 → 匹配 → 返回空
        setExpressLogin();

        CnResult<AgreementInfoDTO> cn = service.queryAgreementInfo();
        assertTrue(cn.isSuccess());
        assertNotNull(cn.getData());
        // 网点(OUTLET) 直接返回空协议
        verify(productionApplicationService, never()).getProductionRule(any());
    }

    @Test
    public void queryAgreementInfo_stationNoProductionRule_shouldReturnEmpty() {
        setStationLogin();
        when(productionApplicationService.getProductionRule(any())).thenReturn(Collections.emptyList());

        CnResult<AgreementInfoDTO> cn = service.queryAgreementInfo();
        assertTrue(cn.isSuccess());
        assertNotNull(cn.getData());
        assertNull(cn.getData().getAgreementCode());
    }

    @Test
    public void queryAgreementInfo_stationRuleWithoutAgreementConfig_shouldReturnEmpty() {
        setStationLogin();
        PurchaseRule rule = new PurchaseRule();
        rule.setAgreementConfig(null);
        when(productionApplicationService.getProductionRule(any())).thenReturn(Collections.singletonList(rule));

        CnResult<AgreementInfoDTO> cn = service.queryAgreementInfo();
        assertTrue(cn.isSuccess());
        assertNull(cn.getData().getAgreementCode());
    }

    @Test
    public void queryAgreementInfo_stationWithSignedAgreement_shouldReturnFullInfo() {
        setStationLogin();
        AgreementConfig ac = new AgreementConfig();
        ac.setAgreementCode("AGR-001");
        PurchaseRule rule = new PurchaseRule();
        rule.setAgreementConfig(Collections.singletonList(ac));
        when(productionApplicationService.getProductionRule(any())).thenReturn(Collections.singletonList(rule));

        AgreementInfoAndSignDTO signInfo = new AgreementInfoAndSignDTO();
        signInfo.setAgreementCode("AGR-001");
        signInfo.setAgreementName("企业购买协议");
        signInfo.setAgreementUrl("http://contract");
        signInfo.setAgreementId(666L);
        signInfo.setSigned(true);
        when(agreementComponent.queryAgreementInfoAndSigned(any())).thenReturn(signInfo);

        CnResult<AgreementInfoDTO> cn = service.queryAgreementInfo();
        assertTrue(cn.isSuccess());
        AgreementInfoDTO data = cn.getData();
        assertEquals("AGR-001", data.getAgreementCode());
        assertEquals("企业购买协议", data.getAgreementName());
        assertEquals("http://contract", data.getAgreementUrl());
        assertEquals("666", data.getAgreementId());
        assertTrue(data.getSign());
    }

    @Test
    public void queryAgreementInfo_stationButAgreementSignNull_shouldHaveAgreementCodeOnly() {
        setStationLogin();
        AgreementConfig ac = new AgreementConfig();
        ac.setAgreementCode("AGR-002");
        PurchaseRule rule = new PurchaseRule();
        rule.setAgreementConfig(Collections.singletonList(ac));
        when(productionApplicationService.getProductionRule(any())).thenReturn(Collections.singletonList(rule));
        when(agreementComponent.queryAgreementInfoAndSigned(any())).thenReturn(null);

        CnResult<AgreementInfoDTO> cn = service.queryAgreementInfo();
        assertTrue(cn.isSuccess());
        // 至少 agreementCode 已被设置
        assertEquals("AGR-002", cn.getData().getAgreementCode());
    }

    @Test
    public void queryAgreementInfo_multipleAgreements_shouldUseFirstOne() {
        setStationLogin();
        AgreementConfig ac1 = new AgreementConfig();
        ac1.setAgreementCode("AGR-FIRST");
        AgreementConfig ac2 = new AgreementConfig();
        ac2.setAgreementCode("AGR-SECOND");
        PurchaseRule rule = new PurchaseRule();
        rule.setAgreementConfig(Arrays.asList(ac1, ac2));
        when(productionApplicationService.getProductionRule(any())).thenReturn(Collections.singletonList(rule));
        when(agreementComponent.queryAgreementInfoAndSigned(any())).thenReturn(null);

        CnResult<AgreementInfoDTO> cn = service.queryAgreementInfo();
        assertEquals("AGR-FIRST", cn.getData().getAgreementCode());
    }

    /* ============================== checkUserPro ============================== */

    @Test
    public void checkUserPro_canBuyTrue_shouldNotThrow() {
        setExpressLogin();
        service.checkUserPro();
    }

    @Test(expected = Exception.class)
    public void checkUserPro_canBuyFalse_shouldThrow() {
        // 灰度名单不命中当前登录用户 → canBuy=false
        CabinetMallConfigDTO config = new CabinetMallConfigDTO();
        config.setGreyCityList(Collections.singletonList(99L));
        CabinetMallConfigDTO.setINSTANCE(config);
        setExpressLogin();

        service.checkUserPro();
    }

    /* ============================== helpers ============================== */

    /**
     * 设置网点（EXPRESS）登录态。expressId=200, cityCode=11, expressCabinetBuyer=true
     */
    @SuppressWarnings({"rawtypes", "unchecked"})
    private void setExpressLogin() {
        ExpressPermissionContext ec = new ExpressPermissionContext();
        ec.setExpressId(200L);
        ec.setExpressCode("EXP-200");
        ec.setUserId(1001L);
        ec.setUserName("张三");
        ec.setCnEmployeeId("EMP-001");
        ec.setCityCode(11L);
        ec.setExpressCabinetBuyer(true);
        PermissionContext ctx = new PermissionContext();
        ctx.setContext(ec);
        ctx.setLoginType(LoginEntityTypeEnum.EXPRESS.getType());
        MtopLoginContext.setContext((PermissionContext<BasePermissionContext>) ctx);
    }

    /**
     * 设置站点（STATION）登录态。stationId=300, corporation=true, authType=2
     */
    @SuppressWarnings({"rawtypes", "unchecked"})
    private void setStationLogin() {
        StationPermissionContext sc = new StationPermissionContext();
        sc.setStationId("300");
        sc.setUserId(2002L);
        sc.setUserName("李四");
        sc.setCorporation(true);
        sc.setAuthType(2);
        sc.setCityCode("21");
        sc.setUserType(1);
        sc.setEmployeeId(8888L);
        sc.setCnAccountId(7777L);
        PermissionContext ctx = new PermissionContext();
        ctx.setContext(sc);
        ctx.setLoginType(LoginEntityTypeEnum.STATION.getType());
        MtopLoginContext.setContext((PermissionContext<BasePermissionContext>) ctx);
    }
}
