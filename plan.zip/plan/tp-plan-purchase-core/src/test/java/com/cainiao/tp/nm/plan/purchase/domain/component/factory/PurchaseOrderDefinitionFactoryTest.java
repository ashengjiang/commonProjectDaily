package com.cainiao.tp.nm.plan.purchase.domain.component.factory;

import com.cainiao.tp.nm.plan.purchase.domain.component.PurchaseOrderDefinition;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.ApplicationContext;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.when;

/**
 * PurchaseOrderDefinitionFactory 单元测试
 * <p>
 * 路由 key 计算规则：
 * - 注册时：bizType + （customType 非空 ? "_" + customType : ""）
 * - 查询时：bizType + （customType 非空 ? "_" + customType : ""）
 * 查询优先级：精确匹配 → 仅 bizType → "default_default" 兜底
 * </p> */
@RunWith(MockitoJUnitRunner.class)
public class PurchaseOrderDefinitionFactoryTest {

    @InjectMocks
    private PurchaseOrderDefinitionFactory factory;

    @Mock
    private ApplicationContext applicationContext;

    @Mock
    private PurchaseOrderDefinition defaultDefinition;

    @Mock
    private PurchaseOrderDefinition cabinetWithCustomType;

    @Mock
    private PurchaseOrderDefinition cabinetWithoutCustomType;

    @Before
    public void setUp() {
        when(defaultDefinition.bizType()).thenReturn("default");
        when(defaultDefinition.customType()).thenReturn("default");

        when(cabinetWithCustomType.bizType()).thenReturn("cabinet");
        when(cabinetWithCustomType.customType()).thenReturn("station");

        when(cabinetWithoutCustomType.bizType()).thenReturn("cabinet");
        when(cabinetWithoutCustomType.customType()).thenReturn("");
    }

    /* ============================== afterPropertiesSet ============================== */

    @Test
    public void afterPropertiesSet_emptyBeans_shouldBuildEmptyRouter() throws Exception {
        when(applicationContext.getBeansOfType(PurchaseOrderDefinition.class)).thenReturn(new HashMap<>());
        factory.afterPropertiesSet();

        assertNull(factory.getDefinition("cabinet", 1));
    }

    @Test
    public void afterPropertiesSet_normalBeans_shouldBuildRouter() throws Exception {
        Map<String, PurchaseOrderDefinition> beanMap = new HashMap<>();
        beanMap.put("d1", defaultDefinition);
        beanMap.put("d2", cabinetWithCustomType);
        when(applicationContext.getBeansOfType(PurchaseOrderDefinition.class)).thenReturn(beanMap);

        factory.afterPropertiesSet();

        // 精确匹配（注意 key 用的是 String，但 getDefinition 入参是 Integer，先确认）
        // 由于 customType 是 Integer，注册时把 customType（String）拼成 key="cabinet_station"
        // 而调用 getDefinition("cabinet", 1) 时拼成 key="cabinet_1"，不一致 → 走兜底
        // 这里先验证默认兜底
        PurchaseOrderDefinition d = factory.getDefinition("cabinet", null);
        // bizType=cabinet, customType=null → key=cabinet → 查不到 → 再查 default_default
        assertSame(defaultDefinition, d);
    }

    @Test
    public void afterPropertiesSet_contextThrows_shouldRethrow() {
        when(applicationContext.getBeansOfType(PurchaseOrderDefinition.class))
                .thenThrow(new RuntimeException("ctx fail"));
        try {
            factory.afterPropertiesSet();
            fail();
        } catch (Exception e) {
            assertEquals("ctx fail", e.getMessage());
        }
    }

    /* ============================== getDefinition ============================== */

    @Test
    public void getDefinition_exactMatch_shouldReturnExact() throws Exception {
        // 自定义一个 mock，bizType="cabinet"、customType="1"（数字字符串）
        PurchaseOrderDefinition exact = org.mockito.Mockito.mock(PurchaseOrderDefinition.class);
        when(exact.bizType()).thenReturn("cabinet");
        when(exact.customType()).thenReturn("1");

        Map<String, PurchaseOrderDefinition> beanMap = new HashMap<>();
        beanMap.put("exact", exact);
        beanMap.put("def", defaultDefinition);
        when(applicationContext.getBeansOfType(PurchaseOrderDefinition.class)).thenReturn(beanMap);
        factory.afterPropertiesSet();

        // getDefinition("cabinet", 1) → 拼出 key="cabinet_1" → 命中 exact
        assertSame(exact, factory.getDefinition("cabinet", 1));
    }

    @Test
    public void getDefinition_bizTypeOnlyMatch_shouldReturnBizTypeOne() throws Exception {
        // 注册一个 bizType=cabinet, customType="" → key="cabinet"
        Map<String, PurchaseOrderDefinition> beanMap = new HashMap<>();
        beanMap.put("cabinet", cabinetWithoutCustomType);
        beanMap.put("def", defaultDefinition);
        when(applicationContext.getBeansOfType(PurchaseOrderDefinition.class)).thenReturn(beanMap);
        factory.afterPropertiesSet();

        // getDefinition("cabinet", 999) → key="cabinet_999" → 未命中 → fallback 到 key="cabinet"
        assertSame(cabinetWithoutCustomType, factory.getDefinition("cabinet", 999));
    }

    @Test
    public void getDefinition_fallbackToDefault_shouldReturnDefault() throws Exception {
        Map<String, PurchaseOrderDefinition> beanMap = new HashMap<>();
        beanMap.put("def", defaultDefinition);
        when(applicationContext.getBeansOfType(PurchaseOrderDefinition.class)).thenReturn(beanMap);
        factory.afterPropertiesSet();

        // 未命中 bizType/精确匹配 → fallback 到 default_default
        assertSame(defaultDefinition, factory.getDefinition("unknown", 999));
    }

    @Test
    public void getDefinition_nothingMatched_shouldReturnNull() throws Exception {
        // 没有 default_default 兜底
        PurchaseOrderDefinition other = org.mockito.Mockito.mock(PurchaseOrderDefinition.class);
        when(other.bizType()).thenReturn("other");
        when(other.customType()).thenReturn("typeA");

        Map<String, PurchaseOrderDefinition> beanMap = new HashMap<>();
        beanMap.put("other", other);
        when(applicationContext.getBeansOfType(PurchaseOrderDefinition.class)).thenReturn(beanMap);
        factory.afterPropertiesSet();

        assertNull(factory.getDefinition("unknown", 1));
    }

    @Test
    public void getDefinition_customTypeNull_shouldUseBizTypeOnly() throws Exception {
        Map<String, PurchaseOrderDefinition> beanMap = new HashMap<>();
        beanMap.put("cabinet", cabinetWithoutCustomType);
        beanMap.put("def", defaultDefinition);
        when(applicationContext.getBeansOfType(PurchaseOrderDefinition.class)).thenReturn(beanMap);
        factory.afterPropertiesSet();

        // customType=null → key="cabinet" → 命中
        assertSame(cabinetWithoutCustomType, factory.getDefinition("cabinet", null));
    }

    @Test
    public void getDefinition_definitionWithBlankCustomType_shouldUseBizTypeOnlyAsKey() throws Exception {
        // bizType=cabinet, customType="" → 注册 key="cabinet"
        Map<String, PurchaseOrderDefinition> beanMap = new HashMap<>();
        beanMap.put("cabinet", cabinetWithoutCustomType);
        when(applicationContext.getBeansOfType(PurchaseOrderDefinition.class)).thenReturn(beanMap);
        factory.afterPropertiesSet();

        // getDefinition("cabinet", null) → key="cabinet" → 命中
        assertSame(cabinetWithoutCustomType, factory.getDefinition("cabinet", null));
    }

    @Test
    public void getDefinition_multipleBeansSameKey_lastWriteWins() throws Exception {
        // 两个 bean key 都是 cabinet_station，后注册的覆盖
        PurchaseOrderDefinition another = org.mockito.Mockito.mock(PurchaseOrderDefinition.class);
        when(another.bizType()).thenReturn("cabinet");
        when(another.customType()).thenReturn("station");

        Map<String, PurchaseOrderDefinition> beanMap = new java.util.LinkedHashMap<>();
        beanMap.put("first", cabinetWithCustomType);
        beanMap.put("second", another);
        when(applicationContext.getBeansOfType(PurchaseOrderDefinition.class)).thenReturn(beanMap);
        factory.afterPropertiesSet();

        // LinkedHashMap 保证遍历顺序；调用 getDefinition("cabinet", null) → key="cabinet" → 未命中 → 找 default_default → 未注册 → null
        assertNull(factory.getDefinition("cabinet", null));
    }
}
