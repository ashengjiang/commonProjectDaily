package com.cainiao.tp.nm.plan.purchase.application.service.impl;

import com.cainiao.tp.nm.plan.api.purchase.application.dto.ProductInfoResultDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.ProductInfoParam;
import com.cainiao.tp.nm.plan.api.purchase.common.constants.ProductStatusEnum;
import com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseCategoryEnum;
import com.cainiao.tp.nm.plan.infra.port.common.constants.ErrorCode;
import com.cainiao.tp.nm.plan.infra.port.common.exception.PurchaseServiceException;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseProduct;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseRule;
import com.cainiao.tp.nm.plan.purchase.domain.model.valobj.CustomerConfig;
import com.cainiao.tp.nm.plan.purchase.domain.repository.PurchaseProductRepository;
import com.cainiao.tp.nm.plan.purchase.domain.repository.PurchaseRuleRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * ProductionApplicationServiceImpl 单元测试 */
@RunWith(MockitoJUnitRunner.class)
public class ProductionApplicationServiceImplTest {

    @InjectMocks
    private ProductionApplicationServiceImpl service;

    @Mock
    private PurchaseRuleRepository purchaseRuleRepository;

    @Mock
    private PurchaseProductRepository purchaseProductRepository;

    /* ============================== 入参校验 ============================== */

    @Test
    public void getProductInfo_paramNull_shouldThrow() {
        assertIllegalParam(() -> service.getProductInfo(null, null));
    }

    @Test
    public void getProductInfo_categoryIdNull_shouldThrow() {
        assertIllegalParam(() -> service.getProductInfo(buildParam(null, "C", 1), null));
    }

    @Test
    public void getProductInfo_customerIdBlank_shouldThrow() {
        assertIllegalParam(() -> service.getProductInfo(buildParam(1, "  ", 1), null));
    }

    @Test
    public void getProductInfo_customerTypeNull_shouldThrow() {
        assertIllegalParam(() -> service.getProductInfo(buildParam(1, "C", null), null));
    }

    /* ============================== 主流程 ============================== */

    @Test
    public void getProductInfo_noRules_shouldReturnEmptyList() {
        ProductInfoParam param = buildParam(PurchaseCategoryEnum.CABINET.getCode(), "C001", 1);
        when(purchaseRuleRepository.getRulesByCategoryId(PurchaseCategoryEnum.CABINET.getCode()))
                .thenReturn(Collections.emptyList());

        ProductInfoResultDTO result = service.getProductInfo(param, null);

        assertNotNull(result);
        assertTrue(result.getProductInfoList().isEmpty());
        verify(purchaseProductRepository, never()).getProductsByIds(anyList());
    }

    @Test
    public void getProductInfo_allRulesFiltered_shouldReturnEmptyList() {
        // 规则均失效（未来才生效）
        PurchaseRule futureRule = buildRule(1L, 100L);
        futureRule.setStartTime(LocalDateTime.now().plusYears(10));
        ProductInfoParam param = buildParam(PurchaseCategoryEnum.CABINET.getCode(), "C001", 1);
        when(purchaseRuleRepository.getRulesByCategoryId(PurchaseCategoryEnum.CABINET.getCode()))
                .thenReturn(Collections.singletonList(futureRule));

        ProductInfoResultDTO result = service.getProductInfo(param, null);

        assertNotNull(result);
        assertTrue(result.getProductInfoList().isEmpty());
        verify(purchaseProductRepository, never()).getProductsByIds(anyList());
    }

    @Test
    public void getProductInfo_customerBlackListed_shouldFilterOut() {
        PurchaseRule rule = buildRule(1L, 100L);
        rule.getCustomerConfig().setBlackList(Collections.singletonList("C001"));
        when(purchaseRuleRepository.getRulesByCategoryId(PurchaseCategoryEnum.CABINET.getCode()))
                .thenReturn(Collections.singletonList(rule));

        ProductInfoResultDTO result = service.getProductInfo(
                buildParam(PurchaseCategoryEnum.CABINET.getCode(), "C001", 1), null);

        assertTrue(result.getProductInfoList().isEmpty());
    }

    @Test
    public void getProductInfo_customerNotInWhiteList_shouldFilterOut() {
        PurchaseRule rule = buildRule(1L, 100L);
        rule.getCustomerConfig().setWhiteList(Collections.singletonList("OTHER"));
        when(purchaseRuleRepository.getRulesByCategoryId(PurchaseCategoryEnum.CABINET.getCode()))
                .thenReturn(Collections.singletonList(rule));

        ProductInfoResultDTO result = service.getProductInfo(
                buildParam(PurchaseCategoryEnum.CABINET.getCode(), "C001", 1), null);

        assertTrue(result.getProductInfoList().isEmpty());
    }

    @Test
    public void getProductInfo_offShelfProduct_shouldBeFilteredOut() {
        PurchaseRule rule = buildRule(1L, 100L);
        when(purchaseRuleRepository.getRulesByCategoryId(PurchaseCategoryEnum.CABINET.getCode()))
                .thenReturn(Collections.singletonList(rule));

        // 下架商品
        PurchaseProduct offShelf = buildProduct(100L, ProductStatusEnum.OFF_SHELF.getCode());
        when(purchaseProductRepository.getProductsByIds(anyList()))
                .thenReturn(Collections.singletonList(offShelf));

        ProductInfoResultDTO result = service.getProductInfo(
                buildParam(PurchaseCategoryEnum.CABINET.getCode(), "C001", 1), null);

        assertTrue(result.getProductInfoList().isEmpty());
    }

    @Test
    public void getProductInfo_onShelfProduct_shouldReturnInList() {
        PurchaseRule rule = buildRule(1L, 100L);
        when(purchaseRuleRepository.getRulesByCategoryId(PurchaseCategoryEnum.CABINET.getCode()))
                .thenReturn(Collections.singletonList(rule));

        PurchaseProduct onShelf = buildProduct(100L, ProductStatusEnum.ON_SHELF.getCode());
        onShelf.setTitle("柜机A");
        onShelf.setPrice(new BigDecimal("1999.00"));
        when(purchaseProductRepository.getProductsByIds(anyList()))
                .thenReturn(Collections.singletonList(onShelf));

        ProductInfoResultDTO result = service.getProductInfo(
                buildParam(PurchaseCategoryEnum.CABINET.getCode(), "C001", 1), null);

        assertEquals(1, result.getProductInfoList().size());
        assertEquals(Integer.valueOf(100), result.getProductInfoList().get(0).getItemId());
        assertEquals("柜机A", result.getProductInfoList().get(0).getItemTitle());
        assertEquals(Double.valueOf(1999.00), result.getProductInfoList().get(0).getPrice());
    }

    @Test
    public void getProductionRule_returnsEffectiveAndAllowedRules() {
        PurchaseRule active = buildRule(1L, 100L);
        PurchaseRule futureRule = buildRule(2L, 200L);
        futureRule.setStartTime(LocalDateTime.now().plusYears(10));

        when(purchaseRuleRepository.getRulesByCategoryId(PurchaseCategoryEnum.CABINET.getCode()))
                .thenReturn(Arrays.asList(active, futureRule));

        List<PurchaseRule> result = service.getProductionRule(
                buildParam(PurchaseCategoryEnum.CABINET.getCode(), "C001", 1));

        assertEquals(1, result.size());
        assertEquals(Long.valueOf(1L), result.get(0).getId());
    }

    /* ============================== helpers ============================== */

    private interface ThrowingCall {
        void call();
    }

    private void assertIllegalParam(ThrowingCall call) {
        try {
            call.call();
            fail("期望抛出 PurchaseServiceException");
        } catch (PurchaseServiceException e) {
            assertEquals(ErrorCode.ILLEGAL_PARAM.getCode(), e.getCode());
        }
    }

    private ProductInfoParam buildParam(Integer categoryId, String customerId, Integer customerType) {
        ProductInfoParam p = new ProductInfoParam();
        p.setCategoryId(categoryId);
        p.setCustomerId(customerId);
        p.setCustomerType(customerType);
        return p;
    }

    private PurchaseRule buildRule(Long ruleId, Long productId) {
        PurchaseRule rule = new PurchaseRule();
        rule.setId(ruleId);
        rule.setProductId(productId);
        rule.setCategoryId(PurchaseCategoryEnum.CABINET.getCode());

        CustomerConfig cc = new CustomerConfig();
        cc.setCustomerType(1);
        rule.setCustomerConfig(cc);
        return rule;
    }

    private PurchaseProduct buildProduct(Long id, Integer status) {
        PurchaseProduct p = new PurchaseProduct();
        p.setId(id);
        p.setStatus(status);
        return p;
    }
}
