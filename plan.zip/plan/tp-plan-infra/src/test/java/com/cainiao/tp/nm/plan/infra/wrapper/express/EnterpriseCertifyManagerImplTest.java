package com.cainiao.tp.nm.plan.infra.wrapper.express;

import com.alibaba.cainiao.express.outlets.api.result.ResultModel;
import com.alibaba.cainiao.express.outlets.contract.api.certify.result.CertifiedEnterpriseDTO;
import com.alibaba.cainiao.express.outlets.contract.api.certify.service.EnterpriseCertifyService;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.CertifiedEnterpriseInfoDTO;
import com.cainiao.tp.nm.plan.infra.port.common.exception.ServiceException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * {@link EnterpriseCertifyManagerImpl} 单元测试
 *
 * <p>覆盖：
 * <ul>
 *   <li>expressCode 为 null / 空 / 空白 → 直接返回 null</li>
 *   <li>下游返回 null / 失败 / data 为 null → 返回 null</li>
 *   <li>下游成功 → 字段映射齐全</li>
 *   <li>下游抛异常 → 包装为 ServiceException</li>
 * </ul> */
@RunWith(MockitoJUnitRunner.class)
public class EnterpriseCertifyManagerImplTest {

    @InjectMocks
    private EnterpriseCertifyManagerImpl manager;

    @Mock
    private EnterpriseCertifyService enterpriseCertifyService;

    /* ============================ blank 参数 ============================ */

    @Test
    public void queryCertifiedEnterprise_nullExpressCode_shouldReturnNull() {
        assertNull(manager.queryCertifiedEnterprise(null));
        verify(enterpriseCertifyService, never()).queryCertifiedEnterprise(anyString());
    }

    @Test
    public void queryCertifiedEnterprise_emptyExpressCode_shouldReturnNull() {
        assertNull(manager.queryCertifiedEnterprise(""));
        verify(enterpriseCertifyService, never()).queryCertifiedEnterprise(anyString());
    }

    @Test
    public void queryCertifiedEnterprise_blankExpressCode_shouldReturnNull() {
        assertNull(manager.queryCertifiedEnterprise("   "));
        verify(enterpriseCertifyService, never()).queryCertifiedEnterprise(anyString());
    }

    /* ============================ 下游返回异常情况 ============================ */

    @Test
    public void queryCertifiedEnterprise_nullResult_shouldReturnNull() {
        when(enterpriseCertifyService.queryCertifiedEnterprise("EX001")).thenReturn(null);
        assertNull(manager.queryCertifiedEnterprise("EX001"));
    }

    @Test
    public void queryCertifiedEnterprise_resultFail_shouldReturnNull() {
        ResultModel<CertifiedEnterpriseDTO> failResult = ResultModel.buildErrorResult("500", "internal");
        when(enterpriseCertifyService.queryCertifiedEnterprise("EX001")).thenReturn(failResult);

        assertNull(manager.queryCertifiedEnterprise("EX001"));
    }

    @Test
    public void queryCertifiedEnterprise_resultDataNull_shouldReturnNull() {
        ResultModel<CertifiedEnterpriseDTO> result = ResultModel.buildSuccessResult(null);
        when(enterpriseCertifyService.queryCertifiedEnterprise("EX001")).thenReturn(result);

        assertNull(manager.queryCertifiedEnterprise("EX001"));
    }

    /* ============================ 下游成功 ============================ */

    @Test
    public void queryCertifiedEnterprise_success_shouldMapAllFields() {
        CertifiedEnterpriseDTO data = new CertifiedEnterpriseDTO();
        data.setEnterpriseName("企业A");
        data.setRegCode("REG001");
        data.setLegalPerson("张三");
        data.setLegalMobile("13800000001");
        data.setTransactorMobile("13800000002");
        data.setSignMobile("13800000003");
        data.setPicOssKey("oss/key");
        java.util.Date gmt = new java.util.Date();
        data.setGmtModified(gmt);

        ResultModel<CertifiedEnterpriseDTO> result = ResultModel.buildSuccessResult(data);
        when(enterpriseCertifyService.queryCertifiedEnterprise("EX001")).thenReturn(result);

        CertifiedEnterpriseInfoDTO actual = manager.queryCertifiedEnterprise("EX001");

        assertNotNull(actual);
        assertEquals("企业A", actual.getEnterpriseName());
        assertEquals("REG001", actual.getRegCode());
        assertEquals("张三", actual.getLegalPerson());
        assertEquals("13800000001", actual.getLegalMobile());
        assertEquals("13800000002", actual.getTransactorMobile());
        assertEquals("13800000003", actual.getSignMobile());
        assertEquals("oss/key", actual.getPicOssKey());
        assertEquals(gmt, actual.getGmtModified());
    }

    /* ============================ 下游抛异常 ============================ */

    @Test
    public void queryCertifiedEnterprise_downstreamThrow_shouldWrapAsServiceException() {
        when(enterpriseCertifyService.queryCertifiedEnterprise("EX001"))
                .thenThrow(new RuntimeException("downstream boom"));

        try {
            manager.queryCertifiedEnterprise("EX001");
            fail("expected ServiceException");
        } catch (ServiceException e) {
            assertEquals("企业认证查询异常", e.getMessage());
        }
    }
}
