package com.cainiao.tp.nm.plan.infra.repository.purchase;

import com.cainiao.tp.nm.plan.infra.repository.purchase.convert.PurchaseProductSkuConvertor;
import com.cainiao.tp.nm.plan.infra.repository.purchase.dto.data.PurchaseProductSkuDO;
import com.cainiao.tp.nm.plan.infra.repository.purchase.dto.param.PurchaseProductSkuQueryParam;
import com.cainiao.tp.nm.plan.infra.repository.purchase.mapper.PurchaseProductSkuMapper;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseProductSku;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * {@link PurchaseProductSkuRepositoryImpl} 单元测试 */
@RunWith(MockitoJUnitRunner.class)
public class PurchaseProductSkuRepositoryImplTest {

    @InjectMocks
    private PurchaseProductSkuRepositoryImpl repository;

    @Mock
    private PurchaseProductSkuMapper purchaseProductSkuMapper;

    @Mock
    private PurchaseProductSkuConvertor purchaseProductSkuConvertor;

    /* ============================ getById ============================ */

    @Test
    public void getById_nullId_shouldReturnNull() {
        assertNull(repository.getById(null));
        verify(purchaseProductSkuMapper, never()).selectById(any());
    }

    @Test
    public void getById_notExist_shouldReturnNull() {
        when(purchaseProductSkuMapper.selectById(1L)).thenReturn(null);
        assertNull(repository.getById(1L));
        verify(purchaseProductSkuConvertor, never()).doToModel(any(PurchaseProductSkuDO.class));
    }

    @Test
    public void getById_exist_shouldConvertAndReturn() {
        PurchaseProductSkuDO doObj = new PurchaseProductSkuDO();
        PurchaseProductSku model = new PurchaseProductSku();
        when(purchaseProductSkuMapper.selectById(1L)).thenReturn(doObj);
        when(purchaseProductSkuConvertor.doToModel(doObj)).thenReturn(model);

        assertEquals(model, repository.getById(1L));
    }

    /* ============================ getBySkuId ============================ */

    @Test
    public void getBySkuId_null_shouldReturnNull() {
        assertNull(repository.getBySkuId(null));
        verify(purchaseProductSkuMapper, never()).selectAll(any());
    }

    @Test
    public void getBySkuId_empty_shouldReturnNull() {
        assertNull(repository.getBySkuId(""));
        verify(purchaseProductSkuMapper, never()).selectAll(any());
    }

    @Test
    public void getBySkuId_notFound_shouldReturnNull() {
        when(purchaseProductSkuMapper.selectAll(any(PurchaseProductSkuQueryParam.class)))
                .thenReturn(Collections.emptyList());

        assertNull(repository.getBySkuId("SKU-X"));
        verify(purchaseProductSkuConvertor, never()).doToModel(any(PurchaseProductSkuDO.class));
    }

    @Test
    public void getBySkuId_found_shouldReturnFirst() {
        PurchaseProductSkuDO d1 = new PurchaseProductSkuDO();
        PurchaseProductSku model = new PurchaseProductSku();
        ArgumentCaptor<PurchaseProductSkuQueryParam> captor =
                ArgumentCaptor.forClass(PurchaseProductSkuQueryParam.class);
        when(purchaseProductSkuMapper.selectAll(captor.capture()))
                .thenReturn(Collections.singletonList(d1));
        when(purchaseProductSkuConvertor.doToModel(d1)).thenReturn(model);

        assertEquals(model, repository.getBySkuId("SKU-1"));
        PurchaseProductSkuQueryParam param = captor.getValue();
        assertEquals("SKU-1", param.getSkuId());
        assertEquals(Integer.valueOf(1), param.getSize());
    }

    /* ============================ listByProductIds ============================ */

    @Test
    public void listByProductIds_nullList_shouldReturnEmpty() {
        List<PurchaseProductSku> result = repository.listByProductIds(null);
        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(purchaseProductSkuMapper, never()).selectAll(any());
    }

    @Test
    public void listByProductIds_emptyList_shouldReturnEmpty() {
        assertTrue(repository.listByProductIds(Collections.emptyList()).isEmpty());
        verify(purchaseProductSkuMapper, never()).selectAll(any());
    }

    @Test
    public void listByProductIds_normal_shouldSetQueryParamAndConvert() {
        List<Long> productIds = Arrays.asList(1L, 2L);
        List<PurchaseProductSkuDO> doList =
                Arrays.asList(new PurchaseProductSkuDO(), new PurchaseProductSkuDO());
        List<PurchaseProductSku> models =
                Arrays.asList(new PurchaseProductSku(), new PurchaseProductSku());

        ArgumentCaptor<PurchaseProductSkuQueryParam> captor =
                ArgumentCaptor.forClass(PurchaseProductSkuQueryParam.class);
        when(purchaseProductSkuMapper.selectAll(captor.capture())).thenReturn(doList);
        when(purchaseProductSkuConvertor.doToModelList(doList)).thenReturn(models);

        List<PurchaseProductSku> result = repository.listByProductIds(productIds);

        assertEquals(2, result.size());
        PurchaseProductSkuQueryParam param = captor.getValue();
        assertEquals(productIds, param.getProductIdList());
        // size = productIds.size() * 10
        assertEquals(Integer.valueOf(20), param.getSize());
    }

    /* ============================ saveProductSku ============================ */

    @Test
    public void saveProductSku_shouldConvertAndInsert() {
        PurchaseProductSku sku = new PurchaseProductSku();
        PurchaseProductSkuDO doObj = new PurchaseProductSkuDO();
        when(purchaseProductSkuConvertor.modelToDO(sku)).thenReturn(doObj);

        PurchaseProductSku result = repository.saveProductSku(sku);

        assertEquals(sku, result);
        verify(purchaseProductSkuMapper).insert(doObj);
    }

    /* ============================ deleteSkusByProductId ============================ */

    @Test
    public void deleteSkusByProductId_nullId_shouldDoNothing() {
        repository.deleteSkusByProductId(null);
        verify(purchaseProductSkuMapper, never()).selectAll(any());
        verify(purchaseProductSkuMapper, never()).batchDeleteByIds(anyList());
    }

    @Test
    public void deleteSkusByProductId_emptyResult_shouldNotInvokeBatchDelete() {
        when(purchaseProductSkuMapper.selectAll(any(PurchaseProductSkuQueryParam.class)))
                .thenReturn(Collections.emptyList());

        repository.deleteSkusByProductId(1L);

        verify(purchaseProductSkuMapper, never()).batchDeleteByIds(anyList());
    }

    @Test
    public void deleteSkusByProductId_normal_shouldBatchDelete() {
        PurchaseProductSkuDO s1 = new PurchaseProductSkuDO();
        s1.setId(11L);
        PurchaseProductSkuDO s2 = new PurchaseProductSkuDO();
        s2.setId(22L);

        ArgumentCaptor<PurchaseProductSkuQueryParam> queryCaptor =
                ArgumentCaptor.forClass(PurchaseProductSkuQueryParam.class);
        when(purchaseProductSkuMapper.selectAll(queryCaptor.capture()))
                .thenReturn(Arrays.asList(s1, s2));

        ArgumentCaptor<List<Long>> idCaptor =
                ArgumentCaptor.forClass(List.class);

        repository.deleteSkusByProductId(1L);

        verify(purchaseProductSkuMapper).batchDeleteByIds(idCaptor.capture());
        assertEquals(Arrays.asList(11L, 22L), idCaptor.getValue());

        // 查询参数：按 productId 单元素 IN 查询
        PurchaseProductSkuQueryParam qp = queryCaptor.getValue();
        assertEquals(Collections.singletonList(1L), qp.getProductIdList());
        assertEquals(Integer.valueOf(100), qp.getSize());
    }

    /* ============================ updateSku ============================ */

    @Test
    public void updateSku_nullParam_shouldReturnNull() {
        assertNull(repository.updateSku(null));
        verify(purchaseProductSkuMapper, never()).update(any());
    }

    @Test
    public void updateSku_nullId_shouldReturnNull() {
        PurchaseProductSku sku = new PurchaseProductSku();
        sku.setId(null);
        assertNull(repository.updateSku(sku));
        verify(purchaseProductSkuMapper, never()).update(any());
    }

    @Test
    public void updateSku_normal_shouldConvertAndUpdate() {
        PurchaseProductSku sku = new PurchaseProductSku();
        sku.setId(1L);
        PurchaseProductSkuDO doObj = new PurchaseProductSkuDO();
        when(purchaseProductSkuConvertor.modelToDO(sku)).thenReturn(doObj);

        PurchaseProductSku result = repository.updateSku(sku);

        assertEquals(sku, result);
        verify(purchaseProductSkuMapper).update(doObj);
    }

    /* ============================ deleteSkuById ============================ */

    @Test
    public void deleteSkuById_nullId_shouldDoNothing() {
        repository.deleteSkuById(null);
        verify(purchaseProductSkuMapper, never()).deleteById(any());
    }

    @Test
    public void deleteSkuById_normal_shouldCallMapper() {
        repository.deleteSkuById(1L);
        verify(purchaseProductSkuMapper).deleteById(1L);
    }
}
