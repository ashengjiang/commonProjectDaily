package com.cainiao.tp.nm.plan.infra.wrapper.express;

import com.alibaba.cainiao.stationplatform.client.domain.OperatorInfo;
import com.alibaba.cainiao.stationplatform.client.domain.StationExpressDTO;
import com.alibaba.cainiao.stationplatform.client.domain.StationResultDTO;
import com.alibaba.cainiao.stationplatform.client.service.StationExpressService;
import com.cainiao.tp.nm.plan.infra.port.common.exception.ServiceException;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.StationExpressInfoDTO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

/**
 * {@link StationExpressManagerImpl} 单元测试 */
@RunWith(MockitoJUnitRunner.class)
public class StationExpressManagerImplTest {

    @InjectMocks
    private StationExpressManagerImpl manager;

    @Mock
    private StationExpressService stationExpressService;

    @Test
    public void queryExpressInfo_nullId_shouldReturnNull() {
        assertNull(manager.queryExpressInfo(null));
    }

    @Test
    public void queryExpressInfo_resultNull_shouldReturnNull() {
        when(stationExpressService.queryCachedExpressById(eq(1L), any(), any(OperatorInfo.class)))
                .thenReturn(null);
        assertNull(manager.queryExpressInfo(1L));
    }

    @Test
    public void queryExpressInfo_resultFail_shouldReturnNull() {
        StationResultDTO<StationExpressDTO> result = new StationResultDTO<>();
        result.setSuccess(false);
        when(stationExpressService.queryCachedExpressById(eq(1L), any(), any(OperatorInfo.class)))
                .thenReturn(result);
        assertNull(manager.queryExpressInfo(1L));
    }

    @Test
    public void queryExpressInfo_dataNull_shouldReturnNull() {
        StationResultDTO<StationExpressDTO> result = new StationResultDTO<>();
        result.setSuccess(true);
        result.setData(null);
        when(stationExpressService.queryCachedExpressById(eq(1L), any(), any(OperatorInfo.class)))
                .thenReturn(result);
        assertNull(manager.queryExpressInfo(1L));
    }

    @Test
    public void queryExpressInfo_success_shouldMapFields() {
        StationExpressDTO data = new StationExpressDTO();
        data.setExpressId(99L);
        data.setExpressName("快递A");
        data.setContactName("contact");
        data.setContactMobile("13800000000");
        data.setCorporationAlipayId("alipay-1");
        data.setCorporationCnuserId(123L);
        data.setStatus((byte) 1);

        StationResultDTO<StationExpressDTO> result = new StationResultDTO<>();
        result.setSuccess(true);
        result.setData(data);
        when(stationExpressService.queryCachedExpressById(eq(99L), any(), any(OperatorInfo.class)))
                .thenReturn(result);

        StationExpressInfoDTO actual = manager.queryExpressInfo(99L);
        assertNotNull(actual);
        assertEquals(Long.valueOf(99L), actual.getExpressId());
        assertEquals("快递A", actual.getExpressName());
        assertEquals("contact", actual.getContactName());
        assertEquals("13800000000", actual.getContactMobile());
        assertEquals("alipay-1", actual.getCorporationAlipayId());
        assertEquals(Long.valueOf(123L), actual.getCorporationCnuserId());
        assertEquals(Byte.valueOf((byte) 1), actual.getStatus());
    }

    @Test
    public void queryExpressInfo_throw_shouldWrapAsServiceException() {
        when(stationExpressService.queryCachedExpressById(anyLong(), any(), any(OperatorInfo.class)))
                .thenThrow(new RuntimeException("downstream boom"));
        try {
            manager.queryExpressInfo(1L);
            fail("expected ServiceException");
        } catch (ServiceException e) {
            assertEquals("网点信息查询异常", e.getMessage());
        }
    }
}
