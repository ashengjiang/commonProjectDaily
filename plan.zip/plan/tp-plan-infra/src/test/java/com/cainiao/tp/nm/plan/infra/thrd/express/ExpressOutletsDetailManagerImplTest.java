package com.cainiao.tp.nm.plan.infra.thrd.express;

import com.alibaba.cainiao.stationplatform.client.cache.StationExpressReadServiceClient;
import com.alibaba.cainiao.stationplatform.client.domain.ClientInfo;
import com.alibaba.cainiao.stationplatform.client.domain.StationExpressDTO;
import com.alibaba.cainiao.stationplatform.client.domain.StationResultDTO;
import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.sutee.commons.base.result.CnResult;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.ExpressOutletsDetailDTO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.ExpressOutletsQueryRequest;
import com.cainiao.tp.nm.plan.api.policy.application.dto.DivisionDTO;
import com.cainiao.tp.nm.plan.api.policy.common.constants.ExpressTypeEnum;
import com.cainiao.tp.nm.plan.infra.port.policy.DivisionManager;
import com.xiniao.service.operate.api.station.XnUnmannedStationJvInfoService;
import com.xiniao.service.operate.api.ticket.dto.param.JointVentureInfoDTO;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Collections;
import java.util.List;

import static org.mockito.ArgumentMatchers.anyString;

@RunWith(MockitoJUnitRunner.class)
public class ExpressOutletsDetailManagerImplTest {
    @InjectMocks
    private ExpressOutletsDetailManagerImpl expressOutletsDetailManagerImpl;
    @Mock
    private XnUnmannedStationJvInfoService xnUnmannedStationJvInfoService;
    @Mock
    private StationExpressReadServiceClient stationExpressReadServiceClient;
    @Mock
    private DivisionManager divisionManager;


    @Test
    public void testQueryExpressOutletsDetailOrgTypeJV() {
        ExpressOutletsQueryRequest request = new ExpressOutletsQueryRequest();
        request.setOrgType(ExpressTypeEnum.JV.getCode());
        request.setOrgCode("testOrgCode");

        JointVentureInfoDTO mockJvInfo = new JointVentureInfoDTO();
        mockJvInfo.setProvinceId(1L);
        mockJvInfo.setCityId(2L);
        mockJvInfo.setCountyId(3L);
        CnResult<JointVentureInfoDTO> mockResult = CnResult.succeed(mockJvInfo);
        Mockito.when(xnUnmannedStationJvInfoService.getJvInfoByCode(anyString())).thenReturn(mockResult);


        ExpressOutletsDetailDTO result = expressOutletsDetailManagerImpl.queryExpressOutletsDetail(request);
        Assert.assertNotNull(result);
        Assert.assertEquals(ExpressTypeEnum.JV.getCode(), result.getOrgType());
    }

    @Test
    public void testQueryExpressOutletsDetailSetJointVentureInfoDTOSuccess() {
        ExpressOutletsQueryRequest request = new ExpressOutletsQueryRequest();
        request.setOrgType(ExpressTypeEnum.JV.getCode());
        request.setOrgCode("validOrgCode");
        JointVentureInfoDTO mockJvInfo = new JointVentureInfoDTO();
        mockJvInfo.setCode("jv");
        mockJvInfo.setProvinceId(1L);
        mockJvInfo.setCityId(2L);
        mockJvInfo.setCountyId(3L);
        CnResult<JointVentureInfoDTO> mockResult = CnResult.succeed(mockJvInfo);
        Mockito.when(xnUnmannedStationJvInfoService.getJvInfoByCode(anyString())).thenReturn(mockResult);
        ExpressOutletsDetailDTO result = expressOutletsDetailManagerImpl.queryExpressOutletsDetail(request);
        Assert.assertNotNull(result);
        Assert.assertEquals(mockJvInfo.getCode(), result.getExpressOutletsDivisionDTO().getExpressId());
    }

    @Test(expected = AladdinBizException.class)
    public void testQueryExpressOutletsDetailJVInfoFailThrowsException() {
        ExpressOutletsQueryRequest request = new ExpressOutletsQueryRequest();
        request.setOrgType(ExpressTypeEnum.JV.getCode());
        request.setOrgCode("invalidOrgCode");
        CnResult<JointVentureInfoDTO> mockResult = CnResult.fail("error_code", "查询服务商失败");
        Mockito.when(xnUnmannedStationJvInfoService.getJvInfoByCode(anyString())).thenReturn(mockResult);
        ExpressOutletsDetailDTO detailDTO = expressOutletsDetailManagerImpl.queryExpressOutletsDetail(request);
        Assert.assertNull(detailDTO);
    }


    @Test
    public void testQueryExpressOutletsDetailOrg() {
        ExpressOutletsQueryRequest request = new ExpressOutletsQueryRequest();
        request.setOrgType(ExpressTypeEnum.EXPRESS.getCode());
        request.setOrgCode("orgCode");
        request.setCpCode("cpCode");
        StationResultDTO<List<StationExpressDTO>> listStationResultDTO = new StationResultDTO<>();
        listStationResultDTO.setSuccess(true);
        StationExpressDTO expressDTO = new StationExpressDTO();
        expressDTO.setCpCode("cpCode");
        expressDTO.setOrgCode("orgCode");
        listStationResultDTO.setData(Collections.singletonList(expressDTO));
        Mockito.when(stationExpressReadServiceClient.queryExpressByOrgCode(Mockito.anyString(), Mockito.anyString(), Mockito.any(ClientInfo.class))).thenReturn(listStationResultDTO);
//        Mockito.when(divisionManager.getDivisionChain(Mockito.anyLong())).thenReturn(new DivisionDTO());


        ExpressOutletsDetailDTO expressOutletsDetailDTO = expressOutletsDetailManagerImpl.queryExpressOutletsDetail(request);
        Assert.assertNotNull(expressOutletsDetailDTO);
        Assert.assertEquals(ExpressTypeEnum.EXPRESS.getCode(), expressOutletsDetailDTO.getOrgType());
        Assert.assertNotNull(expressOutletsDetailDTO.getExpressOutletsDivisionDTO());
        Assert.assertEquals(expressOutletsDetailDTO.getExpressOutletsDivisionDTO().getExpressId(), "cpCode^^^orgCode");
    }


    @Test(expected = AladdinBizException.class)
    public void testQueryExpressOutletsDetailOrgIsNull() {
        ExpressOutletsQueryRequest request = new ExpressOutletsQueryRequest();
        request.setOrgType(ExpressTypeEnum.EXPRESS.getCode());
        request.setOrgCode("orgCode");
        request.setCpCode("cpCode");
        StationResultDTO<List<StationExpressDTO>> listStationResultDTO = new StationResultDTO<>();
        listStationResultDTO.setSuccess(false);
        Mockito.when(stationExpressReadServiceClient.queryExpressByOrgCode(Mockito.anyString(), Mockito.anyString(), Mockito.any(ClientInfo.class))).thenReturn(listStationResultDTO);


        ExpressOutletsDetailDTO expressOutletsDetailDTO = expressOutletsDetailManagerImpl.queryExpressOutletsDetail(request);
        Assert.assertNull(expressOutletsDetailDTO);
    }
}