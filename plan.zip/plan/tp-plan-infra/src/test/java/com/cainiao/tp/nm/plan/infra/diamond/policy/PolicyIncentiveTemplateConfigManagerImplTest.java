package com.cainiao.tp.nm.plan.infra.diamond.policy;

import com.alibaba.fastjson.JSONObject;
import com.cainiao.terminal.finance.quotation.client.quotation.dto.plan.template.QuotationTemplatePlanDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.PolicyIncentiveExpenseItemDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.PolicyIncentivePlanConfigDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.IncentivePlanContentDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.IncentivePlanDTO;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyConfigManager;
import com.cainiao.tp.nm.plan.infra.wrapper.finance.QuotationTemplatePlanWrapper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class PolicyIncentiveTemplateConfigManagerImplTest {

    @InjectMocks
    private PolicyIncentiveTemplateConfigManagerImpl policyIncentiveTemplateConfigManager;

    @Mock
    private PolicyConfigManager policyConfigManager;

    @Mock
    private QuotationTemplatePlanWrapper quotationTemplatePlanWrapper;

    @Mock
    private PolicyIncentiveTemplateConfig policyIncentiveTemplateConfig;

    /**
     * 测试获取激励计划模板的正常情况
     */
    @Test
    public void testGetIncentivePlanTemplateSuccess() {
        String bizType = "bizType";
        String customType = "customType";
        String incentivePlanType = "incentivePlanType";
        String incentivePlanCode = "incentivePlanCode";
        String startTimeStr = "2021-01-01";
        String endTimeStr = "2021-01-31";

        // 模拟调用返回值
        PolicyIncentivePlanConfigDTO policyPlanConfig = mock(PolicyIncentivePlanConfigDTO.class);
        PolicyIncentiveExpenseItemDTO expenseItem = mock(PolicyIncentiveExpenseItemDTO.class);
        String planStr ="{\"coefficient\":[{\"code\":\"basic\",\"frame\":{\"children\":[{\"arithLogic\":\"=\",\"factorCode\":\"stationType\",\"factorName\":\"站点类型\",\"factorResult\":{\"fixedVal\":\"non_station\",\"type\":\"fixed\"},\"incentiveFactorLimit\":{\"canUpdate\":false},\"result\":[{\"code\":\"coefficient\",\"name\":\"默认\",\"resultLimit\":{\"canUpdate\":true,\"limitType\":\"option\",\"optionLimit\":{\"optionList\":[\"0\",\"0.8\",\"1.0\",\"1.4\"]},\"valType\":\"double\"}}]},{\"arithLogic\":\"=\",\"factorCode\":\"stationType\",\"factorName\":\"站点类型\",\"factorResult\":{\"fixedVal\":\"normal_station\",\"type\":\"fixed\"},\"incentiveFactorLimit\":{\"canUpdate\":false},\"result\":[{\"code\":\"coefficient\",\"name\":\"默认\",\"resultLimit\":{\"canUpdate\":true,\"limitType\":\"option\",\"optionLimit\":{\"optionList\":[\"0\",\"0.8\",\"1.0\",\"1.4\"]},\"valType\":\"double\"}}]}]},\"name\":\"默认系数\"}],\"selectPlan\":{\"areaSelectPlan\":{\"national\":true}}}";
        IncentivePlanContentDTO planContentDTO = JSONObject.parseObject(planStr, IncentivePlanContentDTO.class);
        String treeStructureStr = "{\"bizCode\":\"cainiao.express\",\"bizCodeDesc\":\"网点\",\"creator\":{\"userId\":\"67510\",\"userName\":\"壹念\",\"userType\":\"BUC\"},\"endTime\":1759248000000,\"feeCode\":\"fy26q2_sdw_express_extra_fee\",\"feeName\":\"FY26Q2灵活叠加激励\",\"gmtCreate\":1750902856680,\"gmtModified\":1750923626092,\"id\":227,\"lastModifier\":{\"userId\":\"67510\",\"userName\":\"壹念\",\"userType\":\"BUC\"},\"metaData\":{\"bizCode\":\"cainiao.express\",\"scenario\":\"macroPolicyAllowance\",\"isTemplate\":\"true\",\"tenantName\":\"驿站结算\",\"bizCodeDesc\":\"网点\",\"scenarioDesc\":\"网点大政策激励补贴\",\"priceExpression\":\"pricePerUnit * coefficient\",\"priceExpressionDesc\":\"单价(322) * 系数(369)\",\"rootNodeMatchingKey\":\"8702df802331f9474e8f2231202fe5c6\"},\"name\":\"FY26Q2灵活叠加激励-网点\",\"priceExpression\":{\"editableFiledList\":[{\"code\":\"coefficient\",\"editLimit\":[\"0\",\"0.8\",\"1\",\"1.4\"],\"editable\":true,\"editableLimitType\":\"ENUM\",\"name\":\"系数\"}],\"expression\":\" pricePerUnit * coefficient\",\"expressionDesc\":\" 单价(322) * 系数(369)\"},\"priority\":100,\"scenario\":\"macroPolicyAllowance\",\"scenarioDesc\":\"网点大政策激励补贴\",\"startTime\":1751299200000,\"status\":\"DRAFT\",\"tenantCode\":\"CNT_FINANCE\",\"tenantName\":\"驿站结算\",\"tree\":[{\"children\":[{\"code\":\"pricePerUnit\",\"editable\":false,\"name\":\"单价\",\"value\":\"1300\",\"valueType\":\"NUMBER\"}],\"code\":\"test_order_count\",\"editable\":false,\"name\":\"测试订单数:[1300,1400)\",\"value\":{\"empty\":false},\"valueType\":\"RANGE\"},{\"children\":[{\"code\":\"pricePerUnit\",\"editable\":false,\"name\":\"单价\",\"value\":\"1200\",\"valueType\":\"NUMBER\"}],\"code\":\"test_order_count\",\"editable\":false,\"name\":\"测试订单数:[1200,1300)\",\"value\":{\"empty\":false},\"valueType\":\"RANGE\"},{\"children\":[{\"code\":\"pricePerUnit\",\"editable\":false,\"name\":\"单价\",\"value\":\"1500\",\"valueType\":\"NUMBER\"}],\"code\":\"test_order_count\",\"editable\":false,\"name\":\"测试订单数:[1500,1600)\",\"value\":{\"empty\":false},\"valueType\":\"RANGE\"},{\"children\":[{\"code\":\"pricePerUnit\",\"editable\":false,\"name\":\"单价\",\"value\":\"1400\",\"valueType\":\"NUMBER\"}],\"code\":\"test_order_count\",\"editable\":false,\"name\":\"测试订单数:[1400,1500)\",\"value\":{\"empty\":false},\"valueType\":\"RANGE\"},{\"children\":[{\"code\":\"pricePerUnit\",\"editable\":false,\"name\":\"单价\",\"value\":\"200\",\"valueType\":\"NUMBER\"}],\"code\":\"test_order_count\",\"editable\":false,\"name\":\"测试订单数:[200,300)\",\"value\":{\"empty\":false},\"valueType\":\"RANGE\"},{\"children\":[{\"code\":\"pricePerUnit\",\"editable\":false,\"name\":\"单价\",\"value\":\"1700\",\"valueType\":\"NUMBER\"}],\"code\":\"test_order_count\",\"editable\":false,\"name\":\"测试订单数:[1700,1800)\",\"value\":{\"empty\":false},\"valueType\":\"RANGE\"},{\"children\":[{\"code\":\"pricePerUnit\",\"editable\":false,\"name\":\"单价\",\"value\":\"100\",\"valueType\":\"NUMBER\"}],\"code\":\"test_order_count\",\"editable\":false,\"name\":\"测试订单数:[100,200)\",\"value\":{\"empty\":false},\"valueType\":\"RANGE\"},{\"children\":[{\"code\":\"pricePerUnit\",\"editable\":false,\"name\":\"单价\",\"value\":\"1600\",\"valueType\":\"NUMBER\"}],\"code\":\"test_order_count\",\"editable\":false,\"name\":\"测试订单数:[1600,1700)\",\"value\":{\"empty\":false},\"valueType\":\"RANGE\"},{\"children\":[{\"code\":\"pricePerUnit\",\"editable\":false,\"name\":\"单价\",\"value\":\"1900\",\"valueType\":\"NUMBER\"}],\"code\":\"test_order_count\",\"editable\":false,\"name\":\"测试订单数:[1900,2000)\",\"value\":{\"empty\":false},\"valueType\":\"RANGE\"},{\"children\":[{\"code\":\"pricePerUnit\",\"editable\":false,\"name\":\"单价\",\"value\":\"1800\",\"valueType\":\"NUMBER\"}],\"code\":\"test_order_count\",\"editable\":false,\"name\":\"测试订单数:[1800,1900)\",\"value\":{\"empty\":false},\"valueType\":\"RANGE\"},{\"children\":[{\"code\":\"pricePerUnit\",\"editable\":false,\"name\":\"单价\",\"value\":\"2000\",\"valueType\":\"NUMBER\"}],\"code\":\"test_order_count\",\"editable\":false,\"name\":\"测试订单数:[2000,999999999]\",\"value\":{\"empty\":false},\"valueType\":\"RANGE\"},{\"children\":[{\"code\":\"pricePerUnit\",\"editable\":false,\"name\":\"单价\",\"value\":\"400\",\"valueType\":\"NUMBER\"}],\"code\":\"test_order_count\",\"editable\":false,\"name\":\"测试订单数:[400,500)\",\"value\":{\"empty\":false},\"valueType\":\"RANGE\"},{\"children\":[{\"code\":\"pricePerUnit\",\"editable\":false,\"name\":\"单价\",\"value\":\"300\",\"valueType\":\"NUMBER\"}],\"code\":\"test_order_count\",\"editable\":false,\"name\":\"测试订单数:[300,400)\",\"value\":{\"empty\":false},\"valueType\":\"RANGE\"},{\"children\":[{\"code\":\"pricePerUnit\",\"editable\":false,\"name\":\"单价\",\"value\":\"700\",\"valueType\":\"NUMBER\"}],\"code\":\"test_order_count\",\"editable\":false,\"name\":\"测试订单数:[700,800)\",\"value\":{\"empty\":false},\"valueType\":\"RANGE\"},{\"children\":[{\"code\":\"pricePerUnit\",\"editable\":false,\"name\":\"单价\",\"value\":\"600\",\"valueType\":\"NUMBER\"}],\"code\":\"test_order_count\",\"editable\":false,\"name\":\"测试订单数:[600,700)\",\"value\":{\"empty\":false},\"valueType\":\"RANGE\"},{\"children\":[{\"code\":\"pricePerUnit\",\"editable\":false,\"name\":\"单价\",\"value\":\"500\",\"valueType\":\"NUMBER\"}],\"code\":\"test_order_count\",\"editable\":false,\"name\":\"测试订单数:[500,600)\",\"value\":{\"empty\":false},\"valueType\":\"RANGE\"},{\"children\":[{\"code\":\"pricePerUnit\",\"editable\":false,\"name\":\"单价\",\"value\":\"900\",\"valueType\":\"NUMBER\"}],\"code\":\"test_order_count\",\"editable\":false,\"name\":\"测试订单数:[900,1000)\",\"value\":{\"empty\":false},\"valueType\":\"RANGE\"},{\"children\":[{\"code\":\"pricePerUnit\",\"editable\":false,\"name\":\"单价\",\"value\":\"800\",\"valueType\":\"NUMBER\"}],\"code\":\"test_order_count\",\"editable\":false,\"name\":\"测试订单数:[800,900)\",\"value\":{\"empty\":false},\"valueType\":\"RANGE\"},{\"children\":[{\"code\":\"pricePerUnit\",\"editable\":false,\"name\":\"单价\",\"value\":\"1100\",\"valueType\":\"NUMBER\"}],\"code\":\"test_order_count\",\"editable\":false,\"name\":\"测试订单数:[1100,1200)\",\"value\":{\"empty\":false},\"valueType\":\"RANGE\"},{\"children\":[{\"code\":\"pricePerUnit\",\"editable\":false,\"name\":\"单价\",\"value\":\"1000\",\"valueType\":\"NUMBER\"}],\"code\":\"test_order_count\",\"editable\":false,\"name\":\"测试订单数:[1000,1100)\",\"value\":{\"empty\":false},\"valueType\":\"RANGE\"}]}";
        QuotationTemplatePlanDTO treeStructure = JSONObject.parseObject(treeStructureStr, QuotationTemplatePlanDTO.class);

        when(policyConfigManager.getPlanConfigByPlanType(bizType, customType, incentivePlanType))
                .thenReturn(policyPlanConfig);
        when(policyPlanConfig.getExpenseItem(incentivePlanCode, startTimeStr, endTimeStr))
                .thenReturn(expenseItem);
        when(policyIncentiveTemplateConfig.getIncentivePlan(incentivePlanType, incentivePlanCode))
                .thenReturn(planContentDTO);
        when(expenseItem.getFromSettlement()).thenReturn(true);
        when(quotationTemplatePlanWrapper.getTreeStructure(incentivePlanCode, startTimeStr, endTimeStr))
                .thenReturn(treeStructure);

        // 验证方法返回
        try {
            IncentivePlanDTO result = policyIncentiveTemplateConfigManager.getIncentivePlanTemplate(bizType, customType, incentivePlanType, incentivePlanCode, startTimeStr, endTimeStr);
            assertNotNull(result);
        } catch (Exception e) {
        }
        // assert为演示用,运行时请根据具体逻辑修改
        // assertEquals("激励计划名称", result.getPlanName());
    }

    /**
     * 测试不读取结算的情况
     */
    @Test
    public void testGetIncentivePlanTemplateNoSettlement() {
        String bizType = "bizType";
        String customType = "customType";
        String incentivePlanType = "incentivePlanType";
        String incentivePlanCode = "incentivePlanCode";
        String startTimeStr = "2021-01-01";
        String endTimeStr = "2021-01-31";

        // 模拟调用返回值
        PolicyIncentivePlanConfigDTO policyPlanConfig = mock(PolicyIncentivePlanConfigDTO.class);
        PolicyIncentiveExpenseItemDTO expenseItem = mock(PolicyIncentiveExpenseItemDTO.class);
        IncentivePlanContentDTO planContentDTO = new IncentivePlanContentDTO();

        when(policyConfigManager.getPlanConfigByPlanType(bizType, customType, incentivePlanType))
                .thenReturn(policyPlanConfig);
        when(policyPlanConfig.getExpenseItem(incentivePlanCode, startTimeStr, endTimeStr))
                .thenReturn(expenseItem);
        when(expenseItem.getFromSettlement()).thenReturn(false); // 不读取结算
        when(policyIncentiveTemplateConfig.getIncentivePlan(incentivePlanType, incentivePlanCode))
                .thenReturn(planContentDTO);

        // 调用方法
        IncentivePlanDTO result = policyIncentiveTemplateConfigManager.getIncentivePlanTemplate(bizType, customType, incentivePlanType, incentivePlanCode, startTimeStr, endTimeStr);

        assertNotNull(result);
        // assert为演示用,运行时请根据具体逻辑修改
        // assertEquals(planContentDTO, result.getContent());
    }
}