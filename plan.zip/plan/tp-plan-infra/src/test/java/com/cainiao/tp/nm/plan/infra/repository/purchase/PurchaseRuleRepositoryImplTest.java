package com.cainiao.tp.nm.plan.infra.repository.purchase;

import com.cainiao.tp.nm.plan.infra.diamond.PurchaseRuleConfig;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseRule;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

/**
 * {@link PurchaseRuleRepositoryImpl} 单元测试
 *
 * <p>关键覆盖：
 * <ul>
 *   <li>getAllRules：正常列表（深拷贝校验）/ 空列表 / null</li>
 *   <li>getRulesByCategoryId：正常列表（深拷贝校验）/ 空列表 / null</li>
 * </ul>
 * </p> */
@RunWith(MockitoJUnitRunner.class)
public class PurchaseRuleRepositoryImplTest {

    @Mock
    private PurchaseRuleConfig purchaseRuleConfig;

    private PurchaseRuleRepositoryImpl repository;

    @Before
    public void setUp() {
        repository = new PurchaseRuleRepositoryImpl(purchaseRuleConfig);
    }

    /* ============================ getAllRules ============================ */

    @Test
    public void getAllRules_normal_shouldReturnDeepCopy() {
        PurchaseRule rule = new PurchaseRule();
        rule.setId(1L);
        rule.setCategoryId(100);
        when(purchaseRuleConfig.getAllRules()).thenReturn(Collections.singletonList(rule));

        List<PurchaseRule> result = repository.getAllRules();

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(Long.valueOf(1L), result.get(0).getId());
        // 深拷贝：底层引用与返回引用不应是同一对象
        assertNotSame(rule, result.get(0));
    }

    @Test
    public void getAllRules_emptyList_shouldReturnEmpty() {
        when(purchaseRuleConfig.getAllRules()).thenReturn(Collections.emptyList());

        List<PurchaseRule> result = repository.getAllRules();
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void getAllRules_null_shouldReturnEmpty() {
        when(purchaseRuleConfig.getAllRules()).thenReturn(null);

        List<PurchaseRule> result = repository.getAllRules();
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    /* ============================ getRulesByCategoryId ============================ */

    @Test
    public void getRulesByCategoryId_normal_shouldReturnDeepCopy() {
        PurchaseRule r1 = new PurchaseRule();
        r1.setId(1L);
        r1.setCategoryId(100);
        PurchaseRule r2 = new PurchaseRule();
        r2.setId(2L);
        r2.setCategoryId(100);
        when(purchaseRuleConfig.getRulesByCategoryId(100)).thenReturn(Arrays.asList(r1, r2));

        List<PurchaseRule> result = repository.getRulesByCategoryId(100);

        assertEquals(2, result.size());
        assertNotSame(r1, result.get(0));
    }

    @Test
    public void getRulesByCategoryId_empty_shouldReturnEmpty() {
        when(purchaseRuleConfig.getRulesByCategoryId(999)).thenReturn(Collections.emptyList());

        List<PurchaseRule> result = repository.getRulesByCategoryId(999);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void getRulesByCategoryId_null_shouldReturnEmpty() {
        when(purchaseRuleConfig.getRulesByCategoryId(null)).thenReturn(null);

        List<PurchaseRule> result = repository.getRulesByCategoryId(null);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }
}
