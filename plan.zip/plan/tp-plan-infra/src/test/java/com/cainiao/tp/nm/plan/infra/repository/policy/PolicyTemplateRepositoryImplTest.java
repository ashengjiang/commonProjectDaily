package com.cainiao.tp.nm.plan.infra.repository.policy;

import com.base.BaseTest;
import com.cainiao.sutee.commons.base.model.Page;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyTemplateQueryParam;
import com.cainiao.tp.nm.plan.api.policy.common.constants.IncentivePlanTypeEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyFeatureConstants;
import com.cainiao.tp.nm.plan.infra.mybatis.dto.PageResult;
import com.cainiao.tp.nm.plan.infra.repository.policy.convert.PolicyTemplateConvertor;
import com.cainiao.tp.nm.plan.infra.repository.policy.convert.PolicyTemplateDetailConvertor;
import com.cainiao.tp.nm.plan.infra.repository.policy.dto.data.PolicyRuleTemplateDO;
import com.cainiao.tp.nm.plan.infra.repository.policy.dto.data.PolicyTemplateDO;
import com.cainiao.tp.nm.plan.infra.repository.policy.dto.param.PolicyRuleTemplateQueryParam;
import com.cainiao.tp.nm.plan.infra.repository.policy.mapper.PolicyRuleTemplateMapper;
import com.cainiao.tp.nm.plan.infra.repository.policy.mapper.PolicyTemplateMapper;
import com.cainiao.tp.nm.plan.policy.domain.model.PolicyTemplate;
import com.cainiao.tp.nm.plan.policy.domain.model.valobj.incentiveplan.IncentivePlan;
import com.google.common.collect.Lists;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.*;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.*;

/**
 * <a href="https://alidocs.dingtalk.com/i/nodes/dpYLaezmVNRMGX56C1aKjlBOVrMqPxX6">单元测试编写&生成FAQ</a>
 * Created By Thub IDEA插件
 *
 * @Date 2025/6/9 15:58
 */
@RunWith(MockitoJUnitRunner.class)
public class PolicyTemplateRepositoryImplTest extends BaseTest {

    @InjectMocks
    private PolicyTemplateRepositoryImpl policyTemplateRepositoryImpl;
    @Mock
    private PolicyTemplateMapper policyTemplateMapper;
    @Mock
    private PolicyRuleTemplateMapper policyRuleTemplateMapper;
    @Mock
    private PolicyTemplateConvertor policyTemplateConvertor;
    @InjectMocks
    private PolicyTemplateRepositoryImpl policyTemplateRepository;
    @Mock
    private PolicyTemplateDetailConvertor detailConvertor;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testSelectPage() {
        List<PolicyTemplate> policyTemplateList = new ArrayList<>();
        PolicyTemplate policyTemplate1 = PolicyTemplate.builder().id(1L).build();
        PolicyTemplate policyTemplate2 = PolicyTemplate.builder().id(2L).build();
        policyTemplateList.add(policyTemplate1);
        policyTemplateList.add(policyTemplate2);
        Mockito.when(policyTemplateConvertor.doToModelList(any())).thenReturn(policyTemplateList);

        List<IncentivePlan> incentivePlanList = new ArrayList<>();
        IncentivePlan incentivePlan1 = new IncentivePlan();
        incentivePlan1.setIncentivePlanType(IncentivePlanTypeEnum.BASIC.getType());
        incentivePlanList.add(incentivePlan1);
        IncentivePlan incentivePlan2 = new IncentivePlan();
        incentivePlan2.setIncentivePlanType(IncentivePlanTypeEnum.FLEXIBLE.getType());
        incentivePlanList.add(incentivePlan2);
        Mockito.when(policyTemplateConvertor.toIncentivePlan(anyList())).thenReturn(incentivePlanList);

        com.cainiao.tp.nm.plan.infra.mybatis.dto.PageResult<PolicyTemplateDO> selectPage = new PageResult<>();
        PolicyTemplateDO policyTemplateDO1 = new PolicyTemplateDO();
        policyTemplateDO1.setId(1L);

        PolicyTemplateDO policyTemplateDO2 = new PolicyTemplateDO();
        policyTemplateDO2.setId(2L);
        selectPage.setPage(1);
        selectPage.setSize(20);
        selectPage.setTotal(2L);
        selectPage.setData(Arrays.asList(policyTemplateDO1, policyTemplateDO2));

        Mockito.when(policyTemplateMapper.selectPage(any())).thenReturn(selectPage);
        List<PolicyRuleTemplateDO> policyRuleTemplateList = new ArrayList<>();
        PolicyRuleTemplateDO policyRuleTemplateDO1 = new PolicyRuleTemplateDO();
        policyRuleTemplateDO1.setTemplateId(1L);
        policyRuleTemplateDO1.setIncentivePlanType(IncentivePlanTypeEnum.BASIC.getType());
        policyRuleTemplateList.add(policyRuleTemplateDO1);
        PolicyRuleTemplateDO policyRuleTemplateDO2 = new PolicyRuleTemplateDO();
        policyRuleTemplateDO2.setTemplateId(2L);
        policyRuleTemplateDO1.setIncentivePlanType(IncentivePlanTypeEnum.FLEXIBLE.getType());
        policyRuleTemplateList.add(policyRuleTemplateDO2);
        Mockito.when(policyRuleTemplateMapper.selectAll(any())).thenReturn(policyRuleTemplateList);

        // Prepare method arguments
        PolicyTemplateQueryParam queryParam = new PolicyTemplateQueryParam();

        // Run the method to be tested
        Page<PolicyTemplate> result = policyTemplateRepositoryImpl.selectPage(queryParam);

        // Verify the result
        assert result != null;
        assert result.getPageItems() != null;
        assert result.getPageItems().size() == 2;

        Map<String, Boolean> orderFieldNameMap = new HashMap<>();
        orderFieldNameMap.put("gmt_create", true);
        queryParam.setOrderFieldNameMap(orderFieldNameMap);
        queryParam.setDurationStatus("1");
        result = policyTemplateRepositoryImpl.selectPage(queryParam);

        assert result != null;
        assert result.getPageItems() != null;
        assert result.getPageItems().size() == 2;
    }

    /**
     * 测试当模板ID存在时，能正确获取PolicyTemplate对象
     */
    @Test
    public void testGetExistingTemplate() {
        Long templateId = 1L;

        // 设置模拟的返回值
        PolicyTemplateDO policyTemplateDO = new PolicyTemplateDO(); // mock你的PolicyTemplateDO
        when(policyTemplateMapper.selectById(templateId)).thenReturn(policyTemplateDO);

        List<PolicyRuleTemplateDO> ruleTemplateDOS = Collections.emptyList(); // 模拟没有规则模板
        when(policyRuleTemplateMapper.selectAll(any(PolicyRuleTemplateQueryParam.class))).thenReturn(ruleTemplateDOS);

        // 使用构建器创建PolicyTemplate对象
        PolicyTemplate policyTemplate = PolicyTemplate.builder().build();
        when(policyTemplateConvertor.doToModel(policyTemplateDO)).thenReturn(policyTemplate);
        when(policyTemplateConvertor.toIncentivePlan(ruleTemplateDOS)).thenReturn(Collections.emptyList());

        // 调用方法
        PolicyTemplate result = policyTemplateRepository.get(templateId);

        // 断言
        assertEquals(policyTemplate, result);
        verify(policyTemplateMapper).selectById(templateId);
        verify(policyRuleTemplateMapper).selectAll(any(PolicyRuleTemplateQueryParam.class));
    }

    /**
     * 测试当模板ID不存在时，返回null
     */
    @Test
    public void testGetNonExistingTemplate() {
        Long templateId = 2L;

        // 设置模拟的返回值为null，表示找不到模板
        when(policyTemplateMapper.selectById(templateId)).thenReturn(null);

        // 调用方法
        PolicyTemplate result = policyTemplateRepository.get(templateId);

        // 断言返回值为null
        assertEquals(null, result);
        verify(policyTemplateMapper).selectById(templateId);
    }

    /**
     * 测试当获取模板ID存在但无规则模板，返回PolicyTemplate
     */
    @Test
    public void testGetTemplateWithNoRuleTemplates() {
        Long templateId = 3L;

        // 模拟返回的PolicyTemplateDO
        PolicyTemplateDO policyTemplateDO = new PolicyTemplateDO(); // mock你的PolicyTemplateDO
        when(policyTemplateMapper.selectById(templateId)).thenReturn(policyTemplateDO);

        // 模拟获取到的规则模板为空
        when(policyRuleTemplateMapper.selectAll(any(PolicyRuleTemplateQueryParam.class))).thenReturn(Collections.emptyList());

        // 使用构建器创建PolicyTemplate对象
        PolicyTemplate policyTemplate = PolicyTemplate.builder().build();
        when(policyTemplateConvertor.doToModel(policyTemplateDO)).thenReturn(policyTemplate);
        when(policyTemplateConvertor.toIncentivePlan(Collections.emptyList())).thenReturn(Collections.emptyList());

        // 进行方法调用
        PolicyTemplate result = policyTemplateRepository.get(templateId);

        // 断言
        assertEquals(policyTemplate, result);
        verify(policyTemplateMapper).selectById(templateId);
        verify(policyRuleTemplateMapper).selectAll(any(PolicyRuleTemplateQueryParam.class));
    }

    /**
     * 测试get方法，查询规则模板返回不为空时，应该正确填充PolicyTemplate的激励计划列表。
     */
    @Test
    public void testGetWithRuleTemplateDOs() {
        PolicyTemplateDO policyTemplateDO = new PolicyTemplateDO();
        policyTemplateDO.setId(1L);

        List<PolicyTemplateDO> policyTemplateDOS = new ArrayList<>();
        policyTemplateDOS.add(policyTemplateDO);

        PolicyRuleTemplateDO ruleTemplateDO = new PolicyRuleTemplateDO();
        ruleTemplateDO.setTemplateId(1L); // 设置模板ID

        List<PolicyRuleTemplateDO> ruleTemplateDOS = new ArrayList<>();
        ruleTemplateDOS.add(ruleTemplateDO);

        when(policyTemplateMapper.selectAll(any())).thenReturn(policyTemplateDOS);
        when(policyRuleTemplateMapper.selectAll(any(PolicyRuleTemplateQueryParam.class))).thenReturn(ruleTemplateDOS);
        when(policyTemplateConvertor.doToModel(any(PolicyTemplateDO.class))).thenReturn(PolicyTemplate.builder().build());
        when(policyTemplateConvertor.toIncentivePlan(any(List.class))).thenReturn(new ArrayList<>());

        List<PolicyTemplate> result = policyTemplateRepository.get("bizType", "customType");

        assertNotNull(result);
        assertEquals(1, result.size()); // 返回一个元素
        // assertFalse(result.get(0).getIncentivePlanList().isEmpty()); // 确保激励计划列表不为空
        verify(policyRuleTemplateMapper).selectAll(any(PolicyRuleTemplateQueryParam.class));
    }

    /**
     * 测试创建政策模板时，featureMap 中有 approvalFollowId 的情况
     * 验证 insert 和 batchInsert 方法被调用
     */
    @Test
    public void testCreateWithApprovalFollowId() {
        // 创建测试 PolicyTemplate 对象
        Map<String, String> featureMap = new HashMap<>();
        featureMap.put(PolicyFeatureConstants.APPROVAL_FOLLOW_ID, "123");

        PolicyTemplate policyTemplate = PolicyTemplate.builder()
                .templateName("Test Template")
                .featureMap(featureMap)
                .build();

        PolicyTemplateDO policyTemplateDO = new PolicyTemplateDO();
        policyTemplateDO.setId(1L);

        // 模拟转换器返回值
        when(policyTemplateConvertor.doToModel(policyTemplate)).thenReturn(policyTemplateDO);
        when(policyTemplateConvertor.toPolicyRuleTemplateDO(policyTemplate, policyTemplateDO.getId()))
                .thenReturn(Lists.newArrayList(new PolicyRuleTemplateDO())); // 返回一个空的规则模板列表

        // 模拟对政策模板的插入操作
        doNothing().when(policyTemplateMapper).insert(policyTemplateDO);
        doNothing().when(policyRuleTemplateMapper).batchInsert(Lists.newArrayList(new PolicyRuleTemplateDO()));

        // 执行创建方法
        Long result = policyTemplateRepository.create(policyTemplate);

        // 验证结果和方法调用
        // 验证插入方法被调用
        verify(policyTemplateMapper).insert(policyTemplateDO);
        verify(policyRuleTemplateMapper).batchInsert(Lists.newArrayList(new PolicyRuleTemplateDO()));

        // 验证返回的 ID 是否正确
        assert (result.equals(1L)); // 预期返回的 ID 是 1L
    }

    /**
     * 测试创建政策模板时，featureMap 中没有 approvalFollowId 的情况
     * 验证 insert 和 batchInsert 方法被调用
     */
    @Test
    public void testCreateWithoutApprovalFollowId() {
        // 创建测试 PolicyTemplate 对象
        PolicyTemplate policyTemplate = PolicyTemplate.builder()
                .templateName("Test Template")
                .featureMap(new HashMap<>()) // 空的 featureMap 没有 approvalFollowId
                .build();

        PolicyTemplateDO policyTemplateDO = new PolicyTemplateDO();
        policyTemplateDO.setId(2L);

        // 模拟转换器返回值
        when(policyTemplateConvertor.doToModel(policyTemplate)).thenReturn(policyTemplateDO);
        when(policyTemplateConvertor.toPolicyRuleTemplateDO(policyTemplate, policyTemplateDO.getId()))
                .thenReturn(Lists.newArrayList(new PolicyRuleTemplateDO())); // 返回一个空的规则模板列表

        // 模拟对政策模板的插入操作
        doNothing().when(policyTemplateMapper).insert(policyTemplateDO);
        doNothing().when(policyRuleTemplateMapper).batchInsert(Lists.newArrayList(new PolicyRuleTemplateDO()));

        // 执行创建方法
        Long result = policyTemplateRepository.create(policyTemplate);

        // 验证结果和方法调用
        // 验证插入方法被调用
        verify(policyTemplateMapper).insert(policyTemplateDO);
        verify(policyRuleTemplateMapper).batchInsert(Lists.newArrayList(new PolicyRuleTemplateDO()));

        // 验证返回的 ID 是否正确
        assert (result.equals(2L)); // 预期返回的 ID 是 2L
    }

    /**
     * 测试创建政策模板时，插入过程抛出异常的情况
     * 验证异常处理逻辑
     */
    @Test(timeout = 5000) // 设置超时，避免死循环
    public void testCreateInsertThrowsException() {
        // 创建测试 PolicyTemplate 对象
        PolicyTemplate policyTemplate = PolicyTemplate.builder()
                .templateName("Test Template")
                .featureMap(new HashMap<>()) // 空的 featureMap 没有 approvalFollowId
                .build();

        PolicyTemplateDO policyTemplateDO = new PolicyTemplateDO();
        policyTemplateDO.setId(3L);

        // 模拟转换器返回值
        when(policyTemplateConvertor.doToModel(policyTemplate)).thenReturn(policyTemplateDO);
//        when(policyTemplateConvertor.toPolicyRuleTemplateDO(policyTemplate, policyTemplateDO.getId()))
//                .thenReturn(Lists.newArrayList(new PolicyRuleTemplateDO())); // 返回一个空的规则模板列表

        // 模拟对政策模板的插入操作抛出异常
        doThrow(new RuntimeException("插入失败")).when(policyTemplateMapper).insert(policyTemplateDO);

        try {
            policyTemplateRepository.create(policyTemplate);
        } catch (Exception e) {
            // 期望抛出异常，验证异常信息
            assert (e.getMessage().equals("插入失败"));
        }

        // 验证插入方法被调用
        verify(policyTemplateMapper).insert(policyTemplateDO);
        // verify(policyRuleTemplateMapper).batchInsert(anyList()); // 此时不应该调用该方法
    }

    /**
     * 测试创建政策模板时，批量插入过程抛出异常的情况
     * 验证异常处理逻辑
     */
    @Test(timeout = 5000) // 设置超时，避免死循环
    public void testCreateBatchInsertThrowsException() {
        // 创建测试 PolicyTemplate 对象
        Map<String, String> featureMap = new HashMap<>();
        featureMap.put(PolicyFeatureConstants.APPROVAL_FOLLOW_ID, "456");

        PolicyTemplate policyTemplate = PolicyTemplate.builder()
                .templateName("Test Template")
                .featureMap(featureMap)
                .build();

        PolicyTemplateDO policyTemplateDO = new PolicyTemplateDO();
        policyTemplateDO.setId(4L);

        // 模拟转换器返回值
        when(policyTemplateConvertor.doToModel(policyTemplate)).thenReturn(policyTemplateDO);
        when(policyTemplateConvertor.toPolicyRuleTemplateDO(policyTemplate, policyTemplateDO.getId()))
                .thenReturn(Lists.newArrayList(new PolicyRuleTemplateDO())); // 返回一个空的规则模板列表

        // 模拟对政策模板的插入操作
        doNothing().when(policyTemplateMapper).insert(policyTemplateDO);
//        doNothing().when(policyRuleTemplateMapper).batchInsert(Lists.newArrayList(new PolicyRuleTemplateDO()));

        // 模拟批量插入接口抛出异常
        doThrow(new RuntimeException("批量插入失败")).when(policyRuleTemplateMapper).batchInsert(anyList());

        try {
            policyTemplateRepository.create(policyTemplate);
        } catch (Exception e) {
            // 期望抛出异常，验证异常信息
            assert (e.getMessage().equals("批量插入失败"));
        }

        // 验证插入方法被调用
        verify(policyTemplateMapper).insert(policyTemplateDO);
        // verify(policyRuleTemplateMapper).batchInsert(anyList()); // 此时不应该调用该方法
    }

    /**
     * 测试正常删除PolicyTemplate流程
     * 验证update、deleteById、batchDeleteByIds方法是否被调用
     */
    @Test
    public void testDeleteSuccessfully() {
        // 构造测试数据
        PolicyTemplate policyTemplate = PolicyTemplate.builder().id(1L).build();
        PolicyTemplateDO policyTemplateDO = new PolicyTemplateDO();
        policyTemplateDO.setId(1L);

        // Mock行为
        when(policyTemplateConvertor.doToModel(policyTemplate)).thenReturn(policyTemplateDO);
        when(policyTemplateMapper.update(policyTemplateDO)).thenReturn(1);  // 1表示成功更新的记录数
        when(policyTemplateMapper.deleteById(policyTemplateDO.getId())).thenReturn(1);  // 1表示成功删除的记录数

        PolicyRuleTemplateQueryParam ruleParam = new PolicyRuleTemplateQueryParam();
        ruleParam.setTemplateId(policyTemplate.getId());
        when(policyRuleTemplateMapper.selectAll(ruleParam)).thenReturn(Lists.newArrayList(new PolicyRuleTemplateDO())); // 返回空表示没有规则模板

        // 调用方法
        policyTemplateRepository.delete(policyTemplate);

        // 验证各个方法是否被正确调用
        verify(policyTemplateMapper).update(policyTemplateDO);
        verify(policyTemplateMapper).deleteById(policyTemplateDO.getId());
        verify(policyRuleTemplateMapper).selectAll(ruleParam);
        // verify(policyRuleTemplateMapper).batchDeleteByIds(Mockito.anyList()); // 此时无规则模板，故不应调用本方法
    }
}