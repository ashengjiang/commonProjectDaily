package com.cainiao.tp.nm.plan.infra.wrapper.finance;

import com.cainiao.aladdin.reslut.Result;
import com.cainiao.terminal.finance.payment.client.facade.PaymentSignFacade;
import com.cainiao.terminal.finance.payment.client.vo.request.SignRecordQueryReq;
import com.cainiao.terminal.finance.payment.client.vo.response.SignRecordVo;
import com.cainiao.tp.nm.plan.infra.port.common.exception.ServiceException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

/**
 * {@link PaymentSignManagerImpl} 单元测试 */
@RunWith(MockitoJUnitRunner.class)
public class PaymentSignManagerImplTest {

    @InjectMocks
    private PaymentSignManagerImpl manager;

    @Mock
    private PaymentSignFacade paymentSignFacade;

    @Test
    public void isSigned_nullUserId_shouldReturnFalse() {
        assertFalse(manager.isSigned(null));
    }

    @Test
    public void isSigned_resultNull_shouldReturnFalse() {
        when(paymentSignFacade.querySignRecord(any(SignRecordQueryReq.class))).thenReturn(null);
        assertFalse(manager.isSigned(1L));
    }

    @Test
    public void isSigned_resultFail_shouldReturnFalse() {
        Result<SignRecordVo> r = new Result<>();
        r.setSuccess(false);
        when(paymentSignFacade.querySignRecord(any(SignRecordQueryReq.class))).thenReturn(r);
        assertFalse(manager.isSigned(1L));
    }

    @Test
    public void isSigned_dataNull_shouldReturnFalse() {
        Result<SignRecordVo> r = new Result<>();
        r.setSuccess(true);
        r.setData(null);
        when(paymentSignFacade.querySignRecord(any(SignRecordQueryReq.class))).thenReturn(r);
        assertFalse(manager.isSigned(1L));
    }

    @Test
    public void isSigned_signSuccess_true_shouldReturnTrue() {
        SignRecordVo vo = new SignRecordVo();
        vo.setSignSuccess(true);
        Result<SignRecordVo> r = new Result<>();
        r.setSuccess(true);
        r.setData(vo);
        when(paymentSignFacade.querySignRecord(any(SignRecordQueryReq.class))).thenReturn(r);
        assertTrue(manager.isSigned(1L));
    }

    @Test
    public void isSigned_signSuccess_false_shouldReturnFalse() {
        SignRecordVo vo = new SignRecordVo();
        vo.setSignSuccess(false);
        Result<SignRecordVo> r = new Result<>();
        r.setSuccess(true);
        r.setData(vo);
        when(paymentSignFacade.querySignRecord(any(SignRecordQueryReq.class))).thenReturn(r);
        assertFalse(manager.isSigned(1L));
    }

    @Test
    public void isSigned_throw_shouldWrapAsServiceException() {
        when(paymentSignFacade.querySignRecord(any(SignRecordQueryReq.class)))
                .thenThrow(new RuntimeException("boom"));
        try {
            manager.isSigned(1L);
            fail("expected ServiceException");
        } catch (ServiceException e) {
            assertEquals("代扣协议签署查询异常", e.getMessage());
        }
    }
}
