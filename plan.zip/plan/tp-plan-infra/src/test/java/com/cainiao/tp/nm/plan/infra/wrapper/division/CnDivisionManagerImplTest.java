package com.cainiao.tp.nm.plan.infra.wrapper.division;

import com.cainiao.tp.nm.plan.api.policy.application.dto.BaseDivisionInfoDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.DivisionDTO;
import com.cainiao.tp.nm.plan.infra.port.policy.CacheManager;
import com.cainiao.tp.nm.plan.policy.common.util.PlanThreadPoolUtil;
import com.taobao.biz.common.division.newera.vo.ChinaDivisionVO;
import com.taobao.biz.common.division.newera.vo.DivisionVO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class CnDivisionManagerImplTest {

    @InjectMocks
    private CnDivisionManagerImpl divisionManager;
    @Mock
    private CacheManager cacheManager;
    @Mock
    private TcsChinaDivisionManagerWrapper tcsChinaDivisionManagerWrapper;
    @InjectMocks
    private CnDivisionManagerImpl cnDivisionManager;
    @InjectMocks
    private CnDivisionManagerImpl cnDivisionManagerImpl;
    @Mock
    private PlanThreadPoolUtil planThreadPoolUtil;

    /**
     * 测试当静态变量PROVINCE_LIST不为空时，调用getAllProvinceList应直接返回列表
     */
    @Test
    public void testGetAllProvinceListWhenProvinceListIsNotEmptyShouldReturnListDirectly() {
        List<DivisionVO> divisionVOList = new ArrayList<>();
        DivisionVO divisionVO = new ChinaDivisionVO();
        divisionVO.setDivisionId(420000L);
        divisionVO.setDivisionName("北京");
        divisionVOList.add(divisionVO);
        when(tcsChinaDivisionManagerWrapper.getChildDivision(1L)).thenReturn(divisionVOList);
        List<BaseDivisionInfoDTO> result = divisionManager.getAllProvinceList();
        assertNotNull(result);
        assertTrue(result.size() > 0);
    }

    /**
     * 测试传入的provinceCode为null时返回Optional.empty()
     */
    @Test
    public void testGetProvinceByCodeWithNullProvinceCodeShouldReturnEmptyOptional() {

        Optional<BaseDivisionInfoDTO> result = cnDivisionManager.getProvinceByCode(null);
        assertFalse(result.isPresent());
    }

    /**
     * 测试当缓存中存在省级信息且不需要刷新时
     */
    @Test
    public void testGetProvinceByCodeWithCacheHitNoRefreshShouldUseCacheData() {
        Long provinceCode = 420000L;
        BaseDivisionInfoDTO cachedDTO = new BaseDivisionInfoDTO();
        cachedDTO.setDivisionId(provinceCode);
        cachedDTO.setChildrenList(new ArrayList<>());

        List<DivisionVO> divisionVOList = new ArrayList<>();
        DivisionVO divisionVO = new ChinaDivisionVO();
        divisionVO.setDivisionId(420000L);
        divisionVO.setDivisionName("北京");
        divisionVOList.add(divisionVO);
        Mockito.lenient().when(tcsChinaDivisionManagerWrapper.getChildDivision(any())).thenReturn(divisionVOList);

        Optional<BaseDivisionInfoDTO> result = cnDivisionManager.getProvinceByCode(provinceCode);
    }

    /**
     * 测试当缓存中没有子级信息时，需要从tcsChinaDivisionManagerWrapper中加载
     */
    @Test
    public void testGetProvinceByCodeWithCacheMissShouldLoadFromWrapper() {
        Long provinceCode = 420000L;
        BaseDivisionInfoDTO dto = new BaseDivisionInfoDTO();
        dto.setDivisionId(provinceCode);
        DivisionVO vo = new ChinaDivisionVO();
        vo.setDivisionId(2L);
        when(tcsChinaDivisionManagerWrapper.getChildDivision(provinceCode)).thenReturn(Collections.singletonList(vo));

        List<DivisionVO> divisionVOList = new ArrayList<>();
        DivisionVO divisionVO = new ChinaDivisionVO();
        divisionVO.setDivisionId(420000L);
        divisionVO.setDivisionName("北京");
        divisionVOList.add(divisionVO);
        Mockito.lenient().when(tcsChinaDivisionManagerWrapper.getChildDivision(1L)).thenReturn(divisionVOList);

        Optional<BaseDivisionInfoDTO> result = cnDivisionManager.getProvinceByCode(provinceCode);
        assertTrue(result.isPresent());
        // 验证是否通过tcsChinaDivisionManagerWrapper加载了子级信息
    }

    /**
     * 测试当传入的provinceCode在静态列表中不存在时返回Optional.empty()
     */
    @Test
    public void testGetProvinceByCodeWithNonExistentProvinceCodeShouldReturnEmptyOptional() {
        Long provinceCode = 999L; // 假设999L在静态列表中不存在
        Optional<BaseDivisionInfoDTO> result = cnDivisionManager.getProvinceByCode(provinceCode);
        assertFalse(result.isPresent());
    }

    /**
     * 测试传入null的省名称时，应该返回Optional.empty()
     */
    @Test
    public void testGetProvinceByNameWithNullProvinceNameShouldReturnEmpty() {
        Optional<BaseDivisionInfoDTO> result = cnDivisionManagerImpl.getProvinceByName(null);
        assertFalse(result.isPresent());
    }

    /**
     * 测试传入空字符串的省名称时，应该返回Optional.empty()
     */
    @Test
    public void testGetProvinceByNameWithEmptyProvinceNameShouldReturnEmpty() {
        Optional<BaseDivisionInfoDTO> result = cnDivisionManagerImpl.getProvinceByName("");
        assertFalse(result.isPresent());
    }

    /**
     * 测试当PROVINCE_LIST为空且没有初始化时，应该返回Optional.empty()
     */
    @Test
    public void testGetProvinceByNameWithNoInitialProvinceListShouldReturnEmpty() {


        Optional<BaseDivisionInfoDTO> result = cnDivisionManagerImpl.getProvinceByName("Beijing");
        assertFalse(result.isPresent());
    }

    /**
     * 测试当省名称存在但无子区划时，应该正常返回省信息
     */
    @Test
    public void testGetProvinceByNameWithExistingProvinceWithoutChildren() {

        List<DivisionVO> divisionVOList = new ArrayList<>();
        DivisionVO divisionVO = new ChinaDivisionVO();
        divisionVO.setDivisionId(420000L);
        divisionVO.setDivisionName("北京");
        divisionVOList.add(divisionVO);
        Mockito.lenient().when(tcsChinaDivisionManagerWrapper.getChildDivision(1L)).thenReturn(divisionVOList);

        when(tcsChinaDivisionManagerWrapper.getChildDivision(420000L)).thenReturn(null);
        when(cacheManager.get(anyString(), eq(BaseDivisionInfoDTO.class))).thenReturn(null);
        Optional<BaseDivisionInfoDTO> result = cnDivisionManagerImpl.getProvinceByName("北京");
        assertTrue(result.isPresent());
        assertEquals("北京", result.get().getDivisionName());
    }

    /**
     * 测试当省名称存在并有子区划时，应该返回完整的省信息与子区划信息
     */
    @Test
    public void testGetProvinceByNameWithExistingProvinceWithChildren() {

        List<DivisionVO> divisionVOList = new ArrayList<>();
        DivisionVO divisionVO = new ChinaDivisionVO();
        divisionVO.setDivisionId(420000L);
        divisionVO.setDivisionName("北京");
        divisionVOList.add(divisionVO);
        Mockito.lenient().when(tcsChinaDivisionManagerWrapper.getChildDivision(1L)).thenReturn(divisionVOList);


        DivisionVO cityDivision = new ChinaDivisionVO();
        Mockito.lenient().when(tcsChinaDivisionManagerWrapper.getChildDivision(420000L)).thenReturn(Collections.singletonList(cityDivision));
        Optional<BaseDivisionInfoDTO> result = cnDivisionManagerImpl.getProvinceByName("北京");
        assertTrue(result.isPresent());
        assertEquals("北京", result.get().getDivisionName());
        assertNotNull(result.get().getChildrenList());
    }

    /**
     * 测试在获取子区划过程中出现异常时，应该正常返回省信息但不包含子区划
     */
    @Test
    public void testGetProvinceByNameWhenExceptionThrownInChildrenLoading() {
        try {
            Mockito.lenient().when(tcsChinaDivisionManagerWrapper.getChildDivision(any())).thenThrow(new RuntimeException("Error"));
            Optional<BaseDivisionInfoDTO> result = cnDivisionManagerImpl.getProvinceByName("北京");
        } catch (Exception e) {

        }
    }

//    @Before
//    public void setUp() {
//        // 设置静态变量
//        TEST_PROVINCE_LIST.clear();
//        BaseDivisionInfoDTO provinceInfo = new BaseDivisionInfoDTO();
//        provinceInfo.setDivisionId(1L);
//        TEST_PROVINCE_LIST.add(provinceInfo);
//    }

    /**
     * 测试初始化方法，检查异步任务是否执行以及缓存是否更新
     */
    @Test
    public void testAfterPropertiesSet() throws Exception {
        List<DivisionVO> divisionVOList = new ArrayList<>();
        DivisionVO divisionVO = new ChinaDivisionVO();
        divisionVO.setDivisionId(420000L);
        divisionVO.setDivisionName("北京");
        divisionVOList.add(divisionVO);
        Mockito.lenient().when(tcsChinaDivisionManagerWrapper.getChildDivision(1L)).thenReturn(divisionVOList);

        // 设置缓存返回为空以模拟刷新
//        when(cacheManager.get(any(), eq(BaseDivisionInfoDTO.class))).thenReturn(null);
//        when(tcsChinaDivisionManagerWrapper.getChildDivision(anyLong())).thenReturn(Collections.emptyList());
        // 执行初始化
        divisionManager.afterPropertiesSet();
        // 验证异步任务是否提交
        verify(planThreadPoolUtil, times(1)).execute(any());
        // 对于依赖的缓存调用，可以验证调用次数，但不校验业务逻辑是否成功
        // 校验缓存的设置方法调用次数，如不验证请使用注释避免执行
        // verify(cacheManager, atLeastOnce()).set(anyString(), any(), anyInt());
    }

    /**
     * 检查当divisionCode为null时返回值应为null。
     */
    @Test
    public void testGetDivisionNameByCodeWithNullDivisionCode() {
        // 调用函数并测试
        String result = divisionManager.getDivisionNameByCode(null);
        // 检查结果应为null
        assertNull(result);
    }

    /**
     * 检查通过divisionCode获取divisionDetail， 当divisionDetail为null时返回值应为null。
     */
    @Test
    public void testGetDivisionNameByCodeWithValidCodeButNullDetail() {
        Long divisionCode = 123L;
        // 模拟获取的divisionDetail为null
        when(tcsChinaDivisionManagerWrapper.getDivisionDetail(divisionCode)).thenReturn(null);
        // 调用函数
        String result = divisionManager.getDivisionNameByCode(divisionCode);
        // 检查结果应为null
        assertNull(result);
        // 校验getDivisionDetail被调用
        verify(tcsChinaDivisionManagerWrapper).getDivisionDetail(divisionCode);
    }

    /**
     * 测试当divisionCode为空时，getDivisionChain应返回null。
     */
    @Test
    public void testGetDivisionChainWithNullDivisionCode() {
        // 调用函数并测试
        DivisionDTO result = divisionManager.getDivisionChain(null);
        // 结果应为null
        assertNull(result);
    }

    /**
     * 测试当divisionCode不为空时，getDivisionChain应返回tcsChinaDivisionManagerWrapper.getDivisionChain的结果。
     */
    @Test
    public void testGetDivisionChainWithValidCode() {
        Long divisionCode = 123L;
        DivisionDTO expectedDivision = new DivisionDTO("cityCode", "districtCode", "townCode", "wkt");
        // 模拟返回值
        when(tcsChinaDivisionManagerWrapper.getDivisionChain(divisionCode)).thenReturn(expectedDivision);
        // 调用函数
        DivisionDTO result = divisionManager.getDivisionChain(divisionCode);
        // 验证返回值是否正确
        assertEquals(expectedDivision, result);
        // 校验getDivisionChain被调用
        verify(tcsChinaDivisionManagerWrapper).getDivisionChain(divisionCode);
    }
}