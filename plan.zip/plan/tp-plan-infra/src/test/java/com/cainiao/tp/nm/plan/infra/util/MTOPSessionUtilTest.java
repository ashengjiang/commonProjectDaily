package com.cainiao.tp.nm.plan.infra.util;

import com.alibaba.cainiao.stationplatform.client.domain.StationAuthUserDTO;
import com.alibaba.cainiao.stationplatform.client.domain.StationResultDTO;
import com.alibaba.cainiao.stationplatform.client.service.client.StationAuthUserReadServiceClient;
import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.cnmember.client.session.CnSessionWirelessReadClient;
import com.cainiao.tp.nm.plan.infra.common.constants.CommonConstants;
import com.google.common.collect.Lists;
import com.taobao.mtop.api.agent.MtopContext;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MTOPSessionUtilTest {

    @Test(expected = AladdinBizException.class)
    public void testGetStationAuthUserDTO() {
        try (MockedStatic<MtopContext> contextMockedStatic = Mockito.mockStatic(MtopContext.class)) {
            Map<String, Object> sessionAttributes = new HashMap<>();
            sessionAttributes.put("cnAccountId", 1234L);
            sessionAttributes.put("employeeId", 1234L);
            contextMockedStatic.when(MtopContext::getSessionAttributes).thenReturn(sessionAttributes);
            contextMockedStatic.when(MtopContext::getUserId).thenReturn(123L);

            StationResultDTO<List<StationAuthUserDTO>> stationAuthUserListDTO = new StationResultDTO<>();
            stationAuthUserListDTO.setSuccess(true);
            stationAuthUserListDTO.setData(Lists.newArrayList(new StationAuthUserDTO()));
//            Mockito.when(client.queryAuthUserByCnUserAccountId(anyLong(),any())).thenReturn(stationAuthUserListDTO);
            StationAuthUserDTO userDTO = MTOPSessionUtil.getStationAuthUserDTO(new StationAuthUserReadServiceClient(),new CnSessionWirelessReadClient(), CommonConstants.CLIENT_INFO);
            Assert.assertNotNull(userDTO);
        }

    }

    @Test(expected = AladdinBizException.class)
    public void testGetStationAuthUserDTONullEmployeeId() {
        try (MockedStatic<MtopContext> contextMockedStatic = Mockito.mockStatic(MtopContext.class)) {
            Map<String, Object> sessionAttributes = new HashMap<>();
            sessionAttributes.put("cnAccountId", 1234L);
            contextMockedStatic.when(MtopContext::getSessionAttributes).thenReturn(sessionAttributes);
            contextMockedStatic.when(MtopContext::getUserId).thenReturn(123L);
            StationResultDTO<List<StationAuthUserDTO>> stationAuthUserListDTO = new StationResultDTO<>();
            stationAuthUserListDTO.setSuccess(true);
            stationAuthUserListDTO.setData(Lists.newArrayList(new StationAuthUserDTO()));
//            Mockito.when(client.queryAuthUserByCnUserAccountId(anyLong(),any())).thenReturn(stationAuthUserListDTO);
            StationAuthUserDTO userDTO = MTOPSessionUtil.getStationAuthUserDTO(new StationAuthUserReadServiceClient(),new CnSessionWirelessReadClient(), CommonConstants.CLIENT_INFO);
            Assert.assertNotNull(userDTO);
        }

    }

}