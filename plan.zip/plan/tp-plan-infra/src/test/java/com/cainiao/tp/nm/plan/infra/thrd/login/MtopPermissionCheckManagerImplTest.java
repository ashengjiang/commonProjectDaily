package com.cainiao.tp.nm.plan.infra.thrd.login;

import com.cainiao.tp.nm.plan.api.policy.common.constants.RequestSourceEnum;
import com.cainiao.tp.nm.plan.infra.port.common.constants.LoginEntityTypeEnum;
import com.cainiao.tp.nm.plan.infra.port.dto.context.BasePermissionContext;
import com.cainiao.tp.nm.plan.infra.port.dto.context.ExpressPermissionContext;
import com.cainiao.tp.nm.plan.infra.port.dto.context.PermissionContext;
import com.cainiao.tp.nm.plan.infra.port.dto.context.StationPermissionContext;
import com.cainiao.tp.nm.plan.infra.port.policy.StationPermissionCheckManager;
import com.cainiao.tp.nm.plan.infra.thrd.express.ExpressPermissionCheckHandler;
import com.taobao.mtop.api.agent.MtopContext;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

/**
 * {@link MtopPermissionCheckManagerImpl} 单元测试
 *
 * <p>覆盖：
 * <ul>
 *   <li>isExpress：appKey 命中 / 不命中 / 为 null</li>
 *   <li>loginPermission：网点端走 ExpressPermissionCheckHandler 分支</li>
 *   <li>loginPermission：站点端走 StationPermissionCheckManager 分支，source=STATION_OWNER</li>
 * </ul> */
public class MtopPermissionCheckManagerImplTest {

    private MtopPermissionCheckManagerImpl manager;
    private StationPermissionCheckManager stationPermissionCheckManager;
    private ExpressPermissionCheckHandler expressPermissionCheckHandler;

    @Before
    public void setUp() throws Exception {
        manager = new MtopPermissionCheckManagerImpl();
        stationPermissionCheckManager = Mockito.mock(StationPermissionCheckManager.class);
        expressPermissionCheckHandler = Mockito.mock(ExpressPermissionCheckHandler.class);
        injectField(manager, "stationPermissionCheckManager", stationPermissionCheckManager);
        injectField(manager, "expressPermissionCheckHandler", expressPermissionCheckHandler);
    }

    private static void injectField(Object target, String fieldName, Object value) throws Exception {
        java.lang.reflect.Field f = target.getClass().getDeclaredField(fieldName);
        f.setAccessible(true);
        f.set(target, value);
    }

    /* ============================ isExpress ============================ */

    @Test
    public void isExpress_hitYwtAppKey_shouldReturnTrue() {
        try (MockedStatic<MtopContext> mtop = Mockito.mockStatic(MtopContext.class)) {
            mtop.when(MtopContext::getAppKey).thenReturn("33471490");
            assertTrue(manager.isExpress());
        }
        try (MockedStatic<MtopContext> mtop = Mockito.mockStatic(MtopContext.class)) {
            mtop.when(MtopContext::getAppKey).thenReturn("33259236");
            assertTrue(manager.isExpress());
        }
    }

    @Test
    public void isExpress_otherAppKey_shouldReturnFalse() {
        try (MockedStatic<MtopContext> mtop = Mockito.mockStatic(MtopContext.class)) {
            mtop.when(MtopContext::getAppKey).thenReturn("99999999");
            assertFalse(manager.isExpress());
        }
    }

    @Test
    public void isExpress_nullAppKey_shouldReturnFalse() {
        try (MockedStatic<MtopContext> mtop = Mockito.mockStatic(MtopContext.class)) {
            mtop.when(MtopContext::getAppKey).thenReturn(null);
            assertFalse(manager.isExpress());
        }
    }

    /* ============================ loginPermission：网点端 ============================ */

    @Test
    public void loginPermission_express_shouldInvokeExpressHandlerAndSetExpressLoginType() {
        ExpressPermissionContext expressResult = new ExpressPermissionContext();
        expressResult.setUserId(123L);
        Mockito.when(expressPermissionCheckHandler.checkPermission(Mockito.any(ExpressPermissionContext.class)))
                .thenReturn(expressResult);

        try (MockedStatic<MtopContext> mtop = Mockito.mockStatic(MtopContext.class)) {
            mtop.when(MtopContext::getAppKey).thenReturn("33471490");

            PermissionContext<BasePermissionContext> ctx = manager.loginPermission();

            assertNotNull(ctx);
            assertEquals(LoginEntityTypeEnum.EXPRESS.getType(), ctx.getLoginType());
            assertSame(expressResult, ctx.getContext());
            Mockito.verify(stationPermissionCheckManager, Mockito.never())
                    .checkPermission(Mockito.any());
        }
    }

    /* ============================ loginPermission：站点端 ============================ */

    @Test
    public void loginPermission_station_shouldInvokeStationManagerAndSetStationLoginType() {
        StationPermissionContext stationResult = new StationPermissionContext();
        stationResult.setStationId("S001");

        ArgumentCaptor<StationPermissionContext> paramCap =
                ArgumentCaptor.forClass(StationPermissionContext.class);
        Mockito.when(stationPermissionCheckManager.checkPermission(paramCap.capture()))
                .thenReturn(stationResult);

        try (MockedStatic<MtopContext> mtop = Mockito.mockStatic(MtopContext.class)) {
            mtop.when(MtopContext::getAppKey).thenReturn("99999999"); // 非 ywt

            PermissionContext<BasePermissionContext> ctx = manager.loginPermission();

            assertNotNull(ctx);
            assertEquals(LoginEntityTypeEnum.STATION.getType(), ctx.getLoginType());
            assertSame(stationResult, ctx.getContext());
            // 入参 source 被设为 STATION_OWNER
            assertEquals(RequestSourceEnum.STATION_OWNER.getSource(), paramCap.getValue().getSource());
            Mockito.verify(expressPermissionCheckHandler, Mockito.never())
                    .checkPermission(Mockito.any());
        }
    }
}
