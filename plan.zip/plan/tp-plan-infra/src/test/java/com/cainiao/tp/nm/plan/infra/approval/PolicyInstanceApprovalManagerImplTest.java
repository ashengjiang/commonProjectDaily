package com.cainiao.tp.nm.plan.infra.approval;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static org.mockito.Mockito.*;

import com.base.BaseTest;
import com.cainiao.terminal.ticket.client.domain.response.TpTicketRep;
import com.cainiao.tp.nm.plan.api.policy.application.dto.TpTicketDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.PolicyApproveConfigDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.TicketInstanceApprovalStartParam;
import com.cainiao.tp.nm.plan.infra.port.policy.EmployeeRightsLoadManager;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyConfigManager;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyInstanceRuleQueryManager;
import com.cainiao.tp.nm.plan.infra.wrapper.org.TpTicketWrapper;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

/**
 * <a href="https://alidocs.dingtalk.com/i/nodes/dpYLaezmVNRMGX56C1aKjlBOVrMqPxX6">单元测试编写&生成FAQ</a>
 * Created By Thub IDEA插件
 *
 * @Date 2025/6/18 20:32
 */
public class PolicyInstanceApprovalManagerImplTest extends BaseTest {

    @InjectMocks
    private PolicyInstanceApprovalManagerImpl oaPolicyInstanceApprovalManagerImpl;
    @Mock
    private TpTicketWrapper tpTicketWrapper;
    @Mock
    private PolicyConfigManager policyConfigManager;
    @Mock
    private EmployeeRightsLoadManager employeeRightsLoadManager;
    @Mock
    private PolicyInstanceRuleQueryManager instanceRuleReadQueryManger;

    @Before
    public void setUp() throws Exception {MockitoAnnotations.openMocks(this);}

    @Test
    public void testStartApproval() {
        // Setup, prepare mock data
        PolicyApproveConfigDTO policyApproveConfigDTO = new PolicyApproveConfigDTO();
        policyApproveConfigDTO.setInsatnceApprove(true);
        policyApproveConfigDTO.setInsatnceProcessCode("code");
        when(policyConfigManager.getApproveConfig(anyString(), anyString()))
            .thenReturn(policyApproveConfigDTO);

        when(tpTicketWrapper.startTicket(any())).thenReturn("1");
        // Prepare method arguments

        // Run the method to be tested

        TicketInstanceApprovalStartParam policyInstanceApprovalStartParam = new TicketInstanceApprovalStartParam();
        policyInstanceApprovalStartParam.setId(1L);
        policyInstanceApprovalStartParam.setCustomType("customType");
        policyInstanceApprovalStartParam.setBizType("bizType");
        policyInstanceApprovalStartParam.setLastOperatorId(1L);
        String result = oaPolicyInstanceApprovalManagerImpl.startApproval(policyInstanceApprovalStartParam);
        // Verify the result
        assert result.equals("1");
    }

    @Test
    public void testQueryTicketById(){
        TpTicketRep tpTicketRep = new TpTicketRep();
        tpTicketRep.setId(1L);
        when(tpTicketWrapper.queryTicketById(any())).thenReturn(tpTicketRep);
        TpTicketDTO result = oaPolicyInstanceApprovalManagerImpl.queryTicketById(1L);
        Assert.assertEquals(1L, result.getId().longValue());
    }
    @Test
    public void testUpdateTicket(){
        oaPolicyInstanceApprovalManagerImpl.updateTicket(1L,new HashMap<>());
    }
    @Test
    public void testTimeOutPush(){
        oaPolicyInstanceApprovalManagerImpl.timeOutPush(1L,"action");
    }

    @Test
    public void testGetInstanceIdByContextKey(){
        List<TpTicketRep> listPageResult = new ArrayList<>();
        TpTicketRep tpTicketRep = new TpTicketRep();
        tpTicketRep.setProcessInstanceId("1");
        listPageResult.add(tpTicketRep);
        when(tpTicketWrapper.searchTicket(any())).thenReturn(listPageResult);
        String instanceIdByContextKey = oaPolicyInstanceApprovalManagerImpl.getInstanceIdByContextKey("definitionKey", "contextUniqueId");
        Assert.assertEquals("1", instanceIdByContextKey);
    }
}