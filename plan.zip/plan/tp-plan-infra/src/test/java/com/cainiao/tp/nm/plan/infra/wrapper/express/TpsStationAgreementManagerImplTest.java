package com.cainiao.tp.nm.plan.infra.wrapper.express;

import com.cainiao.aladdin.operation.SystemBizOperation;
import com.cainiao.aladdin.reslut.Result;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.TpsAgreementCreateAndSignDTO;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.TpsAgreementInfoDTO;
import com.cainiao.tps.content.client.model.agreement.TpsAgreementDTO;
import com.cainiao.tps.content.client.model.agreement.TpsAgreementInstanceDTO;
import com.cainiao.tps.content.client.request.agreement.TpsAgreementDetailQueryRequest;
import com.cainiao.tps.content.client.request.agreement.TpsAgreementInstanceCreateRequest;
import com.cainiao.tps.content.client.request.agreement.TpsAgreementInstanceSignedQueryRequest;
import com.cainiao.tps.content.client.service.agreement.TpsAgreementInstanceQueryService;
import com.cainiao.tps.content.client.service.agreement.TpsAgreementInstanceWriteService;
import com.cainiao.tps.content.client.service.agreement.TpsAgreementQueryService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Collections;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

/**
 * {@link TpsStationAgreementManagerImpl} 单元测试 */
@RunWith(MockitoJUnitRunner.class)
public class TpsStationAgreementManagerImplTest {

    @InjectMocks
    private TpsStationAgreementManagerImpl manager;

    @Mock
    private TpsAgreementQueryService tpsAgreementQueryService;

    @Mock
    private TpsAgreementInstanceWriteService tpsAgreementInstanceWriteService;

    @Mock
    private TpsAgreementInstanceQueryService tpsAgreementInstanceQueryService;

    /* ============================ queryDetail ============================ */

    @Test
    public void queryDetail_nullId_shouldReturnNull() {
        assertNull(manager.queryDetail(null));
    }

    @Test
    public void queryDetail_resultNull_shouldReturnNull() {
        when(tpsAgreementQueryService.queryDetail(any(TpsAgreementDetailQueryRequest.class),
                any(SystemBizOperation.class))).thenReturn(null);
        assertNull(manager.queryDetail(1L));
    }

    @Test
    public void queryDetail_resultFail_shouldReturnNull() {
        Result<TpsAgreementDTO> r = new Result<>();
        r.setSuccess(false);
        when(tpsAgreementQueryService.queryDetail(any(TpsAgreementDetailQueryRequest.class),
                any(SystemBizOperation.class))).thenReturn(r);
        assertNull(manager.queryDetail(1L));
    }

    @Test
    public void queryDetail_dataNull_shouldReturnNull() {
        Result<TpsAgreementDTO> r = new Result<>();
        r.setSuccess(true);
        r.setData(null);
        when(tpsAgreementQueryService.queryDetail(any(TpsAgreementDetailQueryRequest.class),
                any(SystemBizOperation.class))).thenReturn(r);
        assertNull(manager.queryDetail(1L));
    }

    @Test
    public void queryDetail_success_shouldMapAllFields() {
        TpsAgreementDTO data = buildAgreementDTO();
        Result<TpsAgreementDTO> r = new Result<>();
        r.setSuccess(true);
        r.setData(data);
        when(tpsAgreementQueryService.queryDetail(any(TpsAgreementDetailQueryRequest.class),
                any(SystemBizOperation.class))).thenReturn(r);

        TpsAgreementInfoDTO actual = manager.queryDetail(1L);
        assertAgreementMapped(data, actual);
    }

    @Test
    public void queryDetail_throw_shouldReturnNull() {
        when(tpsAgreementQueryService.queryDetail(any(TpsAgreementDetailQueryRequest.class),
                any(SystemBizOperation.class))).thenThrow(new RuntimeException("boom"));
        assertNull(manager.queryDetail(1L));
    }

    /* ============================ queryByCode ============================ */

    @Test
    public void queryByCode_blank_shouldReturnNull() {
        assertNull(manager.queryByCode(null));
        assertNull(manager.queryByCode(""));
        assertNull(manager.queryByCode("   "));
    }

    @Test
    public void queryByCode_resultNull_shouldReturnNull() {
        when(tpsAgreementQueryService.queryAgreementByCode("CODE")).thenReturn(null);
        assertNull(manager.queryByCode("CODE"));
    }

    @Test
    public void queryByCode_resultFail_shouldReturnNull() {
        Result<TpsAgreementDTO> r = new Result<>();
        r.setSuccess(false);
        when(tpsAgreementQueryService.queryAgreementByCode("CODE")).thenReturn(r);
        assertNull(manager.queryByCode("CODE"));
    }

    @Test
    public void queryByCode_dataNull_shouldReturnNull() {
        Result<TpsAgreementDTO> r = new Result<>();
        r.setSuccess(true);
        r.setData(null);
        when(tpsAgreementQueryService.queryAgreementByCode("CODE")).thenReturn(r);
        assertNull(manager.queryByCode("CODE"));
    }

    @Test
    public void queryByCode_success_shouldMapAllFields() {
        TpsAgreementDTO data = buildAgreementDTO();
        Result<TpsAgreementDTO> r = new Result<>();
        r.setSuccess(true);
        r.setData(data);
        when(tpsAgreementQueryService.queryAgreementByCode("CODE")).thenReturn(r);

        TpsAgreementInfoDTO actual = manager.queryByCode("CODE");
        assertAgreementMapped(data, actual);
    }

    @Test
    public void queryByCode_throw_shouldReturnNull() {
        when(tpsAgreementQueryService.queryAgreementByCode("CODE"))
                .thenThrow(new RuntimeException("boom"));
        assertNull(manager.queryByCode("CODE"));
    }

    /* ============================ createAndSign ============================ */

    @Test
    public void createAndSign_paramNull_shouldReturnNull() {
        assertNull(manager.createAndSign(null));
    }

    @Test
    public void createAndSign_agreementIdNull_shouldReturnNull() {
        TpsAgreementCreateAndSignDTO p = new TpsAgreementCreateAndSignDTO();
        p.setAgreementId(null);
        assertNull(manager.createAndSign(p));
    }

    @Test
    public void createAndSign_userIdBlank_shouldReturnNull() {
        TpsAgreementCreateAndSignDTO p = new TpsAgreementCreateAndSignDTO();
        p.setAgreementId(1L);
        p.setUserId("");
        assertNull(manager.createAndSign(p));

        p.setUserId("   ");
        assertNull(manager.createAndSign(p));

        p.setUserId(null);
        assertNull(manager.createAndSign(p));
    }

    @Test
    public void createAndSign_userTypeNull_shouldReturnNull() {
        TpsAgreementCreateAndSignDTO p = new TpsAgreementCreateAndSignDTO();
        p.setAgreementId(1L);
        p.setUserId("U1");
        p.setUserType(null);
        assertNull(manager.createAndSign(p));
    }

    @Test
    public void createAndSign_resultNull_shouldThrowSiteSignException() {
        TpsAgreementCreateAndSignDTO p = validParam();
        when(tpsAgreementInstanceWriteService.createAndSign(any(TpsAgreementInstanceCreateRequest.class),
                any(SystemBizOperation.class))).thenReturn(null);
        try {
            manager.createAndSign(p);
            fail();
        } catch (RuntimeException e) {
            assertEquals("站点签约异常", e.getMessage());
        }
    }

    @Test
    public void createAndSign_resultFail_shouldThrow() {
        TpsAgreementCreateAndSignDTO p = validParam();
        Result<Long> r = new Result<>();
        r.setSuccess(false);
        when(tpsAgreementInstanceWriteService.createAndSign(any(TpsAgreementInstanceCreateRequest.class),
                any(SystemBizOperation.class))).thenReturn(r);
        try {
            manager.createAndSign(p);
            fail();
        } catch (RuntimeException e) {
            assertEquals("站点签约异常", e.getMessage());
        }
    }

    @Test
    public void createAndSign_dataNull_shouldThrow() {
        TpsAgreementCreateAndSignDTO p = validParam();
        Result<Long> r = new Result<>();
        r.setSuccess(true);
        r.setData(null);
        when(tpsAgreementInstanceWriteService.createAndSign(any(TpsAgreementInstanceCreateRequest.class),
                any(SystemBizOperation.class))).thenReturn(r);
        try {
            manager.createAndSign(p);
            fail();
        } catch (RuntimeException e) {
            assertEquals("站点签约异常", e.getMessage());
        }
    }

    @Test
    public void createAndSign_success_shouldReturnInstanceId() {
        TpsAgreementCreateAndSignDTO p = validParam();
        Result<Long> r = new Result<>();
        r.setSuccess(true);
        r.setData(999L);
        when(tpsAgreementInstanceWriteService.createAndSign(any(TpsAgreementInstanceCreateRequest.class),
                any(SystemBizOperation.class))).thenReturn(r);
        assertEquals(Long.valueOf(999L), manager.createAndSign(p));
    }

    @Test
    public void createAndSign_downstreamThrow_shouldWrapAsRuntime() {
        TpsAgreementCreateAndSignDTO p = validParam();
        when(tpsAgreementInstanceWriteService.createAndSign(any(TpsAgreementInstanceCreateRequest.class),
                any(SystemBizOperation.class))).thenThrow(new RuntimeException("boom"));
        try {
            manager.createAndSign(p);
            fail();
        } catch (RuntimeException e) {
            assertEquals("站点签约异常", e.getMessage());
        }
    }

    /* ============================ isSigned ============================ */

    @Test
    public void isSigned_invalidParams_shouldReturnFalse() {
        assertFalse(manager.isSigned(null, 1L));
        assertFalse(manager.isSigned("", 1L));
        assertFalse(manager.isSigned("   ", 1L));
        assertFalse(manager.isSigned("CODE", null));
    }

    @Test
    public void isSigned_resultNull_shouldReturnFalse() {
        when(tpsAgreementInstanceQueryService.queryAgreementInstanceSignedList(
                any(TpsAgreementInstanceSignedQueryRequest.class),
                any(SystemBizOperation.class))).thenReturn(null);
        assertFalse(manager.isSigned("CODE", 1L));
    }

    @Test
    public void isSigned_resultFail_shouldReturnFalse() {
        Result<java.util.List<TpsAgreementInstanceDTO>> r = new Result<>();
        r.setSuccess(false);
        when(tpsAgreementInstanceQueryService.queryAgreementInstanceSignedList(
                any(TpsAgreementInstanceSignedQueryRequest.class),
                any(SystemBizOperation.class))).thenReturn(r);
        assertFalse(manager.isSigned("CODE", 1L));
    }

    @Test
    public void isSigned_emptyData_shouldReturnFalse() {
        Result<java.util.List<TpsAgreementInstanceDTO>> r = new Result<>();
        r.setSuccess(true);
        r.setData(Collections.emptyList());
        when(tpsAgreementInstanceQueryService.queryAgreementInstanceSignedList(
                any(TpsAgreementInstanceSignedQueryRequest.class),
                any(SystemBizOperation.class))).thenReturn(r);
        assertFalse(manager.isSigned("CODE", 1L));
    }

    @Test
    public void isSigned_dataNotEmpty_shouldReturnTrue() {
        Result<java.util.List<TpsAgreementInstanceDTO>> r = new Result<>();
        r.setSuccess(true);
        r.setData(Collections.singletonList(new TpsAgreementInstanceDTO()));
        when(tpsAgreementInstanceQueryService.queryAgreementInstanceSignedList(
                any(TpsAgreementInstanceSignedQueryRequest.class),
                any(SystemBizOperation.class))).thenReturn(r);
        assertTrue(manager.isSigned("CODE", 1L));
    }

    @Test
    public void isSigned_throw_shouldReturnFalse() {
        when(tpsAgreementInstanceQueryService.queryAgreementInstanceSignedList(
                any(TpsAgreementInstanceSignedQueryRequest.class),
                any(SystemBizOperation.class))).thenThrow(new RuntimeException("boom"));
        assertFalse(manager.isSigned("CODE", 1L));
    }

    /* ============================ helpers ============================ */

    private TpsAgreementCreateAndSignDTO validParam() {
        TpsAgreementCreateAndSignDTO p = new TpsAgreementCreateAndSignDTO();
        p.setAgreementId(1L);
        p.setUserId("U1");
        p.setUserType(1);
        String stationId = "2";
        p.setStationId(stationId);
        java.util.Map<String, String> feature = java.util.Collections.singletonMap("k", "v");
        p.setFeature(feature);
        return p;
    }

    private TpsAgreementDTO buildAgreementDTO() {
        TpsAgreementDTO data = new TpsAgreementDTO();
        data.setId(1L);
        data.setTitle("T");
        data.setContentUrl("u");
        data.setAgreementCode("AC");
        data.setStatus(1);
        data.setValidDate(new java.util.Date());
        data.setInvalidDate(new java.util.Date());
        data.setSignStartDate(new java.util.Date());
        data.setSignEndDate(new java.util.Date());
        data.setBizLine("biz");
        data.setBizType("bizT");
        data.setDescription("desc");
        data.setFeature(java.util.Collections.singletonMap("k", "v"));
        return data;
    }

    private void assertAgreementMapped(TpsAgreementDTO src, TpsAgreementInfoDTO actual) {
        assertNotNull(actual);
        assertEquals(src.getId(), actual.getId());
        assertEquals(src.getTitle(), actual.getTitle());
        assertEquals(src.getContentUrl(), actual.getContentUrl());
        assertEquals(src.getAgreementCode(), actual.getAgreementCode());
        assertEquals(src.getStatus(), actual.getStatus());
        assertEquals(src.getValidDate(), actual.getValidDate());
        assertEquals(src.getInvalidDate(), actual.getInvalidDate());
        assertEquals(src.getSignStartDate(), actual.getSignStartDate());
        assertEquals(src.getSignEndDate(), actual.getSignEndDate());
        assertEquals(src.getBizLine(), actual.getBizLine());
        assertEquals(src.getBizType(), actual.getBizType());
        assertEquals(src.getDescription(), actual.getDescription());
        assertEquals(src.getFeature(), actual.getFeature());
    }
}
