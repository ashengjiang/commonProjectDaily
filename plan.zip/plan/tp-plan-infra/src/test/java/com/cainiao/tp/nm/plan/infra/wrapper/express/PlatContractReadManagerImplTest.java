package com.cainiao.tp.nm.plan.infra.wrapper.express;

import com.alibaba.cainiao.express.outlets.api.result.ResultModel;
import com.alibaba.cainiao.express.outlets.contract.result.PlatContractSimpleDTO;
import com.alibaba.cainiao.express.outlets.contract.service.PlatContractReadService;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.PlatContractSimpleInfoDTO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.when;

/**
 * {@link PlatContractReadManagerImpl} 单元测试
 *
 * <p>覆盖：
 * <ul>
 *   <li>下游 result 失败 → 抛 RuntimeException</li>
 *   <li>下游 dataList 为 null / empty → 返回 null</li>
 *   <li>dataList 全部 signableBegin/End 为 null → isSignable 都为 false → 返回 null</li>
 *   <li>dataList 当前时间 < signableBegin / > signableEnd → 返回 null</li>
 *   <li>有 1 条命中 → 返回首个命中的转换结果</li>
 *   <li>多条命中 → findFirst 返回第一条</li>
 *   <li>convert 字段映射齐全</li>
 * </ul> */
@RunWith(MockitoJUnitRunner.class)
public class PlatContractReadManagerImplTest {

    @InjectMocks
    private PlatContractReadManagerImpl manager;

    @Mock
    private PlatContractReadService platContractReadService;

    /* ============================ result 失败 ============================ */

    @Test
    public void getSimplePlatContract_resultFail_shouldThrow() {
        when(platContractReadService.getSimplePlatContract("SVC"))
                .thenReturn(ResultModel.buildErrorResult("500", "boom"));
        try {
            manager.getSimplePlatContract("SVC");
            fail("expected RuntimeException");
        } catch (RuntimeException e) {
            assertEquals(true, e.getMessage().contains("boom"));
        }
    }

    /* ============================ dataList 为 null / empty ============================ */

    @Test
    public void getSimplePlatContract_dataNull_shouldReturnNull() {
        when(platContractReadService.getSimplePlatContract("SVC"))
                .thenReturn(ResultModel.buildSuccessResult(null));
        assertNull(manager.getSimplePlatContract("SVC"));
    }

    @Test
    public void getSimplePlatContract_dataEmpty_shouldReturnNull() {
        when(platContractReadService.getSimplePlatContract("SVC"))
                .thenReturn(ResultModel.buildSuccessResult(Collections.emptyList()));
        assertNull(manager.getSimplePlatContract("SVC"));
    }

    /* ============================ signable 区间相关 ============================ */

    @Test
    public void getSimplePlatContract_allBeginOrEndNull_shouldReturnNull() {
        // 一条 begin=null，一条 end=null，都过滤掉
        PlatContractSimpleDTO c1 = new PlatContractSimpleDTO();
        c1.setGmtSignableBegin(null);
        c1.setGmtSignableEnd(new Date());
        PlatContractSimpleDTO c2 = new PlatContractSimpleDTO();
        c2.setGmtSignableBegin(new Date());
        c2.setGmtSignableEnd(null);

        when(platContractReadService.getSimplePlatContract("SVC"))
                .thenReturn(ResultModel.buildSuccessResult(Arrays.asList(c1, c2)));

        assertNull(manager.getSimplePlatContract("SVC"));
    }

    @Test
    public void getSimplePlatContract_nowBeforeBegin_shouldReturnNull() {
        long now = System.currentTimeMillis();
        PlatContractSimpleDTO c = buildBasicContract();
        c.setGmtSignableBegin(new Date(now + 60_000L));
        c.setGmtSignableEnd(new Date(now + 120_000L));

        when(platContractReadService.getSimplePlatContract("SVC"))
                .thenReturn(ResultModel.buildSuccessResult(Collections.singletonList(c)));

        assertNull(manager.getSimplePlatContract("SVC"));
    }

    @Test
    public void getSimplePlatContract_nowAfterEnd_shouldReturnNull() {
        long now = System.currentTimeMillis();
        PlatContractSimpleDTO c = buildBasicContract();
        c.setGmtSignableBegin(new Date(now - 120_000L));
        c.setGmtSignableEnd(new Date(now - 60_000L));

        when(platContractReadService.getSimplePlatContract("SVC"))
                .thenReturn(ResultModel.buildSuccessResult(Collections.singletonList(c)));

        assertNull(manager.getSimplePlatContract("SVC"));
    }

    /* ============================ 单条命中 ============================ */

    @Test
    public void getSimplePlatContract_singleSignable_shouldReturnConverted() {
        long now = System.currentTimeMillis();
        PlatContractSimpleDTO c = buildBasicContract();
        c.setGmtSignableBegin(new Date(now - 60_000L));
        c.setGmtSignableEnd(new Date(now + 60_000L));

        when(platContractReadService.getSimplePlatContract("SVC"))
                .thenReturn(ResultModel.buildSuccessResult(Collections.singletonList(c)));

        PlatContractSimpleInfoDTO actual = manager.getSimplePlatContract("SVC");
        assertNotNull(actual);
        assertEquals("SVC1", actual.getServiceCode());
        assertEquals("服务名", actual.getServiceName());
        assertNotNull(actual.getGmtBegin());
        assertNotNull(actual.getGmtEnd());
        assertNotNull(actual.getGmtInterimEnd());
        assertNotNull(actual.getGmtSignableBegin());
        assertNotNull(actual.getGmtSignableEnd());
        assertEquals("content-x", actual.getContent());
        assertEquals(Long.valueOf(123L), actual.getContractId());
    }

    /* ============================ 多条命中：findFirst ============================ */

    @Test
    public void getSimplePlatContract_multiSignable_shouldReturnFirst() {
        long now = System.currentTimeMillis();
        PlatContractSimpleDTO c1 = buildBasicContract();
        c1.setServiceCode("FIRST");
        c1.setGmtSignableBegin(new Date(now - 60_000L));
        c1.setGmtSignableEnd(new Date(now + 60_000L));
        PlatContractSimpleDTO c2 = buildBasicContract();
        c2.setServiceCode("SECOND");
        c2.setGmtSignableBegin(new Date(now - 60_000L));
        c2.setGmtSignableEnd(new Date(now + 60_000L));

        when(platContractReadService.getSimplePlatContract("SVC"))
                .thenReturn(ResultModel.buildSuccessResult(Arrays.asList(c1, c2)));

        PlatContractSimpleInfoDTO actual = manager.getSimplePlatContract("SVC");
        assertNotNull(actual);
        assertEquals("FIRST", actual.getServiceCode());
    }

    /* ============================ 部分命中：跳过不符合，命中后面的 ============================ */

    @Test
    public void getSimplePlatContract_skipInvalidPickValid() {
        long now = System.currentTimeMillis();
        PlatContractSimpleDTO invalid = buildBasicContract();
        invalid.setServiceCode("INVALID");
        invalid.setGmtSignableBegin(null);
        invalid.setGmtSignableEnd(new Date(now + 60_000L));

        PlatContractSimpleDTO valid = buildBasicContract();
        valid.setServiceCode("VALID");
        valid.setGmtSignableBegin(new Date(now - 60_000L));
        valid.setGmtSignableEnd(new Date(now + 60_000L));

        List<PlatContractSimpleDTO> list = Arrays.asList(invalid, valid);
        when(platContractReadService.getSimplePlatContract("SVC"))
                .thenReturn(ResultModel.buildSuccessResult(list));

        PlatContractSimpleInfoDTO actual = manager.getSimplePlatContract("SVC");
        assertNotNull(actual);
        assertEquals("VALID", actual.getServiceCode());
    }

    private PlatContractSimpleDTO buildBasicContract() {
        PlatContractSimpleDTO c = new PlatContractSimpleDTO();
        c.setServiceCode("SVC1");
        c.setServiceName("服务名");
        c.setGmtBegin(new Date());
        c.setGmtEnd(new Date());
        c.setGmtInterimEnd(new Date());
        c.setContent("content-x");
        c.setContractId(123L);
        return c;
    }
}