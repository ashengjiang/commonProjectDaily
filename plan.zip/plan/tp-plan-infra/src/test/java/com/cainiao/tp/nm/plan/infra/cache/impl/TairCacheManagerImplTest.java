package com.cainiao.tp.nm.plan.infra.cache.impl;

import com.taobao.tair.DataEntry;
import com.taobao.tair.Result;
import com.taobao.tair.ResultCode;
import com.taobao.tair.TairManager;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class TairCacheManagerImplTest {

    @InjectMocks
    private TairCacheManagerImpl tairCacheManager;

    @Mock
    private TairManager tairManager;

    @Mock
    private Result<DataEntry> result;

    @Mock
    private DataEntry dataEntry;

    /**
     * 测试传入空 key，期望返回 null
     */
    @Test
    public void testGetStringWithNullKey() {
        String result = tairCacheManager.getString(null);
        assert (result == null); // 验证结果为 null
    }

    /**
     * 测试传入空字符串 key，期望返回 null
     */
    @Test
    public void testGetStringWithEmptyKey() {
        String result = tairCacheManager.getString("");
        assert (result == null); // 验证结果为 null
    }

    /**
     * 测试 TairManager.get 返回 null 的情况，期望返回 null
     */
    @Test(expected = IllegalArgumentException.class)
    public void testGetStringWhenResultIsNull() {
        when(tairManager.get(TairCacheManagerImpl.DEFAULT_NAMESPACE, "key")).thenReturn(null);
        tairCacheManager.getString("key");
    }

    /**
     * 测试 TairManager.get 返回成功但 DataEntry 值为 null 的情况，期望返回 null
     */
    @Test
    public void testGetStringWhenDataEntryValueIsNull() {
        when(tairManager.get(TairCacheManagerImpl.DEFAULT_NAMESPACE, "key")).thenReturn(result);
        when(result.isSuccess()).thenReturn(true);
        when(result.getValue()).thenReturn(null);
        String result = tairCacheManager.getString("key");
        assert (result == null); // 验证结果为 null
    }

    /**
     * 测试正常获取字符串值，期望返回值为 "value"
     */
    @Test
    public void testGetStringWithValidKey() {
        when(tairManager.get(TairCacheManagerImpl.DEFAULT_NAMESPACE, "key")).thenReturn(result);
        when(result.isSuccess()).thenReturn(true);
        when(result.getValue()).thenReturn(dataEntry);
        when(dataEntry.getValue()).thenReturn("value");

        String result = tairCacheManager.getString("key");
        assert ("value".equals(result)); // 验证返回的值应为 "value"
    }

    /**
     * 测试setStr方法时，value为null时应抛出IllegalArgumentException
     */
    @Test(expected = IllegalArgumentException.class)
    public void testSetStrValueIsNullShouldThrowException() {
        // 传入key, null的value，expire
        tairCacheManager.setStr("key", null, 10);
    }

    /**
     * 测试当值为null时，setStr方法应抛出异常
     */
    @Test(expected = IllegalArgumentException.class)
    public void testSetStrValueIsNull() {
        tairCacheManager.setStr("testKey", null, 3600);
    }

}