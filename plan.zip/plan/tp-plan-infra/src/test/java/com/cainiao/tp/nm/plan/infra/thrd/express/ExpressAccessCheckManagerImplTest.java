package com.cainiao.tp.nm.plan.infra.thrd.express;

import com.alibaba.cainiao.express.outlets.base.api.result.org.EmployeeOrgDTO;
import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.cnmember.client.session.CnSessionWirelessReadClient;
import com.cainiao.cnmember.session.domain.CnMemberSessionDTO;
import com.cainiao.member.common.CnMemberResult;
import com.cainiao.tp.nm.plan.api.policy.application.dto.ExpressContentDTO;
import com.cainiao.tp.nm.plan.infra.wrapper.express.ExpressOrgServiceWrapper;
import com.google.common.collect.Lists;
import com.taobao.eagleeye.EagleEye;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.List;

import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;

@RunWith(MockitoJUnitRunner.class)
public class ExpressAccessCheckManagerImplTest {
    @InjectMocks
    private ExpressAccessCheckManagerImpl expressAccessCheckManagerImpl;
    @Mock
    private CnSessionWirelessReadClient cnSessionWirelessReadClient;
    @Mock
    private ExpressOrgServiceWrapper expressOrgServiceWrapper;

    private MockedStatic<EagleEye> eagleEyeMockedStatic;

    @Before
    public void before() {
        eagleEyeMockedStatic = Mockito.mockStatic(EagleEye.class);
    }

    @After
    public void after() {
        eagleEyeMockedStatic.close();
    }

    @Test
    public void testCheckExpAndJVAccessQuery() {
        ExpressContentDTO context = new ExpressContentDTO();
        context.setSessionId("1");
        context.setAppKey("2");
        context.setUserId(10L);
        context.setCpCode("cpCode");
        context.setOrgCode("orgCode");
        CnMemberSessionDTO sessionDTO = new CnMemberSessionDTO();
        sessionDTO.setSessionId("1");
        sessionDTO.setCnAccountId(10L);
        sessionDTO.setEmployeeId(11L);
        CnMemberResult<CnMemberSessionDTO> success = CnMemberResult.success(sessionDTO);
        Mockito.when(cnSessionWirelessReadClient.querySession(anyString(), anyString())).thenReturn(success);

        EmployeeOrgDTO dto = new EmployeeOrgDTO();
        dto.setOrgCode("orgCode");
        dto.setOrgName("name");
        dto.setCpCode("cpCode");
        dto.setCpName("cpName");
        List<EmployeeOrgDTO> employeeOrgDTOS = Lists.newArrayList(dto);
        Mockito.when(expressOrgServiceWrapper.queryCombineOrgList(anyLong())).thenReturn(employeeOrgDTOS);
        expressAccessCheckManagerImpl.checkExpAndJVAccess(context);

        Assert.assertEquals(context.getCpCode(), employeeOrgDTOS.get(0).getCpCode());
        Assert.assertEquals(context.getOrgCode(), employeeOrgDTOS.get(0).getOrgCode());
        Assert.assertEquals(context.getUserId(), sessionDTO.getCnAccountId());
    }

    @Test(expected = AladdinBizException.class)
    public void testCheckExpAndJVAccessQuerySessionFail() {
        ExpressContentDTO context = new ExpressContentDTO();
        context.setSessionId("1");
        context.setAppKey("2");
        context.setUserId(10L);
        context.setCpCode("cpCode");
        context.setOrgCode("orgCode");
        CnMemberResult<CnMemberSessionDTO> failure = CnMemberResult.failure("1", "2");
        Mockito.when(cnSessionWirelessReadClient.querySession(anyString(), anyString())).thenReturn(failure);

        expressAccessCheckManagerImpl.checkExpAndJVAccess(context);

    }

    @Test(expected = AladdinBizException.class)
    public void testCheckExpAndJVAccessQueryOrgIsNull() {
        ExpressContentDTO context = new ExpressContentDTO();
        context.setSessionId("1");
        context.setAppKey("2");
        context.setUserId(10L);
        context.setCpCode("cpCode");
        context.setOrgCode("orgCode");
        CnMemberSessionDTO sessionDTO = new CnMemberSessionDTO();
        sessionDTO.setSessionId("1");
        sessionDTO.setCnAccountId(10L);
        sessionDTO.setEmployeeId(11L);
        CnMemberResult<CnMemberSessionDTO> success = CnMemberResult.success(sessionDTO);
        Mockito.when(cnSessionWirelessReadClient.querySession(anyString(), anyString())).thenReturn(success);


        Mockito.when(expressOrgServiceWrapper.queryCombineOrgList(anyLong())).thenReturn(Lists.newArrayList());
        expressAccessCheckManagerImpl.checkExpAndJVAccess(context);

        Assert.assertEquals(context.getUserId(), sessionDTO.getCnAccountId());
    }


}