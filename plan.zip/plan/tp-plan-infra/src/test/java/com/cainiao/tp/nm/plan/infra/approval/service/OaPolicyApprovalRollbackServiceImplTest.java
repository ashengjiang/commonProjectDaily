package com.cainiao.tp.nm.plan.infra.approval.service;

import static org.mockito.Mockito.*;

import java.util.HashMap;
import java.util.Map;

import com.base.BaseTest;
import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.terminal.ticket.client.domain.response.TpTicketRep;
import com.cainiao.tp.nm.plan.api.policy.application.service.PolicyInstanceAppService;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyInstanceApprovalStatusEnum;
import com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils;
import com.cainiao.tp.nm.plan.infra.wrapper.org.TpTicketWrapper;
import com.cainiao.tp.nm.plan.policy.domain.model.PolicyInstance;
import com.cainiao.tp.nm.plan.policy.domain.repository.PolicyInstanceRepository;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyLong;
import static org.mockito.Mockito.anyString;

/**
 * <a href="https://alidocs.dingtalk.com/i/nodes/dpYLaezmVNRMGX56C1aKjlBOVrMqPxX6">单元测试编写&生成FAQ</a>
 * Created By Thub IDEA插件
 *
 * @Date 2025/6/21 08:50
 */
public class OaPolicyApprovalRollbackServiceImplTest extends BaseTest {

    @InjectMocks
    private OaPolicyApprovalRollbackServiceImpl oaPolicyApprovalRollbackServiceImpl;
    @Mock
    private TpTicketWrapper tpTicketWrapper;
    @Mock
    private PolicyInstanceRepository policyInstanceRepository;
    @Mock
    private PolicyInstanceAppService policyInstanceAppService;
    @Mock
    private AbstractOperation opInfo;

    @Before
    public void setUp() throws Exception {MockitoAnnotations.openMocks(this);}

    @Test
    public void testAgree_effect() {
        TpTicketRep tpTicketRep = new TpTicketRep();
        Map<String, Object> context = new HashMap<>();
        context.put("policyInstanceId", "1");
        tpTicketRep.setContext(context);
        // Setup, prepare mock data
        Mockito.when(tpTicketWrapper.queryTicketByProcessId(anyString()))
            .thenReturn(tpTicketRep);
        Mockito.when(policyInstanceRepository.get(anyLong()))
            .thenReturn(
                PolicyInstance.builder()
                    .id(1L)
                    .approvalStatus(PolicyInstanceApprovalStatusEnum.APPROVALING.getCode())
                    .build()
            );

        // Prepare method arguments

        // Run the method to be tested
        oaPolicyApprovalRollbackServiceImpl.agree("1");

        // Verify the result
        Mockito.verify(policyInstanceAppService).effect(any(), any());
    }

    @Test
    public void testAgree_loseEffect() {
        TpTicketRep tpTicketRep = new TpTicketRep();
        Map<String, Object> context = new HashMap<>();
        context.put("policyInstanceId", "1");
        tpTicketRep.setContext(context);
        // Setup, prepare mock data
        Mockito.when(tpTicketWrapper.queryTicketByProcessId(anyString()))
            .thenReturn(tpTicketRep);
        Mockito.when(policyInstanceRepository.get(anyLong()))
            .thenReturn(
                PolicyInstance.builder()
                    .id(1L)
                    .approvalStatus(PolicyInstanceApprovalStatusEnum.APPROVALING.getCode())
                    .startTime(DateUtils.toLocalDateTimeYmdStart("2000-06-21"))
                    .build()
            );

        // Prepare method arguments

        // Run the method to be tested
        oaPolicyApprovalRollbackServiceImpl.agree("1");

        // Verify the result
//        Mockito.verify(policyInstanceAppService).loseEffect(any(), any());
    }

    @Test
    public void testDisagree_reject() {
        TpTicketRep tpTicketRep = new TpTicketRep();
        Map<String, Object> context = new HashMap<>();
        context.put("policyInstanceId", "1");
        tpTicketRep.setContext(context);
        // Setup, prepare mock data
        Mockito.when(tpTicketWrapper.queryTicketByProcessId(anyString()))
            .thenReturn(tpTicketRep);
        Mockito.when(policyInstanceRepository.get(anyLong()))
            .thenReturn(
                PolicyInstance.builder()
                    .id(1L)
                    .approvalStatus(PolicyInstanceApprovalStatusEnum.APPROVALING.getCode())
                    .build()
            );

        // Run the method to be tested
        oaPolicyApprovalRollbackServiceImpl.disagree("1");

        // Verify the result
        Mockito.verify(policyInstanceAppService).loseEffect(any(), any());
    }

    @Test
    public void testAgree_timeout() {
        TpTicketRep tpTicketRep = new TpTicketRep();
        Map<String, Object> context = new HashMap<>();
        context.put("policyInstanceId", "1");
        tpTicketRep.setContext(context);
        // Setup, prepare mock data
        Mockito.when(tpTicketWrapper.queryTicketByProcessId(anyString()))
            .thenReturn(tpTicketRep);
        Mockito.when(policyInstanceRepository.get(anyLong()))
            .thenReturn(
                PolicyInstance.builder()
                    .id(1L)
                    .approvalStatus(PolicyInstanceApprovalStatusEnum.APPROVALING.getCode())
                    .startTime(DateUtils.toLocalDateTimeYmdStart("2000-06-21"))
                    .build()
            );

        // Prepare method arguments

        // Run the method to be tested
        oaPolicyApprovalRollbackServiceImpl.disagree("1");

        // Verify the result
        Mockito.verify(policyInstanceAppService).loseEffect(any(), any());
    }

    @Test
    public void testTimeoutAutoReject(){
        TpTicketRep tpTicketRep = new TpTicketRep();
        Map<String, Object> context = new HashMap<>();
        context.put("policyInstanceId", "1");
        tpTicketRep.setContext(context);
        // Setup, prepare mock data
        Mockito.when(tpTicketWrapper.queryTicketByProcessId(anyString()))
            .thenReturn(tpTicketRep);
        Mockito.when(policyInstanceRepository.get(anyLong()))
            .thenReturn(
                PolicyInstance.builder()
                    .id(1L)
                    .approvalStatus(PolicyInstanceApprovalStatusEnum.APPROVALING.getCode())
                    .startTime(DateUtils.toLocalDateTimeYmdStart("2000-06-21"))
                    .build()
            );

        // Prepare method arguments

        // Run the method to be tested
        oaPolicyApprovalRollbackServiceImpl.timeoutAutoReject("1");

        // Verify the result
        Mockito.verify(policyInstanceAppService).loseEffect(any(), any());
    }
}