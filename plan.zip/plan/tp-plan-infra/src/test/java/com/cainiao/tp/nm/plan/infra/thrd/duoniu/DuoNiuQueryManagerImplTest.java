package com.cainiao.tp.nm.plan.infra.thrd.duoniu;

import com.alibaba.fastjson.JSONObject;
import com.cainiao.terminal.iot.aftersales.api.domain.output.DuoNiuOrderDetailResDTO;
import com.cainiao.terminal.iot.aftersales.api.domain.output.DuoNiuOrderTradeDTO;
import com.cainiao.terminal.iot.aftersales.api.domain.output.DuoNiuOrdersDTO;
import com.cainiao.terminal.iot.aftersales.api.domain.output.DuoNiuSkuDetailResDTO;
import com.cainiao.terminal.iot.aftersales.api.domain.output.Skus;
import com.cainiao.terminal.iot.aftersales.api.service.duoniu.DuoNiuQueryService;
import com.cainiao.terminal.sta.result.TpRestResult;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.DuoNiuOrderDetailDTO;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.DuoNiuSkuDetailDTO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.Collections;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.when;

/**
 * {@link DuoNiuQueryManagerImpl} 单元测试 */
@RunWith(MockitoJUnitRunner.class)
public class DuoNiuQueryManagerImplTest {

    @InjectMocks
    private DuoNiuQueryManagerImpl manager;

    @Mock
    private DuoNiuQueryService duoNiuQueryService;

    /* ============================ querySkuByItemId ============================ */

    @Test
    public void querySkuByItemId_resultFail_shouldThrow() {
        TpRestResult<DuoNiuSkuDetailResDTO> r = new TpRestResult<>();
        r.setSuccess(false);
        r.setErrorMsg("boom");
        when(duoNiuQueryService.querySkuByItemId(1)).thenReturn(r);
        try {
            manager.querySkuByItemId(1);
            fail();
        } catch (RuntimeException e) {
            assertTrue(e.getMessage().contains("boom"));
        }
    }

    @Test
    public void querySkuByItemId_dataNull_shouldReturnNull() {
        TpRestResult<DuoNiuSkuDetailResDTO> r = new TpRestResult<>();
        r.setSuccess(true);
        r.setData(null);
        when(duoNiuQueryService.querySkuByItemId(1)).thenReturn(r);
        assertNull(manager.querySkuByItemId(1));
    }

    @Test
    public void querySkuByItemId_success_emptySkusList_shouldReturnEmpty() {
        DuoNiuSkuDetailResDTO data = buildSkuDetail();
        data.setSkusList(null);
        TpRestResult<DuoNiuSkuDetailResDTO> r = new TpRestResult<>();
        r.setSuccess(true);
        r.setData(data);
        when(duoNiuQueryService.querySkuByItemId(1)).thenReturn(r);

        DuoNiuSkuDetailDTO actual = manager.querySkuByItemId(1);
        assertNotNull(actual);
        assertTrue(actual.getSkusList().isEmpty());
        // 主字段映射
        assertEquals("100", actual.getItemId());
        assertEquals("title", actual.getTitle());
    }

    @Test
    public void querySkuByItemId_success_withSkusList_shouldConvertEach() {
        Skus s1 = new Skus();
        s1.setSkuID("11");
        s1.setItemID("100");
        s1.setSkuCode("SKU-A");
        Skus s2 = new Skus();
        s2.setSkuID("22");
        s2.setSkuCode("SKU-B");
        DuoNiuSkuDetailResDTO data = buildSkuDetail();
        data.setSkusList(Arrays.asList(s1, s2));

        TpRestResult<DuoNiuSkuDetailResDTO> r = new TpRestResult<>();
        r.setSuccess(true);
        r.setData(data);
        when(duoNiuQueryService.querySkuByItemId(1)).thenReturn(r);

        DuoNiuSkuDetailDTO actual = manager.querySkuByItemId(1);
        assertEquals(2, actual.getSkusList().size());
        assertEquals("11", actual.getSkusList().get(0).getSkuId());
        assertEquals("SKU-A", actual.getSkusList().get(0).getSkuCode());
        assertEquals("22", actual.getSkusList().get(1).getSkuId());
    }

    /* ============================ queryOrderDetailById ============================ */

    @Test
    public void queryOrderDetailById_resultFail_shouldThrow() {
        TpRestResult<DuoNiuOrderDetailResDTO> r = new TpRestResult<>();
        r.setSuccess(false);
        r.setErrorMsg("boom");
        when(duoNiuQueryService.queryOrderDetailById("OID", "SUP")).thenReturn(r);
        try {
            manager.queryOrderDetailById("OID", "SUP");
            fail();
        } catch (RuntimeException e) {
            assertTrue(e.getMessage().contains("boom"));
        }
    }

    @Test
    public void queryOrderDetailById_dataNull_shouldReturnNull() {
        TpRestResult<DuoNiuOrderDetailResDTO> r = new TpRestResult<>();
        r.setSuccess(true);
        r.setData(null);
        when(duoNiuQueryService.queryOrderDetailById("OID", "SUP")).thenReturn(r);
        assertNull(manager.queryOrderDetailById("OID", "SUP"));
    }

    @Test
    public void queryOrderDetailById_success_snJsonNull_shouldKeepNull() {
        DuoNiuOrderDetailResDTO data = buildOrderDetail();
        data.setSnJson(null);
        data.setOrders(null);
        data.setTradeDTOList(null);

        TpRestResult<DuoNiuOrderDetailResDTO> r = new TpRestResult<>();
        r.setSuccess(true);
        r.setData(data);
        when(duoNiuQueryService.queryOrderDetailById("OID", "SUP")).thenReturn(r);

        DuoNiuOrderDetailDTO actual = manager.queryOrderDetailById("OID", "SUP");
        assertNotNull(actual);
        assertEquals("TID", actual.getTradeId());
        assertNull(actual.getSnJson());
        assertTrue(actual.getOrders().isEmpty());
        assertTrue(actual.getTradeDTOList().isEmpty());
    }

    @Test
    public void queryOrderDetailById_success_withSnJsonAndLists() {
        DuoNiuOrderDetailResDTO data = buildOrderDetail();
        JSONObject snJson = new JSONObject();
        snJson.put("sn", "SN-1");
        data.setSnJson(snJson);

        DuoNiuOrdersDTO o = new DuoNiuOrdersDTO();
        o.setOrderID("O1");
        o.setItemID("100");
        o.setItemTitle("商品");
        o.setSkuID("11");
        data.setOrders(Collections.singletonList(o));

        DuoNiuOrderTradeDTO t = new DuoNiuOrderTradeDTO();
        t.setTradeNo("T-1");
        t.setExpressCode("YTO");
        t.setExpressName("圆通");
        data.setTradeDTOList(Collections.singletonList(t));

        TpRestResult<DuoNiuOrderDetailResDTO> r = new TpRestResult<>();
        r.setSuccess(true);
        r.setData(data);
        when(duoNiuQueryService.queryOrderDetailById("OID", "SUP")).thenReturn(r);

        DuoNiuOrderDetailDTO actual = manager.queryOrderDetailById("OID", "SUP");
        assertNotNull(actual);
        assertTrue(actual.getSnJson().contains("SN-1"));
        assertEquals(1, actual.getOrders().size());
        assertEquals("O1", actual.getOrders().get(0).getOrderId());
        assertEquals("100", actual.getOrders().get(0).getItemId());
        assertEquals(1, actual.getTradeDTOList().size());
        assertEquals("T-1", actual.getTradeDTOList().get(0).getTradeNo());
        assertEquals("YTO", actual.getTradeDTOList().get(0).getExpressCode());
    }

    /* ============================ helpers ============================ */

    private DuoNiuSkuDetailResDTO buildSkuDetail() {
        DuoNiuSkuDetailResDTO d = new DuoNiuSkuDetailResDTO();
        d.setItemID("100");
        d.setTitle("title");
        return d;
    }

    private DuoNiuOrderDetailResDTO buildOrderDetail() {
        DuoNiuOrderDetailResDTO d = new DuoNiuOrderDetailResDTO();
        d.setTradeID("TID");
        d.setSupplierID("SUP");
        return d;
    }
}
