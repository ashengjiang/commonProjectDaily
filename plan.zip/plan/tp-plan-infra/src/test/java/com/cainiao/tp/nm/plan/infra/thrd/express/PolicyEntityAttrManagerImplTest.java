package com.cainiao.tp.nm.plan.infra.thrd.express;

import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.Assert;

import com.alibaba.cainiao.express.outlets.contract.result.ServiceOpenRelationDTO;

import com.base.BaseTest;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiverule.select.EntitySelectRuleDTO;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyCustomTypeEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyEntityAttrEnum;
import com.cainiao.tp.nm.plan.infra.port.policy.TgManager;
import com.cainiao.tp.nm.plan.infra.wrapper.express.ServiceProductServiceWrapper;
import org.apache.poi.ss.formula.functions.T;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

/**
 * <a href="https://alidocs.dingtalk.com/i/nodes/dpYLaezmVNRMGX56C1aKjlBOVrMqPxX6">单元测试编写&生成FAQ</a>
 * Created By Thub IDEA插件
 *
 * @Date 2025/6/26 17:48
 */
public class PolicyEntityAttrManagerImplTest extends BaseTest {

    @InjectMocks
    private PolicyEntityAttrManagerImpl policyEntityAttrManagerImpl;
    @Mock
    private ServiceProductServiceWrapper serviceProductServiceWrapper;
    @Mock
    private TgManager tgManager;

    @Before
    public void setUp() throws Exception {MockitoAnnotations.openMocks(this);}

    @Test
    public void testHasAttr() {

        Mockito.when(serviceProductServiceWrapper.queryJvExtendServices(anyString(), anyString(), anyString(), anyList()))
            .thenReturn(new ArrayList<>());
        Mockito.when(tgManager.getListData(any()))
            .thenReturn(new ArrayList<>());

        EntitySelectRuleDTO entitySelectRuleDTO = new EntitySelectRuleDTO();
        entitySelectRuleDTO.setEntityId("ZTO^^^87087");
        entitySelectRuleDTO.setType(PolicyCustomTypeEnum.EXPRESS.getType());
        Map<String, List<String>> attrMap = new HashMap<>();
        attrMap.put(PolicyEntityAttrEnum.SIGN_PROTOCOL.getCode(), Arrays.asList("String"));
        // Run the method to be tested
        Map<String, Boolean> result = policyEntityAttrManagerImpl.hasAttr(entitySelectRuleDTO,attrMap );

        Assert.assertNotNull(result);
        Assert.assertFalse(result.get(PolicyEntityAttrEnum.SIGN_PROTOCOL.getCode()));
    }
}