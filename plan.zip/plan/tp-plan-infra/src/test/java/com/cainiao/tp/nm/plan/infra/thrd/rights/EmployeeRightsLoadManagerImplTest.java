package com.cainiao.tp.nm.plan.infra.thrd.rights;

import com.alibaba.cainiao.tp.trc.org.client.domain.employee.output.TpAccountDTO;
import com.alibaba.cainiao.tp.trc.org.client.domain.employee.output.TpEmployeeDetailDTO;
import com.alibaba.fastjson.JSON;
import com.base.BaseTest;
import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.aladdin.reslut.PageResult;
import com.cainiao.tp.nm.plan.infra.wrapper.division.TcsChinaDivisionManagerWrapper;
import com.cainiao.tp.nm.plan.infra.wrapper.org.TpEmployeeManager;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.PolicyOpRightsVO;
import com.cainiao.tp.nm.plan.infra.port.policy.CacheManager;
import com.cainiao.tps.control.org.client.api.newOrg.TpsNewOrgDeptService;
import com.cainiao.tps.control.org.client.constant.HcmOmOrgCodeEnum;
import com.cainiao.tps.control.org.client.model.dto.dept.TpsOrgDeptDTO;
import com.taobao.biz.common.division.newera.vo.ChinaDivisionLevel;
import com.taobao.biz.common.division.newera.vo.ChinaDivisionVO;
import com.taobao.biz.common.division.newera.vo.DivisionVO;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.*;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class EmployeeRightsLoadManagerImplTest extends BaseTest {

    @InjectMocks
    private EmployeeRightsLoadManagerImpl employeeRightsLoadManager;

    @Mock
    private CacheManager cacheManager;

    @Mock
    private TpEmployeeManager tpEmployeeManager;
    @Mock
    private TcsChinaDivisionManagerWrapper tcsChinaDivisionManagerWrapper;
    @Mock
    private List<String> CITY_UPPER_DIRECT_DEPT_LIST;
    @Mock
    private AbstractOperation opInfo;
    @Mock
    private TpsNewOrgDeptService tpsNewOrgDeptService;

    @Test
    // 测试员工角色从缓存中获取成功
    public void testGetEmployeeRolesCacheHit() {
        Long employeeId = 1L;
        List<String> cachedRoles = Arrays.asList("ROLE_USER", "ROLE_ADMIN");
        Set<String> expectRoleCodes = new HashSet<>(Arrays.asList("ROLE_USER", "ROLE_ADMIN"));
        String cacheKey = EmployeeRightsLoadManagerImpl.CACHE_KEY_EMPLOYEE_ROLES + employeeId;

        // 模拟cacheManager的行为
//        when(cacheManager.get(cacheKey, List.class)).thenReturn(cachedRoles);

        TpEmployeeDetailDTO employeeDetailDTO = new TpEmployeeDetailDTO();
        when(tpEmployeeManager.getEmployee(any(), any())).thenReturn(employeeDetailDTO);

        List<String> result = employeeRightsLoadManager.getEmployeeRoles(employeeId,expectRoleCodes);

//        assertEquals(cachedRoles, result);
//        verify(cacheManager, times(1)).get(cacheKey, List.class);
        // verify(tpEmployeeManager, never()).getEmployee(anyLong(), any());
        // */
    }

    /**
     * 测试方法：验证用户有全国权限的场景
     */
    @Test
    public void testGetDivisionRightsWithCnLevelRights() {
        Long employeeId = 1L;
        String cacheKey = EmployeeRightsLoadManagerImpl.CACHE_KEY_DIVISION_RIGHTS + employeeId;

        // Mock返回值
        TpsOrgDeptDTO deptDTO = mock(TpsOrgDeptDTO.class);
        when(deptDTO.getLevelCode()).thenReturn("CN");
        List<TpsOrgDeptDTO> deptList = Collections.singletonList(deptDTO);

        // Mock tpEmployeeManager的行为
        when(tpEmployeeManager.queryDeptByEmployeeId(employeeId, HcmOmOrgCodeEnum.YZ_MERGE_OPERATE.getBizDomain())).thenReturn(deptList);

        // 调用getDivisionRights方法
        PolicyOpRightsVO result = employeeRightsLoadManager.getDivisionRights(employeeId);

        // 断言结果
        assertTrue(result.isHasCnRights());
        // verify(cacheManager, times(1)).set(cacheKey, result, 60 * 60 * 24); // 这里会在测试中执行，不必要校验
    }

    /**
     * 测试方法：验证用户没有任何部门权限的场景
     */
    @Test
    public void testGetDivisionRightsNoDepartments() {
        Long employeeId = 2L;
        String cacheKey = EmployeeRightsLoadManagerImpl.CACHE_KEY_DIVISION_RIGHTS + employeeId;

        // Mock返回值
        when(tpEmployeeManager.queryDeptByEmployeeId(employeeId, HcmOmOrgCodeEnum.YZ_MERGE_OPERATE.getBizDomain())).thenReturn(
            Collections.emptyList());

        // 调用getDivisionRights方法
        PolicyOpRightsVO result = employeeRightsLoadManager.getDivisionRights(employeeId);

        // 断言结果
        assertFalse(result.isHasCnRights());
        // verify(cacheManager, times(1)).set(cacheKey, result, 60 * 60 * 24); // 这里会在测试中执行，不必要校验
    }

    /**
     * 测试方法：验证用户部门权限为城市以上权限的场景
     */
    @Test
    public void testGetDivisionRightsWithSubDepartments() {
        Long employeeId = 3L;
        String cacheKey = EmployeeRightsLoadManagerImpl.CACHE_KEY_DIVISION_RIGHTS + employeeId;

        // Mock返回值
        TpsOrgDeptDTO deptDTO = new TpsOrgDeptDTO();
        deptDTO.setLevelCode("CT");
        deptDTO.setPermissionData("100");
        List<TpsOrgDeptDTO> deptList = Collections.singletonList(deptDTO);

        when(tpEmployeeManager.queryDeptByEmployeeId(employeeId, HcmOmOrgCodeEnum.YZ_MERGE_OPERATE.getBizDomain())).thenReturn(deptList);

        // Mock tcsChinaDivisionManagerWrapper的行为
        DivisionVO divisionVO = new ChinaDivisionVO();
        divisionVO.setDivisionId(100L);
        divisionVO.setDivisionLevel(ChinaDivisionLevel.CITY.getLevel());
//        when(tcsChinaDivisionManagerWrapper.getChildDivision(anyLong())).thenReturn(Collections.singletonList(divisionVO));

        DivisionVO divisionVO1 = new ChinaDivisionVO();
        divisionVO1.setDivisionId(100L);
        divisionVO1.setDivisionLevel(ChinaDivisionLevel.CITY.getLevel());
        when(tcsChinaDivisionManagerWrapper.getDivisionDetail(anyLong())).thenReturn(divisionVO1);

        // 调用getDivisionRights方法
        PolicyOpRightsVO result = employeeRightsLoadManager.getDivisionRights(employeeId);

        // 断言结果
        assertNotNull(result.getCityCodes());
        assertEquals(1, result.getCityCodes().size());
        assertTrue(result.getCityCodes().contains(100L));
        // verify(cacheManager, times(1)).set(cacheKey, result, 60 * 60 * 24); // 这里会在测试中执行，不必要校验
    }

    /**
     * 测试方法：验证用户部门权限为省份权限的场景
     */
    @Test
    public void testGetDivisionRightsWithProvDepartments() {
        Long employeeId = 3L;
        String cacheKey = EmployeeRightsLoadManagerImpl.CACHE_KEY_DIVISION_RIGHTS + employeeId;

        // Mock返回值
        TpsOrgDeptDTO deptDTO = new TpsOrgDeptDTO();
        deptDTO.setLevelCode("RG");
        deptDTO.setPermissionData("100");
        List<TpsOrgDeptDTO> deptList = Collections.singletonList(deptDTO);

        when(tpEmployeeManager.queryDeptByEmployeeId(employeeId, HcmOmOrgCodeEnum.YZ_MERGE_OPERATE.getBizDomain())).thenReturn(deptList);

        // Mock tcsChinaDivisionManagerWrapper的行为
        DivisionVO divisionVO = new ChinaDivisionVO();
        divisionVO.setDivisionId(100L);
        divisionVO.setDivisionLevel(ChinaDivisionLevel.CITY.getLevel());
        when(tcsChinaDivisionManagerWrapper.getChildDivision(anyLong())).thenReturn(Collections.singletonList(divisionVO));

        DivisionVO divisionVO1 = new ChinaDivisionVO();
        divisionVO1.setDivisionId(100L);
        divisionVO1.setDivisionLevel(ChinaDivisionLevel.PROV.getLevel());
        when(tcsChinaDivisionManagerWrapper.getDivisionDetail(anyLong())).thenReturn(divisionVO1);

        // 调用getDivisionRights方法
        PolicyOpRightsVO result = employeeRightsLoadManager.getDivisionRights(employeeId);

        // 断言结果
        assertNotNull(result.getCityCodes());
        assertEquals(1, result.getCityCodes().size());
        assertTrue(result.getCityCodes().contains(100L));
        // verify(cacheManager, times(1)).set(cacheKey, result, 60 * 60 * 24); // 这里会在测试中执行，不必要校验
    }

    /**
     * 测试方法：验证获取用户权限时的缓存机制
     */
    @Test
    public void testGetDivisionRightsCacheUtilization() {
        Long employeeId = 5L;
        String cacheKey = EmployeeRightsLoadManagerImpl.CACHE_KEY_DIVISION_RIGHTS + employeeId;

        // Mock返回的权限对象
        PolicyOpRightsVO cachedRights = new PolicyOpRightsVO();
        cachedRights.setHasCnRights(false);
        when(cacheManager.get(cacheKey, PolicyOpRightsVO.class)).thenReturn(cachedRights);

        // 调用getDivisionRights方法
        PolicyOpRightsVO result = employeeRightsLoadManager.getDivisionRights(employeeId);

        // 断言结果
        assertFalse(result.isHasCnRights());
        verify(tpEmployeeManager, never()).queryDeptByEmployeeId(anyLong(), any()); // 确认未调用下层查询
    }

    @Before
    public void setUp() throws Exception {MockitoAnnotations.openMocks(this);}

    @Test
    public void testGetCnUserId() {
        // Setup, prepare mock data
        TpEmployeeDetailDTO tpEmployeeDetailDTO = new TpEmployeeDetailDTO();
        tpEmployeeDetailDTO.setBindAccounts(JSON.parseArray(getBindUserInfo(), TpAccountDTO.class));
        when(tpEmployeeManager.getEmployee(anyLong(), any()))
            .thenReturn(tpEmployeeDetailDTO);

        // Prepare method arguments

        // Run the method to be tested
        String result = employeeRightsLoadManager.getCnUserId(1L);

        // Verify the result
        assertEquals("2212785786788", result);
    }

    private String getBindUserInfo() {
        return "[{\"accountId\":\"3401621\",\"accountType\":\"BUC\",\"employeeId\":95932,\"id\":154172,\"outLoginAccountId\":\"3401621\",\"gmtCreate\":1704702124000},{\"accountId\":\"WB01885371\",\"accountType\":\"EMP\",\"employeeId\":95932,\"id\":154173,\"outLoginAccountId\":\"\",\"gmtCreate\":1704702124000},{\"accountId\":\"30592432\",\"accountType\":\"CNEMP\",\"employeeId\":95932,\"id\":154174,\"outLoginAccountId\":\"\",\"gmtCreate\":1704702124000},{\"accountId\":\"3401621\",\"accountType\":\"DINGDING\",\"employeeId\":95932,\"id\":154175,\"outLoginAccountId\":\"1372528806\",\"gmtCreate\":1704702124000,\"accountNick\":\"17609182767\"},{\"accountId\":\"2212785786788\",\"accountType\":\"CN_USER\",\"employeeId\":95932,\"id\":167246,\"outLoginAccountId\":\"\",\"gmtCreate\":1744716444000,\"accountNick\":\"cn9542093238042190\"}]";
    }

    @Test
    public void testSelectRegionDeptCode(){


        PageResult<List<TpsOrgDeptDTO>> tpsOrgDeptPageResult = new PageResult<>();
        List<TpsOrgDeptDTO> tpsOrgDeptDTOList2 = new ArrayList<>();
        TpsOrgDeptDTO tpsOrgDeptDTO2 = new TpsOrgDeptDTO();
        tpsOrgDeptDTO2.setDeptCode("100");
        tpsOrgDeptDTOList2.add(tpsOrgDeptDTO2);

        tpsOrgDeptPageResult.setData(tpsOrgDeptDTOList2);
        tpsOrgDeptPageResult.setSuccess(true);
        tpsOrgDeptPageResult.setTotalCount(1);
        when(tpsNewOrgDeptService.queryDeptWithCondition(any()))
            .thenReturn(tpsOrgDeptPageResult);

        // Prepare method arguments

        // Run the method to be tested
        String result = employeeRightsLoadManager.selectRegionDeptCode("1");

        // Verify the result
        assertEquals("100", result);
    }

    @Test
    public void testSelectRegionDeptCode_empty(){
        // Setup, prepare mock data
        List<TpsOrgDeptDTO> tpsOrgDeptDTOList = new ArrayList<>();
        TpsOrgDeptDTO tpsOrgDeptDTO = new TpsOrgDeptDTO();
        tpsOrgDeptDTO.setAddressCode(Arrays.asList("100"));
        tpsOrgDeptDTOList.add(tpsOrgDeptDTO);
//        when(tpEmployeeManager.queryDeptByEmployeeId(anyLong(), anyString()))
//            .thenReturn(tpsOrgDeptDTOList);

        PageResult<List<TpsOrgDeptDTO>> tpsOrgDeptPageResult = new PageResult<>();
        tpsOrgDeptPageResult.setData(new ArrayList<>());
        tpsOrgDeptPageResult.setSuccess(true);
        tpsOrgDeptPageResult.setTotalCount(1);
        when(tpsNewOrgDeptService.queryDeptWithCondition(any()))
            .thenReturn(tpsOrgDeptPageResult);

        // Prepare method arguments

        // Run the method to be tested
        try {
            employeeRightsLoadManager.selectRegionDeptCode("1");
        }catch (AladdinBizException e){
            Assert.assertEquals("查询大区部门失败", e.getMessage());
        }

    }


    @Test
    public void testGetEmployeeHighestLevelCode(){
        TpsOrgDeptDTO tpsOrgDeptDTO = new TpsOrgDeptDTO();
        tpsOrgDeptDTO.setLevelCode("100");
        // Setup, prepare mock data
        when(tpEmployeeManager.getEmployeeHighestDept(anyLong(), anyString()))
            .thenReturn(tpsOrgDeptDTO);

        // Prepare method arguments

        // Run the method to be tested
        String result = employeeRightsLoadManager.getEmployeeHighestLevelCode(1L);

        // Verify the result
        assertEquals("100", result);
    }
}