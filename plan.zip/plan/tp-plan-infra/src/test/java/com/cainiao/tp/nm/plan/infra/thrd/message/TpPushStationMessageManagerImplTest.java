package com.cainiao.tp.nm.plan.infra.thrd.message;

import com.cainiao.aladdin.env.SystemEnvUtil;
import com.cainiao.aladdin.operation.SystemBizOperation;
import com.cainiao.aladdin.reslut.Result;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.NewStaPerformSubsidyPopConfigDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.NewStaPerformNextLadderDTO;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyConfigManager;
import com.cainiao.tps.channel.common.domain.message.TpMessageDTO;
import com.cainiao.tps.channel.request.TpMessageCreateRequest;
import com.cainiao.tps.channel.service.TpMessageService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class TpPushStationMessageManagerImplTest {

    @Mock
    private PolicyConfigManager policyConfigManager;

    @Mock
    private TpMessageService tpMessageService;

    @InjectMocks
    private TpPushStationMessageManagerImpl tpPushStationMessageManager;

    /**
     * 测试发送激励活动消息时，配置为空的场景。
     */
    @Test
    public void testSendNewStaPerformSubsidyPopupConfigIsNull() {
        // 当 policyConfigManager 返回 null
        when(policyConfigManager.getNewStaPerformSubsidyPopConfig()).thenReturn(null);

        // 执行方法
        tpPushStationMessageManager.sendNewStaPerformSubsidyPopup(1L);

        // 验证没有发送消息
        verify(tpMessageService, never()).standardCreateMessage(any(), any());
    }

    /**
     * 测试发送激励活动消息时，配置不可发送的场景。
     */
    @Test
    public void testSendNewStaPerformSubsidyPopupConfigCannotSend() {
        // 创建一个配置对象并将 canSendPop 设置为 false
        NewStaPerformSubsidyPopConfigDTO popConfig = mock(NewStaPerformSubsidyPopConfigDTO.class);
        when(popConfig.getCanSendPop()).thenReturn(false);
        when(policyConfigManager.getNewStaPerformSubsidyPopConfig()).thenReturn(popConfig);

        // 执行方法
        tpPushStationMessageManager.sendNewStaPerformSubsidyPopup(1L);

        // 验证没有发送消息
        verify(tpMessageService, never()).standardCreateMessage(any(), any());
    }

    /**
     * 测试成功发送激励活动消息的场景。
     */
    @Test
    public void testSendNewStaPerformSubsidyPopupSuccess() {
        SystemEnvUtil.initEnv("PRE");
        // 创建一个有效的配置对象
        NewStaPerformSubsidyPopConfigDTO popConfig = mock(NewStaPerformSubsidyPopConfigDTO.class);
        when(popConfig.getCanSendPop()).thenReturn(true);
        when(popConfig.getTitle()).thenReturn("测试标题");
        when(popConfig.getContent()).thenReturn("测试内容");
        when(popConfig.getGoToUrl()).thenReturn("http://example.com");
        when(popConfig.getSourceCode()).thenReturn("source_code");
        when(popConfig.getImageUrl()).thenReturn("http://example.com/image.jpg");
        when(policyConfigManager.getNewStaPerformSubsidyPopConfig()).thenReturn(popConfig);

        // 模拟 tpMessageService 返回成功结果
        Result<List<TpMessageDTO>> result = Result.create(Collections.emptyList());
        when(tpMessageService.standardCreateMessage(any(TpMessageCreateRequest.class), any()))
                .thenReturn(result);

        // 执行方法
        tpPushStationMessageManager.sendNewStaPerformSubsidyPopup(1L);

        // 验证消息发送方法被调用
        verify(tpMessageService, times(1)).standardCreateMessage(any(), any());
    }

    // 测试发送补贴消息成功的情况
    @Test
    public void testSendNewStaPerformSubsidySatisfyPopupSuccess() {
        // 准备模拟返回结果
        Result<List<TpMessageDTO>> mockResult = Result.create();
        when(tpMessageService.standardCreateMessage(any(TpMessageCreateRequest.class), any(SystemBizOperation.class)))
                .thenReturn(mockResult);

        NewStaPerformNextLadderDTO nextLadderDTO = new NewStaPerformNextLadderDTO();
        nextLadderDTO.setNextSubOrder(1);
        nextLadderDTO.setNextSubsidy(100.0);
        nextLadderDTO.setIsTop(true);

        // 调用要测试的方法
        tpPushStationMessageManager.sendNewStaPerformSubsidySatisfyPopup(100L, nextLadderDTO, "http://example.com");

        // 验证服务方法被调用
        verify(tpMessageService).standardCreateMessage(any(), any());
    }

    // 测试发送补贴消息失败的情况
    @Test
    public void testSendNewStaPerformSubsidySatisfyPopupFailure() {
        // 准备模拟失败结果
        Result<List<TpMessageDTO>> mockResult = Result.createFailed("给驿站掌柜发送消息失败");
        when(tpMessageService.standardCreateMessage(any(TpMessageCreateRequest.class), any(SystemBizOperation.class)))
                .thenReturn(mockResult);

        NewStaPerformNextLadderDTO nextLadderDTO = new NewStaPerformNextLadderDTO();
        nextLadderDTO.setNextSubOrder(1);
        nextLadderDTO.setNextSubsidy(100.0);
        nextLadderDTO.setIsTop(false);

        // 预期抛出异常
        try {
            tpPushStationMessageManager.sendNewStaPerformSubsidySatisfyPopup(100L, nextLadderDTO, "http://example.com");
        } catch (Exception e) {
            // 这里可以检查异常信息
            assertEquals("给驿站掌柜发送消息失败", e.getMessage());
        }

        // 验证服务方法被调用
        verify(tpMessageService).standardCreateMessage(any(), any());
    }

    // 测试发送消息的跳转链接设置
    @Test
    public void testSendNewStaPerformSubsidySatisfyPopupWithJumpUrl() {
        // 准备模拟返回结果
        Result<List<TpMessageDTO>> mockResult = Result.create();
        when(tpMessageService.standardCreateMessage(any(TpMessageCreateRequest.class), any(SystemBizOperation.class)))
                .thenReturn(mockResult);

        NewStaPerformNextLadderDTO nextLadderDTO = new NewStaPerformNextLadderDTO();
        nextLadderDTO.setIsTop(true);

        // 调用要测试的方法
        tpPushStationMessageManager.sendNewStaPerformSubsidySatisfyPopup(200L, nextLadderDTO, "http://example.com");

        // 验证服务方法被调用
        verify(tpMessageService).standardCreateMessage(any(), any());
    }

    // 测试当 isTop 为 false 时的处理
    @Test
    public void testSendNewStaPerformSubsidySatisfyPopupWithIsTopFalse() {
        // 准备模拟返回结果
        Result<List<TpMessageDTO>> mockResult = Result.create();
        when(tpMessageService.standardCreateMessage(any(TpMessageCreateRequest.class), any(SystemBizOperation.class)))
                .thenReturn(mockResult);

        NewStaPerformNextLadderDTO nextLadderDTO = new NewStaPerformNextLadderDTO();
        nextLadderDTO.setNextSubOrder(2);
        nextLadderDTO.setNextSubsidy(200.0);
        nextLadderDTO.setIsTop(false);

        // 调用要测试的方法
        tpPushStationMessageManager.sendNewStaPerformSubsidySatisfyPopup(300L, nextLadderDTO, "http://example.com");

        // 验证服务方法被调用
        verify(tpMessageService).standardCreateMessage(any(), any());
    }
}