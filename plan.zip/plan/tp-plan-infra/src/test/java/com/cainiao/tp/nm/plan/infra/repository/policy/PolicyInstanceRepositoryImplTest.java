package com.cainiao.tp.nm.plan.infra.repository.policy;

import com.base.BaseTest;
import com.cainiao.sutee.commons.base.model.Page;
import com.cainiao.tp.nm.plan.infra.mybatis.dto.PageResult;
import com.cainiao.tp.nm.plan.infra.repository.policy.convert.PolicyInstanceConvertor;
import com.cainiao.tp.nm.plan.infra.repository.policy.dto.data.PolicyInstanceDO;
import com.cainiao.tp.nm.plan.infra.repository.policy.dto.data.PolicyRuleInstanceDO;
import com.cainiao.tp.nm.plan.infra.repository.policy.dto.param.PolicyInstanceQueryParam;
import com.cainiao.tp.nm.plan.infra.repository.policy.dto.param.PolicyRuleInstanceQueryParam;
import com.cainiao.tp.nm.plan.infra.repository.policy.mapper.PolicyInstanceMapper;
import com.cainiao.tp.nm.plan.infra.repository.policy.mapper.PolicyRuleInstanceMapper;
import com.cainiao.tp.nm.plan.policy.domain.model.PolicyInstance;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.*;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.when;

/**
 * <a href="https://alidocs.dingtalk.com/i/nodes/dpYLaezmVNRMGX56C1aKjlBOVrMqPxX6">单元测试编写&生成FAQ</a>
 * Created By Thub IDEA插件
 *
 * @Date 2025/6/16 11:40
 */
@RunWith(MockitoJUnitRunner.class)
public class PolicyInstanceRepositoryImplTest extends BaseTest {

    @InjectMocks
    private PolicyInstanceRepositoryImpl policyInstanceRepositoryImpl;
    @Mock
    private PolicyInstanceMapper policyInstanceMapper;
    @Mock
    private PolicyRuleInstanceMapper policyRuleInstanceMapper;
    @Mock
    private PolicyInstanceConvertor policyInstanceConvertor;
    @InjectMocks
    private PolicyInstanceRepositoryImpl policyInstanceRepository;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testQueryPolicyInstanceList() {
        com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyInstanceQueryParam queryParam = new com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyInstanceQueryParam();
        queryParam.setStatus((byte) 1);
        queryParam.setApprovalStatus((byte) 1);
        Map<String, Boolean> orderFieldNameMap = Maps.newHashMap();
        orderFieldNameMap.put("id", true);
        queryParam.setOrderFieldNameMap(orderFieldNameMap);

        PageResult<PolicyInstanceDO> pageResult = new PageResult<>();
        pageResult.setTotal(1L);
        PolicyInstanceDO policyInstanceDO = new PolicyInstanceDO();
        policyInstanceDO.setId(1L);
        pageResult.setData(Arrays.asList(policyInstanceDO));
        when(policyInstanceMapper.selectPage(Mockito.any())).thenReturn(pageResult);

        List<PolicyInstance> policyInstances = new ArrayList<>();
        PolicyInstance policyInstance = PolicyInstance.builder().id(1L).build();
        policyInstances.add(policyInstance);
        when(policyInstanceConvertor.doToModelList(Mockito.anyList())).thenReturn(policyInstances);
        Page<PolicyInstance> result = policyInstanceRepositoryImpl.queryPolicyInstanceList(queryParam);

        // Verify the result
        Assert.assertNotNull(result);
        Assert.assertEquals(1L, result.getPageTotal());
        Assert.assertEquals(1, result.getPageItems().size());

    }

    /**
     * 测试获取实例时，输入的ID不存在，期望返回null。
     */
    @Test
    public void testGetInstanceIdDoesNotExist() {
        Long instanceId = 1L;
        when(policyInstanceMapper.selectById(instanceId)).thenReturn(null);

        PolicyInstance result = policyInstanceRepository.get(instanceId);

        assertNull(result); // 期望返回null，因为没有找到对应的策略实例
    }

    /**
     * 测试获取实例时，输入的ID存在，且对应的策略规则实例为空，期望返回一个转换后的PolicyInstance对象。
     */
    @Test
    public void testGetInstanceIdExistsWithEmptyRuleList() {
        Long instanceId = 1L;
        PolicyInstanceDO policyInstanceDO = new PolicyInstanceDO();
        when(policyInstanceMapper.selectById(instanceId)).thenReturn(policyInstanceDO);
        when(policyRuleInstanceMapper.selectAll(any(PolicyRuleInstanceQueryParam.class))).thenReturn(Collections.emptyList());
        when(policyInstanceConvertor.doToModel(policyInstanceDO)).thenReturn(PolicyInstance.builder().build());
        when(policyInstanceConvertor.doToPolicyRuleInstance(Collections.emptyList())).thenReturn(Collections.emptyList());

        PolicyInstance result = policyInstanceRepository.get(instanceId);

        assertNotNull(result); // 期望返回非null的PolicyInstance对象
        // verify(policyInstanceConvertor).doToPolicyRuleInstance(Collections.emptyList()); // 验证方法调用
    }

    /**
     * 测试获取实例时，输入的ID存在且有对应的策略规则实例，期望返回一个转换后的PolicyInstance对象，且规则列表不为空。
     */
    @Test
    public void testGetInstanceIdExistsWithRuleList() {
        Long instanceId = 1L;
        PolicyInstanceDO policyInstanceDO = new PolicyInstanceDO();
        when(policyInstanceMapper.selectById(instanceId)).thenReturn(policyInstanceDO);

        PolicyRuleInstanceDO ruleInstanceDO = new PolicyRuleInstanceDO();
        List<PolicyRuleInstanceDO> ruleInstances = Collections.singletonList(ruleInstanceDO);
        when(policyRuleInstanceMapper.selectAll(any(PolicyRuleInstanceQueryParam.class))).thenReturn(ruleInstances);
        when(policyInstanceConvertor.doToModel(policyInstanceDO)).thenReturn(PolicyInstance.builder().build());
//        when(policyInstanceConvertor.doToPolicyRuleInstance(ruleInstances)).thenReturn(Lists.newArrayList());

        PolicyInstance result = policyInstanceRepository.get(instanceId);

        assertNotNull(result); // 期望返回非null的PolicyInstance对象
        // verify(policyInstanceConvertor).doToPolicyRuleInstance(ruleInstances); // 验证方法调用
    }

    /**
     * 测试当模板ID和激励方案类型有效时, 返回的政策实例列表不为空
     */
    @Test
    public void testListByTemplateValidInputReturnPolicyInstances() {
        Long templateId = 1L;
        String incentivePlanType = "testPlanType";

        PolicyInstanceDO policyInstanceDO = new PolicyInstanceDO();
        policyInstanceDO.setId(1L);
        List<PolicyInstanceDO> policyInstanceDOS = Collections.singletonList(policyInstanceDO);


        when(policyInstanceMapper.selectAll(any(PolicyInstanceQueryParam.class))).thenReturn(policyInstanceDOS);
        when(policyInstanceConvertor.doToModelList(policyInstanceDOS)).thenReturn(Lists.newArrayList());

//        when(policyRuleInstanceMapper.selectAll(any())).thenReturn(Collections.emptyList());
//        when(policyInstanceConvertor.doToPolicyRuleInstance(anyList())).thenReturn(Collections.emptyList());

        List<PolicyInstance> result = policyInstanceRepository.listByTemplate(templateId, incentivePlanType);

        assertNotNull(result);
//        assertEquals(1, result.size());
    }


}