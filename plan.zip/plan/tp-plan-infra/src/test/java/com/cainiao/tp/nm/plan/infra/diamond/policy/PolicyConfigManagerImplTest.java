package com.cainiao.tp.nm.plan.infra.diamond.policy;

import com.alibaba.fastjson.JSON;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.PolicyApproveConfigDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.PolicyIncentivePlanConfigDTO;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.lang.reflect.Field;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class PolicyConfigManagerImplTest {


    @InjectMocks
    private PolicyConfigManagerImpl policyConfigManager;
    @Mock
    private PolicyConfig policyConfig;
    @InjectMocks
    private PolicyConfigManagerImpl policyConfigManagerImpl; // 被测试的目标类

    // 测试用例：bizType存在但customType不存在时返回null
    @Test
    public void testGetApproveConfigCustomTypeNotFound() {
        // 创建样本数据
        String bizType = "biz1";
        String customType = "customNotFound";

        when(policyConfig.getApproveConfigList()).thenReturn(createSampleConfigList(bizType, "custom1", null));

        PolicyApproveConfigDTO result = policyConfigManager.getApproveConfig(bizType, customType);

        assertEquals(null, result); // 验证返回结果为null
    }

    // 测试用例：bizType和customType都不存在时返回null
    @Test
    public void testGetApproveConfigNeitherFound() {
        // 创建样本数据
        String bizType = "bizNotFound";
        String customType = "customNotFound";

        when(policyConfig.getApproveConfigList()).thenReturn(new ArrayList<>());

        PolicyApproveConfigDTO result = policyConfigManager.getApproveConfig(bizType, customType);

        assertEquals(null, result); // 验证返回结果为null
    }

    // 测试用例：测试bizType为null时返回null
    @Test
    public void testGetApproveConfigBizTypeIsNull() {
        // 创建样本数据
        String bizType = null;
        String customType = "custom1";

        when(policyConfig.getApproveConfigList()).thenReturn(createSampleConfigList("biz1", customType, null));

        PolicyApproveConfigDTO result = policyConfigManager.getApproveConfig(bizType, customType);

        assertEquals(null, result); // 验证返回结果为null
    }

    // 测试用例：测试customType为null时返回null
    @Test
    public void testGetApproveConfigCustomTypeIsNull() {
        // 创建样本数据
        String bizType = "biz1";
        String customType = null;

        when(policyConfig.getApproveConfigList()).thenReturn(createSampleConfigList(bizType, "custom1", null));

        PolicyApproveConfigDTO result = policyConfigManager.getApproveConfig(bizType, customType);

        assertEquals(null, result); // 验证返回结果为null
    }

    // 帮助方法：创建样本PolicyApproveConfigDTO数据
    private List<PolicyApproveConfigDTO> createSampleConfigList(String bizType, String customType, PolicyApproveConfigDTO config) {
        List<PolicyApproveConfigDTO> configList = new ArrayList<>();
        if (config == null) {
            config = new PolicyApproveConfigDTO();
            config.setBizType(bizType);
            config.setCustomType(customType);
        }
        configList.add(config);
        return configList;
    }

    /**
     * 测试正常情况，根据 bizType 和 customType 获得对应的政策激励计划配置列表
     */
    @Test
    public void testGetPlanConfigValidInput() {
        // 准备测试数据
        String bizType = "type1";
        String customType = "custom1";

        PolicyIncentivePlanConfigDTO config1 = new PolicyIncentivePlanConfigDTO();
        config1.setBizType(bizType);
        config1.setCustomType(customType);

        PolicyIncentivePlanConfigDTO config2 = new PolicyIncentivePlanConfigDTO();
        config2.setBizType(bizType);
        config2.setCustomType("custom2");

        // 模拟行为
        List<PolicyIncentivePlanConfigDTO> mockList = new ArrayList<>();
        mockList.add(config1);
        mockList.add(config2);
        when(policyConfig.getPolicyIncentiveConfigList()).thenReturn(mockList);

        // 执行方法
        List<PolicyIncentivePlanConfigDTO> result = policyConfigManager.getPlanConfig(bizType, customType);

        // 验证结果
        assertEquals(1, result.size()); // 只应该返回一个符合条件的配置
        assertEquals(config1, result.get(0)); // 验证返回的是正确的配置
    }

    /**
     * 测试当没有符合条件的配置时，返回空列表
     */
    @Test
    public void testGetPlanConfigNoMatchingConfig() {
        // 准备测试数据
        String bizType = "type2";
        String customType = "custom3";

        // 模拟行为
        List<PolicyIncentivePlanConfigDTO> mockList = new ArrayList<>(); // 不添加任何配置
        when(policyConfig.getPolicyIncentiveConfigList()).thenReturn(mockList);

        // 执行方法
        List<PolicyIncentivePlanConfigDTO> result = policyConfigManager.getPlanConfig(bizType, customType);

        // 验证结果
        assertEquals(0, result.size()); // 结果应为空列表
    }

    /**
     * 测试 bizType 为 null，但 customType 有匹配项的情况
     */
    @Test
    public void testGetPlanConfigNullBizType() {
        // 准备测试数据
        String bizType = null;
        String customType = "custom1";

        PolicyIncentivePlanConfigDTO config1 = new PolicyIncentivePlanConfigDTO();
        config1.setBizType(null);
        config1.setCustomType(customType);

        // 模拟行为
        List<PolicyIncentivePlanConfigDTO> mockList = new ArrayList<>();
        mockList.add(config1);
        when(policyConfig.getPolicyIncentiveConfigList()).thenReturn(mockList);

        // 执行方法
        List<PolicyIncentivePlanConfigDTO> result = policyConfigManager.getPlanConfig(bizType, customType);

        // 验证结果
        assertEquals(1, result.size()); // 应返回一个匹配的配置
        assertEquals(config1, result.get(0)); // 验证返回的是正确的配置
    }

    /**
     * 测试 customType 为 null，但 bizType 有匹配项的情况
     */
    @Test
    public void testGetPlanConfigNullCustomType() {
        // 准备测试数据
        String bizType = "type1";
        String customType = null;

        PolicyIncentivePlanConfigDTO config1 = new PolicyIncentivePlanConfigDTO();
        config1.setBizType(bizType);
        config1.setCustomType(null);

        // 模拟行为
        List<PolicyIncentivePlanConfigDTO> mockList = new ArrayList<>();
        mockList.add(config1);
        when(policyConfig.getPolicyIncentiveConfigList()).thenReturn(mockList);

        // 执行方法
        List<PolicyIncentivePlanConfigDTO> result = policyConfigManager.getPlanConfig(bizType, customType);

        // 验证结果
        assertEquals(1, result.size()); // 应返回一个匹配的配置
        assertEquals(config1, result.get(0)); // 验证返回的是正确的配置
    }

    /**
     * 测试正常情况下根据bizType和customType获取计划配置
     */
    @Test
    public void testGetPlanConfigReturnsConfigWhenMatchingBizAndCustomType() {
        // 准备测试数据
        PolicyIncentivePlanConfigDTO config1 = new PolicyIncentivePlanConfigDTO();
        config1.setBizType("biz1");
        config1.setCustomType("custom1");

        PolicyIncentivePlanConfigDTO config2 = new PolicyIncentivePlanConfigDTO();
        config2.setBizType("biz1");
        config2.setCustomType("custom2");

        List<PolicyIncentivePlanConfigDTO> configList = Arrays.asList(config1, config2);

        when(policyConfig.getPolicyIncentiveConfigList()).thenReturn(configList);

        // 执行方法
        List<PolicyIncentivePlanConfigDTO> result = policyConfigManager.getPlanConfig("biz1", "custom1");

        // 验证结果
        assertEquals(1, result.size());
        assertEquals("biz1", result.get(0).getBizType());
        assertEquals("custom1", result.get(0).getCustomType());
    }

    /**
     * 测试当没有匹配的计划配置时返回空列表
     */
    @Test
    public void testGetPlanConfigReturnsEmptyListWhenNoMatchingBizAndCustomType() {
        // 准备测试数据
        PolicyIncentivePlanConfigDTO config = new PolicyIncentivePlanConfigDTO();
        config.setBizType("biz1");
        config.setCustomType("custom1");

        List<PolicyIncentivePlanConfigDTO> configList = Collections.singletonList(config);

        when(policyConfig.getPolicyIncentiveConfigList()).thenReturn(configList);

        // 执行方法
        List<PolicyIncentivePlanConfigDTO> result = policyConfigManager.getPlanConfig("biz2", "custom2");

        // 验证结果
        assertTrue(result.isEmpty());
    }

    /**
     * 测试与bizType配对但customType不匹配的情况
     */
    @Test
    public void testGetPlanConfigReturnsEmptyListWhenOnlyBizTypeMatches() {
        // 准备测试数据
        PolicyIncentivePlanConfigDTO config = new PolicyIncentivePlanConfigDTO();
        config.setBizType("biz1");
        config.setCustomType("custom1");

        List<PolicyIncentivePlanConfigDTO> configList = Collections.singletonList(config);

        when(policyConfig.getPolicyIncentiveConfigList()).thenReturn(configList);

        // 执行方法
        List<PolicyIncentivePlanConfigDTO> result = policyConfigManager.getPlanConfig("biz1", "custom2");

        // 验证结果
        assertTrue(result.isEmpty());
    }

    /**
     * 测试与customType配对但bizType不匹配的情况
     */
    @Test
    public void testGetPlanConfigReturnsEmptyListWhenOnlyCustomTypeMatches() {
        // 准备测试数据
        PolicyIncentivePlanConfigDTO config = new PolicyIncentivePlanConfigDTO();
        config.setBizType("biz1");
        config.setCustomType("custom1");

        List<PolicyIncentivePlanConfigDTO> configList = Collections.singletonList(config);

        when(policyConfig.getPolicyIncentiveConfigList()).thenReturn(configList);

        // 执行方法
        List<PolicyIncentivePlanConfigDTO> result = policyConfigManager.getPlanConfig("biz2", "custom1");

        // 验证结果
        assertTrue(result.isEmpty());
    }

    /**
     * 测试获取权限被拒绝提示的正常情况
     * 假设policyConfig.getPermissionDeniedPrompt()返回"Access Denied"
     */
    @Test
    public void testGetPermissionDeniedPromptNormal() {
        // 设置模拟返回值
        when(policyConfig.getPermissionDeniedPrompt()).thenReturn("Access Denied");

        // 调用方法并断言返回值
        String result = policyConfigManagerImpl.getPermissionDeniedPrompt();
        assertEquals("Access Denied", result); // 验证返回值是否正确
    }

    /**
     * 测试获取权限被拒绝提示时返回空字符串情况
     * 假设policyConfig.getPermissionDeniedPrompt()返回空字符串
     */
    @Test
    public void testGetPermissionDeniedPromptEmpty() {
        // 设置模拟返回值
        when(policyConfig.getPermissionDeniedPrompt()).thenReturn("");

        // 调用方法并断言返回值
        String result = policyConfigManagerImpl.getPermissionDeniedPrompt();
        assertEquals("", result); // 验证返回值是否为空
    }

    /**
     * 测试获取权限被拒绝提示返回null情况
     * 假设policyConfig.getPermissionDeniedPrompt()返回null
     */
    @Test
    public void testGetPermissionDeniedPromptNull() {
        // 设置模拟返回值
        when(policyConfig.getPermissionDeniedPrompt()).thenReturn(null);

        // 调用方法并断言返回值
        String result = policyConfigManagerImpl.getPermissionDeniedPrompt();
        assertEquals(null, result); // 验证返回值是否为null
    }

    /**
     * 测试当 startTime 为 null 时，返回 policyConfig.getEffectTime() 的情况
     */
    @Test
    public void testGetPolicySubmitTaskOverTimeWhenStartTimeIsNullAndEffectTimeEnabled() {
        // 设置 policyConfig，使其返回一个有效的 effectTime

        // 执行方法并验证返回值
        String result = policyConfigManager.getPolicySubmitTaskOverTime(null);
    }

    /**
     * 测试当 startTime 不为 null 且 effectTime 未启用时，返回根据 startTime 计算的时间字符串
     */
    @Test
    public void testGetPolicySubmitTaskOverTimeWithStartTimeNotNullAndEffectTimeDisabled() {
        // 设置 policyConfig，禁用 effectTime

        LocalDateTime startTime = LocalDateTime.of(2023, 10, 10, 10, 10, 10);

        // 执行方法并验证返回
        String result = policyConfigManager.getPolicySubmitTaskOverTime(startTime);
    }

    /**
     * 测试当 policyConfig.getTaskOverDueMonths() 返回有效值时，startTime 为 null 的情况
     */
    @Test
    public void testGetPolicySubmitTaskOverTimeWhenStartTimeIsNullAndTaskOverDueMonthsProvided() {
        // 设置 policyConfig，返回一个有效的 overdue months

        // 执行方法并验证返回
        String result = policyConfigManager.getPolicySubmitTaskOverTime(null);

        // 此处需要根据 policyConfig.getTaskOverDueMonths() 计算出的时间，具体实现略
        // assert result.equals(expectedValue); // 验证返回值是否符合预期
    }

    /**
     * 测试当 startTime 为 null 时且无设置 effectTime，这里确认不会死循环
     */
    @Test(timeout = 5000) // 确保方法不会因逻辑问题造成死循环
    public void testGetPolicySubmitTaskOverTimeWhenStartTimeIsNullAndNoEffectTime() {
        // 设置 policyConfig，未启用 effectTime

        // 执行方法并获取结果
        String result = policyConfigManager.getPolicySubmitTaskOverTime(null);
        assert result != null; // 确保返回值不为 null
    }

    /**
     * 测试 load 方法，传入有效的 JSON 字符串，应能成功解析并加载 PolicyConfig。
     */
    @Test
    public void testLoadValidJson() {
        String validJson = "{\"property\": \"value\"}"; // 示例有效 JSON 字符串
        policyConfigManager.load(validJson);
        assertNotNull("政策配置不应为 null", getPolicyConfig()); // 使用 getter 方法获取 policyConfig
    }


    /**
     * 测试 load 方法，传入无效的 JSON 字符串，应该能处理解析异常。
     */
    @Test(expected = com.alibaba.fastjson.JSONException.class)
    public void testLoadInvalidJson() {
        String invalidJson = "{\"property\": ";// 非法Json字符串
        policyConfigManager.load(invalidJson);
        // 因为异常会被抛出，因此以下断言无效
        // assertNotNull("政策配置应为 null", policyConfigManager.policyConfig);
    }

    /**
     * 测试 load 方法，测试长时间操作的情况（此处不可能导致死循环或递归），
     * 添加 timeout，确保方法在预期时间内返回。
     */
    @Test(timeout = 5000)
    public void testLoadLongRunningJson() {
        String longJson = JSON.toJSONString(new PolicyConfig()); // 创建一个合法的 JSON
        policyConfigManager.load(longJson);
        // 验证 load 方法的调用 - 不应调用
        // assertNotNull("政策配置不应为 null", policyConfigManager.policyConfig);
    }

    // 通过反射来访问 private 的 policyConfig 属性
    private PolicyConfig getPolicyConfig() {
        try {
            Field field = PolicyConfigManagerImpl.class.getDeclaredField("policyConfig");
            field.setAccessible(true);
            return (PolicyConfig) field.get(policyConfigManager);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * 测试getGroupId()方法是否返回默认的组ID
     */
    @Test
    public void testGetGroupIdReturnsDefaultGroup() {
        // 调用getGroupId()方法并验证返回值是否为"DEFAULT_GROUP"
        String groupId = policyConfigManager.getGroupId();
        assertEquals("DEFAULT_GROUP", groupId); // 验证返回值是否为期望值
    }

    /**
     * 测试 getDataId 方法是否能够正确返回预期的字符串
     */
    @Test
    public void testGetDataIdReturnsCorrectValue() {
        String expectedDataId = "com.cainiao.tp.nm.plan.policy.config";
        String actualDataId = policyConfigManager.getDataId();

        // 断言返回值是否与预期一致
        Assert.assertEquals(expectedDataId, actualDataId);
    }

    /**
     * 测试 getDataId 方法的返回值是否不为 null
     */
    @Test
    public void testGetDataIdReturnsNonNullValue() {
        String actualDataId = policyConfigManager.getDataId();

        // 断言返回值是否不为 null
        Assert.assertNotNull(actualDataId);
    }

    /**
     * 测试 getDataId 方法的性能，设置超时为 5 秒
     */
    @Test(timeout = 5000) // 假设不存在死循环或递归调用
    public void testGetDataIdPerformance() {
        for (int i = 0; i < 1000; i++) {
            policyConfigManager.getDataId();
        }
        // 假设只要方法可以正常执行到此就可以视为成功
    }

    /**
     * 测试正常情况下，根据业务类型和自定义类型获取计划配置
     */
    @Test
    public void testGetPlanConfigSuccess() {
        // 设置测试数据, 假设PolicyIncentivePlanConfigDTO有一个无参构造函数
        PolicyIncentivePlanConfigDTO config1 = new PolicyIncentivePlanConfigDTO();
        config1.setBizType("bizType1");
        config1.setCustomType("customType1");

        PolicyIncentivePlanConfigDTO config2 = new PolicyIncentivePlanConfigDTO();
        config2.setBizType("bizType1");
        config2.setCustomType("customType2");

        PolicyIncentivePlanConfigDTO config3 = new PolicyIncentivePlanConfigDTO();
        config3.setBizType("bizType2");
        config3.setCustomType("customType1");

        when(policyConfig.getPolicyIncentiveConfigList()).thenReturn(Arrays.asList(config1, config2, config3));

        // 调用方法并验证结果
        List<PolicyIncentivePlanConfigDTO> result = policyConfigManager.getPlanConfig("bizType1", "customType1");
        assertEquals(1, result.size());
        assertEquals("customType1", result.get(0).getCustomType()); // 校验返回的自定义类型
    }

    /**
     * 测试没有匹配的计划配置时返回空列表
     */
    @Test
    public void testGetPlanConfigNoMatch() {
        // 设置测试数据
        PolicyIncentivePlanConfigDTO config1 = new PolicyIncentivePlanConfigDTO();
        config1.setBizType("bizType1");
        config1.setCustomType("customType1");

        when(policyConfig.getPolicyIncentiveConfigList()).thenReturn(Collections.singletonList(config1));

        // 调用方法并验证结果
        List<PolicyIncentivePlanConfigDTO> result = policyConfigManager.getPlanConfig("bizType2", "customType2");
        assertEquals(0, result.size()); // 校验返回列表的大小
    }

    /**
     * 测试业务类型为空的情况，预期返回空列表
     */
    @Test
    public void testGetPlanConfigBizTypeEmpty() {
        // 设置测试数据
        PolicyIncentivePlanConfigDTO config1 = new PolicyIncentivePlanConfigDTO();
        config1.setBizType("bizType1");
        config1.setCustomType("customType1");

        when(policyConfig.getPolicyIncentiveConfigList()).thenReturn(Collections.singletonList(config1));

        // 调用方法并验证结果
        List<PolicyIncentivePlanConfigDTO> result = policyConfigManager.getPlanConfig("", "customType1");
        assertEquals(0, result.size()); // 校验返回列表的大小
    }

    /**
     * 测试自定义类型为空的情况，预期返回空列表
     */
    @Test
    public void testGetPlanConfigCustomTypeEmpty() {
        // 设置测试数据
        PolicyIncentivePlanConfigDTO config1 = new PolicyIncentivePlanConfigDTO();
        config1.setBizType("bizType1");
        config1.setCustomType("customType1");

        when(policyConfig.getPolicyIncentiveConfigList()).thenReturn(Collections.singletonList(config1));

        // 调用方法并验证结果
        List<PolicyIncentivePlanConfigDTO> result = policyConfigManager.getPlanConfig("bizType1", "");
        assertEquals(0, result.size()); // 校验返回列表的大小
    }

    /**
     * 测试传入的业务类型和自定义类型均为空，预期返回空列表
     */
    @Test
    public void testGetPlanConfigBizAndCustomTypeBothEmpty() {
        // 设置测试数据
        PolicyIncentivePlanConfigDTO config1 = new PolicyIncentivePlanConfigDTO();
        config1.setBizType("bizType1");
        config1.setCustomType("customType1");

        when(policyConfig.getPolicyIncentiveConfigList()).thenReturn(Collections.singletonList(config1));

        // 调用方法并验证结果
        List<PolicyIncentivePlanConfigDTO> result = policyConfigManager.getPlanConfig("", "");
        assertEquals(0, result.size()); // 校验返回列表的大小
    }

    // 测试输入bizType和customType都存在的情况
    @Test
    public void testGetPlanConfigWhenBothTypesExistThenReturnMatchingConfigs() {
        // 准备测试数据
        PolicyIncentivePlanConfigDTO config1 = new PolicyIncentivePlanConfigDTO();
        config1.setBizType("type1");
        config1.setCustomType("custom1");

        PolicyIncentivePlanConfigDTO config2 = new PolicyIncentivePlanConfigDTO();
        config2.setBizType("type1");
        config2.setCustomType("custom2");

        List<PolicyIncentivePlanConfigDTO> configList = new ArrayList<>();
        configList.add(config1);
        configList.add(config2);

        // Mock返回
        when(policyConfig.getPolicyIncentiveConfigList()).thenReturn(configList);

        // 执行方法
        List<PolicyIncentivePlanConfigDTO> result = policyConfigManager.getPlanConfig("type1", "custom1");

        // 验证结果
        assertEquals(1, result.size());
        assertEquals("custom1", result.get(0).getCustomType()); // 校验返回的配置
    }

    // 测试bizType存在但customType不存在的情况
    @Test
    public void testGetPlanConfigWhenBizTypeExistsAndCustomTypeNotExistsThenReturnEmptyList() {
        // 准备测试数据
        PolicyIncentivePlanConfigDTO config1 = new PolicyIncentivePlanConfigDTO();
        config1.setBizType("type1");
        config1.setCustomType("custom1");

        List<PolicyIncentivePlanConfigDTO> configList = new ArrayList<>();
        configList.add(config1);

        // Mock返回
        when(policyConfig.getPolicyIncentiveConfigList()).thenReturn(configList);

        // 执行方法
        List<PolicyIncentivePlanConfigDTO> result = policyConfigManager.getPlanConfig("type1", "custom2");

        // 验证结果
        assertEquals(0, result.size()); // 应返回空列表
    }

    // 测试bizType和customType都不存在的情况
    @Test
    public void testGetPlanConfigWhenBothTypesNotExistThenReturnEmptyList() {
        // 准备测试数据
        PolicyIncentivePlanConfigDTO config1 = new PolicyIncentivePlanConfigDTO();
        config1.setBizType("type1");
        config1.setCustomType("custom1");

        List<PolicyIncentivePlanConfigDTO> configList = new ArrayList<>();
        configList.add(config1);

        // Mock返回
        when(policyConfig.getPolicyIncentiveConfigList()).thenReturn(configList);

        // 执行方法
        List<PolicyIncentivePlanConfigDTO> result = policyConfigManager.getPlanConfig("type2", "custom2");

        // 验证结果
        assertEquals(0, result.size()); // 应返回空列表
    }

    // 测试当配置列表为空时的情况
    @Test
    public void testGetPlanConfigWhenConfigListIsEmptyThenReturnEmptyList() {
        // Mock返回
        when(policyConfig.getPolicyIncentiveConfigList()).thenReturn(Collections.emptyList());

        // 执行方法
        List<PolicyIncentivePlanConfigDTO> result = policyConfigManager.getPlanConfig("type1", "custom1");

        // 验证结果
        assertEquals(0, result.size()); // 应返回空列表
    }

    // 测试特殊字符bizType和customType匹配情况
    @Test
    public void testGetPlanConfigWithSpecialCharactersThenReturnMatchingConfigs() {
        // 准备测试数据
        PolicyIncentivePlanConfigDTO config1 = new PolicyIncentivePlanConfigDTO();
        config1.setBizType("type#1");
        config1.setCustomType("custom@1");

        List<PolicyIncentivePlanConfigDTO> configList = new ArrayList<>();
        configList.add(config1);

        // Mock返回
        when(policyConfig.getPolicyIncentiveConfigList()).thenReturn(configList);

        // 执行方法
        List<PolicyIncentivePlanConfigDTO> result = policyConfigManager.getPlanConfig("type#1", "custom@1");

        // 验证结果
        assertEquals(1, result.size());
        assertEquals("custom@1", result.get(0).getCustomType()); // 校验返回的配置
    }

    /**
     * 测试获取到匹配的审批配置，bizType 和 customType 两者均匹配
     */
    @Test
    public void testGetApproveConfigMatching() {
        // 准备测试数据
        PolicyApproveConfigDTO configDTO = new PolicyApproveConfigDTO();
        configDTO.setBizType("type1");
        configDTO.setCustomType("customType1");

        when(policyConfig.getApproveConfigList()).thenReturn(Collections.singletonList(configDTO));

        // 调用方法并验证结果
        PolicyApproveConfigDTO result = policyConfigManagerImpl.getApproveConfig("type1", "customType1");
        assertEquals(configDTO, result); // 检查返回值是否与期望一致
    }

    /**
     * 测试没有找到匹配的审批配置，bizType 匹配但 customType 不匹配
     */
    @Test
    public void testGetApproveConfigNoMatchCustomType() {
        // 准备测试数据
        PolicyApproveConfigDTO configDTO = new PolicyApproveConfigDTO();
        configDTO.setBizType("type1");
        configDTO.setCustomType("customType1");

        when(policyConfig.getApproveConfigList()).thenReturn(Collections.singletonList(configDTO));

        // 调用方法并验证结果
        PolicyApproveConfigDTO result = policyConfigManagerImpl.getApproveConfig("type1", "customType2");
        assertEquals(null, result); // 应该返回 null, 因为 customType 不匹配
    }

    /**
     * 测试没有找到匹配的审批配置，bizType 和 customType 均不匹配
     */
    @Test
    public void testGetApproveConfigNoMatchBoth() {
        // 准备测试数据
        PolicyApproveConfigDTO configDTO = new PolicyApproveConfigDTO();
        configDTO.setBizType("type1");
        configDTO.setCustomType("customType1");

        when(policyConfig.getApproveConfigList()).thenReturn(Collections.singletonList(configDTO));

        // 调用方法并验证结果
        PolicyApproveConfigDTO result = policyConfigManagerImpl.getApproveConfig("type2", "customType2");
        assertEquals(null, result); // 应该返回 null, 因为两者均不匹配
    }

    /**
     * 测试审批配置列表为空的情况
     */
    @Test
    public void testGetApproveConfigEmptyList() {
        // mock 空列表
        when(policyConfig.getApproveConfigList()).thenReturn(Collections.emptyList());

        // 调用方法并验证结果
        PolicyApproveConfigDTO result = policyConfigManagerImpl.getApproveConfig("type1", "customType1");
        assertEquals(null, result); // 应该返回 null, 因为列表为空
    }

    /**
     * 测试bizType和customType均为空的情况
     */
    @Test(timeout = 5000) // 设置超时为5秒，防止死循环
    public void testGetApproveConfigBothNull() {
        // 准备测试数据
        PolicyApproveConfigDTO configDTO = new PolicyApproveConfigDTO();
        configDTO.setBizType(null);
        configDTO.setCustomType(null);

        when(policyConfig.getApproveConfigList()).thenReturn(Collections.singletonList(configDTO));

        // 调用方法
        PolicyApproveConfigDTO result = policyConfigManagerImpl.getApproveConfig(null, null);
        assertEquals(configDTO, result); // 期望返回的是 configDTO
    }

    /**
     * 测试审批配置列表为空的情况
     */
    @Test
    public void testGetPlanConfigByPlanType() {
        List<PolicyIncentivePlanConfigDTO> approveConfigList = new ArrayList<>();
        PolicyIncentivePlanConfigDTO approveConfigDTO = new PolicyIncentivePlanConfigDTO();
        approveConfigDTO.setBizType("bizType");
        approveConfigDTO.setCustomType("customType");
        approveConfigDTO.setIncentivePlanType("incentivePlanType");
        approveConfigList.add(approveConfigDTO);
        // mock 空列表
        when(policyConfig.getPolicyIncentiveConfigList()).thenReturn(approveConfigList);

        // 调用方法并验证结果
        PolicyIncentivePlanConfigDTO planConfigByPlanType = policyConfigManagerImpl.getPlanConfigByPlanType("bizType", "customType", "incentivePlanType");
        assertNotNull( planConfigByPlanType);
    }
}