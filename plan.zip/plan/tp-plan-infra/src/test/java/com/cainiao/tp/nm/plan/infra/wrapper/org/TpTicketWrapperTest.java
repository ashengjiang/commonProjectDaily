package com.cainiao.tp.nm.plan.infra.wrapper.org;

import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSON;

import com.base.BaseTest;
import com.cainiao.aladdin.reslut.PageResult;
import com.cainiao.aladdin.reslut.Result;
import com.cainiao.terminal.ticket.client.constant.TpTicketTaskStatusEnum;
import com.cainiao.terminal.ticket.client.domain.dto.TpTicketTaskDTO;
import com.cainiao.terminal.ticket.client.domain.request.TpSearchTicketReq;
import com.cainiao.terminal.ticket.client.domain.response.TpTicketRep;
import com.cainiao.terminal.ticket.client.service.TpTicketPushService;
import com.cainiao.terminal.ticket.client.service.TpTicketService;
import com.cainiao.terminal.ticket.client.service.TpTicketTaskReadService;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicySubmissionNodeEnum;
import com.cainiao.tp.nm.plan.infra.wrapper.org.param.TpStartTicketParam;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyLong;
import static org.mockito.Mockito.anyString;

/**
 * <a href="https://alidocs.dingtalk.com/i/nodes/dpYLaezmVNRMGX56C1aKjlBOVrMqPxX6">单元测试编写&生成FAQ</a>
 * Created By Thub IDEA插件
 *
 * @Date 2025/6/9 15:49
 */
public class TpTicketWrapperTest extends BaseTest {

    @InjectMocks
    private TpTicketWrapper tpTicketWrapper;

    @Mock
    private TpTicketService tpOaTicketService;

    @Mock
    private TpTicketTaskReadService tpTicketTaskReadService;

    @Mock
    private TpTicketPushService tpTicketPushService;

    @Before
    public void setUp() throws Exception {MockitoAnnotations.openMocks(this);}

    @Test
    public void testStartTicket() {
        // Setup, prepare mock data
        Result<Long> longResult = new Result<>();
        longResult.setData(1L);
        longResult.setSuccess(true);
        Mockito.when(tpOaTicketService.startTicket(any()))
            .thenReturn(longResult);

        Result<TpTicketRep> resultMock = new Result<>();
        TpTicketRep tpTicketRep = new TpTicketRep();
        tpTicketRep.setProcessInstanceId("1");
        tpTicketRep.setId(1L);
        resultMock.setData(tpTicketRep);
        resultMock.setSuccess(true);
        Mockito.when(tpOaTicketService.queryTicketByTicketId(anyLong()))
            .thenReturn(resultMock);
        // Prepare method arguments

        // Run the method to be tested
        String result = tpTicketWrapper.startTicket(new TpStartTicketParam());

        // Verify the result
        Assert.assertEquals("1", result);
    }

    @Test
    public void testQueryTicketById() {
        Result<TpTicketRep> resultMock = new Result<>();
        TpTicketRep tpTicketRep = new TpTicketRep();
        tpTicketRep.setId(1L);
        resultMock.setData(tpTicketRep);
        resultMock.setSuccess(true);
        // Setup, prepare mock data
        Mockito.when(tpOaTicketService.queryTicketByTicketId(anyLong()))
            .thenReturn(resultMock);

        // Prepare method arguments

        // Run the method to be tested
        TpTicketRep result = tpTicketWrapper.queryTicketById(1L);

        // Verify the result
        Assert.assertEquals(1L, result.getId().longValue());
    }

    @Test
    public void testQueryTicketByProcessId() {
        Result<TpTicketRep> resultMock = new Result<>();
        TpTicketRep tpTicketRep = new TpTicketRep();
        tpTicketRep.setProcessInstanceId("1");
        resultMock.setData(tpTicketRep);
        resultMock.setSuccess(true);
        // Setup, prepare mock data
        Mockito.when(tpOaTicketService.queryTicketByProcessId(anyString()))
            .thenReturn(resultMock);

        // Prepare method arguments

        // Run the method to be tested
        TpTicketRep result = tpTicketWrapper.queryTicketByProcessId("oaProcessInstanceId");

        // Verify the result
        Assert.assertEquals("1", result.getProcessInstanceId());
    }

    @Test
    public void testSearchTicket() {
        PageResult<List<TpTicketRep>> listPageResult = new PageResult<>();
        List<TpTicketRep> tpTicketRepList = new ArrayList<>();
        TpTicketRep tpTicketRep = new TpTicketRep();
        tpTicketRep.setId(1L);
        tpTicketRepList.add(tpTicketRep);
        listPageResult.setData(tpTicketRepList);
        // Setup, prepare mock data
        Mockito.when(tpOaTicketService.searchTicket(any()))
            .thenReturn(listPageResult);

        // Prepare method arguments

        // Run the method to be tested
        List<TpTicketRep> result = tpTicketWrapper.searchTicket(new TpSearchTicketReq());

        // Verify the result
        Assert.assertEquals(1L, result.get(0).getId().longValue());
    }

    @Test
    public void testCancelTicket() {
        Result<Void> voidResult = new Result<>();
        voidResult.setSuccess(true);
        // Setup, prepare mock data
        Mockito.when(tpOaTicketService.cancelTicket2Reason(any()))
            .thenReturn(voidResult);

        // Prepare method arguments

        // Run the method to be tested
        tpTicketWrapper.cancelTicket(1L, "cancelReason");

        // Verify the result
        Mockito.verify(tpOaTicketService).cancelTicket2Reason(any());
    }

    @Test
    public void testTerminateProcessInstance() {
        Result<Void> voidResult = new Result<>();
        voidResult.setSuccess(true);
        // Setup, prepare mock data
        Mockito.when(tpOaTicketService.cancelTicket2Reason(any()))
            .thenReturn(voidResult);

        Result<TpTicketRep> resultMock = new Result<>();
        TpTicketRep tpTicketRep = new TpTicketRep();
        tpTicketRep.setProcessInstanceId("1");
        resultMock.setData(tpTicketRep);
        resultMock.setSuccess(true);
        // Setup, prepare mock data
        Mockito.when(tpOaTicketService.queryTicketByProcessId(anyString()))
            .thenReturn(resultMock);

        // Prepare method arguments

        // Run the method to be tested
        tpTicketWrapper.terminateProcessInstance("1", "reason");

        // Verify the result
        Mockito.verify(tpOaTicketService).queryTicketByProcessId(anyString());
        Mockito.verify(tpOaTicketService).cancelTicket2Reason(any());
    }

    @Test
    public void testUpdateTicket() {
        Result<Void> voidResult = new Result<>();
        voidResult.setSuccess(true);
        // Setup, prepare mock data
        Mockito.when(tpOaTicketService.updateTicket(any()))
            .thenReturn(voidResult);

        // Prepare method arguments

        // Run the method to be tested
        tpTicketWrapper.updateTicket(1L, new HashMap<String, Object>() {{put("String", "context");}});

        // Verify the result
        Mockito.verify(tpOaTicketService).updateTicket(any());
    }

    @Test
    public void testQueryTask() {
        // Setup, prepare mock data
        Result<TpTicketTaskDTO> tpTicketTaskDTOResult = new Result<>();
        TpTicketTaskDTO tpTicketTaskDTO = new TpTicketTaskDTO();
        tpTicketTaskDTO.setId(1L);
        tpTicketTaskDTOResult.setData(tpTicketTaskDTO);
        Mockito.when(tpTicketTaskReadService.queryTask(anyLong()))
            .thenReturn(tpTicketTaskDTOResult);

        // Prepare method arguments

        // Run the method to be tested
        TpTicketTaskDTO result = tpTicketWrapper.queryTask(1L);

        // Verify the result
        Assert.assertEquals(1L, result.getId().longValue());
    }

    @Test
    public void testTimeOutPush() {
        Result<TpTicketTaskDTO> tpTicketTaskDTOResult = new Result<>();
        TpTicketTaskDTO tpTicketTaskDTO = new TpTicketTaskDTO();
        tpTicketTaskDTO.setId(1L);
        tpTicketTaskDTOResult.setData(tpTicketTaskDTO);
        // Setup, prepare mock data
        Mockito.when(tpTicketTaskReadService.queryTask(anyLong()))
            .thenReturn(tpTicketTaskDTOResult);
        Result<Void> voidResult = new Result<>();
        voidResult.setSuccess(true);
        Mockito.when(tpTicketPushService.pushByTaskId(any()))
            .thenReturn(voidResult);

        // Prepare method arguments

        // Run the method to be tested
        tpTicketWrapper.timeOutPush(1L, "action");

    }

    @Test
    public void testQueryTaskList() {
        PageResult<List<TpTicketTaskDTO>> pageResult = PageResult.create();
        pageResult.setData(buildTpTicketTaskDTOList());
        // Setup, prepare mock data
        Mockito.when(tpTicketTaskReadService.queryTaskList(any(), any()))
            .thenReturn(pageResult);

        // Prepare method arguments

        // Run the method to be tested
        List<TpTicketTaskDTO> result = tpTicketWrapper.queryTaskList(1L, Arrays.<TpTicketTaskStatusEnum>asList(TpTicketTaskStatusEnum.PENDING));

        // Verify the result
        Assert.assertEquals(8, result.size());
    }

    private List<TpTicketTaskDTO> buildTpTicketTaskDTOList() {
        String str
            = "[{\"assigneeNameList\":[\"索其\"],\"outerType\":1,\"operatorIdentityId\":\"10093888\",\"operatorIdentityType\":\"cainiaobuc\",\"operatorIdentityCnUserId\":\"2207412236218\",\"gmtCreate\":1750668712000,\"dueTime\":1750927866000,\"version\":4,\"content\":\"{\\\"reason\\\":\\\"test2\\\",\\\"formCode\\\":\\\"F89080_1140\\\",\\\"formName\\\":\\\"审核拒绝原因(必填)\\\",\\\"action\\\":\\\"reject\\\",\\\"formInstanceId\\\":134811080357,\\\"NX_COMPLETE_ACTION\\\":\\\"reject\\\",\\\"NX_COMPLETE_RULE\\\":\\\"审批拒绝\\\"}\",\"taskDesc\":\"大区批量提报一城一策，请点开查看附件Excel，确认数据无误后进行审批。\",\"taskType\":1,\"assigneeIdentityType\":\"cainiaobuc\",\"feature\":\"{\\\"oaParentNodeId\\\":\\\"task_kJSmsh\\\",\\\"subProcessInstanceId\\\":\\\"612608912017466\\\",\\\"overDueNbpId\\\":\\\"SE4vU-4OINVF1H16P2-0110_ticket_task_overdue\\\",\\\"assigneeType\\\":\\\"cnmember\\\",\\\"userName\\\":\\\"索其\\\"}\",\"linkUrl\":{\"mobileUrl\":\"https://page-pre.cainiao-inc.com/cn-yz/m-flow-approve/index.html/?actionPlanInstanceCode=null&#/new-flow-approve?detailCode=4834661\"},\"assigneeIdentityCnUserId\":\"2207412236218\",\"taskName\":\"大区总\",\"outerId\":\"612608994017466\",\"id\":187557892,\"assigneeIdentityId\":\"10093888\",\"ticketId\":4834661,\"taskCategory\":\"BatchSubmissionOfPolicies\",\"status\":99},{\"assigneeNameList\":[\"殷存渝\"],\"outerType\":1,\"operatorIdentityId\":\"30592432\",\"operatorIdentityType\":\"cnmember\",\"operatorIdentityCnUserId\":\"2212785786788\",\"gmtCreate\":1750668711000,\"dueTime\":1750927866000,\"version\":5,\"content\":\"{\\\"reason\\\":\\\"test2\\\",\\\"formCode\\\":\\\"F89080_1140\\\",\\\"formName\\\":\\\"审核拒绝原因(必填)\\\",\\\"action\\\":\\\"reject\\\",\\\"formInstanceId\\\":134811080357,\\\"NX_COMPLETE_ACTION\\\":\\\"reject\\\",\\\"NX_COMPLETE_RULE\\\":\\\"审批拒绝\\\"}\",\"taskDesc\":\"大区批量提报一城一策，请点开查看附件Excel，确认数据无误后进行审批。\",\"taskType\":1,\"assigneeIdentityType\":\"cainiaobuc\",\"feature\":\"{\\\"oaParentNodeId\\\":\\\"task_kJSmsh\\\",\\\"taskSubmitAction\\\":\\\"reject\\\",\\\"subProcessInstanceId\\\":\\\"612608912017466\\\",\\\"overDueNbpId\\\":\\\"7QCez-2L0IM47PS90MO-0110_ticket_task_overdue\\\",\\\"assigneeType\\\":\\\"cnmember\\\",\\\"operatorType\\\":\\\"cnmember\\\",\\\"userName\\\":\\\"殷存渝\\\"}\",\"linkUrl\":{\"mobileUrl\":\"https://page-pre.cainiao-inc.com/cn-yz/m-flow-approve/index.html/?actionPlanInstanceCode=null&#/new-flow-approve?detailCode=4834661\"},\"assigneeIdentityCnUserId\":\"2212785786788\",\"taskName\":\"大区总\",\"outerId\":\"612612271017466\",\"id\":187557891,\"endTime\":1750668720000,\"assigneeIdentityId\":\"30592432\",\"ticketId\":4834661,\"taskCategory\":\"BatchSubmissionOfPolicies\",\"status\":16},{\"assigneeNameList\":[\"腓腓\"],\"outerType\":1,\"operatorIdentityId\":\"10103014\",\"operatorIdentityType\":\"cainiaobuc\",\"operatorIdentityCnUserId\":\"2210229446491\",\"gmtCreate\":1750668711000,\"dueTime\":1750927866000,\"version\":4,\"content\":\"{\\\"reason\\\":\\\"test2\\\",\\\"formCode\\\":\\\"F89080_1140\\\",\\\"formName\\\":\\\"审核拒绝原因(必填)\\\",\\\"action\\\":\\\"reject\\\",\\\"formInstanceId\\\":134811080357,\\\"NX_COMPLETE_ACTION\\\":\\\"reject\\\",\\\"NX_COMPLETE_RULE\\\":\\\"审批拒绝\\\"}\",\"taskDesc\":\"大区批量提报一城一策，请点开查看附件Excel，确认数据无误后进行审批。\",\"taskType\":1,\"assigneeIdentityType\":\"cainiaobuc\",\"feature\":\"{\\\"oaParentNodeId\\\":\\\"task_kJSmsh\\\",\\\"subProcessInstanceId\\\":\\\"612608912017466\\\",\\\"overDueNbpId\\\":\\\"VpBd9-2L0IM47PS90MK-0110_ticket_task_overdue\\\",\\\"assigneeType\\\":\\\"cnmember\\\",\\\"userName\\\":\\\"腓腓\\\"}\",\"linkUrl\":{\"mobileUrl\":\"https://page-pre.cainiao-inc.com/cn-yz/m-flow-approve/index.html/?actionPlanInstanceCode=null&#/new-flow-approve?detailCode=4834661\"},\"assigneeIdentityCnUserId\":\"2210229446491\",\"taskName\":\"大区总\",\"outerId\":\"612611206017466\",\"id\":187557890,\"assigneeIdentityId\":\"10103014\",\"ticketId\":4834661,\"taskCategory\":\"BatchSubmissionOfPolicies\",\"status\":99},{\"assigneeNameList\":[\"喵匠\"],\"outerType\":1,\"operatorIdentityId\":\"XN00224\",\"operatorIdentityType\":\"cainiaobuc\",\"operatorIdentityCnUserId\":\"2205286661865\",\"gmtCreate\":1750668710000,\"dueTime\":1750927866000,\"version\":4,\"content\":\"{\\\"reason\\\":\\\"test2\\\",\\\"formCode\\\":\\\"F89080_1140\\\",\\\"formName\\\":\\\"审核拒绝原因(必填)\\\",\\\"action\\\":\\\"reject\\\",\\\"formInstanceId\\\":134811080357,\\\"NX_COMPLETE_ACTION\\\":\\\"reject\\\",\\\"NX_COMPLETE_RULE\\\":\\\"审批拒绝\\\"}\",\"taskDesc\":\"大区批量提报一城一策，请点开查看附件Excel，确认数据无误后进行审批。\",\"taskType\":1,\"assigneeIdentityType\":\"cainiaobuc\",\"feature\":\"{\\\"oaParentNodeId\\\":\\\"task_kJSmsh\\\",\\\"subProcessInstanceId\\\":\\\"612608912017466\\\",\\\"overDueNbpId\\\":\\\"lCZzB-5NOINVA4N0RAO-0110_ticket_task_overdue\\\",\\\"assigneeType\\\":\\\"cnmember\\\",\\\"userName\\\":\\\"喵匠\\\"}\",\"linkUrl\":{\"mobileUrl\":\"https://page-pre.cainiao-inc.com/cn-yz/m-flow-approve/index.html/?actionPlanInstanceCode=null&#/new-flow-approve?detailCode=4834661\"},\"assigneeIdentityCnUserId\":\"2205286661865\",\"taskName\":\"大区总\",\"outerId\":\"612610223017466\",\"id\":187557889,\"assigneeIdentityId\":\"XN00224\",\"ticketId\":4834661,\"taskCategory\":\"BatchSubmissionOfPolicies\",\"status\":99},{\"assigneeNameList\":[\"索其\"],\"outerType\":1,\"operatorIdentityId\":\"10093888\",\"operatorIdentityType\":\"cainiaobuc\",\"operatorIdentityCnUserId\":\"2207412236218\",\"gmtCreate\":1750668673000,\"dueTime\":1750927866000,\"version\":4,\"content\":\"{\\\"formCode\\\":\\\"F89567_582\\\",\\\"formName\\\":\\\"备注\\\",\\\"action\\\":\\\"approve\\\",\\\"remark\\\":\\\"test1\\\",\\\"formInstanceId\\\":134801030357,\\\"NX_COMPLETE_ACTION\\\":\\\"approve\\\",\\\"NX_COMPLETE_RULE\\\":\\\"审批通过\\\"}\",\"taskDesc\":\"大区批量提报一城一策，请点开查看附件Excel，确认数据无误后进行审批。\",\"taskType\":1,\"assigneeIdentityType\":\"cainiaobuc\",\"feature\":\"{\\\"oaParentNodeId\\\":\\\"task_ijpfa2\\\",\\\"subProcessInstanceId\\\":\\\"612569365017466\\\",\\\"overDueNbpId\\\":\\\"aCGpv-5R0IM0O2BKB60-0110_ticket_task_overdue\\\",\\\"assigneeType\\\":\\\"cnmember\\\",\\\"userName\\\":\\\"索其\\\"}\",\"linkUrl\":{\"mobileUrl\":\"https://page-pre.cainiao-inc.com/cn-yz/m-flow-approve/index.html/?actionPlanInstanceCode=null&#/new-flow-approve?detailCode=4834661\"},\"assigneeIdentityCnUserId\":\"2207412236218\",\"taskName\":\"大区中台TL\",\"outerId\":\"612569283017466\",\"id\":187557885,\"assigneeIdentityId\":\"10093888\",\"ticketId\":4834661,\"taskCategory\":\"BatchSubmissionOfPolicies\",\"status\":99},{\"assigneeNameList\":[\"腓腓\"],\"outerType\":1,\"operatorIdentityId\":\"10103014\",\"operatorIdentityType\":\"cainiaobuc\",\"operatorIdentityCnUserId\":\"2210229446491\",\"gmtCreate\":1750668672000,\"dueTime\":1750927866000,\"version\":4,\"content\":\"{\\\"formCode\\\":\\\"F89567_582\\\",\\\"formName\\\":\\\"备注\\\",\\\"action\\\":\\\"approve\\\",\\\"remark\\\":\\\"test1\\\",\\\"formInstanceId\\\":134801030357,\\\"NX_COMPLETE_ACTION\\\":\\\"approve\\\",\\\"NX_COMPLETE_RULE\\\":\\\"审批通过\\\"}\",\"taskDesc\":\"大区批量提报一城一策，请点开查看附件Excel，确认数据无误后进行审批。\",\"taskType\":1,\"assigneeIdentityType\":\"cainiaobuc\",\"feature\":\"{\\\"oaParentNodeId\\\":\\\"task_ijpfa2\\\",\\\"subProcessInstanceId\\\":\\\"612569365017466\\\",\\\"overDueNbpId\\\":\\\"G0jSw-2L0IM47PS90E5-0110_ticket_task_overdue\\\",\\\"assigneeType\\\":\\\"cnmember\\\",\\\"userName\\\":\\\"腓腓\\\"}\",\"linkUrl\":{\"mobileUrl\":\"https://page-pre.cainiao-inc.com/cn-yz/m-flow-approve/index.html/?actionPlanInstanceCode=null&#/new-flow-approve?detailCode=4834661\"},\"assigneeIdentityCnUserId\":\"2210229446491\",\"taskName\":\"大区中台TL\",\"outerId\":\"612571413017466\",\"id\":187557884,\"assigneeIdentityId\":\"10103014\",\"ticketId\":4834661,\"taskCategory\":\"BatchSubmissionOfPolicies\",\"status\":99},{\"assigneeNameList\":[\"喵匠\"],\"outerType\":1,\"operatorIdentityId\":\"XN00224\",\"operatorIdentityType\":\"cainiaobuc\",\"operatorIdentityCnUserId\":\"2205286661865\",\"gmtCreate\":1750668671000,\"dueTime\":1750927866000,\"version\":4,\"content\":\"{\\\"formCode\\\":\\\"F89567_582\\\",\\\"formName\\\":\\\"备注\\\",\\\"action\\\":\\\"approve\\\",\\\"remark\\\":\\\"test1\\\",\\\"formInstanceId\\\":134801030357,\\\"NX_COMPLETE_ACTION\\\":\\\"approve\\\",\\\"NX_COMPLETE_RULE\\\":\\\"审批通过\\\"}\",\"taskDesc\":\"大区批量提报一城一策，请点开查看附件Excel，确认数据无误后进行审批。\",\"taskType\":1,\"assigneeIdentityType\":\"cainiaobuc\",\"feature\":\"{\\\"oaParentNodeId\\\":\\\"task_ijpfa2\\\",\\\"subProcessInstanceId\\\":\\\"612569365017466\\\",\\\"overDueNbpId\\\":\\\"JuD7f-5MOIM0EDMBL6O-0110_ticket_task_overdue\\\",\\\"assigneeType\\\":\\\"cnmember\\\",\\\"userName\\\":\\\"喵匠\\\"}\",\"linkUrl\":{\"mobileUrl\":\"https://page-pre.cainiao-inc.com/cn-yz/m-flow-approve/index.html/?actionPlanInstanceCode=null&#/new-flow-approve?detailCode=4834661\"},\"assigneeIdentityCnUserId\":\"2205286661865\",\"taskName\":\"大区中台TL\",\"outerId\":\"612568300017466\",\"id\":187557883,\"assigneeIdentityId\":\"XN00224\",\"ticketId\":4834661,\"taskCategory\":\"BatchSubmissionOfPolicies\",\"status\":99},{\"assigneeNameList\":[\"殷存渝\"],\"outerType\":1,\"operatorIdentityId\":\"30592432\",\"operatorIdentityType\":\"cnmember\",\"operatorIdentityCnUserId\":\"2212785786788\",\"gmtCreate\":1750668670000,\"dueTime\":1750927866000,\"version\":5,\"content\":\"{\\\"formCode\\\":\\\"F89567_582\\\",\\\"formName\\\":\\\"备注\\\",\\\"action\\\":\\\"approve\\\",\\\"remark\\\":\\\"test1\\\",\\\"formInstanceId\\\":134801030357,\\\"NX_COMPLETE_ACTION\\\":\\\"approve\\\",\\\"NX_COMPLETE_RULE\\\":\\\"审批通过\\\"}\",\"taskDesc\":\"大区批量提报一城一策，请点开查看附件Excel，确认数据无误后进行审批。\",\"taskType\":1,\"assigneeIdentityType\":\"cainiaobuc\",\"feature\":\"{\\\"oaParentNodeId\\\":\\\"task_ijpfa2\\\",\\\"taskSubmitAction\\\":\\\"approve\\\",\\\"subProcessInstanceId\\\":\\\"612569365017466\\\",\\\"overDueNbpId\\\":\\\"tmNOb-5P0IO0H1SHAE0-0110_ticket_task_overdue\\\",\\\"assigneeType\\\":\\\"cnmember\\\",\\\"operatorType\\\":\\\"cnmember\\\",\\\"userName\\\":\\\"殷存渝\\\"}\",\"linkUrl\":{\"mobileUrl\":\"https://page-pre.cainiao-inc.com/cn-yz/m-flow-approve/index.html/?actionPlanInstanceCode=null&#/new-flow-approve?detailCode=4834661\"},\"assigneeIdentityCnUserId\":\"2212785786788\",\"taskName\":\"大区中台TL\",\"outerId\":\"612570348017466\",\"id\":187557882,\"endTime\":1750668710000,\"assigneeIdentityId\":\"30592432\",\"ticketId\":4834661,\"taskCategory\":\"BatchSubmissionOfPolicies\",\"status\":16}]";
        return JSON.parseArray(str, TpTicketTaskDTO.class);
    }

    @Test
    public void testQueryProcessTaskV2() {
        PageResult<List<TpTicketTaskDTO>> pageResult = PageResult.create();
        pageResult.setData(buildTpTicketTaskDTOList());
        // Setup, prepare mock data
        Mockito.when(tpTicketTaskReadService.queryTaskList(any(), any()))
            .thenReturn(pageResult);

        // Prepare method arguments

        // Run the method to be tested
        Map<String, List<TpTicketTaskDTO>> stringListMap = tpTicketWrapper.queryProcessTask(1L);

        // Verify the result
        //System.out.println(JSON.toJSONString(stringListMap));
        Assert.assertEquals(2, stringListMap.size());
    }

    @Test
    public void testGetLastReason(){
        PageResult<List<TpTicketTaskDTO>> pageResult = PageResult.create();
        pageResult.setData(buildTpTicketTaskDTOList());
        // Setup, prepare mock data
        Mockito.when(tpTicketTaskReadService.queryTaskList(any(), any()))
            .thenReturn(pageResult);

        // Prepare method arguments
        List<String> codeList = PolicySubmissionNodeEnum.getCodeList(false);
        // Run the method to be tested
        String result = tpTicketWrapper.getLastReason(1L, codeList);
        System.out.println(result);

    }
}