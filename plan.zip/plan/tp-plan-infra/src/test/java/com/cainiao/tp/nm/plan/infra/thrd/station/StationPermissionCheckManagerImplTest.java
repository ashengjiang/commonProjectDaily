package com.cainiao.tp.nm.plan.infra.thrd.station;

import com.cainiao.tp.nm.plan.infra.port.dto.context.StationPermissionContext;
import com.cainiao.tp.nm.plan.infra.thrd.station.handler.StationPermissionCheckHandler;
import com.google.common.collect.Maps;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.lang.reflect.Field;
import java.util.Map;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class StationPermissionCheckManagerImplTest {
    @Mock
    private StationPermissionCheckHandler stationPermissionCheckHandler;
    @InjectMocks
    private StationPermissionCheckManagerImpl stationPermissionCheckManager;

    /**
     * 测试用例: 当根据source能够找到对应的handler时，应正确调用该handler的checkPermission方法
     * 场景:
     * - 输入的context中包含一个有效的source。
     * - 内部的handlerMap中存在该source对应的handler实例。
     * 验证:
     * - 正确的handler的checkPermission方法被调用。
     * - 方法返回handler执行后的结果。
     */
    @Test
    public void testCheckPermissionWhenHandlerExistsShouldCallHandler() throws Exception {
        // 准备数据
        String source = "TEST_SOURCE";
        StationPermissionContext inputContext = new StationPermissionContext();
        // 假设@Data注解已为source字段生成setter方法
        inputContext.setSource(source);
        StationPermissionContext expectedResultContext = new StationPermissionContext();
        // 模拟handlerMap，这是被测类的一个私有final字段，需要通过反射来设置
        Map<String, StationPermissionCheckHandler> handlerMap = Maps.newHashMap();
        handlerMap.put(source, stationPermissionCheckHandler);
        // 使用反射设置私有字段的值
        Field mapField = StationPermissionCheckManagerImpl.class.getDeclaredField("handlerMap");
        mapField.setAccessible(true);
        mapField.set(stationPermissionCheckManager, handlerMap);
        // 模拟依赖方法的行为
        when(stationPermissionCheckHandler.checkPermission(inputContext)).thenReturn(expectedResultContext);
        // 调用实际方法
        StationPermissionContext actualResult = stationPermissionCheckManager.checkPermission(inputContext);
        // 验证行为
        verify(stationPermissionCheckHandler).checkPermission(inputContext);
        // 验证返回结果
        Assert.assertEquals(expectedResultContext, actualResult);
    }
}