package com.cainiao.tp.nm.plan.infra.wrapper.express;

import com.alibaba.cainiao.express.outlets.api.result.ResultModel;
import com.alibaba.cainiao.express.outlets.contract.result.ServiceProductDTO;
import com.alibaba.cainiao.express.outlets.contract.service.ServiceProductInfoService;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.ServiceProductInfoDTO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.when;

/**
 * {@link ServiceProductInfoManagerImpl} 单元测试 */
@RunWith(MockitoJUnitRunner.class)
public class ServiceProductInfoManagerImplTest {

    @InjectMocks
    private ServiceProductInfoManagerImpl manager;

    @Mock
    private ServiceProductInfoService serviceProductInfoService;

    /* ============================ result 失败 ============================ */

    @Test
    public void queryServiceProductInfoByCode_resultFail_shouldThrow() {
        when(serviceProductInfoService.queryServiceProductInfoByCode("SVC"))
                .thenReturn(ResultModel.buildErrorResult("500", "boom"));
        try {
            manager.queryServiceProductInfoByCode("SVC");
            fail("expected RuntimeException");
        } catch (RuntimeException e) {
            assertTrue(e.getMessage().contains("boom"));
        }
    }

    /* ============================ data 为 null ============================ */

    @Test
    public void queryServiceProductInfoByCode_dataNull_shouldReturnNull() {
        when(serviceProductInfoService.queryServiceProductInfoByCode("SVC"))
                .thenReturn(ResultModel.buildSuccessResult(null));
        assertNull(manager.queryServiceProductInfoByCode("SVC"));
    }

    /* ============================ data 含主字段（不含 productVersionList） ============================ */

    @Test
    public void queryServiceProductInfoByCode_withoutVersionList_shouldMapMainFields() {
        ServiceProductDTO data = new ServiceProductDTO();
        data.setId(1L);
        data.setStatus(10);
        data.setServiceName("svc-name");
        data.setServiceCode("SVC1");
        data.setServiceContent("content");
        data.setMarkedPrice(new BigDecimal("100"));
        data.setActualPrice(new BigDecimal("90"));
        data.setSlogan("slogan");
        // featrue 是源 DTO 的字段名（typo），与 feature 互转
        data.setFeatrue("feat");
        data.setBizDomain("biz");
        data.setProductType("type");
        data.setDefPriceType("priceType");
        data.setBizType("bizType");
        // 不设置 productVersionList → null → 不进入 stream 分支

        when(serviceProductInfoService.queryServiceProductInfoByCode("SVC1"))
                .thenReturn(ResultModel.buildSuccessResult(data));

        ServiceProductInfoDTO actual = manager.queryServiceProductInfoByCode("SVC1");

        assertNotNull(actual);
        assertEquals(Long.valueOf(1L), actual.getId());
        assertEquals(Integer.valueOf(10), actual.getStatus());
        assertEquals("svc-name", actual.getServiceName());
        assertEquals("SVC1", actual.getServiceCode());
        assertEquals("content", actual.getServiceContent());
        assertEquals(new BigDecimal("100"), actual.getMarkedPrice());
        assertEquals(new BigDecimal("90"), actual.getActualPrice());
        assertEquals("slogan", actual.getSlogan());
        assertEquals("feat", actual.getFeature());
        assertEquals("biz", actual.getBizDomain());
        assertEquals("type", actual.getProductType());
        assertEquals("priceType", actual.getDefPriceType());
        assertEquals("bizType", actual.getBizType());
        assertNull(actual.getProductVersionList());
    }

    @Test
    public void queryServiceProductInfoByCode_emptyVersionList_shouldNotSet() {
        ServiceProductDTO data = new ServiceProductDTO();
        data.setProductVersionList(Collections.emptyList());

        when(serviceProductInfoService.queryServiceProductInfoByCode("SVC"))
                .thenReturn(ResultModel.buildSuccessResult(data));

        ServiceProductInfoDTO actual = manager.queryServiceProductInfoByCode("SVC");
        assertNotNull(actual);
        // CollectionUtils.isNotEmpty(emptyList) = false → 不进入 set 分支
        assertNull(actual.getProductVersionList());
    }

    @Test
    public void queryServiceProductInfoByCode_withVersionList_shouldConvertEach() {
        ServiceProductDTO.ProductVersionDTO v1 = new ServiceProductDTO.ProductVersionDTO();
        v1.setName("v1");
        v1.setCode("C1");
        v1.setValid(true);
        v1.setPrice(new BigDecimal("10"));
        ServiceProductDTO.ProductVersionDTO v2 = new ServiceProductDTO.ProductVersionDTO();
        v2.setName("v2");
        v2.setCode("C2");
        v2.setValid(false);
        v2.setPrice(new BigDecimal("20"));

        ServiceProductDTO data = new ServiceProductDTO();
        data.setProductVersionList(Arrays.asList(v1, v2));

        when(serviceProductInfoService.queryServiceProductInfoByCode("SVC"))
                .thenReturn(ResultModel.buildSuccessResult(data));

        ServiceProductInfoDTO actual = manager.queryServiceProductInfoByCode("SVC");

        assertNotNull(actual.getProductVersionList());
        assertEquals(2, actual.getProductVersionList().size());
        ServiceProductInfoDTO.ProductVersionDTO d1 = actual.getProductVersionList().get(0);
        assertEquals("v1", d1.getName());
        assertEquals("C1", d1.getCode());
        assertEquals(Boolean.TRUE, d1.getValid());
        assertEquals(new BigDecimal("10"), d1.getPrice());

        ServiceProductInfoDTO.ProductVersionDTO d2 = actual.getProductVersionList().get(1);
        assertEquals(Boolean.FALSE, d2.getValid());
        assertEquals(new BigDecimal("20"), d2.getPrice());
    }
}
