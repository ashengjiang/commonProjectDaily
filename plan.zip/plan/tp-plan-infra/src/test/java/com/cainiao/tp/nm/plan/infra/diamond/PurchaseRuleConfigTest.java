package com.cainiao.tp.nm.plan.infra.diamond;

import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseRule;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * {@link PurchaseRuleConfig} 单元测试
 * <p>
 * received(json) 内部逻辑覆盖：
 * 1) 正常 JSON 数组 → 解析成功并按 categoryId 索引
 * 2) 空 JSON 数组 → 走"解析为空"分支，清空缓存
 * 3) null JSON → 走"解析为空"分支
 * 4) 非法 JSON → 走 catch 分支，清空缓存
 * 5) categoryId == null 的规则 → 跳过分类索引但仍进入 allRules
 * 6) 多次 received → 覆盖上一次结果
 *
 * 查询方法覆盖：
 *  - getAllRules
 *  - getRulesByCategoryId(命中/未命中)
 * </p> */
public class PurchaseRuleConfigTest {

    private PurchaseRuleConfig config;

    @Before
    public void setUp() {
        config = new PurchaseRuleConfig();
    }

    /* ============================ 初始状态 ============================ */

    @Test
    public void initialState_shouldHaveEmptyRules() {
        assertNotNull(config.getAllRules());
        assertTrue(config.getAllRules().isEmpty());
        assertNotNull(config.getRulesByCategoryId(100));
        assertTrue(config.getRulesByCategoryId(100).isEmpty());
    }

    /* ============================ received - 正常路径 ============================ */

    @Test
    public void received_validJsonArray_shouldLoadAndIndexByCategory() {
        // PurchaseRule.level 是 int 原生类型，JSON 必须显式赋值，否则 fastjson 反序列化抛 NPE
        String json = "[{\"id\":1,\"productId\":1001,\"categoryId\":100,\"level\":1},"
                + "{\"id\":2,\"productId\":1002,\"categoryId\":100,\"level\":2},"
                + "{\"id\":3,\"productId\":2001,\"categoryId\":200,\"level\":1}]";

        config.received(json);

        List<PurchaseRule> all = config.getAllRules();
        assertEquals(3, all.size());
        assertEquals(2, config.getRulesByCategoryId(100).size());
        assertEquals(1, config.getRulesByCategoryId(200).size());
        // 未命中的类目 → 空列表
        assertTrue(config.getRulesByCategoryId(999).isEmpty());
        // null 参数 → 空列表（map.getOrDefault(null, empty)）
        assertTrue(config.getRulesByCategoryId(null).isEmpty());
    }

    /* ============================ received - 空 JSON 数组 ============================ */

    @Test
    public void received_emptyJsonArray_shouldClearRules() {
        // 先放点东西（level 必填，否则 fastjson 解析 int 字段时 NPE）
        config.received("[{\"id\":1,\"categoryId\":100,\"level\":1}]");
        assertEquals(1, config.getAllRules().size());

        // 再传空数组 → 清空
        config.received("[]");
        assertTrue(config.getAllRules().isEmpty());
        assertTrue(config.getRulesByCategoryId(100).isEmpty());
    }

    /* ============================ received - null 字符串 ============================ */

    @Test
    public void received_nullString_shouldClearRules() {
        config.received("[{\"id\":1,\"categoryId\":100,\"level\":1}]");
        assertEquals(1, config.getAllRules().size());

        // JSON.parseObject(null,...) 返回 null → CollectionUtils.isEmpty true → 清空分支
        config.received(null);
        assertTrue(config.getAllRules().isEmpty());
    }

    /* ============================ received - 非法 JSON 进 catch 分支 ============================ */

    @Test
    public void received_invalidJson_shouldClearRulesAndNotThrow() {
        config.received("[{\"id\":1,\"categoryId\":100,\"level\":1}]");
        assertEquals(1, config.getAllRules().size());

        // 非法 JSON → 抛异常 → catch 中清空
        config.received("not a json");
        assertTrue(config.getAllRules().isEmpty());
        assertTrue(config.getRulesByCategoryId(100).isEmpty());
    }

    /* ============================ categoryId 为 null 的规则会被跳过索引 ============================ */

    @Test
    public void received_ruleWithNullCategoryId_shouldSkipIndexButKeepInAllRules() {
        // 第二条没 categoryId；level 必填
        String json = "[{\"id\":1,\"categoryId\":100,\"level\":1},{\"id\":2,\"level\":1}]";

        config.received(json);

        // all 列表保留 2 条
        assertEquals(2, config.getAllRules().size());
        // 但 categoryId 索引只有 100 这一组
        assertEquals(1, config.getRulesByCategoryId(100).size());
    }

    /* ============================ 多次 received 覆盖 ============================ */

    @Test
    public void received_multipleTimes_shouldOverrideLastResult() {
        config.received("[{\"id\":1,\"categoryId\":100,\"level\":1}]");
        assertEquals(1, config.getAllRules().size());

        config.received("[{\"id\":2,\"categoryId\":200,\"level\":1},{\"id\":3,\"categoryId\":200,\"level\":1}]");
        assertEquals(2, config.getAllRules().size());
        // 类目 100 应该被清空
        assertTrue(config.getRulesByCategoryId(100).isEmpty());
        assertEquals(2, config.getRulesByCategoryId(200).size());
    }
}
