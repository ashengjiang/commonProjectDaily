package com.cainiao.tp.nm.plan.infra.repository.purchase;

import com.cainiao.tp.nm.plan.infra.repository.purchase.convert.PurchaseOrderConvertor;
import com.cainiao.tp.nm.plan.infra.repository.purchase.dto.data.PurchaseOrderDO;
import com.cainiao.tp.nm.plan.infra.repository.purchase.dto.data.PurchaseOrderProductSnapshotDO;
import com.cainiao.tp.nm.plan.infra.repository.purchase.dto.param.PurchaseOrderProductSnapshotQueryParam;
import com.cainiao.tp.nm.plan.infra.repository.purchase.dto.param.PurchaseOrderQueryParam;
import com.cainiao.tp.nm.plan.infra.repository.purchase.mapper.PurchaseOrderMapper;
import com.cainiao.tp.nm.plan.infra.repository.purchase.mapper.PurchaseOrderProductSnapshotMapper;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseOrder;
import com.cainiao.tp.nm.plan.purchase.domain.model.valobj.PurchaseOrderProductSnapshot;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * {@link PurchaseOrderRepositoryImpl} 单元测试 */
@RunWith(MockitoJUnitRunner.class)
public class PurchaseOrderRepositoryImplTest {

    @InjectMocks
    private PurchaseOrderRepositoryImpl repository;

    @Mock
    private PurchaseOrderMapper purchaseOrderMapper;

    @Mock
    private PurchaseOrderProductSnapshotMapper purchaseOrderProductSnapshotMapper;

    @Mock
    private PurchaseOrderConvertor purchaseOrderConvertor;

    /* ============================ findById ============================ */

    @Test
    public void findById_notExist_shouldReturnNull() {
        when(purchaseOrderMapper.selectById(1L)).thenReturn(null);

        assertNull(repository.findById(1L));
        verify(purchaseOrderProductSnapshotMapper, never()).selectAll(any());
    }

    @Test
    public void findById_exist_shouldLoadSnapshotsAndReturn() {
        PurchaseOrderDO orderDO = new PurchaseOrderDO();
        orderDO.setId(1L);
        PurchaseOrder model = PurchaseOrder.builder().id(1L).build();
        List<PurchaseOrderProductSnapshotDO> snapshotDOs =
                Arrays.asList(new PurchaseOrderProductSnapshotDO(), new PurchaseOrderProductSnapshotDO());
        List<PurchaseOrderProductSnapshot> snapshots =
                Arrays.asList(new PurchaseOrderProductSnapshot(), new PurchaseOrderProductSnapshot());

        when(purchaseOrderMapper.selectById(1L)).thenReturn(orderDO);
        when(purchaseOrderConvertor.doToModel(orderDO)).thenReturn(model);

        ArgumentCaptor<PurchaseOrderProductSnapshotQueryParam> captor =
                ArgumentCaptor.forClass(PurchaseOrderProductSnapshotQueryParam.class);
        when(purchaseOrderProductSnapshotMapper.selectAll(captor.capture())).thenReturn(snapshotDOs);
        when(purchaseOrderConvertor.doToProductSnapshotList(snapshotDOs)).thenReturn(snapshots);

        PurchaseOrder result = repository.findById(1L);

        assertNotNull(result);
        assertEquals(snapshots, result.getProductSnapshotList());
        // 查询参数：orderId=1, page=1, size=100
        PurchaseOrderProductSnapshotQueryParam qp = captor.getValue();
        assertEquals(Long.valueOf(1L), qp.getOrderId());
        assertEquals(Integer.valueOf(1), qp.getPage());
        assertEquals(Integer.valueOf(100), qp.getSize());
    }

    /* ============================ findByFulfillmentPlatformOrderId ============================ */

    @Test
    public void findByFulfillmentPlatformOrderId_nullParam_shouldReturnNullAndSkipDb() {
        assertNull(repository.findByFulfillmentPlatformOrderId(null));
        verify(purchaseOrderMapper, never()).selectAll(any(PurchaseOrderQueryParam.class));
    }

    @Test
    public void findByFulfillmentPlatformOrderId_emptyParam_shouldReturnNullAndSkipDb() {
        assertNull(repository.findByFulfillmentPlatformOrderId(""));
        verify(purchaseOrderMapper, never()).selectAll(any(PurchaseOrderQueryParam.class));
    }

    @Test
    public void findByFulfillmentPlatformOrderId_dbEmpty_shouldReturnNull() {
        when(purchaseOrderMapper.selectAll(any(PurchaseOrderQueryParam.class)))
                .thenReturn(Collections.emptyList());

        assertNull(repository.findByFulfillmentPlatformOrderId("DN-001"));
        // 不进入 convertor
        verify(purchaseOrderConvertor, never()).doToModel(any(PurchaseOrderDO.class));
    }

    @Test
    public void findByFulfillmentPlatformOrderId_dbNull_shouldReturnNull() {
        when(purchaseOrderMapper.selectAll(any(PurchaseOrderQueryParam.class))).thenReturn(null);

        assertNull(repository.findByFulfillmentPlatformOrderId("DN-001"));
        verify(purchaseOrderConvertor, never()).doToModel(any(PurchaseOrderDO.class));
    }

    @Test
    public void findByFulfillmentPlatformOrderId_hit_shouldConvertFirstAndReturn() {
        PurchaseOrderDO orderDO = new PurchaseOrderDO();
        orderDO.setId(99L);
        PurchaseOrder model = PurchaseOrder.builder().id(99L).build();

        ArgumentCaptor<PurchaseOrderQueryParam> captor =
                ArgumentCaptor.forClass(PurchaseOrderQueryParam.class);
        when(purchaseOrderMapper.selectAll(captor.capture()))
                .thenReturn(Arrays.asList(orderDO, new PurchaseOrderDO()));
        when(purchaseOrderConvertor.doToModel(orderDO)).thenReturn(model);

        PurchaseOrder result = repository.findByFulfillmentPlatformOrderId("DN-001");

        assertNotNull(result);
        assertEquals(Long.valueOf(99L), result.getId());
        // 查询参数：fulfillmentPlatformOrderId=DN-001, page=1, size=1
        PurchaseOrderQueryParam qp = captor.getValue();
        assertEquals("DN-001", qp.getFulfillmentPlatformOrderId());
        assertEquals(Integer.valueOf(1), qp.getPage());
        assertEquals(Integer.valueOf(1), qp.getSize());
        // 仅转换第一条，第二条被忽略
        verify(purchaseOrderConvertor).doToModel(orderDO);
    }

    /* ============================ save ============================ */

    @Test
    public void save_withSnapshots_shouldInsertOrderAndBatchInsertSnapshots() {
        PurchaseOrder order = PurchaseOrder.builder().build();
        order.setProductSnapshotList(Arrays.asList(
                new PurchaseOrderProductSnapshot(), new PurchaseOrderProductSnapshot()));

        PurchaseOrderDO orderDO = new PurchaseOrderDO();
        List<PurchaseOrderProductSnapshotDO> snapshotDOs =
                Arrays.asList(new PurchaseOrderProductSnapshotDO(), new PurchaseOrderProductSnapshotDO());

        when(purchaseOrderConvertor.doToModel(order)).thenReturn(orderDO);
        // 模拟 mybatis insert 回填 id
        org.mockito.Mockito.doAnswer(invocation -> {
            PurchaseOrderDO entity = invocation.getArgument(0);
            entity.setId(888L);
            return null;
        }).when(purchaseOrderMapper).insert(orderDO);
        when(purchaseOrderConvertor.doToProductSnapshotDOList(order.getProductSnapshotList(), 888L))
                .thenReturn(snapshotDOs);

        repository.save(order);

        // 订单 id 回填到 model
        assertEquals(Long.valueOf(888L), order.getId());
        verify(purchaseOrderMapper).insert(orderDO);
        verify(purchaseOrderProductSnapshotMapper).batchInsert(snapshotDOs);
    }

    @Test
    public void save_snapshotListNull_shouldNotBatchInsert() {
        PurchaseOrder order = PurchaseOrder.builder().build();
        order.setProductSnapshotList(null);

        PurchaseOrderDO orderDO = new PurchaseOrderDO();
        when(purchaseOrderConvertor.doToModel(order)).thenReturn(orderDO);
        when(purchaseOrderConvertor.doToProductSnapshotDOList(null, null)).thenReturn(null);

        repository.save(order);

        verify(purchaseOrderMapper).insert(orderDO);
        verify(purchaseOrderProductSnapshotMapper, never()).batchInsert(anyList());
    }

    @Test
    public void save_snapshotListEmpty_shouldNotBatchInsert() {
        PurchaseOrder order = PurchaseOrder.builder().build();
        order.setProductSnapshotList(Collections.emptyList());

        PurchaseOrderDO orderDO = new PurchaseOrderDO();
        when(purchaseOrderConvertor.doToModel(order)).thenReturn(orderDO);
        when(purchaseOrderConvertor.doToProductSnapshotDOList(Collections.emptyList(), null))
                .thenReturn(Collections.emptyList());

        repository.save(order);

        verify(purchaseOrderMapper).insert(orderDO);
        verify(purchaseOrderProductSnapshotMapper, never()).batchInsert(anyList());
    }

    /* ============================ update ============================ */

    @Test
    public void update_shouldConvertAndCallMapperUpdate() {
        PurchaseOrder order = PurchaseOrder.builder().id(1L).build();
        PurchaseOrderDO doObj = new PurchaseOrderDO();
        when(purchaseOrderConvertor.doToModel(order)).thenReturn(doObj);

        repository.update(order);

        verify(purchaseOrderMapper).update(doObj);
    }

    /* ============================ deleteOrder ============================ */

    @Test
    public void deleteOrder_withSnapshots_shouldBatchDeleteAndDeleteOrder() {
        PurchaseOrderProductSnapshotDO s1 = new PurchaseOrderProductSnapshotDO();
        s1.setId(11L);
        PurchaseOrderProductSnapshotDO s2 = new PurchaseOrderProductSnapshotDO();
        s2.setId(22L);
        when(purchaseOrderProductSnapshotMapper.selectAll(any(PurchaseOrderProductSnapshotQueryParam.class)))
                .thenReturn(Arrays.asList(s1, s2));

        repository.deleteOrder(1L);

        ArgumentCaptor<List<Long>> idCap = ArgumentCaptor.forClass(List.class);
        verify(purchaseOrderProductSnapshotMapper).batchDeleteByIds(idCap.capture());
        assertEquals(Arrays.asList(11L, 22L), idCap.getValue());
        verify(purchaseOrderMapper).deleteById(1L);
    }

    @Test
    public void deleteOrder_emptySnapshots_shouldOnlyDeleteOrder() {
        when(purchaseOrderProductSnapshotMapper.selectAll(any(PurchaseOrderProductSnapshotQueryParam.class)))
                .thenReturn(Collections.emptyList());

        repository.deleteOrder(1L);

        verify(purchaseOrderProductSnapshotMapper, never()).batchDeleteByIds(anyList());
        verify(purchaseOrderMapper).deleteById(1L);
    }

    @Test
    public void deleteOrder_nullSnapshots_shouldOnlyDeleteOrder() {
        when(purchaseOrderProductSnapshotMapper.selectAll(any(PurchaseOrderProductSnapshotQueryParam.class)))
                .thenReturn(null);

        repository.deleteOrder(1L);

        verify(purchaseOrderProductSnapshotMapper, never()).batchDeleteByIds(anyList());
        verify(purchaseOrderMapper).deleteById(1L);
    }

    /* ============================ updateOrderStatusAndSnapshotFeature ============================ */

    @Test
    public void updateOrderStatusAndSnapshotFeature_orderNotExist_shouldReturnEarly() {
        when(purchaseOrderMapper.selectById(1L)).thenReturn(null);

        repository.updateOrderStatusAndSnapshotFeature(1L, 20, 11L, new HashMap<>());

        verify(purchaseOrderMapper, never()).update(any());
        verify(purchaseOrderProductSnapshotMapper, never()).selectById(any());
    }

    @Test
    public void updateOrderStatusAndSnapshotFeature_snapshotNotExist_shouldOnlyUpdateOrder() {
        PurchaseOrderDO orderDO = new PurchaseOrderDO();
        when(purchaseOrderMapper.selectById(1L)).thenReturn(orderDO);
        when(purchaseOrderProductSnapshotMapper.selectById(11L)).thenReturn(null);

        repository.updateOrderStatusAndSnapshotFeature(1L, 20, 11L, new HashMap<>());

        assertEquals(Integer.valueOf(20), orderDO.getStatus());
        verify(purchaseOrderMapper).update(orderDO);
        verify(purchaseOrderProductSnapshotMapper, never()).update(any());
    }

    @Test
    public void updateOrderStatusAndSnapshotFeature_existingFeatureBlank_shouldStartFromEmptyMap() {
        PurchaseOrderDO orderDO = new PurchaseOrderDO();
        PurchaseOrderProductSnapshotDO snapshotDO = new PurchaseOrderProductSnapshotDO();
        snapshotDO.setFeature(null); // 走 null 分支

        when(purchaseOrderMapper.selectById(1L)).thenReturn(orderDO);
        when(purchaseOrderProductSnapshotMapper.selectById(11L)).thenReturn(snapshotDO);

        Map<String, String> additional = new HashMap<>();
        additional.put("k", "v");
        repository.updateOrderStatusAndSnapshotFeature(1L, 20, 11L, additional);

        assertEquals(Integer.valueOf(20), orderDO.getStatus());
        verify(purchaseOrderMapper).update(orderDO);
        // feature 序列化结果包含 k:v
        assertTrue(snapshotDO.getFeature().contains("\"k\""));
        assertTrue(snapshotDO.getFeature().contains("\"v\""));
        verify(purchaseOrderProductSnapshotMapper).update(snapshotDO);
    }

    @Test
    public void updateOrderStatusAndSnapshotFeature_existingFeatureAndAdditionalMerge() {
        PurchaseOrderDO orderDO = new PurchaseOrderDO();
        PurchaseOrderProductSnapshotDO snapshotDO = new PurchaseOrderProductSnapshotDO();
        snapshotDO.setFeature("{\"oldKey\":\"oldVal\"}");

        when(purchaseOrderMapper.selectById(1L)).thenReturn(orderDO);
        when(purchaseOrderProductSnapshotMapper.selectById(11L)).thenReturn(snapshotDO);

        Map<String, String> additional = new HashMap<>();
        additional.put("newKey", "newVal");
        repository.updateOrderStatusAndSnapshotFeature(1L, 20, 11L, additional);

        String merged = snapshotDO.getFeature();
        assertTrue(merged.contains("oldKey"));
        assertTrue(merged.contains("newKey"));
    }

    @Test
    public void updateOrderStatusAndSnapshotFeature_additionalFeatureNull_shouldStillSerializeExisting() {
        PurchaseOrderDO orderDO = new PurchaseOrderDO();
        PurchaseOrderProductSnapshotDO snapshotDO = new PurchaseOrderProductSnapshotDO();
        snapshotDO.setFeature("{\"k\":\"v\"}");

        when(purchaseOrderMapper.selectById(1L)).thenReturn(orderDO);
        when(purchaseOrderProductSnapshotMapper.selectById(11L)).thenReturn(snapshotDO);

        repository.updateOrderStatusAndSnapshotFeature(1L, 20, 11L, null);

        assertTrue(snapshotDO.getFeature().contains("\"k\""));
        verify(purchaseOrderProductSnapshotMapper).update(snapshotDO);
    }

    /* ============================ updateSnapshotFeature ============================ */

    @Test
    public void updateSnapshotFeature_snapshotNotExist_shouldDoNothing() {
        when(purchaseOrderProductSnapshotMapper.selectById(11L)).thenReturn(null);

        repository.updateSnapshotFeature(11L, new HashMap<>());

        verify(purchaseOrderProductSnapshotMapper, never()).update(any());
    }

    @Test
    public void updateSnapshotFeature_existingFeatureBlank_shouldStartFromEmptyMap() {
        PurchaseOrderProductSnapshotDO snapshotDO = new PurchaseOrderProductSnapshotDO();
        snapshotDO.setFeature("");
        when(purchaseOrderProductSnapshotMapper.selectById(11L)).thenReturn(snapshotDO);

        Map<String, String> additional = new HashMap<>();
        additional.put("k", "v");
        repository.updateSnapshotFeature(11L, additional);

        assertTrue(snapshotDO.getFeature().contains("\"k\""));
        verify(purchaseOrderProductSnapshotMapper).update(snapshotDO);
    }

    @Test
    public void updateSnapshotFeature_existingFeatureMerge() {
        PurchaseOrderProductSnapshotDO snapshotDO = new PurchaseOrderProductSnapshotDO();
        snapshotDO.setFeature("{\"oldKey\":\"oldVal\"}");
        when(purchaseOrderProductSnapshotMapper.selectById(11L)).thenReturn(snapshotDO);

        Map<String, String> additional = new HashMap<>();
        additional.put("newKey", "newVal");
        repository.updateSnapshotFeature(11L, additional);

        assertTrue(snapshotDO.getFeature().contains("oldKey"));
        assertTrue(snapshotDO.getFeature().contains("newKey"));
    }

    @Test
    public void updateSnapshotFeature_additionalNull_shouldKeepExisting() {
        PurchaseOrderProductSnapshotDO snapshotDO = new PurchaseOrderProductSnapshotDO();
        snapshotDO.setFeature("{\"k\":\"v\"}");
        when(purchaseOrderProductSnapshotMapper.selectById(11L)).thenReturn(snapshotDO);

        repository.updateSnapshotFeature(11L, null);

        assertTrue(snapshotDO.getFeature().contains("\"k\""));
        verify(purchaseOrderProductSnapshotMapper).update(snapshotDO);
    }
}
