package com.cainiao.tp.nm.plan.infra.thrd.station;

import com.alibaba.fastjson.TypeReference;
import com.cainiao.aladdin.AladdinOSearchManager;
import com.cainiao.aladdin.domain.AladdinOSearchStructureDTO;
import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.aladdin.reslut.PageResult;
import com.cainiao.tp.nm.plan.infra.common.constants.OSearchAppEnum;
import com.cainiao.tp.nm.plan.infra.port.policy.IncentiveRemindStationManager;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

/**
 * վ��ʵ�ټ�������-վ���ѯʵ�ֵ�Ԫ����
 *
 * @date 2026-03-27
 */
@RunWith(MockitoJUnitRunner.class)
public class IncentiveRemindStationManagerImplTest {

    @Mock
    private AladdinOSearchManager aladdinOpenSearchManager;

    @InjectMocks
    private IncentiveRemindStationManagerImpl incentiveRemindStationManager;

    private static final LocalDate TEST_JOIN_START_DATE = LocalDate.of(2026, 3, 27);
    private static final int TEST_PAGE_SIZE = 100;

    /**
     * ���Գ������״β�ѯ�ɹ�������վ���б��� scrollId
     */
    @Test
    public void testScrollStations_FirstQuerySuccess() {
        // ׼����������
        IncentiveRemindStationManagerImpl.StaPerformFinanceOSearchDTO dto1 = new IncentiveRemindStationManagerImpl.StaPerformFinanceOSearchDTO();
        dto1.setStationId("123456");
        dto1.setMarginedTime("2026-03-27 10:00:00");

        IncentiveRemindStationManagerImpl.StaPerformFinanceOSearchDTO dto2 = new IncentiveRemindStationManagerImpl.StaPerformFinanceOSearchDTO();
        dto2.setStationId("789012");
        dto2.setMarginedTime("2026-03-28");

        List<IncentiveRemindStationManagerImpl.StaPerformFinanceOSearchDTO> dtoList = Arrays.asList(dto1, dto2);

        // Mock OpenSearch ���ؽ��
        PageResult<List<IncentiveRemindStationManagerImpl.StaPerformFinanceOSearchDTO>> osResult = new PageResult<>();
        osResult.setSuccess(true);
        osResult.setData(dtoList);
        
        Map<String, Object> otherData = new HashMap<>();
        otherData.put("scroll_id", "scrollId123");
        otherData.put("aboutCount", 1000L);
        osResult.setOtherData(otherData);

        when(aladdinOpenSearchManager.scollList(
                any(StaPerformFinanceOSearchQuery.class),
                eq(OSearchAppEnum.TP_STA_PERFORM_FINANCE_JOIN),
                any(TypeReference.class),
                any(AbstractOperation.class),
                isNull(),
                any()
        )).thenReturn(osResult);

        // ִ�в���
        IncentiveRemindStationManager.ScrollResult result = incentiveRemindStationManager.scrollStations(
                TEST_JOIN_START_DATE, TEST_PAGE_SIZE, null);

        // ��֤���
        assertNotNull("�����ӦΪ��", result);
        assertEquals("Ӧ����2��վ��", 2, result.getStationList().size());
        assertEquals("scrollId Ӧ��ȷ", "scrollId123", result.getScrollId());
        assertEquals("����Ӧ��ȷ", Long.valueOf(1000L), result.getTotalCount());

        // ��֤վ������
        IncentiveRemindStationManager.StationJoinInfo station1 = result.getStationList().get(0);
        assertEquals("վ��IDӦ��ȷ", "123456", station1.getStationId());
        assertEquals("��פ����Ӧ��ȷ", LocalDate.of(2026, 3, 27), station1.getJoinDate());

        IncentiveRemindStationManager.StationJoinInfo station2 = result.getStationList().get(1);
        assertEquals("վ��IDӦ��ȷ", "789012", station2.getStationId());
        assertEquals("��פ����Ӧ��ȷ", LocalDate.of(2026, 3, 28), station2.getJoinDate());
    }

    /**
     * ���Գ�����������ѯ�ɹ���ʹ�� scrollId
     */
    @Test
    public void testScrollStations_NextQuerySuccess() {
        // ׼����������
        IncentiveRemindStationManagerImpl.StaPerformFinanceOSearchDTO dto = new IncentiveRemindStationManagerImpl.StaPerformFinanceOSearchDTO();
        dto.setStationId("345678");
        dto.setMarginedTime("2026-03-29");

        List<IncentiveRemindStationManagerImpl.StaPerformFinanceOSearchDTO> dtoList = Collections.singletonList(dto);

        // Mock OpenSearch ���ؽ��
        PageResult<List<IncentiveRemindStationManagerImpl.StaPerformFinanceOSearchDTO>> osResult = new PageResult<>();
        osResult.setSuccess(true);
        osResult.setData(dtoList);
        
        Map<String, Object> otherData = new HashMap<>();
        otherData.put("scroll_id", null);
        otherData.put("aboutCount", 1000L);
        osResult.setOtherData(otherData);

        when(aladdinOpenSearchManager.scollList(
                any(StaPerformFinanceOSearchQuery.class),
                eq(OSearchAppEnum.TP_STA_PERFORM_FINANCE_JOIN),
                any(TypeReference.class),
                any(AbstractOperation.class),
                eq("scrollId123"),
                any()
        )).thenReturn(osResult);

        // ִ�в���
        IncentiveRemindStationManager.ScrollResult result = incentiveRemindStationManager.scrollStations(
                TEST_JOIN_START_DATE, TEST_PAGE_SIZE, "scrollId123");

        // ��֤���
        assertNotNull("�����ӦΪ��", result);
        assertEquals("Ӧ����1��վ��", 1, result.getStationList().size());
        assertNull("scrollId ӦΪ null�����һ����", result.getScrollId());
        assertEquals("����Ӧ��ȷ", Long.valueOf(1000L), result.getTotalCount());
    }

    /**
     * ���Գ�������ѯ���ؿ��б�
     */
    @Test
    public void testScrollStations_EmptyResult() {
        // Mock OpenSearch ���ؿս��
        PageResult<List<IncentiveRemindStationManagerImpl.StaPerformFinanceOSearchDTO>> osResult = new PageResult<>();
        osResult.setSuccess(true);
        osResult.setData(Collections.emptyList());
        
        Map<String, Object> otherData = new HashMap<>();
        otherData.put("scroll_id", null);
        otherData.put("aboutCount", 0L);
        osResult.setOtherData(otherData);

        when(aladdinOpenSearchManager.scollList(
                any(StaPerformFinanceOSearchQuery.class),
                eq(OSearchAppEnum.TP_STA_PERFORM_FINANCE_JOIN),
                any(TypeReference.class),
                any(AbstractOperation.class),
                isNull(),
                any()
        )).thenReturn(osResult);

        // ִ�в���
        IncentiveRemindStationManager.ScrollResult result = incentiveRemindStationManager.scrollStations(
                TEST_JOIN_START_DATE, TEST_PAGE_SIZE, null);

        // ��֤���
        assertNotNull("�����ӦΪ��", result);
        assertTrue("վ���б�ӦΪ��", result.getStationList().isEmpty());
        assertNull("scrollId ӦΪ null", result.getScrollId());
        assertEquals("����ӦΪ0", Long.valueOf(0L), result.getTotalCount());
    }

    /**
     * ���Գ�����OpenSearch ��ѯʧ��
     */
    @Test
    public void testScrollStations_OpenSearchFailed() {
        // Mock OpenSearch ����ʧ�ܽ��
        PageResult<List<IncentiveRemindStationManagerImpl.StaPerformFinanceOSearchDTO>> osResult = new PageResult<>();
        osResult.setSuccess(false);
        osResult.setErrorMsg("��ѯʧ��");

        when(aladdinOpenSearchManager.scollList(
                any(StaPerformFinanceOSearchQuery.class),
                eq(OSearchAppEnum.TP_STA_PERFORM_FINANCE_JOIN),
                any(TypeReference.class),
                any(AbstractOperation.class),
                isNull(),
                any()
        )).thenReturn(osResult);

        // ִ�в���
        IncentiveRemindStationManager.ScrollResult result = incentiveRemindStationManager.scrollStations(
                TEST_JOIN_START_DATE, TEST_PAGE_SIZE, null);

        // ��֤���
        assertNotNull("�����ӦΪ��", result);
        assertTrue("վ���б�ӦΪ��", result.getStationList().isEmpty());
        assertNull("scrollId ӦΪ null", result.getScrollId());
        assertEquals("����ӦΪ0", Long.valueOf(0L), result.getTotalCount());
    }

    /**
     * ���Գ�����OpenSearch ��ѯ�׳��쳣
     */
    @Test
    public void testScrollStations_OpenSearchException() {
        // Mock OpenSearch �׳��쳣
        when(aladdinOpenSearchManager.scollList(
                any(StaPerformFinanceOSearchQuery.class),
                eq(OSearchAppEnum.TP_STA_PERFORM_FINANCE_JOIN),
                any(TypeReference.class),
                any(AbstractOperation.class),
                isNull(),
                any()
        )).thenThrow(new RuntimeException("�����쳣"));

        // ִ�в���
        IncentiveRemindStationManager.ScrollResult result = incentiveRemindStationManager.scrollStations(
                TEST_JOIN_START_DATE, TEST_PAGE_SIZE, null);

        // ��֤���
        assertNotNull("�����ӦΪ��", result);
        assertTrue("վ���б�ӦΪ��", result.getStationList().isEmpty());
        assertNull("scrollId ӦΪ null", result.getScrollId());
        assertEquals("����ӦΪ0", Long.valueOf(0L), result.getTotalCount());
    }

    /**
     * ���Գ�����DTO ���ݽ���ʧ�ܣ�ȱ�ٱ�Ҫ�ֶΣ�
     */
    @Test
    public void testScrollStations_InvalidDTO() {
        // ׼���������� - ȱ�� stationId
        IncentiveRemindStationManagerImpl.StaPerformFinanceOSearchDTO dto1 = new IncentiveRemindStationManagerImpl.StaPerformFinanceOSearchDTO();
        dto1.setStationId(null);
        dto1.setMarginedTime("2026-03-27");

        // ׼���������� - ȱ�� marginedTime
        IncentiveRemindStationManagerImpl.StaPerformFinanceOSearchDTO dto2 = new IncentiveRemindStationManagerImpl.StaPerformFinanceOSearchDTO();
        dto2.setStationId("789012");
        dto2.setMarginedTime(null);

        List<IncentiveRemindStationManagerImpl.StaPerformFinanceOSearchDTO> dtoList = Arrays.asList(dto1, dto2);

        // Mock OpenSearch ���ؽ��
        PageResult<List<IncentiveRemindStationManagerImpl.StaPerformFinanceOSearchDTO>> osResult = new PageResult<>();
        osResult.setSuccess(true);
        osResult.setData(dtoList);
        
        Map<String, Object> otherData = new HashMap<>();
        otherData.put("scroll_id", null);
        otherData.put("aboutCount", 2L);
        osResult.setOtherData(otherData);

        when(aladdinOpenSearchManager.scollList(
                any(StaPerformFinanceOSearchQuery.class),
                eq(OSearchAppEnum.TP_STA_PERFORM_FINANCE_JOIN),
                any(TypeReference.class),
                any(AbstractOperation.class),
                isNull(),
                any()
        )).thenReturn(osResult);

        // ִ�в���
        IncentiveRemindStationManager.ScrollResult result = incentiveRemindStationManager.scrollStations(
                TEST_JOIN_START_DATE, TEST_PAGE_SIZE, null);

        // ��֤���
        assertNotNull("�����ӦΪ��", result);
        assertTrue("վ���б�ӦΪ�գ�����DTO����Ч��", result.getStationList().isEmpty());
    }

    /**
     * ���Գ��������� DTO ��Ч��������Ч
     */
    @Test
    public void testScrollStations_PartialInvalidDTO() {
        // ׼���������� - ��Ч����
        IncentiveRemindStationManagerImpl.StaPerformFinanceOSearchDTO dto1 = new IncentiveRemindStationManagerImpl.StaPerformFinanceOSearchDTO();
        dto1.setStationId("123456");
        dto1.setMarginedTime("2026-03-27");

        // ׼���������� - ��Ч���ݣ�ȱ�� marginedTime��
        IncentiveRemindStationManagerImpl.StaPerformFinanceOSearchDTO dto2 = new IncentiveRemindStationManagerImpl.StaPerformFinanceOSearchDTO();
        dto2.setStationId("789012");
        dto2.setMarginedTime(null);

        // ׼���������� - ��Ч����
        IncentiveRemindStationManagerImpl.StaPerformFinanceOSearchDTO dto3 = new IncentiveRemindStationManagerImpl.StaPerformFinanceOSearchDTO();
        dto3.setStationId("345678");
        dto3.setMarginedTime("2026-03-28");

        List<IncentiveRemindStationManagerImpl.StaPerformFinanceOSearchDTO> dtoList = Arrays.asList(dto1, dto2, dto3);

        // Mock OpenSearch ���ؽ��
        PageResult<List<IncentiveRemindStationManagerImpl.StaPerformFinanceOSearchDTO>> osResult = new PageResult<>();
        osResult.setSuccess(true);
        osResult.setData(dtoList);
        
        Map<String, Object> otherData = new HashMap<>();
        otherData.put("scroll_id", null);
        otherData.put("aboutCount", 3L);
        osResult.setOtherData(otherData);

        when(aladdinOpenSearchManager.scollList(
                any(StaPerformFinanceOSearchQuery.class),
                eq(OSearchAppEnum.TP_STA_PERFORM_FINANCE_JOIN),
                any(TypeReference.class),
                any(AbstractOperation.class),
                isNull(),
                any()
        )).thenReturn(osResult);

        // ִ�в���
        IncentiveRemindStationManager.ScrollResult result = incentiveRemindStationManager.scrollStations(
                TEST_JOIN_START_DATE, TEST_PAGE_SIZE, null);

        // ��֤���
        assertNotNull("�����ӦΪ��", result);
        assertEquals("Ӧ����2����Чվ��", 2, result.getStationList().size());
    }

    /**
     * ���Գ��������ڸ�ʽ�����Բ��ԣ�yyyy-MM-dd��
     */
    @Test
    public void testScrollStations_DateFormatShort() {
        // ׼���������� - �����ڸ�ʽ
        IncentiveRemindStationManagerImpl.StaPerformFinanceOSearchDTO dto = new IncentiveRemindStationManagerImpl.StaPerformFinanceOSearchDTO();
        dto.setStationId("123456");
        dto.setMarginedTime("2026-03-27");

        List<IncentiveRemindStationManagerImpl.StaPerformFinanceOSearchDTO> dtoList = Collections.singletonList(dto);

        // Mock OpenSearch ���ؽ��
        PageResult<List<IncentiveRemindStationManagerImpl.StaPerformFinanceOSearchDTO>> osResult = new PageResult<>();
        osResult.setSuccess(true);
        osResult.setData(dtoList);
        
        Map<String, Object> otherData = new HashMap<>();
        otherData.put("scroll_id", null);
        otherData.put("aboutCount", 1L);
        osResult.setOtherData(otherData);

        when(aladdinOpenSearchManager.scollList(
                any(StaPerformFinanceOSearchQuery.class),
                eq(OSearchAppEnum.TP_STA_PERFORM_FINANCE_JOIN),
                any(TypeReference.class),
                any(AbstractOperation.class),
                isNull(),
                any()
        )).thenReturn(osResult);

        // ִ�в���
        IncentiveRemindStationManager.ScrollResult result = incentiveRemindStationManager.scrollStations(
                TEST_JOIN_START_DATE, TEST_PAGE_SIZE, null);

        // ��֤���
        assertNotNull("�����ӦΪ��", result);
        assertEquals("Ӧ����1��վ��", 1, result.getStationList().size());
        assertEquals("��פ����Ӧ��ȷ", LocalDate.of(2026, 3, 27), result.getStationList().get(0).getJoinDate());
    }
}
