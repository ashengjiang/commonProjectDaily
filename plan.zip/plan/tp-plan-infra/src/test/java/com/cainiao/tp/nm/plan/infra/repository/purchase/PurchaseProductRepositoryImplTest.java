package com.cainiao.tp.nm.plan.infra.repository.purchase;

import com.cainiao.tp.nm.plan.infra.repository.purchase.convert.PurchaseProductConvertor;
import com.cainiao.tp.nm.plan.infra.repository.purchase.dto.data.PurchaseProductDO;
import com.cainiao.tp.nm.plan.infra.repository.purchase.dto.param.PurchaseProductQueryParam;
import com.cainiao.tp.nm.plan.infra.repository.purchase.mapper.PurchaseProductMapper;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseProduct;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * {@link PurchaseProductRepositoryImpl} 单元测试 */
@RunWith(MockitoJUnitRunner.class)
public class PurchaseProductRepositoryImplTest {

    @InjectMocks
    private PurchaseProductRepositoryImpl repository;

    @Mock
    private PurchaseProductMapper purchaseProductMapper;

    @Mock
    private PurchaseProductConvertor purchaseProductConvertor;

    /* ============================ getProductsByIds ============================ */

    @Test
    public void getProductsByIds_nullList_shouldReturnEmpty() {
        List<PurchaseProduct> result = repository.getProductsByIds(null);

        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(purchaseProductMapper, never()).selectAll(any());
    }

    @Test
    public void getProductsByIds_emptyList_shouldReturnEmpty() {
        List<PurchaseProduct> result = repository.getProductsByIds(Collections.emptyList());

        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(purchaseProductMapper, never()).selectAll(any());
    }

    @Test
    public void getProductsByIds_normal_shouldSetQueryParamAndConvert() {
        List<Long> ids = Arrays.asList(1L, 2L, 3L);
        List<PurchaseProductDO> doList = Arrays.asList(new PurchaseProductDO(), new PurchaseProductDO(), new PurchaseProductDO());
        List<PurchaseProduct> models = Arrays.asList(new PurchaseProduct(), new PurchaseProduct(), new PurchaseProduct());

        ArgumentCaptor<PurchaseProductQueryParam> captor = ArgumentCaptor.forClass(PurchaseProductQueryParam.class);
        when(purchaseProductMapper.selectAll(captor.capture())).thenReturn(doList);
        when(purchaseProductConvertor.doToModelList(doList)).thenReturn(models);

        List<PurchaseProduct> result = repository.getProductsByIds(ids);

        assertEquals(3, result.size());
        PurchaseProductQueryParam param = captor.getValue();
        assertEquals(ids, param.getIdList());
        assertEquals(Integer.valueOf(3), param.getSize());
    }

    /* ============================ getProductById ============================ */

    @Test
    public void getProductById_nullId_shouldReturnNull() {
        assertNull(repository.getProductById(null));
        verify(purchaseProductMapper, never()).selectById(any());
    }

    @Test
    public void getProductById_notExist_shouldReturnNull() {
        when(purchaseProductMapper.selectById(99L)).thenReturn(null);

        assertNull(repository.getProductById(99L));
        verify(purchaseProductConvertor, never()).doToModel(any(PurchaseProductDO.class));
    }

    @Test
    public void getProductById_exist_shouldConvertAndReturn() {
        PurchaseProductDO doObj = new PurchaseProductDO();
        doObj.setId(1L);
        PurchaseProduct model = new PurchaseProduct();
        when(purchaseProductMapper.selectById(1L)).thenReturn(doObj);
        when(purchaseProductConvertor.doToModel(doObj)).thenReturn(model);

        PurchaseProduct result = repository.getProductById(1L);
        assertEquals(model, result);
    }

    /* ============================ saveProduct ============================ */

    @Test
    public void saveProduct_shouldInsertAndBackfillId() {
        PurchaseProduct product = new PurchaseProduct();
        PurchaseProductDO doObj = new PurchaseProductDO();
        when(purchaseProductConvertor.modelToDO(product)).thenReturn(doObj);

        // 模拟 insert 后 mybatis 回填 id
        org.mockito.Mockito.doAnswer(invocation -> {
            PurchaseProductDO entity = invocation.getArgument(0);
            entity.setId(999L);
            return null;
        }).when(purchaseProductMapper).insert(doObj);

        PurchaseProduct result = repository.saveProduct(product);

        assertEquals(Long.valueOf(999L), result.getId());
        verify(purchaseProductMapper).insert(doObj);
    }

    /* ============================ deleteProduct ============================ */

    @Test
    public void deleteProduct_nullId_shouldDoNothing() {
        repository.deleteProduct(null);
        verify(purchaseProductMapper, never()).deleteById(any());
    }

    @Test
    public void deleteProduct_normal_shouldCallMapperDelete() {
        repository.deleteProduct(1L);
        verify(purchaseProductMapper).deleteById(1L);
    }

    /* ============================ getProductsByCategoryId ============================ */

    @Test
    public void getProductsByCategoryId_nullCategory_shouldReturnEmpty() {
        List<PurchaseProduct> result = repository.getProductsByCategoryId(null);
        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(purchaseProductMapper, never()).selectAll(any());
    }

    @Test
    public void getProductsByCategoryId_normal_shouldSetCategoryParam() {
        List<PurchaseProductDO> doList = Collections.singletonList(new PurchaseProductDO());
        List<PurchaseProduct> models = Collections.singletonList(new PurchaseProduct());

        ArgumentCaptor<PurchaseProductQueryParam> captor = ArgumentCaptor.forClass(PurchaseProductQueryParam.class);
        when(purchaseProductMapper.selectAll(captor.capture())).thenReturn(doList);
        when(purchaseProductConvertor.doToModelList(doList)).thenReturn(models);

        List<PurchaseProduct> result = repository.getProductsByCategoryId(100);

        assertEquals(1, result.size());
        PurchaseProductQueryParam param = captor.getValue();
        assertEquals(Integer.valueOf(100), param.getCategoryId());
        assertEquals(Integer.valueOf(100), param.getSize());
    }

    /* ============================ updateProduct ============================ */

    @Test
    public void updateProduct_shouldSetIdAndCallMapper() {
        PurchaseProduct product = new PurchaseProduct();
        product.setId(123L);
        PurchaseProductDO doObj = new PurchaseProductDO();
        when(purchaseProductConvertor.modelToDO(product)).thenReturn(doObj);

        repository.updateProduct(product);

        // 源码会把 product.id 显式回写到 doObj
        assertEquals(Long.valueOf(123L), doObj.getId());
        verify(purchaseProductMapper).update(doObj);
    }
}
