package com.cainiao.tp.nm.plan.infra.approval.handler;

import static org.mockito.Mockito.*;

import java.util.Map;

import com.alibaba.rocketmq.common.message.MessageExt;

import com.base.BaseTest;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

/**
 * <a href="https://alidocs.dingtalk.com/i/nodes/dpYLaezmVNRMGX56C1aKjlBOVrMqPxX6">单元测试编写&生成FAQ</a>
 * Created By Thub IDEA插件
 *
 * @Date 2025/6/26 15:28
 */
public class ApprovalListenerHandlerFactoryTest extends BaseTest {

    @InjectMocks
    private ApprovalListenerHandlerFactory approvalListenerHandlerFactory;
    @Mock
    private Map<String, ApprovalListenerHandler<?>> approvalHandlerMap;

    @Before
    public void setUp() throws Exception {MockitoAnnotations.openMocks(this);}

    @Test
    public void testRegister() {
        // Prepare method arguments

        // Run the method to be tested
        approvalListenerHandlerFactory.register(new ApprovalListenerHandler<String>() {
            @Override
            public void doConsume(String event, MessageExt message) {

            }

            @Override
            public String getHandlerDefineKey() {
                return "test_test_test";
            }
        });

        ApprovalListenerHandler<?> listenerHandler = approvalListenerHandlerFactory.getListenerHandler("test", "test", "test");
        assert listenerHandler != null;

    }
}