package com.cainiao.tp.nm.plan.infra.wrapper.express;

import com.alibaba.cainiao.express.outlets.api.result.ResultModel;
import com.alibaba.cainiao.express.outlets.api.result.express.ExpressDTO;
import com.alibaba.cainiao.express.outlets.api.service.express.ExpressService;
import com.cainiao.aladdin.exception.AladdinException;
import com.cainiao.tp.nm.plan.infra.port.dto.PlanExpressDTO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.when;

/**
 * {@link ExpressInfoManagerImpl} 单元测试 */
@RunWith(MockitoJUnitRunner.class)
public class ExpressInfoManagerImplTest {

    @InjectMocks
    private ExpressInfoManagerImpl manager;

    @Mock
    private ExpressService expressService;

    /* ============================ 失败分支 ============================ */

    @Test
    public void getExpressDTO_resultFail_shouldThrowAladdinException() {
        ResultModel<ExpressDTO> result = ResultModel.buildErrorResult("500", "fail");
        when(expressService.queryExpressByOrgCode("CP", "ORG")).thenReturn(result);

        try {
            manager.getExpressDTO("CP", "ORG");
            fail("expected AladdinException");
        } catch (AladdinException e) {
            // 异常消息包含 cpCode-orgCode
            assertEquals(true, e.getMessage().contains("CP-ORG"));
        }
    }

    /* ============================ 成功但 data 为 null ============================ */

    @Test
    public void getExpressDTO_successButDataNull_shouldReturnNull() {
        ResultModel<ExpressDTO> result = ResultModel.buildSuccessResult(null);
        when(expressService.queryExpressByOrgCode("CP", "ORG")).thenReturn(result);

        assertNull(manager.getExpressDTO("CP", "ORG"));
    }

    /* ============================ 成功且 data 完整映射 ============================ */

    @Test
    public void getExpressDTO_successAllFieldsMapped() {
        ExpressDTO data = new ExpressDTO();
        data.setExpressId(99L);
        data.setExpressName("快递A");
        data.setCpCode("YTO");
        data.setCpName("圆通");
        data.setOrgCode("ORG-1");
        data.setProvinceCode(110000L);
        data.setCityCode(110100L);
        data.setAreaCode(110105L);
        data.setTownCode(110105001L);

        ResultModel<ExpressDTO> result = ResultModel.buildSuccessResult(data);
        when(expressService.queryExpressByOrgCode("YTO", "ORG-1")).thenReturn(result);

        PlanExpressDTO actual = manager.getExpressDTO("YTO", "ORG-1");

        assertNotNull(actual);
        assertEquals(Long.valueOf(99L), actual.getExpressId());
        assertEquals("快递A", actual.getExpressName());
        assertEquals("YTO", actual.getCpCode());
        assertEquals("圆通", actual.getCpName());
        assertEquals("ORG-1", actual.getOrgCode());
        assertEquals(Long.valueOf(110000L), actual.getProvinceCode());
        assertEquals(Long.valueOf(110100L), actual.getCityCode());
        assertEquals(Long.valueOf(110105L), actual.getAreaCode());
        assertEquals(Long.valueOf(110105001L), actual.getTownCode());
    }
}
