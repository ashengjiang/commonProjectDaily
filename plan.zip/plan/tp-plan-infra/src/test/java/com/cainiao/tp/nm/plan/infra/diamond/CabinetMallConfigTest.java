package com.cainiao.tp.nm.plan.infra.diamond;

import com.cainiao.tp.nm.plan.api.purchase.adaptor.dto.CabinetMallConfigDTO;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

/**
 * {@link CabinetMallConfig} 单元测试。
 * <p>
 * 由于其继承 {@link com.cainiao.aladdin.diamond.AladdinBootJsonDiamondListener}，
 * received(json) 父类已实现且带 try/catch，子类仅需覆盖 setInstance / getClazz。
 * 重点验证：
 *  1) setInstance 会更新 CabinetMallConfigDTO 静态 INSTANCE
 *  2) getClazz 返回正确的目标类型
 *  3) received(正常 json) 端到端 — 配置真正落到 INSTANCE
 *  4) received(非法 json) — 父类吞掉异常，不影响 INSTANCE
 * </p> */
public class CabinetMallConfigTest {

    private CabinetMallConfig listener;

    /**
     * 保留原始 INSTANCE，测试结束后还原，避免污染其他测试
     */
    private CabinetMallConfigDTO originalInstance;

    @Before
    public void setUp() {
        originalInstance = CabinetMallConfigDTO.getINSTANCE();
        listener = new CabinetMallConfig();
    }

    @After
    public void tearDown() {
        CabinetMallConfigDTO.setINSTANCE(originalInstance);
    }

    @Test
    public void getClazz_shouldReturnDTOClass() {
        assertEquals(CabinetMallConfigDTO.class, listener.getClazz());
    }

    @Test
    public void setInstance_shouldUpdateStaticInstance() {
        CabinetMallConfigDTO newConfig = new CabinetMallConfigDTO();
        newConfig.setLargestPurchaseNum(99);

        listener.setInstance(newConfig);

        assertSame(newConfig, CabinetMallConfigDTO.getINSTANCE());
        assertEquals(Integer.valueOf(99), CabinetMallConfigDTO.getINSTANCE().getLargestPurchaseNum());
    }

    @Test
    public void setInstance_nullInput_shouldUpdateInstanceToNull() {
        listener.setInstance(null);
        assertNull(CabinetMallConfigDTO.getINSTANCE());
    }

    @Test
    public void received_validJson_shouldLoadIntoStaticInstance() {
        String json = "{\"largestPurchaseNum\":50,\"greyEntityIdList\":[\"E1\",\"E2\"]}";

        listener.received(json);

        CabinetMallConfigDTO actual = CabinetMallConfigDTO.getINSTANCE();
        assertNotNull(actual);
        assertEquals(Integer.valueOf(50), actual.getLargestPurchaseNum());
        assertEquals(Arrays.asList("E1", "E2"), actual.getGreyEntityIdList());
    }

    @Test
    public void received_invalidJson_shouldBeSwallowedByParent() {
        CabinetMallConfigDTO before = CabinetMallConfigDTO.getINSTANCE();

        listener.received("not a json");

        // 父类 try-catch 吞掉异常 → INSTANCE 不变
        assertSame(before, CabinetMallConfigDTO.getINSTANCE());
    }

    @Test
    public void received_emptyObjectJson_shouldOverrideWithEmptyDTO() {
        listener.received("{}");
        CabinetMallConfigDTO actual = CabinetMallConfigDTO.getINSTANCE();
        assertNotNull(actual);
        // 所有字段都为 null（emptyJson 反序列化的默认值）
        assertNull(actual.getLargestPurchaseNum());
        assertNull(actual.getGreyEntityIdList());
        assertTrue(true);
    }
}
