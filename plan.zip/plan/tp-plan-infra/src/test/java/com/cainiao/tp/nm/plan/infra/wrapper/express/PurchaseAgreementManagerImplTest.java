package com.cainiao.tp.nm.plan.infra.wrapper.express;

import com.alibaba.cainiao.express.outlets.contract.result.ServiceOpenRelationDTO;
import com.cainiao.tp.nm.plan.api.policy.common.constants.ExpressTypeEnum;
import com.cainiao.tp.nm.plan.infra.port.dto.param.ExpressAgreementParam;
import com.cainiao.tp.nm.plan.infra.port.utils.ExpressUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * {@link PurchaseAgreementManagerImpl} 单元测试
 *
 * <p>覆盖：
 * <ul>
 *   <li>下游返回空列表 → false</li>
 *   <li>下游返回非空列表 → true，且透传给 {@link ServiceProductServiceWrapper} 的参数都正确</li>
 * </ul>
 * </p> */
@RunWith(MockitoJUnitRunner.class)
public class PurchaseAgreementManagerImplTest {

    @InjectMocks
    private PurchaseAgreementManagerImpl manager;

    @Mock
    private ServiceProductServiceWrapper serviceProductServiceWrapper;

    /* ============================ 命中 ============================ */

    @Test
    public void queryPurchaseAgreement_hasRelation_shouldReturnTrue() {
        // expressCode 格式 cpCode^^^expressCode（见 ExpressUtils.build/unpack）
        String packed = ExpressUtils.build("EX01", "YTO");
        ExpressAgreementParam param = new ExpressAgreementParam();
        param.setExpressCode(packed);
        param.setAgreementCode("AGREE1");

        when(serviceProductServiceWrapper.queryJvExtendServices(
                eq("YTO"),
                eq("EX01"),
                eq(ExpressTypeEnum.EXPRESS.getCode()),
                org.mockito.ArgumentMatchers.<List<String>>any()))
                .thenReturn(Arrays.asList(new ServiceOpenRelationDTO()));

        boolean result = manager.queryPurchaseAgreement(param);

        assertTrue(result);
        // 校验 serviceCodeList 参数正确传入
        ArgumentCaptor<List<String>> codeCap = ArgumentCaptor.forClass(List.class);
        verify(serviceProductServiceWrapper).queryJvExtendServices(
                eq("YTO"), eq("EX01"),
                eq(ExpressTypeEnum.EXPRESS.getCode()),
                codeCap.capture());
        assertEquals(Collections.singletonList("AGREE1"), codeCap.getValue());
    }

    /* ============================ 未命中 ============================ */

    @Test
    public void queryPurchaseAgreement_noRelation_shouldReturnFalse() {
        String packed = ExpressUtils.build("EX01", "YTO");
        ExpressAgreementParam param = new ExpressAgreementParam();
        param.setExpressCode(packed);
        param.setAgreementCode("AGREE1");

        when(serviceProductServiceWrapper.queryJvExtendServices(
                org.mockito.ArgumentMatchers.anyString(),
                org.mockito.ArgumentMatchers.anyString(),
                org.mockito.ArgumentMatchers.anyString(),
                org.mockito.ArgumentMatchers.<List<String>>any()))
                .thenReturn(Collections.emptyList());

        assertFalse(manager.queryPurchaseAgreement(param));
    }

    /* ============================ 下游返回 null：CollectionUtils.isNotEmpty(null)=false ============================ */

    @Test
    public void queryPurchaseAgreement_downstreamNull_shouldReturnFalse() {
        String packed = ExpressUtils.build("EX01", "YTO");
        ExpressAgreementParam param = new ExpressAgreementParam();
        param.setExpressCode(packed);
        param.setAgreementCode("AGREE1");

        when(serviceProductServiceWrapper.queryJvExtendServices(
                org.mockito.ArgumentMatchers.anyString(),
                org.mockito.ArgumentMatchers.anyString(),
                org.mockito.ArgumentMatchers.anyString(),
                org.mockito.ArgumentMatchers.<List<String>>any()))
                .thenReturn(null);

        assertFalse(manager.queryPurchaseAgreement(param));
    }
}
