package com.cainiao.tp.nm.plan.infra.repository.purchase;

import com.cainiao.tp.nm.plan.infra.diamond.purchase.PurchasePaymentPlanConfigManager;
import com.cainiao.tp.nm.plan.infra.repository.purchase.convert.PurchasePaymentPlanConvertor;
import com.cainiao.tp.nm.plan.infra.repository.purchase.dto.data.PurchasePaymentPlanDO;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchasePaymentPlan;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * {@link PurchasePaymentPlanRepositoryImpl} 单元测试 */
@RunWith(MockitoJUnitRunner.class)
public class PurchasePaymentPlanRepositoryImplTest {

    @InjectMocks
    private PurchasePaymentPlanRepositoryImpl repository;

    @Mock
    private PurchasePaymentPlanConfigManager configManager;

    @Mock
    private PurchasePaymentPlanConvertor convertor;

    /* ============================ getById ============================ */

    @Test
    public void getById_nullId_shouldReturnNullDirectly() {
        PurchasePaymentPlan result = repository.getById(null);

        assertNull(result);
        verify(configManager, never()).getById(isNull());
    }

    @Test
    public void getById_notExist_shouldReturnNull() {
        when(configManager.getById(1L)).thenReturn(null);

        PurchasePaymentPlan result = repository.getById(1L);

        assertNull(result);
        verify(convertor, never()).doToModel(org.mockito.ArgumentMatchers.<PurchasePaymentPlanDO>any());
    }

    @Test
    public void getById_exist_shouldConvertAndReturn() {
        PurchasePaymentPlanDO doObj = new PurchasePaymentPlanDO();
        doObj.setId(1L);
        PurchasePaymentPlan model = new PurchasePaymentPlan();
        when(configManager.getById(1L)).thenReturn(doObj);
        when(convertor.doToModel(doObj)).thenReturn(model);

        PurchasePaymentPlan result = repository.getById(1L);

        assertNotNull(result);
        assertEquals(model, result);
    }

    /* ============================ listByIds ============================ */

    @Test
    public void listByIds_nullList_shouldReturnEmpty() {
        List<PurchasePaymentPlan> result = repository.listByIds(null);

        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(configManager, never()).listByIds(anyList());
    }

    @Test
    public void listByIds_emptyList_shouldReturnEmpty() {
        List<PurchasePaymentPlan> result = repository.listByIds(Collections.emptyList());

        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(configManager, never()).listByIds(anyList());
    }

    @Test
    public void listByIds_normal_shouldDelegateAndConvert() {
        List<Long> ids = Arrays.asList(1L, 2L);
        PurchasePaymentPlanDO d1 = new PurchasePaymentPlanDO();
        PurchasePaymentPlanDO d2 = new PurchasePaymentPlanDO();
        List<PurchasePaymentPlanDO> doList = Arrays.asList(d1, d2);
        List<PurchasePaymentPlan> models = Arrays.asList(new PurchasePaymentPlan(), new PurchasePaymentPlan());

        when(configManager.listByIds(ids)).thenReturn(doList);
        when(convertor.doToModelList(doList)).thenReturn(models);

        List<PurchasePaymentPlan> result = repository.listByIds(ids);

        assertEquals(2, result.size());
        verify(configManager).listByIds(ids);
        verify(convertor).doToModelList(doList);
    }

}
