package com.cainiao.tp.nm.plan.infra.cache.impl;

import com.github.benmanes.caffeine.cache.Cache;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.io.Serializable;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class LocalCacheManagerImplTest {


    @InjectMocks
    private LocalCacheManagerImpl localCacheManagerImpl;
    @Mock
    private Cache<String, Serializable> cache;
    @InjectMocks
    private LocalCacheManagerImpl localCacheManager;

    @Before
    public void setUp() {
        localCacheManager = new LocalCacheManagerImpl();
        String key = "testKey";
        Serializable value = "testValue";
        localCacheManager.set(key, value);

    }

    /**
     * 测试从缓存中获取存在的键对应的值
     */
    @Test
    public void testGetExistingKey() {
        String key = "testKey";
        Serializable expectedValue = "testValue";
//        Mockito.when(cache.getIfPresent(anyString())).thenReturn(expectedValue);
        // 从缓存中获取该值并进行验证
        String actualValue = localCacheManagerImpl.get(key, String.class);
        Assert.assertNotNull(actualValue);
        Assert.assertEquals(actualValue,expectedValue);
    }

    /**
     * 测试从缓存中获取不存在的键
     */
    @Test
    public void testGetNonExistingKey() {
        // 模拟缓存返回null
        String key = "nonExistingKey";
//        Mockito.when(cache.getIfPresent(key)).thenReturn(null);
        // 从缓存中获取该值并进行验证
        String actualValue = localCacheManagerImpl.get(key, String.class);
        Assert.assertNull(actualValue);
    }

    /**
     * 测试从缓存中获取存在的键，但类型不匹配
     */
    @Test
    public void testGetExistingKeyWithWrongType() {
        String key = "wrongTypeKey";
//        Mockito.when(cache.getIfPresent(key)).thenReturn(cachedValue);
        // 从缓存中获取该值并进行验证
        String actualValue = localCacheManagerImpl.get(key, String.class);
        Assert.assertNull(actualValue);
    }

}