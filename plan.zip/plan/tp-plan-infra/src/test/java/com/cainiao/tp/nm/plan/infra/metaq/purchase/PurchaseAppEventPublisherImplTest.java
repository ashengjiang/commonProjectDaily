package com.cainiao.tp.nm.plan.infra.metaq.purchase;

import com.alibaba.fastjson.JSON;
import com.cainiao.tp.nm.plan.infra.metaq.MetaQueueProducer;
import com.cainiao.tp.nm.plan.purchase.adaptor.metaq.event.PurchaseCustomerSnEvent;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.verify;

/**
 * {@link PurchaseAppEventPublisherImpl} 单元测试 */
@RunWith(MockitoJUnitRunner.class)
public class PurchaseAppEventPublisherImplTest {

    @InjectMocks
    private PurchaseAppEventPublisherImpl publisher;

    @Mock
    private MetaQueueProducer metaQueueProducer;

    @Test
    public void publishCustomerSnRelation_shouldInvokeProducerWithExpectedArgs() {
        PurchaseCustomerSnEvent event = PurchaseCustomerSnEvent.builder()
                .customId("C001")
                .customType(1)
                .snCode("SN-XYZ")
                .deliveryTime("2026-05-21 10:00:00")
                .build();

        publisher.publishCustomerSnRelation(event);

        ArgumentCaptor<String> topicCap = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tagCap = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> bodyCap = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> keyCap = ArgumentCaptor.forClass(String.class);
        verify(metaQueueProducer).publishMsg(
                topicCap.capture(), tagCap.capture(), bodyCap.capture(), keyCap.capture());

        assertEquals("purchase_customer_sn", topicCap.getValue());
        assertEquals("relation", tagCap.getValue());
        assertEquals("C001_SN-XYZ", keyCap.getValue());

        // body 是 JSON 化的 event，反序列化回来对比关键字段
        PurchaseCustomerSnEvent body = JSON.parseObject(bodyCap.getValue(), PurchaseCustomerSnEvent.class);
        assertEquals("C001", body.getCustomId());
        assertEquals(Integer.valueOf(1), body.getCustomType());
        assertEquals("SN-XYZ", body.getSnCode());
        assertEquals("2026-05-21 10:00:00", body.getDeliveryTime());
    }

    @Test
    public void publishCustomerSnRelation_withNullSnCode_keyShouldContainNullLiteral() {
        // 验证 customId + "_" + snCode 拼接，snCode 为 null 时 key = "C001_null"
        PurchaseCustomerSnEvent event = PurchaseCustomerSnEvent.builder()
                .customId("C001")
                .snCode(null)
                .build();

        publisher.publishCustomerSnRelation(event);

        ArgumentCaptor<String> keyCap = ArgumentCaptor.forClass(String.class);
        verify(metaQueueProducer).publishMsg(
                org.mockito.ArgumentMatchers.anyString(),
                org.mockito.ArgumentMatchers.anyString(),
                org.mockito.ArgumentMatchers.anyString(),
                keyCap.capture());

        assertEquals("C001_null", keyCap.getValue());
    }
}
