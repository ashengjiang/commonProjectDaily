package com.cainiao.tp.nm.plan.infra.wrapper.org;

import com.alibaba.cainiao.tp.trc.org.client.domain.employee.input.TpEmployeeDetailSingleQuery;
import com.alibaba.cainiao.tp.trc.org.client.domain.employee.output.TpEmployeeDetailDTO;
import com.alibaba.cainiao.tp.trc.org.client.service.TpEmployeeService;
import com.cainiao.aladdin.exception.AladdinException;
import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.aladdin.reslut.Result;
import com.cainiao.tps.control.org.client.api.newOrg.TpsNewOrgDeptEmployeeService;
import com.cainiao.tps.control.org.client.model.dto.dept.TpsOrgDeptDTO;
import com.cainiao.tps.control.org.client.model.rep.TpsOrgEmployeeBelongDeptRep;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Collections;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class TpEmployeeManagerTest {

    @InjectMocks
    private TpEmployeeManager tpEmployeeManager;

    @Mock
    private TpEmployeeService tpEmployeeService;
    @Mock
    private TpsNewOrgDeptEmployeeService tpsNewOrgDeptEmployeeService;

    @Test
    public void testGetEmployeeSuccess() {
        // 测试在成功情况下获取员工信息
        Long employeeId = 1L;
        AbstractOperation opInfo = mock(AbstractOperation.class);

        TpEmployeeDetailDTO employeeDetailDTO = new TpEmployeeDetailDTO();
        Result<TpEmployeeDetailDTO> result = Result.create(employeeDetailDTO);

        when(tpEmployeeService.detailEmployeeInfo(any(TpEmployeeDetailSingleQuery.class), eq(opInfo)))
                .thenReturn(result);

        TpEmployeeDetailDTO resultDTO = tpEmployeeManager.getEmployee(employeeId, opInfo);

        assertNotNull(resultDTO); // 确保返回的 DTO 不为 null
        // assertEquals(...) // 可根据需要添加额外断言
    }

    @Test
    public void testGetEmployeeFailedDueToBusinessError() {
        // 测试在业务错误情况下获取员工信息
        Long employeeId = 2L;
        AbstractOperation opInfo = mock(AbstractOperation.class);

        Result<TpEmployeeDetailDTO> result = Result.createFailed("业务错误信息");

        when(tpEmployeeService.detailEmployeeInfo(any(TpEmployeeDetailSingleQuery.class), eq(opInfo)))
                .thenReturn(result);

        try {
            tpEmployeeManager.getEmployee(employeeId, opInfo);
            fail("应该抛出异常"); // 如果没有抛出异常，测试失败
        } catch (Exception e) {
            // 确认异常类型
            assertTrue(e.getMessage().contains("业务错误信息")); // 使用适当的断言或处理异常
        }
    }

    @Test
    public void testGetEmployeeNullEmployeeId() {
        // 测试传入 null 的员工 ID
        Long employeeId = null;
        AbstractOperation opInfo = mock(AbstractOperation.class);

        try {
            tpEmployeeManager.getEmployee(employeeId, opInfo);
            fail("应该抛出非法参数异常"); // 如果没有抛出异常，测试失败
        } catch (Exception e) {
            // 确认异常类型
            assertTrue(true); // 使用适当的断言
        }
    }

    /**
     * 测试根据用户Id成功查询到部门信息
     */
    @Test
    public void testQueryDeptByEmployeeIdSuccess() {
        Long employeeId = 1L;
        String bizDomain = "testBizDomain";

        TpsOrgEmployeeBelongDeptRep deptRep = new TpsOrgEmployeeBelongDeptRep();
        deptRep.setAllDeptList(Collections.singletonList(new TpsOrgDeptDTO())); // 模拟返回一个部门

        Result<TpsOrgEmployeeBelongDeptRep> result = Result.create(deptRep);
        when(tpsNewOrgDeptEmployeeService.queryBelongDeptByEmployeeId(any())).thenReturn(result);

        List<TpsOrgDeptDTO> deptList = tpEmployeeManager.queryDeptByEmployeeId(employeeId, bizDomain);

        assertNotNull(deptList);
        assertEquals(1, deptList.size());
        verify(tpsNewOrgDeptEmployeeService, times(1)).queryBelongDeptByEmployeeId(any());
    }

    /**
     * 测试根据用户Id查询失败时抛出AladdinException
     */
    @Test(expected = AladdinException.class)
    public void testQueryDeptByEmployeeIdFailure() {
        Long employeeId = 1L;

        Result<TpsOrgEmployeeBelongDeptRep> result = Result.createFailed("1001", "查询失败");
        when(tpsNewOrgDeptEmployeeService.queryBelongDeptByEmployeeId(any())).thenReturn(result);

        tpEmployeeManager.queryDeptByEmployeeId(employeeId, null);

        verify(tpsNewOrgDeptEmployeeService, times(1)).queryBelongDeptByEmployeeId(any()); // 验证是否调用
    }

    /**
     * 测试根据用户Id查询到的部门信息为空
     */
    @Test
    public void testQueryDeptByEmployeeIdNoDeptFound() {
        Long employeeId = 1L;

        Result<TpsOrgEmployeeBelongDeptRep> result = Result.create(new TpsOrgEmployeeBelongDeptRep());
        when(tpsNewOrgDeptEmployeeService.queryBelongDeptByEmployeeId(any())).thenReturn(result);

        List<TpsOrgDeptDTO> deptList = tpEmployeeManager.queryDeptByEmployeeId(employeeId, null);

        assertNotNull(deptList);
        assertTrue(deptList.isEmpty()); // 返回的部门列表应该为空
        verify(tpsNewOrgDeptEmployeeService, times(1)).queryBelongDeptByEmployeeId(any());
    }

    /**
     * 测试传入的bizDomain为空时的情况
     */
    @Test
    public void testQueryDeptByEmployeeIdBizDomainNull() {
        Long employeeId = 1L;

        TpsOrgEmployeeBelongDeptRep deptRep = new TpsOrgEmployeeBelongDeptRep();
        deptRep.setAllDeptList(Collections.singletonList(new TpsOrgDeptDTO())); // 模拟返回一个部门

        Result<TpsOrgEmployeeBelongDeptRep> result = Result.create(deptRep);
        when(tpsNewOrgDeptEmployeeService.queryBelongDeptByEmployeeId(any())).thenReturn(result);

        List<TpsOrgDeptDTO> deptList = tpEmployeeManager.queryDeptByEmployeeId(employeeId, null);

        assertNotNull(deptList);
        assertEquals(1, deptList.size());
        verify(tpsNewOrgDeptEmployeeService, times(1)).queryBelongDeptByEmployeeId(any());
    }

    @Test
    public void testGetEmployeeHighestDept(){
        Result<TpsOrgEmployeeBelongDeptRep> repResult = new Result<>();
        TpsOrgEmployeeBelongDeptRep tpsOrgEmployeeBelongDeptRep = new TpsOrgEmployeeBelongDeptRep();
        TpsOrgDeptDTO tpsOrgDeptDTO = new TpsOrgDeptDTO();
        tpsOrgDeptDTO.setDeptCode("100");
        tpsOrgEmployeeBelongDeptRep.setHighestDeptDTO(tpsOrgDeptDTO);
        repResult.setData(tpsOrgEmployeeBelongDeptRep);
        // Setup, prepare mock data
        when(tpsNewOrgDeptEmployeeService.queryBelongDeptByEmployeeId(any()))
            .thenReturn(repResult);

        // Prepare method arguments

        // Run the method to be tested
        TpsOrgDeptDTO result = tpEmployeeManager.getEmployeeHighestDept(1L, "bizDomain");

        // Verify the result
        assertNotNull(result);
        assertEquals("100", result.getDeptCode());
    }
}