package com.cainiao.tp.nm.plan.infra.wrapper.division;

import com.cainiao.aladdin.reslut.Result;
import com.cainiao.tp.pangu.basic.client.domain.dto.TpDataAllDetailDTO;
import com.cainiao.tp.pangu.basic.client.domain.request.DataTreeDetailRequest;
import com.cainiao.tp.pangu.basic.client.service.TpsDataHeaderService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class TrcDataHeaderWrapperTest {
    // 注入需要测试的对象
    @InjectMocks
    private TrcDataHeaderWrapper trcDataHeaderWrapper;
    // Mock依赖对象
    @Mock
    private TpsDataHeaderService tpsDataHeaderService;

    /**
     * 测试调用权限服务查询数据详情
     */
    @Test
    public void testGetAllMultiDivisionShouldReturnData() {
        Long employeeId = 123456L;
        String dataValue = "STREET#010";
        String dataType = "MERGE_DISTRICT";
        // 设置Mock对象的行为
        TpDataAllDetailDTO expectedDTO = new TpDataAllDetailDTO();
        when(tpsDataHeaderService.getDataAllDetail(any(DataTreeDetailRequest.class)))
                .thenReturn(Result.create(expectedDTO));
        // 执行被测方法
        TpDataAllDetailDTO result = trcDataHeaderWrapper.getAllMultiDivision(employeeId, dataValue, dataType);
        // 验证结果不为null
        assertNotNull(result);
        // 验证返回的数据是否符合预期，无法保证通过的校验请用注释避免执行
        // 添加更多断言来验证result的属性
    }
}