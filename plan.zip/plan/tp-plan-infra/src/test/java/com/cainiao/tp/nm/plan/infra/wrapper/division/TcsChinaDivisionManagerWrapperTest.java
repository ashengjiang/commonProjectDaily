package com.cainiao.tp.nm.plan.infra.wrapper.division;

import com.base.BaseTest;
import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.aladdin.reslut.Result;
import com.cainiao.tp.nm.plan.api.policy.application.dto.DivisionDTO;
import com.cainiao.tp.nm.plan.api.policy.common.constants.AddressDivisionLevelEnum;
import com.cainiao.tp.nm.plan.infra.port.policy.CacheManager;
import com.cainiao.tps.pangu.org.client.model.dto.TpsOrgDeptDTO;
import com.cainiao.tps.pangu.org.client.service.TpsPanguOrgDeptService;
import com.taobao.biz.common.division.newera.exception.DivisionException;
import com.taobao.biz.common.division.newera.managers.division.ChinaDivisionManager;
import com.taobao.biz.common.division.newera.vo.ChinaDivisionVO;
import com.taobao.biz.common.division.newera.vo.DivisionVO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyLong;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class TcsChinaDivisionManagerWrapperTest extends BaseTest {

    @Mock
    private ChinaDivisionManager chinaDivisionManager;

    @InjectMocks
    private TcsChinaDivisionManagerWrapper wrapper;

    @Mock
    private TpsPanguOrgDeptService tpsPanguOrgDeptService;
    @Mock
    private CacheManager cacheManager;

    /**
     * 测试传入null时，getDivisionDetail应返回null
     */
    @Test
    public void testGetDivisionDetailNullDivisionId() {
        DivisionVO result = wrapper.getDivisionDetail(null);
        assertNull(result); // 验证返回值为null
    }

    /**
     * 测试传入有效的divisionId时，getDivisionDetail应正确调用chinaDivisionManager并返回DivisionVO对象
     */
    @Test
    public void testGetDivisionDetailValidDivisionId() throws DivisionException {
        Long divisionId = 1L;

        // 创建一个模拟的DivisionVO对象
        DivisionVO mockDivisionVO = Mockito.mock(DivisionVO.class);
        when(chinaDivisionManager.getDivisionById(divisionId)).thenReturn(mockDivisionVO);

        // 调用被测试的方法
        DivisionVO result = wrapper.getDivisionDetail(divisionId);

        assertNotNull(result); // 验证返回值不为null
    }

    /**
     * 测试当chinaDivisionManager抛出异常时，getDivisionDetail应捕获该异常并抛出AladdinBizException
     */
    @Test(expected = AladdinBizException.class)
    public void testGetDivisionDetailThrowsException() throws DivisionException {
        Long divisionId = 1L;

        // 模拟当调用getDivisionById时抛出异常
        when(chinaDivisionManager.getDivisionById(divisionId)).thenThrow(new RuntimeException("数据库异常"));

        // 调用被测试的方法，将抛出AladdinBizException
        wrapper.getDivisionDetail(divisionId);
    }

    /**
     * 测试传入null的divisionId时，应该返回null
     */
    @Test
    public void testGetChildDivisionWithNullDivisionIdShouldReturnNull() {
        List<DivisionVO> result = wrapper.getChildDivision(null);
        assertNull(result);
    }

    /**
     * 测试传入的divisionId无对应下级区划时，应该返回空列表
     */
    @Test
    public void testGetChildDivisionWithNoChildDivisionsShouldReturnEmptyList() throws DivisionException {
        Long divisionId = 1L;
        when(chinaDivisionManager.getChildDivisionsById(divisionId)).thenReturn(Collections.emptyList());

        List<DivisionVO> result = wrapper.getChildDivision(divisionId);
        assertEquals(0, result.size());
    }

    /**
     * 测试传入的divisionId存在下级区划时，应该正常返回下级区划列表
     */
    @Test
    public void testGetChildDivisionWithValidDivisionIdShouldReturnDivisionList() throws DivisionException {
        Long divisionId = 1L;
        DivisionVO divisionVO1 = new ChinaDivisionVO();
        DivisionVO divisionVO2 = new ChinaDivisionVO();
        List<DivisionVO> divisionVOList = Arrays.asList(divisionVO1, divisionVO2);
        when(chinaDivisionManager.getChildDivisionsById(divisionId)).thenReturn(divisionVOList);

        List<DivisionVO> result = wrapper.getChildDivision(divisionId);
        assertEquals(2, result.size());
    }

    /**
     * 测试处理时发生异常时，应该抛出自定义异常
     */
    @Test(expected = AladdinBizException.class)
    public void testGetChildDivisionWhenExceptionThrownShouldThrowAladdinBizException() throws DivisionException {
        Long divisionId = 1L;
        when(chinaDivisionManager.getChildDivisionsById(divisionId)).thenThrow(new RuntimeException("Error"));

        wrapper.getChildDivision(divisionId);
    }

    @Before
    public void setUp() throws Exception {MockitoAnnotations.openMocks(this);}

    @Test
    public void testQueryRegionCodeByCityCode() throws DivisionException {

        List<DivisionVO> divisionVOList1 = new ArrayList<>();
        DivisionVO divisionVO1 = new ChinaDivisionVO();
        divisionVO1.setDivisionName("divisionName");
        divisionVO1.setDivisionId(1L);
        divisionVO1.setDivisionLevel(4);
        DivisionVO divisionVO2 = new ChinaDivisionVO();
        divisionVO2.setDivisionName("divisionName");
        divisionVO2.setDivisionId(2L);
        divisionVO2.setDivisionLevel(4);
        divisionVOList1.add(divisionVO1);
        divisionVOList1.add(divisionVO2);

        List<DivisionVO> divisionVOList2 = new ArrayList<>();
        DivisionVO divisionVO3 = new ChinaDivisionVO();
        divisionVO3.setDivisionName("divisionName");
        divisionVO3.setDivisionId(3L);
        divisionVO3.setDivisionLevel(5);
        DivisionVO divisionVO4 = new ChinaDivisionVO();
        divisionVO4.setDivisionName("divisionName");
        divisionVO4.setDivisionId(4L);
        divisionVO4.setDivisionLevel(5);
        divisionVOList2.add(divisionVO3);
        divisionVOList2.add(divisionVO4);
        // Setup, prepare mock data
        when(chinaDivisionManager.getChildDivisionsById(anyLong()))
                .thenReturn(divisionVOList1, divisionVOList2, new ArrayList<>());

        List<TpsOrgDeptDTO> tpsOrgDeptDTOList = new ArrayList<>();
        TpsOrgDeptDTO tpsOrgDeptDTO = new TpsOrgDeptDTO();
        tpsOrgDeptDTO.setDeptCode("deptCode");
        tpsOrgDeptDTOList.add(tpsOrgDeptDTO);
        Result<List<TpsOrgDeptDTO>> deptWithAddressResult = Result.create(tpsOrgDeptDTOList);
        // Setup, prepare mock data

        when(tpsPanguOrgDeptService.getDeptWithAddress(any()))
                .thenReturn(deptWithAddressResult);
        when(cacheManager.get(anyString(), any()))
                .thenReturn(null);

        // Prepare method arguments

        // Run the method to be tested
        String result = wrapper.queryRegionCodeByCityCode("11");

        // Verify the result
        assertEquals("deptCode", result);
    }

    // 该城市下区县有街道的情况
    @Test
    public void testGetArbitraryTownCodeByCityCode() throws DivisionException {
        List<DivisionVO> divisionVOList1 = new ArrayList<>();
        DivisionVO divisionVO1 = new ChinaDivisionVO();
        divisionVO1.setDivisionName("其它县");
        divisionVO1.setDivisionId(1L);
        divisionVO1.setDivisionLevel(4);
        DivisionVO divisionVO2 = new ChinaDivisionVO();
        divisionVO2.setDivisionName("A县");
        divisionVO2.setDivisionId(2L);
        divisionVO2.setDivisionLevel(4);
        divisionVOList1.add(divisionVO1);
        divisionVOList1.add(divisionVO2);

        List<DivisionVO> divisionVOList2 = new ArrayList<>();
        DivisionVO divisionVO3 = new ChinaDivisionVO();
        divisionVO3.setDivisionName("街道1");
        divisionVO3.setDivisionId(3L);
        divisionVO3.setDivisionLevel(5);
        DivisionVO divisionVO4 = new ChinaDivisionVO();
        divisionVO4.setDivisionName("街道2");
        divisionVO4.setDivisionId(4L);
        divisionVO4.setDivisionLevel(5);
        divisionVOList2.add(divisionVO3);
        divisionVOList2.add(divisionVO4);
        // Setup, prepare mock data
        when(chinaDivisionManager.getChildDivisionsById(anyLong()))
                .thenReturn(divisionVOList1, divisionVOList2);

        // Prepare method arguments

        // Run the method to be tested
        String result = wrapper.getArbitraryTownCodeByCityCode("1");

        // Verify the result
        assertEquals("3", result);
    }

    // 该城市下区县无街道的情况
    @Test
    public void testGetArbitraryTownCodeByCityCode2() throws DivisionException {
        List<DivisionVO> divisionVOList1 = new ArrayList<>();
        DivisionVO divisionVO1 = new ChinaDivisionVO();
        divisionVO1.setDivisionName("其它县");
        divisionVO1.setDivisionId(1L);
        divisionVO1.setDivisionLevel(4);
        DivisionVO divisionVO2 = new ChinaDivisionVO();
        divisionVO2.setDivisionName("A县");
        divisionVO2.setDivisionId(2L);
        divisionVO2.setDivisionLevel(4);
        divisionVOList1.add(divisionVO1);
        divisionVOList1.add(divisionVO2);

        when(chinaDivisionManager.getChildDivisionsById(anyLong()))
                .thenReturn(divisionVOList1, new ArrayList<>());

        // Prepare method arguments

        // Run the method to be tested
        String result = wrapper.getArbitraryTownCodeByCityCode("1");

        // Verify the result
        assertEquals("1", result);
    }

    /**
     * 测试处理省级区划的分支
     * 当 divisionVO 包含省级区划时应该正确设置省级信息
     */
    @Test
    public void testGetDivisionChainWithProvinceLevel() throws DivisionException {
        Long divisionId = 1L;
        DivisionVO provinceVO = mock(DivisionVO.class);
        provinceVO.setDivisionLevel(AddressDivisionLevelEnum.DIVISION_LEVEL_PROVINECE.getLevel());
        provinceVO.setDivisionId(110000L);
        provinceVO.setDivisionName("北京市");
        List<DivisionVO> divisionVOList = Arrays.asList(provinceVO);
        when(chinaDivisionManager.getDivisionChainById(anyLong())).thenReturn(divisionVOList);
        DivisionDTO result = wrapper.getDivisionChain(divisionId);
    }

    /**
     * 测试处理市级区划的分支
     * 当 divisionVO 包含市级区划时应该正确设置市级信息
     */
    @Test
    public void testGetDivisionChainWithCityLevel() throws DivisionException {
        Long divisionId = 1L;
        DivisionVO cityVO = mock(DivisionVO.class);
        cityVO.setDivisionLevel(AddressDivisionLevelEnum.DIVISION_LEVEL_CITY.getLevel());
        cityVO.setDivisionId(110100L);
        cityVO.setDivisionName("北京市区");
        List<DivisionVO> divisionVOList = Arrays.asList(cityVO);
        when(chinaDivisionManager.getDivisionChainById(anyLong())).thenReturn(divisionVOList);
        DivisionDTO result = wrapper.getDivisionChain(divisionId);
    }

    /**
     * 测试处理区级区划的分支
     * 当 divisionVO 包含区级区划时应该正确设置区级信息
     */
    @Test
    public void testGetDivisionChainWithDistrictLevel() throws DivisionException {
        Long divisionId = 1L;
        DivisionVO districtVO = mock(DivisionVO.class);
        districtVO.setDivisionLevel(AddressDivisionLevelEnum.DIVISION_LEVEL_DISTRICT.getLevel());
        districtVO.setDivisionId(110101L);
        districtVO.setDivisionName("东城区");
        List<DivisionVO> divisionVOList = Arrays.asList(districtVO);
        when(chinaDivisionManager.getDivisionChainById(anyLong())).thenReturn(divisionVOList);
        DivisionDTO result = wrapper.getDivisionChain(divisionId);
    }

    /**
     * 测试处理镇级区划的分支
     * 当 divisionVO 包含镇级区划时应该正确设置镇级信息
     */
    @Test
    public void testGetDivisionChainWithTownLevel() throws DivisionException {
        Long divisionId = 1L;
        DivisionVO townVO = mock(DivisionVO.class);
        townVO.setDivisionLevel(AddressDivisionLevelEnum.DIVISION_LEVEL_TOWN.getLevel());
        townVO.setDivisionId(110102001L);
        townVO.setDivisionName("故宫镇");
        List<DivisionVO> divisionVOList = Arrays.asList(townVO);
        when(chinaDivisionManager.getDivisionChainById(anyLong())).thenReturn(divisionVOList);
        DivisionDTO result = wrapper.getDivisionChain(divisionId);
    }

    @Test(expected = AladdinBizException.class)
    public void testGetDivisionChainWithErr() throws DivisionException {
        Long divisionId = 1L;
        DivisionVO townVO = mock(DivisionVO.class);
        townVO.setDivisionLevel(AddressDivisionLevelEnum.DIVISION_LEVEL_TOWN.getLevel());
        townVO.setDivisionId(110102001L);
        townVO.setDivisionName("故宫镇");
        List<DivisionVO> divisionVOList = Arrays.asList(townVO);
        when(chinaDivisionManager.getDivisionChainById(anyLong())).thenThrow(new AladdinBizException("getDivisionChain", "getDivisionChain error"));
        DivisionDTO result = wrapper.getDivisionChain(divisionId);
    }
}