package com.cainiao.tp.nm.plan.infra.wrapper.express;

import com.alibaba.cainiao.express.outlets.api.result.ResultModel;
import com.alibaba.cainiao.express.outlets.base.api.result.org.EmployeeOrgDTO;
import com.alibaba.cainiao.express.outlets.base.api.result.org.OrgDTO;
import com.alibaba.cainiao.express.outlets.base.api.service.org.ExpressOrgService;
import com.alibaba.cainiao.express.outlets.contract.service.CloverOrgWhiteListService;
import com.base.BaseTest;
import com.cainiao.cnmember.client.organization.CnDepartmentReadClient;
import com.cainiao.cnmember.client.permission.DataPermissionReadClient;
import com.cainiao.member.common.CnMemberResult;
import com.cainiao.tp.nm.plan.api.policy.common.constants.CpCodeEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.OrgTypeEnum;
import com.google.common.collect.Lists;
import com.taobao.aeap.service.client.domain.CnDepartmentDTO;
import com.taobao.aeap.service.client.enums.CnOrgTypeEnum;
import com.taobao.eagleeye.EagleEye;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ExpressOrgServiceWrapperTest extends BaseTest {
    @InjectMocks
    private ExpressOrgServiceWrapper expressOrgServiceWrapper;
    @Mock
    private ExpressOrgService expressOrgService;
    @Mock
    private CnDepartmentReadClient cnDepartmentReadClient;
    @Mock
    private DataPermissionReadClient dataPermissionReadClient;
    private MockedStatic<EagleEye> eagleEyeMockedStatic;
    @Mock
    private CloverOrgWhiteListService cloverOrgWhiteListService;

    @Before
    public void setUp() throws Exception {
        // 初始化Mock对象
        MockitoAnnotations.openMocks(this);
        eagleEyeMockedStatic = Mockito.mockStatic(EagleEye.class);
    }

    @After
    public void after() {
        eagleEyeMockedStatic.close();
    }

    @Test
    public void testQueryEmployeeOrgByAccountIdSuccess() {
        // 准备Mock数据
        ResultModel<List<EmployeeOrgDTO>> listResultModel = new ResultModel<>();
        listResultModel.setData(Collections.singletonList(new EmployeeOrgDTO()));
        when(expressOrgService.queryAllDutyEmployeeOrgsByAccountId(anyLong())).thenReturn(listResultModel);
        List<EmployeeOrgDTO> result = expressOrgServiceWrapper.queryEmployeeOrgByAccountId(123L);
        Assert.assertNotNull(result);
        Assert.assertEquals(1, result.size());

    }

    @Test
    public void testQueryDataPermissionOrgListBatchQuery() {
        Long employeeId = 3L;
        CnMemberResult<List<Long>> success = CnMemberResult.success(Arrays.asList(1L, 2L, 3L));

        when(dataPermissionReadClient.getUserDataPermissionByUserId(anyLong(), anyInt())).thenReturn(success);

        CnMemberResult<List<CnDepartmentDTO>> success1 = CnMemberResult.success(Lists.newArrayList(new CnDepartmentDTO(), new CnDepartmentDTO()));
        when(cnDepartmentReadClient.queryDepartmentsByIdList(anyList()))
                .thenReturn(success1);
        List<OrgDTO> result = expressOrgServiceWrapper.queryDataPermissionOrgList(employeeId);
        Assert.assertNotNull(result);
        Assert.assertEquals(2, result.size());
    }

    @Test
    public void testQueryDataPermissionOrgListDepartmentToOrgDTO() {
        Long employeeId = 4L;

        CnMemberResult<List<Long>> success = CnMemberResult.success(Collections.singletonList(1L));
        when(dataPermissionReadClient.getUserDataPermissionByUserId(anyLong(), anyInt())).thenReturn(success);

        CnMemberResult<List<CnDepartmentDTO>> success1 = CnMemberResult.success(Collections.singletonList(new CnDepartmentDTO()));
        when(cnDepartmentReadClient.queryDepartmentsByIdList(anyList())).thenReturn(success1);

        List<OrgDTO> result = expressOrgServiceWrapper.queryDataPermissionOrgList(employeeId);
        Assert.assertNotNull(result);
    }


    /**
     * 测试过滤有效的员工组织
     */
    @Test
    public void testFilterValidEmployeeOrg() {
        // 模拟返回有效的员工组织数据
        EmployeeOrgDTO employeeOrgDTO1 = new EmployeeOrgDTO();
        employeeOrgDTO1.setCpCode("VALID_CODE");
        employeeOrgDTO1.setOrgType(CnOrgTypeEnum.BRANCH.getType());
        employeeOrgDTO1.setOrgCode("ORG_CODE_1");
        EmployeeOrgDTO employeeOrgDTO2 = new EmployeeOrgDTO();
        employeeOrgDTO2.setCpCode("INVALID_CODE");
        employeeOrgDTO2.setOrgType(CnOrgTypeEnum.BRANCH.getType());
        employeeOrgDTO2.setOrgCode("ORG_CODE_2");
        ResultModel<List<EmployeeOrgDTO>> mockResult = ResultModel.success(Arrays.asList(employeeOrgDTO1, employeeOrgDTO2));
        when(expressOrgService.queryAllDutyEmployeeOrgsByAccountId(anyLong())).thenReturn(mockResult);
//        ResultModel<CloverOrgWhiteListDTO> whiteListResult = ResultModel.success(new CloverOrgWhiteListDTO());
//        when(cloverOrgWhiteListService.queryValidOrg(anyString(), anyString())).thenReturn(whiteListResult);
        // 调用方法
        List<EmployeeOrgDTO> result = expressOrgServiceWrapper.queryCombineOrgList(1L);
        // 验证过滤掉无效员工组织
        assertEquals(2, result.size());
        assertEquals("VALID_CODE", result.get(0).getCpCode()); // 使用了静态方法进行校验
    }


    @Test
    public void testProcessValidEmployeeOrg() {
        // 模拟返回有效的溪鸟员工组织数据
        EmployeeOrgDTO xnEmployeeOrgDTO = new EmployeeOrgDTO();
        xnEmployeeOrgDTO.setCpCode(CpCodeEnum.XINIAO.getCode());
        xnEmployeeOrgDTO.setEmployeeId(123L);
        xnEmployeeOrgDTO.setOrgType(OrgTypeEnum.JV.getTypeCode());
        ResultModel<List<EmployeeOrgDTO>> mockResult = ResultModel.success(Collections.singletonList(xnEmployeeOrgDTO));
        when(expressOrgService.queryAllDutyEmployeeOrgsByAccountId(anyLong())).thenReturn(mockResult);
        CnMemberResult<List<Long>> mockDataPermResult = CnMemberResult.success(Arrays.asList(1L, 2L, 3L));
        when(dataPermissionReadClient.getUserDataPermissionByUserId(anyLong(), anyInt())).thenReturn(mockDataPermResult);
        CnDepartmentDTO dto = new CnDepartmentDTO();
        dto.setType(OrgTypeEnum.JV.getTypeCode());
        CnDepartmentDTO dto2 = new CnDepartmentDTO();
        dto2.setType(OrgTypeEnum.JV.getTypeCode());

        CnDepartmentDTO dto3 = new CnDepartmentDTO();
        dto3.setType(OrgTypeEnum.JV.getTypeCode());

        CnMemberResult<List<CnDepartmentDTO>> mockDeptResult = CnMemberResult.success(Arrays.asList(dto, dto2, dto3));
        when(cnDepartmentReadClient.queryDepartmentsByIdList(anyList())).thenReturn(mockDeptResult);
        List<EmployeeOrgDTO> result = expressOrgServiceWrapper.queryCombineOrgList(1L);
        assertEquals(3, result.size());
    }
}