package com.cainiao.tp.nm.plan.infra.diamond.purchase;

import com.cainiao.tp.nm.plan.infra.repository.purchase.dto.data.PurchasePaymentPlanDO;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

/**
 * {@link PurchasePaymentPlanConfigManager} 单元测试 */
public class PurchasePaymentPlanConfigManagerTest {

    private PurchasePaymentPlanConfigManager manager;

    @Before
    public void setUp() {
        manager = new PurchasePaymentPlanConfigManager();
    }

    /* ============================ 元信息 ============================ */

    @Test
    public void getGroupId_shouldReturnDefaultGroup() {
        assertEquals("DEFAULT_GROUP", manager.getGroupId());
    }

    @Test
    public void getDataId_shouldReturnExpectedDataId() {
        assertEquals("com.cainiao.tp.nm.plan.purchase.payment.plan.config", manager.getDataId());
    }

    /* ============================ 初始状态 ============================ */

    @Test
    public void getById_beforeLoad_shouldReturnNull() {
        assertNull(manager.getById(1L));
    }

    @Test
    public void listByIds_beforeLoad_shouldReturnEmpty() {
        List<PurchasePaymentPlanDO> result = manager.listByIds(Arrays.asList(1L, 2L));
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    /* ============================ load ============================ */

    @Test
    public void load_validJsonArray_shouldPopulateMap() {
        String json = "[{\"id\":1,\"payCode\":\"P1\",\"payName\":\"全款\",\"paymentMode\":1},"
                + "{\"id\":2,\"payCode\":\"P2\",\"paymentMode\":10}]";

        manager.load(json);

        PurchasePaymentPlanDO p1 = manager.getById(1L);
        assertNotNull(p1);
        assertEquals("P1", p1.getPayCode());
        assertEquals("全款", p1.getPayName());

        PurchasePaymentPlanDO p2 = manager.getById(2L);
        assertNotNull(p2);
        assertEquals("P2", p2.getPayCode());
    }

    @Test
    public void load_nullText_shouldClearToEmpty() {
        // 先 load 一些数据
        manager.load("[{\"id\":1,\"payCode\":\"P1\"}]");
        assertNotNull(manager.getById(1L));

        // JSON.parseObject(null, ...) 返回 null → 走兜底 emptyList
        manager.load(null);
        assertNull(manager.getById(1L));
        assertTrue(manager.listByIds(Arrays.asList(1L, 2L)).isEmpty());
    }

    @Test
    public void load_emptyJsonArray_shouldClearMap() {
        manager.load("[{\"id\":1,\"payCode\":\"P1\"}]");
        assertNotNull(manager.getById(1L));

        manager.load("[]");
        assertNull(manager.getById(1L));
    }

    @Test
    public void load_idNullEntries_shouldBeFilteredOut() {
        // 第二条没有 id，应该被 filter 掉
        String json = "[{\"id\":1,\"payCode\":\"P1\"},{\"payCode\":\"P2\"}]";

        manager.load(json);

        assertNotNull(manager.getById(1L));
        // 没有 id 的不会被索引；但 paymentPlanList 也存了，目前没有暴露 getAll，所以只验证 map
    }

    @Test
    public void load_duplicateId_shouldKeepLastByMergeFunction() {
        // (a, b) -> b 表示后者覆盖前者
        String json = "[{\"id\":1,\"payCode\":\"A\"},{\"id\":1,\"payCode\":\"B\"}]";

        manager.load(json);

        assertEquals("B", manager.getById(1L).getPayCode());
    }

    @Test
    public void load_invalidJson_shouldThrow() {
        try {
            manager.load("not a json");
            fail("expected exception");
        } catch (Exception e) {
            // 源码 load 没有 try-catch，应当抛出
        }
    }

    /* ============================ getById ============================ */

    @Test
    public void getById_nullId_shouldReturnNull() {
        manager.load("[{\"id\":1,\"payCode\":\"P1\"}]");
        assertNull(manager.getById(null));
    }

    @Test
    public void getById_notExist_shouldReturnNull() {
        manager.load("[{\"id\":1,\"payCode\":\"P1\"}]");
        assertNull(manager.getById(999L));
    }

    /* ============================ listByIds ============================ */

    @Test
    public void listByIds_nullOrEmpty_shouldReturnEmptyList() {
        manager.load("[{\"id\":1,\"payCode\":\"P1\"}]");
        assertTrue(manager.listByIds(null).isEmpty());
        assertTrue(manager.listByIds(Collections.emptyList()).isEmpty());
    }

    @Test
    public void listByIds_someNotExist_shouldFilterOutNullResults() {
        manager.load("[{\"id\":1,\"payCode\":\"P1\"},{\"id\":2,\"payCode\":\"P2\"}]");

        List<PurchasePaymentPlanDO> result = manager.listByIds(Arrays.asList(1L, 999L, 2L));
        assertEquals(2, result.size());
        // 顺序按入参顺序保留（1 存在 → 999 被过滤 → 2 存在）
        assertEquals("P1", result.get(0).getPayCode());
        assertEquals("P2", result.get(1).getPayCode());
    }

    @Test
    public void listByIds_allExist_shouldReturnAll() {
        manager.load("[{\"id\":1,\"payCode\":\"P1\"},{\"id\":2,\"payCode\":\"P2\"}]");

        List<PurchasePaymentPlanDO> result = manager.listByIds(Arrays.asList(1L, 2L));
        assertEquals(2, result.size());
    }
}
