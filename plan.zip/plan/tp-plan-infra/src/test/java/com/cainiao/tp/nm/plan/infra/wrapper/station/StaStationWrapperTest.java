package com.cainiao.tp.nm.plan.infra.wrapper.station;

import com.alibaba.cainiao.stationplatform.client.domain.StationResultDTO;
import com.alibaba.cainiao.stationplatform.client.domain.StationStationDTO;
import com.alibaba.cainiao.stationplatform.client.service.StationStationService;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.anyLong;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class StaStationWrapperTest {
    @InjectMocks
    private StaStationWrapper staStationWrapper;
    @Mock
    private StationStationService stationStationService;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testQueryStationByStationIdSuccess() {
        // 测试场景: 当stationResult.isSuccess()为true时，方法正常返回StationDTO
        // 设置mock数据
        StationStationDTO mockStationDTO = new StationStationDTO();
        StationResultDTO<StationStationDTO> mockResult = new StationResultDTO<>();
        mockResult.setData(mockStationDTO);
        mockResult.setSuccess(true);
        when(stationStationService.queryStationByStationId(anyLong())).thenReturn(mockResult);
        // 执行被测方法
        StationStationDTO result = staStationWrapper.queryStationByStationId(123L);
        Assert.assertNotNull(result);
    }

    @Test
    public void testQueryStationByStationCode() {
        // 设置mock数据
        StationStationDTO mockStationDTO = new StationStationDTO();
        StationResultDTO<StationStationDTO> mockResult = new StationResultDTO<>();
        mockResult.setData(mockStationDTO);
        mockResult.setSuccess(true);
        when(stationStationService.queryStationByStationCode(anyString())).thenReturn(mockResult);
        // 执行被测方法
        StationStationDTO result = staStationWrapper.queryStationByStationCode("stationCode");
        Assert.assertNotNull(result);
    }
}