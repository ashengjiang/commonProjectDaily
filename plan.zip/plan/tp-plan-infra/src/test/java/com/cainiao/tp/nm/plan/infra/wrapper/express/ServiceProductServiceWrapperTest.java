package com.cainiao.tp.nm.plan.infra.wrapper.express;

import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.List;

import com.alibaba.cainiao.express.outlets.api.result.ResultModel;
import com.alibaba.cainiao.express.outlets.contract.result.ServiceOpenRelationDTO;
import com.alibaba.cainiao.express.outlets.contract.service.ServiceProductService;

import com.base.BaseTest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.ExpressOutletsDetailDTO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.ExpressOutletsDivisionDTO;
import com.cainiao.tp.nm.plan.infra.port.policy.ExpressOutletsDetailManager;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

/**
 * <a href="https://alidocs.dingtalk.com/i/nodes/dpYLaezmVNRMGX56C1aKjlBOVrMqPxX6">单元测试编写&生成FAQ</a>
 * Created By Thub IDEA插件
 *
 * @Date 2025/6/26 17:40
 */
public class ServiceProductServiceWrapperTest extends BaseTest {

    @InjectMocks
    private ServiceProductServiceWrapper serviceProductServiceWrapper;
    @Mock
    private ServiceProductService serviceProductService;
    @Mock
    private ExpressOutletsDetailManager expressOutletsDetailManager;

    @Before
    public void setUp() throws Exception {MockitoAnnotations.openMocks(this);}

    @Test
    public void testQueryServices() {
        // Setup, prepare mock data
        ResultModel<List<ServiceOpenRelationDTO>> listResultModel = new ResultModel<>();
        listResultModel.setData(Arrays.asList(new ServiceOpenRelationDTO()));
        Mockito.when(serviceProductService.queryServices(any()))
            .thenReturn(listResultModel);

        // Prepare method arguments

        // Run the method to be tested
        List<ServiceOpenRelationDTO> result = serviceProductServiceWrapper.queryJvExtendServices("cpCode", "cpIdentifiedCode", "express",
            Arrays.asList("String"));

        // Verify the result
        assert result != null;
    }

    @Test
    public void testQueryServices1() {
        // Setup, prepare mock data
        ResultModel<List<ServiceOpenRelationDTO>> listResultModel = new ResultModel<>();
        listResultModel.setData(Arrays.asList(new ServiceOpenRelationDTO()));
        Mockito.when(serviceProductService.queryServices(any()))
                .thenReturn(listResultModel);

        // Prepare method arguments
        ExpressOutletsDetailDTO expressOutletsDetailDTO = new ExpressOutletsDetailDTO();
        ExpressOutletsDivisionDTO expressOutletsDivisionDTO = new ExpressOutletsDivisionDTO();
        expressOutletsDivisionDTO.setJvCpCode("jvCpCode");
        expressOutletsDetailDTO.setExpressOutletsDivisionDTO(expressOutletsDivisionDTO);
        Mockito.when(expressOutletsDetailManager.queryExpressOutletsDetail(any()))
                .thenReturn(expressOutletsDetailDTO);
        // Run the method to be tested
        List<ServiceOpenRelationDTO> result = serviceProductServiceWrapper.queryJvExtendServices("cpCode", "cpIdentifiedCode", "jv",
                Arrays.asList("String"));

        // Verify the result
        assert result != null;
    }
}