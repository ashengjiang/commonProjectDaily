package com.cainiao.tp.nm.plan.infra.wrapper.express;

import com.alibaba.cainiao.express.outlets.api.result.ResultModel;
import com.alibaba.cainiao.express.outlets.contract.param.mixcontract.EntityLaunchEditDTO;
import com.alibaba.cainiao.express.outlets.contract.service.MixContractWriteService;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.EntityLaunchEditParam;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.when;

/**
 * {@link MixContractManagerImpl} 单元测试 */
@RunWith(MockitoJUnitRunner.class)
public class MixContractManagerImplTest {

    @InjectMocks
    private MixContractManagerImpl manager;

    @Mock
    private MixContractWriteService mixContractWriteService;

    /* ============================ success ============================ */

    @Test
    public void editEntityLaunchRelation_success_shouldConvertParamsAndReturnIds() {
        EntityLaunchEditParam p1 = new EntityLaunchEditParam();
        p1.setServiceCode("SVC1");
        p1.setLaunchEntityType("EXPRESS");
        p1.setLaunchEntityCode("EC1");
        p1.setEnv("prod");
        p1.setStatus(10);
        EntityLaunchEditParam p2 = new EntityLaunchEditParam();
        p2.setServiceCode("SVC2");
        p2.setLaunchEntityCode("EC2");

        List<Long> ids = Arrays.asList(11L, 22L);
        when(mixContractWriteService.editEntityLaunchRelation(org.mockito.ArgumentMatchers.<List<EntityLaunchEditDTO>>any()))
                .thenReturn(ResultModel.buildSuccessResult(ids));

        ArgumentCaptor<List<EntityLaunchEditDTO>> captor =
                ArgumentCaptor.forClass(List.class);

        List<Long> actual = manager.editEntityLaunchRelation(Arrays.asList(p1, p2));

        assertSame(ids, actual);
        org.mockito.Mockito.verify(mixContractWriteService).editEntityLaunchRelation(captor.capture());
        List<EntityLaunchEditDTO> dtoList = captor.getValue();
        assertEquals(2, dtoList.size());
        EntityLaunchEditDTO d1 = dtoList.get(0);
        assertEquals("SVC1", d1.getServiceCode());
        assertEquals("EXPRESS", d1.getLaunchEntityType());
        assertEquals("EC1", d1.getLaunchEntityCode());
        assertEquals("prod", d1.getEnv());
        assertEquals(Integer.valueOf(10), d1.getStatus());
        // 第二个：未设置的字段保持 null
        EntityLaunchEditDTO d2 = dtoList.get(1);
        assertEquals("SVC2", d2.getServiceCode());
        assertEquals("EC2", d2.getLaunchEntityCode());
    }

    /* ============================ empty params ============================ */

    @Test
    public void editEntityLaunchRelation_emptyParams_shouldStillCallDownstream() {
        when(mixContractWriteService.editEntityLaunchRelation(org.mockito.ArgumentMatchers.<List<EntityLaunchEditDTO>>any()))
                .thenReturn(ResultModel.buildSuccessResult(Collections.emptyList()));

        List<Long> actual = manager.editEntityLaunchRelation(Collections.emptyList());
        assertNotNull(actual);
        assertEquals(0, actual.size());
    }

    /* ============================ fail ============================ */

    @Test
    public void editEntityLaunchRelation_resultFail_shouldThrowRuntime() {
        when(mixContractWriteService.editEntityLaunchRelation(org.mockito.ArgumentMatchers.<List<EntityLaunchEditDTO>>any()))
                .thenReturn(ResultModel.buildErrorResult("500", "down err"));

        try {
            manager.editEntityLaunchRelation(Collections.singletonList(new EntityLaunchEditParam()));
            fail("expected RuntimeException");
        } catch (RuntimeException e) {
            assertEquals(true, e.getMessage().contains("down err"));
        }
    }
}
