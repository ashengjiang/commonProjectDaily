package com.cainiao.tp.nm.plan.infra.wrapper.express;

import com.alibaba.cainiao.express.outlets.api.result.ResultModel;
import com.alibaba.cainiao.express.outlets.contract.api.certify.result.CertifiedEnterpriseDTO;
import com.alibaba.cainiao.express.outlets.contract.api.certify.service.EnterpriseCertifyService;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.CertifiedEnterpriseInfoDTO;
import com.cainiao.tp.nm.plan.infra.port.common.exception.ServiceException;
import com.cainiao.tp.nm.plan.infra.port.purchase.EnterpriseCertifyManager;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * 企业认证查询端口实现 */
@Slf4j
@Component
public class EnterpriseCertifyManagerImpl implements EnterpriseCertifyManager {

    /**
     * 参数拼接分隔符
     */
    private static final String PARAM_SEPARATOR = "^^^";

    @Resource
    private EnterpriseCertifyService enterpriseCertifyService;

    @Override
    public CertifiedEnterpriseInfoDTO queryCertifiedEnterprise(String expressCode) {
        if (StringUtils.isBlank(expressCode)) {
            log.warn("queryCertifiedEnterprise 参数为空, expressCode={}", expressCode);
            return null;
        }

        try {
            ResultModel<CertifiedEnterpriseDTO> result = enterpriseCertifyService.queryCertifiedEnterprise(expressCode);
            if (result == null || !result.isSuccess() || result.getData() == null) {
                log.warn("queryCertifiedEnterprise 调用失败, param={}, result={}", expressCode, result);
                return null;
            }
            return convert(result.getData());
        } catch (Exception e) {
            log.error("queryCertifiedEnterprise 调用异常, param={}", expressCode, e);
            throw ServiceException.of("企业认证查询异常");
        }
    }

    private CertifiedEnterpriseInfoDTO convert(CertifiedEnterpriseDTO source) {
        CertifiedEnterpriseInfoDTO target = new CertifiedEnterpriseInfoDTO();
        target.setEnterpriseName(source.getEnterpriseName());
        target.setRegCode(source.getRegCode());
        target.setLegalPerson(source.getLegalPerson());
        target.setLegalMobile(source.getLegalMobile());
        target.setTransactorMobile(source.getTransactorMobile());
        target.setSignMobile(source.getSignMobile());
        target.setPicOssKey(source.getPicOssKey());
        target.setGmtModified(source.getGmtModified());
        return target;
    }
}
