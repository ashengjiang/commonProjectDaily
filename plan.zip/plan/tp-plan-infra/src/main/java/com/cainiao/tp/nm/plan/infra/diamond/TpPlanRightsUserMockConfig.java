package com.cainiao.tp.nm.plan.infra.diamond;

import com.alibaba.boot.diamond.annotation.DiamondListener;
import com.cainiao.aladdin.diamond.AladdinBootJsonDiamondListener;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.RightsUserMockHolderDTO;

@DiamondListener(dataId = "plan.rights.user.mock", executeAfterInit = true)
public class TpPlanRightsUserMockConfig extends AladdinBootJsonDiamondListener<RightsUserMockHolderDTO> {


    @Override
    public void setInstance(RightsUserMockHolderDTO holder) {
        RightsUserMockHolderDTO.setInstance(holder);
    }

    @Override
    public Class<RightsUserMockHolderDTO> getClazz() {
        return RightsUserMockHolderDTO.class;
    }
}
