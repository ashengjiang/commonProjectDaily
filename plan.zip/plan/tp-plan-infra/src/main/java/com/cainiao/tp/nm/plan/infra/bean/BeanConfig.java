package com.cainiao.tp.nm.plan.infra.bean;

import com.alibaba.cainiao.stationplatform.client.cache.StationExpressReadServiceClient;
import com.alibaba.cainiao.stationplatform.client.service.StationAuthUserService;
import com.alibaba.cainiao.stationplatform.client.service.StationPartnerService;
import com.alibaba.cainiao.stationplatform.client.service.StationStationService;
import com.alibaba.cainiao.stationplatform.client.service.client.StationAuthUserReadServiceClient;
import com.alibaba.cainiao.stationplatform.client.service.client.StationStationReadServiceClient;
import com.alibaba.cainiao.stationplatform.client.service.client.cache.StationCacheServiceClient;
import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.tp.nm.plan.infra.bean.condition.DailyEnvironmentCondition;
import com.taobao.mtop.api.agent.MtopAgent;
import com.taobao.mtop2.spi.jar.JarSessionSPI;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

/**
 * @code date 2025年06月10日 14:50
 * @code desc:null
 */
@Configuration
public class BeanConfig {
    @Bean
    public StationExpressReadServiceClient stationExpressReadServiceClient() {
        return new StationExpressReadServiceClient();
    }
    @Bean
    @Conditional(DailyEnvironmentCondition.class)
    public MtopAgent mtopHsfAgent(@Qualifier("cnMemberMtopSessionService") JarSessionSPI cnMemberMtopSessionService) {
        Map<String, JarSessionSPI> customSessionSPIMap = new HashMap<>();
        customSessionSPIMap.put("CAINIAO", cnMemberMtopSessionService);
        MtopAgent mtopAgent = new MtopAgent();
        mtopAgent.setAppName("tp-nm-plan");
        mtopAgent.setCustomSessionSPIMap(customSessionSPIMap);
        mtopAgent.init();
        return mtopAgent;
    }

    @Bean
    public StationCacheServiceClient stationCacheServiceClient() {
        StationCacheServiceClient cacheServiceClient = new StationCacheServiceClient();
        try {
            cacheServiceClient.afterPropertiesSet();
        } catch (Exception e) {
            throw new AladdinBizException("Inject.bean.error", "stationCacheServiceClient error", e);
        }
        return cacheServiceClient;
    }

    @Bean
    public StationAuthUserReadServiceClient stationAuthUserReadServiceClient(
            @Qualifier("stationCacheServiceClient") StationCacheServiceClient stationCacheServiceClient,
            @Qualifier("stationAuthUserService") StationAuthUserService stationAuthUserService) {
        StationAuthUserReadServiceClient serviceClient = new StationAuthUserReadServiceClient();
        serviceClient.setStationAuthUserService(stationAuthUserService);
        serviceClient.setStationCacheServiceClient(stationCacheServiceClient);
        return serviceClient;
    }

    @Bean
    @ConditionalOnMissingBean
    public StationStationReadServiceClient stationStationReadServiceClient(@Qualifier("stationCacheServiceClient") StationCacheServiceClient stationCacheServiceClient, @Qualifier("stationStationService") StationStationService stationStationService, @Qualifier("stationPartnerService") StationPartnerService stationPartnerService) {
        StationStationReadServiceClient readServiceClient = new StationStationReadServiceClient();
        readServiceClient.setStationCacheServiceClient(stationCacheServiceClient);
        readServiceClient.setStationStationService(stationStationService);
        readServiceClient.setStationPartnerService(stationPartnerService);
        return readServiceClient;
    }


}
