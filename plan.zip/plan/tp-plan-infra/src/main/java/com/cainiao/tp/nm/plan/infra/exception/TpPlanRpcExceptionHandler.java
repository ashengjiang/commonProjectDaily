package com.cainiao.tp.nm.plan.infra.exception;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * 站点域全局异常拦截处理器 */
@Aspect
@Component
@Order
public class TpPlanRpcExceptionHandler extends AbstractRpcExceptionHandler {

    @Pointcut("execution(public * com.cainiao.tp.nm.plan.*.adaptor.service..*.*(..)) || execution(public * com.cainiao.tp.nm.plan.*.adaptor.mtop..*.*(..))")
    public void pointCutAt() {
    }

    @Around("pointCutAt()")
    public Object around(ProceedingJoinPoint proceedingJoinPoint) {
        return super.around(proceedingJoinPoint);
    }

}
