package com.cainiao.tp.nm.plan.infra.diamond;

import com.alibaba.boot.diamond.annotation.DiamondListener;
import com.cainiao.aladdin.diamond.AladdinBootJsonDiamondListener;
import com.cainiao.tp.nm.plan.api.policy.application.dto.StationAssessmentConfigHolder;

/**
 * @code date 2025年08月04日 10:15
 * @code desc:null
 */
@DiamondListener(dataId = "plan.station.incentive.assessment.config", executeAfterInit = true)
public class TpPlanStationAssessmentConfig extends AladdinBootJsonDiamondListener<StationAssessmentConfigHolder> {

    @Override
    public void setInstance(StationAssessmentConfigHolder stationAssessmentConfigHolder) {
        StationAssessmentConfigHolder.setINSTANCE(stationAssessmentConfigHolder);
    }

    @Override
    public Class<StationAssessmentConfigHolder> getClazz() {
        return StationAssessmentConfigHolder.class;
    }
}
