package com.cainiao.tp.nm.plan.infra.bean.condition;

import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.env.Environment;
import org.springframework.core.type.AnnotatedTypeMetadata;
import org.springframework.stereotype.Component;

/**
 * @code date 2025年06月12日 17:01
 * @code desc:null
 */
@Component
public class DailyEnvironmentCondition implements Condition {


    @Override
    public boolean matches(@NotNull ConditionContext context, @NotNull AnnotatedTypeMetadata metadata) {
        Environment environment = context.getEnvironment();
        String env = environment.getProperty("spring.tp.env");
        return !"DAILY".equals(env);
    }
}
