package com.cainiao.tp.nm.plan.infra.wrapper.express;

import com.alibaba.cainiao.express.outlets.api.result.ResultModel;
import com.alibaba.cainiao.express.outlets.contract.enums.ServiceOpenRelationStatusEnum;
import com.alibaba.cainiao.express.outlets.contract.param.QueryServiceRequest;
import com.alibaba.cainiao.express.outlets.contract.result.ServiceOpenRelationDTO;
import com.alibaba.cainiao.express.outlets.contract.service.ServiceProductService;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.ExpressOutletsDetailDTO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.ExpressOutletsQueryRequest;
import com.cainiao.tp.nm.plan.api.policy.common.constants.ExpressTypeEnum;
import com.cainiao.tp.nm.plan.infra.port.policy.ExpressOutletsDetailManager;
import com.cainiao.tp.nm.plan.infra.wrapper.enums.ExpressTypeMapperEnum;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * @Date 2025/6/3 16:34
 * @code desc: 工单wrapper
 */
@Slf4j
@Component
public class ServiceProductServiceWrapper {

    @Resource
    ServiceProductService serviceProductService;

    @Resource
    ExpressOutletsDetailManager expressOutletsDetailManager;

    public List<ServiceOpenRelationDTO> queryServices(String cpCode, String cpIdentifiedCode,String entityType, List<String> serviceCodeList) {
        QueryServiceRequest queryServiceRequest = new QueryServiceRequest();
        queryServiceRequest.setCpCode(cpCode);
        queryServiceRequest.setCpIdentifiedCode(cpIdentifiedCode);
        queryServiceRequest.setStatusList(Lists.newArrayList(ServiceOpenRelationStatusEnum.OPENED.getValue()));
        queryServiceRequest.setServiceCodeList(serviceCodeList);
        ExpressTypeMapperEnum expressTypeMapperEnum = ExpressTypeMapperEnum.ofCustomerType(entityType);
        AssertUtil.isTrue(null != expressTypeMapperEnum, "未找到映射类型，无法查询");

        queryServiceRequest.setEntityType(expressTypeMapperEnum.getExpressEntityTypeEnum().getValue());
        queryServiceRequest.setBizDomain(expressTypeMapperEnum.getBizDomainEnum().getValue());
        ResultModel<List<ServiceOpenRelationDTO>> queryServices = serviceProductService.queryServices(queryServiceRequest);

        AssertUtil.isTrue(null != queryServices && queryServices.isSuccess(), "serviceProductService.queryServices调用失败");
        return queryServices.getData();
    }




    public List<ServiceOpenRelationDTO> queryJvExtendServices(String cpCode, String cpIdentifiedCode,String entityType, List<String> serviceCodeList) {
        String signCode=cpIdentifiedCode;
        if (ExpressTypeEnum.JV.getCode().equals(entityType)) {
            ExpressOutletsQueryRequest request=new ExpressOutletsQueryRequest();
            request.setOrgType(entityType);
            request.setOrgCode(cpIdentifiedCode);
            request.setCpCode(cpCode);

            ExpressOutletsDetailDTO expressOutletsDetailDTO = expressOutletsDetailManager.queryExpressOutletsDetail(request);
            if(null==expressOutletsDetailDTO){
                return Lists.newArrayList();
            }
            signCode = expressOutletsDetailDTO.getExpressOutletsDivisionDTO().getJvCpCode();
        }
        QueryServiceRequest queryServiceRequest = new QueryServiceRequest();
        queryServiceRequest.setCpCode(cpCode);
        queryServiceRequest.setCpIdentifiedCode(signCode);
        queryServiceRequest.setStatusList(Lists.newArrayList(ServiceOpenRelationStatusEnum.OPENED.getValue()));
        queryServiceRequest.setServiceCodeList(serviceCodeList);
        ExpressTypeMapperEnum expressTypeMapperEnum = ExpressTypeMapperEnum.ofCustomerType(entityType);
        AssertUtil.isTrue(null != expressTypeMapperEnum, "未找到映射类型，无法查询");

        queryServiceRequest.setEntityType(expressTypeMapperEnum.getExpressEntityTypeEnum().getValue());
        queryServiceRequest.setBizDomain(expressTypeMapperEnum.getBizDomainEnum().getValue());
        ResultModel<List<ServiceOpenRelationDTO>> queryServices = serviceProductService.queryServices(queryServiceRequest);

        AssertUtil.isTrue(null != queryServices && queryServices.isSuccess(), "serviceProductService.queryServices调用失败");
        return queryServices.getData();
    }


}
