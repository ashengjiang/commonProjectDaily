package com.cainiao.tp.nm.plan.infra.thrd.duoniu;

import com.cainiao.terminal.iot.aftersales.api.domain.output.DuoNiuOrderDetailResDTO;
import com.cainiao.terminal.iot.aftersales.api.domain.output.DuoNiuOrderTradeDTO;
import com.cainiao.terminal.iot.aftersales.api.domain.output.DuoNiuOrdersDTO;
import com.cainiao.terminal.iot.aftersales.api.domain.output.DuoNiuSkuDetailResDTO;
import com.cainiao.terminal.iot.aftersales.api.domain.output.Skus;
import com.cainiao.terminal.iot.aftersales.api.service.duoniu.DuoNiuQueryService;
import com.cainiao.terminal.sta.result.TpRestResult;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.DuoNiuOrderDetailDTO;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.DuoNiuSkuDTO;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.DuoNiuSkuDetailDTO;
import com.cainiao.tp.nm.plan.infra.port.purchase.DuoNiuQueryManager;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 多牛商品查询端口实现
 * <p>
 * 通过 HSF 调用 {@link DuoNiuQueryService#querySkuByItemId(Integer)} 查询万里牛 SKU 详情，
 * 并将三方 DTO 转换为 port 层自定义 DTO 返回。
 * </p> */
@Slf4j
@Component
public class DuoNiuQueryManagerImpl implements DuoNiuQueryManager {

    @Resource
    private DuoNiuQueryService duoNiuQueryService;

    @Override
    public DuoNiuSkuDetailDTO querySkuByItemId(Integer itemId) {
        log.info("querySkuByItemId, itemId={}", itemId);
        TpRestResult<DuoNiuSkuDetailResDTO> result = duoNiuQueryService.querySkuByItemId(itemId);
        if (!result.isSuccess()) {
            log.error("querySkuByItemId 调用失败, itemId={}, errorMsg={}", itemId, result.getErrorMsg());
            throw new RuntimeException("querySkuByItemId 调用失败, itemId=" + itemId + ", errorMsg=" + result.getErrorMsg());
        }
        return convertToSkuDetailDTO(result.getData());
    }

    private DuoNiuSkuDetailDTO convertToSkuDetailDTO(DuoNiuSkuDetailResDTO source) {
        if (source == null) {
            return null;
        }
        DuoNiuSkuDetailDTO target = new DuoNiuSkuDetailDTO();
        target.setItemId(source.getItemID());
        target.setCategoryId(source.getCategoryID());
        target.setSupplierId(source.getSupplierID());
        target.setTitle(source.getTitle());
        target.setPrice(source.getPrice());
        target.setQuantity(source.getQuantity());
        target.setItemUrl(source.getItemURL());
        target.setImageUrl(source.getImageURL());
        target.setStatus(source.getStatus());
        target.setCreateTime(source.getCreateTime());
        target.setProperties(source.getProperties());
        target.setBrand(source.getBrand());
        target.setItemCode(source.getItemCode());
        target.setArticleNumber(source.getArticleNumber());
        target.setSkusList(convertSkusList(source.getSkusList()));
        return target;
    }

    private List<DuoNiuSkuDTO> convertSkusList(List<Skus> sourceList) {
        if (CollectionUtils.isEmpty(sourceList)) {
            return Collections.emptyList();
        }
        return sourceList.stream().map(source -> {
            DuoNiuSkuDTO target = new DuoNiuSkuDTO();
            target.setSkuId(source.getSkuID());
            target.setItemId(source.getItemID());
            target.setSkuCode(source.getSkuCode());
            target.setPrice(source.getPrice());
            target.setSupplierId(source.getSupplierID());
            target.setImageUrl(source.getImageURL());
            target.setStatus(source.getStatus());
            target.setWeight(source.getWeight());
            target.setAttributes(source.getAttributes());
            target.setVolume(source.getVolume());
            target.setBarCode(source.getBarCode());
            return target;
        }).collect(Collectors.toList());
    }

    @Override
    public DuoNiuOrderDetailDTO queryOrderDetailById(String orderId, String supplierId) {
        log.info("queryOrderDetailById, orderId={}, supplierId={}", orderId, supplierId);
        TpRestResult<DuoNiuOrderDetailResDTO> result = duoNiuQueryService.queryOrderDetailById(orderId, supplierId);
        if (!result.isSuccess()) {
            log.error("queryOrderDetailById 调用失败, orderId={}, supplierId={}, errorMsg={}", orderId, supplierId, result.getErrorMsg());
            throw new RuntimeException("queryOrderDetailById 调用失败, orderId=" + orderId + ", errorMsg=" + result.getErrorMsg());
        }
        return convertToOrderDetailDTO(result.getData());
    }

    private DuoNiuOrderDetailDTO convertToOrderDetailDTO(DuoNiuOrderDetailResDTO source) {
        if (source == null) {
            return null;
        }
        DuoNiuOrderDetailDTO target = new DuoNiuOrderDetailDTO();
        target.setTradeId(source.getTradeID());
        target.setSupplierId(source.getSupplierID());
        target.setDistributorId(source.getDistributorID());
        target.setPayTime(source.getPayTime());
        target.setEndTime(source.getEndTime());
        target.setModifyTime(source.getModifyTime());
        target.setShippingTime(source.getShippingTime());
        target.setSellerMemo(source.getSellerMemo());
        target.setShippingType(source.getShippingType());
        target.setItemAmount(source.getItemAmount());
        target.setTotalFee(source.getTotalFee());
        target.setPostFee(source.getPostFee());
        target.setPayment(source.getPayment());
        target.setDiscountFee(source.getDiscountFee());
        target.setBuyer(source.getBuyer());
        target.setBuyerMessage(source.getBuyerMessage());
        target.setReceiverMobile(source.getReceiverMobile());
        target.setHasRefund(source.getHasRefund());
        target.setLogisticsNo(source.getLogisticsNo());
        target.setLogisticsName(source.getLogisticsName());
        target.setInvoiceType(source.getInvoiceType());
        target.setOrderDels(source.getOrderDels());
        target.setPaymentType(source.getPaymentType());
        target.setPayStatus(source.getPayStatus());
        target.setPayNo(source.getPayNo());
        target.setPayDeclareAmount(source.getPayDeclareAmount());
        target.setTradePayInfo(source.getTradePayInfo());
        target.setTradeType(source.getTradeType());
        target.setSnJson(source.getSnJson() != null ? source.getSnJson().toJSONString() : null);
        target.setStationId(source.getStationId());
        target.setOrders(convertOrdersList(source.getOrders()));
        target.setTradeDTOList(convertTradeList(source.getTradeDTOList()));
        target.setExtParam(source.getExtParam());
        String siteAppExtParam = source.getSiteAppExtParam();
        target.setSiteAppExtParam(siteAppExtParam);
        return target;
    }

    private List<DuoNiuOrderDetailDTO.OrderItemDTO> convertOrdersList(List<DuoNiuOrdersDTO> sourceList) {
        if (CollectionUtils.isEmpty(sourceList)) {
            return Collections.emptyList();
        }
        return sourceList.stream().map(source -> {
            DuoNiuOrderDetailDTO.OrderItemDTO target = new DuoNiuOrderDetailDTO.OrderItemDTO();
            target.setTradeId(source.getTradeID());
            target.setOrderId(source.getOrderID());
            target.setItemId(source.getItemID());
            target.setItemTitle(source.getItemTitle());
            target.setSupplierId(source.getSupplierID());
            target.setSkuId(source.getSkuID());
            target.setSkuTitle(source.getSkuTitle());
            target.setSkuCode(source.getSkuCode());
            target.setStatus(source.getStatus());
            target.setSize(source.getSize());
            target.setPayment(source.getPayment());
            target.setPrice(source.getPrice());
            target.setActualPrice(source.getActualPrice());
            return target;
        }).collect(Collectors.toList());
    }

    private List<DuoNiuOrderDetailDTO.OrderTradeDTO> convertTradeList(List<DuoNiuOrderTradeDTO> sourceList) {
        if (CollectionUtils.isEmpty(sourceList)) {
            return Collections.emptyList();
        }
        return sourceList.stream().map(source -> {
            DuoNiuOrderDetailDTO.OrderTradeDTO target = new DuoNiuOrderDetailDTO.OrderTradeDTO();
            target.setTradeNo(source.getTradeNo());
            target.setWaybill(source.getWaybill());
            target.setExpressId(source.getExpressID());
            target.setExpressCode(source.getExpressCode());
            target.setExpressName(source.getExpressName());
            target.setTradeId(source.getTradeID());
            target.setSupplierId(source.getSupplierID());
            target.setErpTradeNo(source.getErpTradeNo());
            target.setStorageName(source.getStorageName());
            return target;
        }).collect(Collectors.toList());
    }
}
