package com.cainiao.tp.nm.plan.infra.thrd.rights;

import com.alibaba.cainiao.tp.trc.org.client.constants.TpAccountTypeEnum;
import com.alibaba.cainiao.tp.trc.org.client.domain.employee.output.TpAccountDTO;
import com.alibaba.cainiao.tp.trc.org.client.domain.employee.output.TpEmployeeDetailDTO;
import com.alibaba.cainiao.tp.trc.org.client.domain.employee.output.TpEmployeeTerritoryDTO;
import com.alibaba.fastjson.JSON;

import cn.hutool.core.collection.CollUtil;
import com.cainiao.aladdin.exception.AladdinParamException;
import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.aladdin.operation.SystemBizOperation;
import com.cainiao.aladdin.reslut.PageResult;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.tp.nm.plan.infra.port.policy.CacheManager;
import com.cainiao.tp.nm.plan.infra.wrapper.division.TcsChinaDivisionManagerWrapper;
import com.cainiao.tp.nm.plan.infra.wrapper.org.TpEmployeeManager;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.PolicyOpRightsVO;
import com.cainiao.tp.nm.plan.infra.port.policy.EmployeeRightsLoadManager;
import com.cainiao.tps.control.org.client.api.newOrg.TpsNewOrgDeptService;
import com.cainiao.tps.control.org.client.constant.HcmOmOrgCodeEnum;
import com.cainiao.tps.control.org.client.constant.newDept.TpsOrgNewDeptLevelEnum;
import com.cainiao.tps.control.org.client.model.dto.dept.TpsOrgDeptDTO;
import com.cainiao.tps.control.org.client.model.request.query.newDept.TpsNewDeptQueryWithConditionReq;
import com.cainiao.tps.pangu.org.common.enums.TpsOrgEmployeePermissionEnum;
import com.taobao.biz.common.division.newera.vo.ChinaDivisionLevel;
import com.taobao.biz.common.division.newera.vo.DivisionVO;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @description:员工权限加载
 */
@Component
public class EmployeeRightsLoadManagerImpl implements EmployeeRightsLoadManager {

    // 城市以上(包含城市)，直接获取部门权限地址的层级
    private static final List<String> CITY_UPPER_DIRECT_DEPT_LIST = Arrays.asList("RG", "RP", "HP", "CP", "EBU", "CT");

    @Resource
    private TpEmployeeManager tpEmployeeManager;

    @Resource
    private TcsChinaDivisionManagerWrapper tcsChinaDivisionManagerWrapper;

    @Resource
    private CacheManager cacheManager;

    @Resource
    private TpsNewOrgDeptService tpsNewOrgDeptService;

    private final AbstractOperation opInfo = new SystemBizOperation(0L, "tp-nm-plan");

    public final static String CACHE_KEY_EMPLOYEE_ROLES = "CACHE_KEY_EMPLOYEE_ROLES:";

    public final static String CACHE_KEY_DIVISION_RIGHTS = "CACHE_KEY_DIVISION_RIGHTS:v5:";

    //缓存2小时
    private final static Integer EXPIRE_TIME = 60*60*2;

    private static final String HIGHEST_DEPT_CODE_TAIR_KEY = "plan:highest:levelCode:v3:";

    private static final int HIGHEST_DEPT_CODE_TAIR_EXPIRE = 60 * 60 * 2;

    @Override
    public List<String> getEmployeeRoles(Long employeeId,Set<String> expectRoleCodes) {
        String cacheKey = CACHE_KEY_EMPLOYEE_ROLES+employeeId;
        List<String> roleCodes = cacheManager.get(cacheKey, ArrayList.class);
        if(CollectionUtils.isNotEmpty(roleCodes)){
            return roleCodes;
        }
        opInfo.setOperatorId(employeeId.toString());
        TpEmployeeDetailDTO employeeDetailDTO = tpEmployeeManager.getEmployee(employeeId, opInfo);
        if(CollectionUtils.isEmpty(employeeDetailDTO.getEmployeeTerritoryDTOS())){
            return null;
        }
        List<String> roleCodesResult = employeeDetailDTO.getEmployeeTerritoryDTOS().stream().map(TpEmployeeTerritoryDTO::getRoleCode).collect(Collectors.toList());
        //提升体验，命中预期才放置缓存
        if(expectRoleCodes!=null && !expectRoleCodes.isEmpty()){
            if(new HashSet<>(roleCodesResult).containsAll(expectRoleCodes)){
                cacheManager.set(cacheKey,new ArrayList<>(roleCodesResult), EXPIRE_TIME);
            }
        }else{
            cacheManager.set(cacheKey,new ArrayList<>(roleCodesResult), EXPIRE_TIME);
        }
        return roleCodesResult;
    }

    @Override
    public PolicyOpRightsVO getDivisionRights(Long employeeId) {
        String cacheKey = CACHE_KEY_DIVISION_RIGHTS+employeeId;
        PolicyOpRightsVO rightsVO = cacheManager.get(cacheKey, PolicyOpRightsVO.class);
        if(rightsVO != null){
            return rightsVO;
        }
        // 1. 查询用户所在的部门
        List<TpsOrgDeptDTO> employeeDeptList = tpEmployeeManager.queryDeptByEmployeeId(
                employeeId, HcmOmOrgCodeEnum.YZ_MERGE_OPERATE.getBizDomain());
        PolicyOpRightsVO policyOpRightsVO = buildPolicyOpRightsVO(employeeDeptList);
        cacheManager.set(cacheKey, policyOpRightsVO, EXPIRE_TIME);
        return policyOpRightsVO;
    }

    @Override
    public String getCnUserId(Long employeeId) {
        TpEmployeeDetailDTO employeeDetailDTO = tpEmployeeManager.getEmployee(employeeId, opInfo);
        TpAccountDTO cnUserAccount = CollUtil.findOne(
            employeeDetailDTO.getBindAccounts(),
            account -> TpAccountTypeEnum.CN_USER.name().equals(account.getAccountType())
        );
        if (cnUserAccount == null) {
            throw new AladdinParamException("获取菜鸟会员ID失败 employeeId: " + employeeId);
        }
        return cnUserAccount.getAccountId();
    }

    @Override
    public String selectRegionDeptCode(String cityCode) {
        TpsNewDeptQueryWithConditionReq req = new TpsNewDeptQueryWithConditionReq();
        req.setPermissionData(cityCode);
        req.setBizDomain(HcmOmOrgCodeEnum.YZ_MERGE_OPERATE.getBizDomain());
        req.setLevelCode(TpsOrgNewDeptLevelEnum.RG_LEVEL.getCode());
        req.setPermissionDataType(TpsOrgEmployeePermissionEnum.DISTRICT.getType());
        PageResult<List<TpsOrgDeptDTO>> tpsOrgDeptPageResult = tpsNewOrgDeptService.queryDeptWithCondition(req);
        AssertUtil.isTrue(tpsOrgDeptPageResult.isSuccess(), "查询大区部门失败");
        AssertUtil.isTrue(CollectionUtils.isNotEmpty(tpsOrgDeptPageResult.getData()), "查询大区部门失败");
        AssertUtil.notNull(tpsOrgDeptPageResult.getData().get(0), "查询大区部门失败");
        AssertUtil.notNull(tpsOrgDeptPageResult.getData().get(0).getDeptCode(), "查询大区部门失败");
        return tpsOrgDeptPageResult.getData().get(0).getDeptCode();
    }


    @Override
    public String getEmployeeHighestLevelCode(Long employeeId) {
//        String cacheKey = HIGHEST_DEPT_CODE_TAIR_KEY + employeeId;
//        String levelCode = cacheManager.get(cacheKey, String.class);
//        if (StringUtils.isNotBlank(levelCode)) {
//            return levelCode;
//        }
        TpsOrgDeptDTO employeeHighestDept = tpEmployeeManager.getEmployeeHighestDept(employeeId, HcmOmOrgCodeEnum.YZ_MERGE_OPERATE.getBizDomain());
        if (employeeHighestDept == null) {
            throw new AladdinParamException("获取员工最高部门失败 employeeId: " + employeeId);
        }
//        levelCode = employeeHighestDept.getLevelCode();
//        cacheManager.set(cacheKey, levelCode, HIGHEST_DEPT_CODE_TAIR_EXPIRE);
//        return levelCode;
        return employeeHighestDept.getLevelCode();
    }

    @Override
    public String queryRegionCodeByCityCode(String cityCode) {
        String regionCode = tcsChinaDivisionManagerWrapper.queryRegionCodeByCityCode(cityCode);
        if (StringUtils.isBlank(regionCode)) {
            throw new AladdinParamException("获取大区code失败 cityCode: " + cityCode);
        }
        return regionCode;
    }

    @Override
    public void clearCache(Long employeeId) {
        String roleCacheKey = CACHE_KEY_EMPLOYEE_ROLES+employeeId;
        String cityCacheKey = CACHE_KEY_DIVISION_RIGHTS+employeeId;
        cacheManager.set(roleCacheKey,null,EXPIRE_TIME);
        cacheManager.set(cityCacheKey,null,EXPIRE_TIME);
    }


    private PolicyOpRightsVO buildPolicyOpRightsVO(List<TpsOrgDeptDTO> employeeDeptList) {
        PolicyOpRightsVO policyOpRightsVO = new PolicyOpRightsVO();
        if (CollectionUtils.isEmpty(employeeDeptList)) {
            return policyOpRightsVO;
        }
        List<TpsOrgDeptDTO> cnDeptList = employeeDeptList.stream().filter(o->o.getLevelCode().equals(TpsOrgNewDeptLevelEnum.CN_LEVEL.getCode())).collect(Collectors.toList());
        if(!CollectionUtils.isEmpty(cnDeptList)){
            policyOpRightsVO.setHasCnRights(Boolean.TRUE);
            //有全国权限就没必要展开了
            return policyOpRightsVO;
        }
        List<TpsOrgDeptDTO> subDeptList = employeeDeptList.stream().filter(o->CITY_UPPER_DIRECT_DEPT_LIST.contains(o.getLevelCode())).collect(Collectors.toList());
        //城市以下的权限不用关注
        if(CollectionUtils.isEmpty(subDeptList)){
            return policyOpRightsVO;
        }
        // 城市以上的部门,直接获取区划地址
        Map<Integer, Set<Long>> divisionPermissionMap = this.convertDept2DivisionMap(new ArrayList<>(subDeptList));
        policyOpRightsVO.setCityCodes(divisionPermissionMap.get(ChinaDivisionLevel.CITY.getLevel()));
        Set<Long> provIdList = divisionPermissionMap.get(ChinaDivisionLevel.PROV.getLevel());
        // 如果没有省级权限，直接返回
        if (CollectionUtils.isEmpty(provIdList)) {
            return policyOpRightsVO;
        }
        // 将省的数据转换为城市
        for (Long provId : provIdList) {
            List<DivisionVO> childDivisionList = tcsChinaDivisionManagerWrapper.getChildDivision(provId);
            if (CollectionUtils.isEmpty(childDivisionList)) {
                continue;
            }
            for (DivisionVO divisionDetail : childDivisionList) {
                if (null == divisionDetail) {
                    continue;
                }
                if (policyOpRightsVO.getCityCodes() == null) {
                    policyOpRightsVO.setCityCodes(new HashSet<>());
                }
                policyOpRightsVO.getCityCodes().add(divisionDetail.getDivisionId());
            }
        }
        return policyOpRightsVO;
    }


    /**
     * 将部门代码列表转换为分区权限Map
     *
     * <p>根据部门代码列表，将其转换为以分区级别为键，分区ID集合为值的Map。</p>
     *
     * @param deptCodeList 部门代码列表
     * @return 分区权限Map，如果部门代码列表为空，则返回空Map
     */
    private Map<Integer, Set<Long>> convertDept2DivisionMap(List<TpsOrgDeptDTO> deptCodeList) {
        Map<Integer, Set<Long>> divisionPermissionMap = new HashMap<>();
        if (org.apache.commons.collections4.CollectionUtils.isEmpty(deptCodeList)) {
            return divisionPermissionMap;
        }
        for (TpsOrgDeptDTO orgDeptDTO : deptCodeList) {
            if (orgDeptDTO == null) {
                continue;
            }
            if (StringUtils.isBlank(orgDeptDTO.getPermissionData())) {
                continue;
            }
            final List<String> addressCodeList = Arrays.asList(orgDeptDTO.getPermissionData().split(","));
            if (org.apache.commons.collections4.CollectionUtils.isEmpty(addressCodeList)) {
                continue;
            }
            for (String address : addressCodeList) {
                Long divisionId = JSON.parseObject(address, Long.class);
                DivisionVO divisionDetail = tcsChinaDivisionManagerWrapper.getDivisionDetail(divisionId);
                if (null == divisionDetail) {
                    continue;
                }
                Set<Long> divisionIdList = divisionPermissionMap.get(divisionDetail.getDivisionLevel());
                if (divisionIdList == null) {
                    divisionIdList = new HashSet<>();
                }
                divisionIdList.add(divisionDetail.getDivisionId());
                divisionPermissionMap.put(divisionDetail.getDivisionLevel(), divisionIdList);
            }
        }
        return divisionPermissionMap;
    }
}
