package com.cainiao.tp.nm.plan.infra.repository.policy;

import com.cainiao.aladdin.utils.Safes;
import com.cainiao.sutee.commons.base.model.CnPage;
import com.cainiao.sutee.commons.base.model.Page;
import com.cainiao.tp.nm.plan.infra.repository.policy.convert.PolicyTemplateConvertor;
import com.cainiao.tp.nm.plan.infra.repository.policy.convert.PolicyTemplateDetailConvertor;
import com.cainiao.tp.nm.plan.infra.repository.policy.dto.data.PolicyRuleTemplateDO;
import com.cainiao.tp.nm.plan.infra.repository.policy.dto.data.PolicyTemplateDO;
import com.cainiao.tp.nm.plan.infra.repository.policy.dto.param.PolicyRuleTemplateQueryParam;
import com.cainiao.tp.nm.plan.infra.repository.policy.dto.param.PolicyTemplateQueryParam;
import com.cainiao.tp.nm.plan.infra.repository.policy.mapper.PolicyRuleTemplateMapper;
import com.cainiao.tp.nm.plan.infra.repository.policy.mapper.PolicyTemplateMapper;
import com.cainiao.tp.nm.plan.infra.repository.policy.sort.PolicyTempldateSortEnum;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyTemplateDTO;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyFeatureConstants;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyTemplateDurationStatusEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyTemplateStatusEnum;
import com.cainiao.tp.nm.plan.policy.domain.model.PolicyTemplate;
import com.cainiao.tp.nm.plan.policy.domain.repository.PolicyTemplateRepository;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @code date 2024年10月28日 17:04
 * @code desc: 政策模版仓储
 */
@Component
@Slf4j
public class PolicyTemplateRepositoryImpl implements PolicyTemplateRepository {

    @Resource
    private PolicyTemplateMapper policyTemplateMapper;
    @Resource
    private PolicyRuleTemplateMapper policyRuleTemplateMapper;
    @Resource
    private PolicyTemplateConvertor policyTemplateConvertor;
    @Resource
    private PolicyTemplateDetailConvertor detailConvertor;
    @Override
    public PolicyTemplate get(Long templateId) {
        PolicyTemplateDO policyTemplateDO = policyTemplateMapper.selectById(templateId);
        if(null == policyTemplateDO){
            return null;
        }
        PolicyTemplate policyTemplate = policyTemplateConvertor.doToModel(policyTemplateDO);

        PolicyRuleTemplateQueryParam param = new PolicyRuleTemplateQueryParam();
        param.setTemplateId(templateId);
        List<PolicyRuleTemplateDO> ruleTemplateDOS = policyRuleTemplateMapper.selectAll(param);
        policyTemplate.setIncentivePlanList(policyTemplateConvertor.toIncentivePlan(ruleTemplateDOS));

        return policyTemplate;
    }

    @Override
    public List<PolicyTemplate> get(String bizType, String customType) {
        PolicyTemplateQueryParam param = new PolicyTemplateQueryParam();
        param.setBizType(bizType);
        param.setCustomType(customType);
        param.setStatusList(Lists.newArrayList(PolicyTemplateStatusEnum.WAITING_EFFECT.getCode(), PolicyTemplateStatusEnum.EFFECT.getCode()));
        List<PolicyTemplateDO> policyTemplateDOS = policyTemplateMapper.selectAll(param);
        if(CollectionUtils.isEmpty(policyTemplateDOS)){
            return Lists.newArrayList();
        }

        List<Long> templateIds = policyTemplateDOS.stream().map(PolicyTemplateDO::getId).collect(Collectors.toList());

        PolicyRuleTemplateQueryParam ruleParam = new PolicyRuleTemplateQueryParam();
        ruleParam.setTemplateIds(templateIds);
        List<PolicyRuleTemplateDO> ruleTemplateDOS = policyRuleTemplateMapper.selectAll(ruleParam);
        Map<Long, List<PolicyRuleTemplateDO>> templateMap = ruleTemplateDOS.stream().collect(Collectors.groupingBy(PolicyRuleTemplateDO::getTemplateId));

        return policyTemplateDOS.stream().map(template -> {
            PolicyTemplate policyTemplate = policyTemplateConvertor.doToModel(template);
            policyTemplate.setIncentivePlanList(policyTemplateConvertor.toIncentivePlan(templateMap.get(template.getId())));
            return policyTemplate;
        }).collect(Collectors.toList());
    }

    @Override
    @Transactional(rollbackFor = Throwable.class)
    public Long create(PolicyTemplate policyTemplate) {
        PolicyTemplateDO policyTemplateDO = policyTemplateConvertor.doToModel(policyTemplate);
        String approvalFollowId = MapUtils.getObject(policyTemplate.getFeatureMap(), PolicyFeatureConstants.APPROVAL_FOLLOW_ID);
        if(StringUtils.isNotBlank(approvalFollowId)){
            policyTemplateDO.setApprovalFollowId(Long.valueOf(approvalFollowId));
        }
        // 保存政策模版
        policyTemplateMapper.insert(policyTemplateDO);

        // 保存政策规则模版
        List<PolicyRuleTemplateDO> policyRuleTemplateDOList = policyTemplateConvertor.toPolicyRuleTemplateDO(policyTemplate, policyTemplateDO.getId());
        policyRuleTemplateMapper.batchInsert(policyRuleTemplateDOList);
        return policyTemplateDO.getId();
    }

    @Override
    @Transactional(rollbackFor = Throwable.class)
    public void delete(PolicyTemplate policyTemplate) {
        PolicyTemplateDO policyTemplateDO = policyTemplateConvertor.doToModel(policyTemplate);
        // 修改内容
        policyTemplateMapper.update(policyTemplateDO);
        // 逻辑删除 模版表
        policyTemplateMapper.deleteById(policyTemplateDO.getId());

        // 逻辑删除 规则模版表
        PolicyRuleTemplateQueryParam ruleParam = new PolicyRuleTemplateQueryParam();
        ruleParam.setTemplateId(policyTemplate.getId());
        List<PolicyRuleTemplateDO> ruleTemplateDOS = policyRuleTemplateMapper.selectAll(ruleParam);
        if(CollectionUtils.isNotEmpty(ruleTemplateDOS)){
            policyRuleTemplateMapper.batchDeleteByIds(ruleTemplateDOS.stream().map(PolicyRuleTemplateDO::getId).collect(Collectors.toList()));
        }
    }

    @Override
    public Page<PolicyTemplate> selectPage(com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyTemplateQueryParam queryParam) {
        PolicyTemplateQueryParam param = buildPagePolicyTemplateQueryParam(queryParam);
        com.cainiao.tp.nm.plan.infra.mybatis.dto.PageResult<PolicyTemplateDO> selectPage = policyTemplateMapper.selectPage(param);
        // 转换为model
        List<PolicyTemplate> policyTemplateList = convertList(Safes.of(selectPage.getData()));
        return CnPage.of(queryParam.getPageIndex(), queryParam.getPageSize(),policyTemplateList, selectPage.getTotal());
    }

    @Override
    public List<PolicyTemplateDTO> selectAll(com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyTemplateQueryParam queryParam) {
        PolicyTemplateQueryParam param = buildPagePolicyTemplateQueryParam(queryParam);
        List<PolicyTemplateDO> templateDOS = policyTemplateMapper.selectAll(param);
        return detailConvertor.doToDto(templateDOS);
    }

    private List<PolicyTemplate> convertList(List<PolicyTemplateDO> policyTemplateDOList){
        List<PolicyTemplate> policyTemplateList = policyTemplateConvertor.doToModelList(policyTemplateDOList);

        Map<Long, PolicyTemplate> policyTemplateMap = policyTemplateList.stream().collect(
            Collectors.toMap(PolicyTemplate::getId, Function.identity(), (policyTemplate1, policyTemplate2) -> policyTemplate1));
        List<Long> templateIds = new ArrayList<>(policyTemplateMap.keySet());

        // 查询对应的政策规则模版
        PolicyRuleTemplateQueryParam ruleTemplateQueryParam = new PolicyRuleTemplateQueryParam();
        ruleTemplateQueryParam.setTemplateIds(templateIds);
        List<PolicyRuleTemplateDO> policyRuleTemplateList = policyRuleTemplateMapper.selectAll(ruleTemplateQueryParam);
        if (CollectionUtils.isEmpty(policyRuleTemplateList)) {
            return policyTemplateList;
        }

        // 按模板id进行分组
        Map<Long, List<PolicyRuleTemplateDO>> policyRuleGroupMap = policyRuleTemplateList.stream().collect(
            Collectors.groupingBy(PolicyRuleTemplateDO::getTemplateId, Collectors.toList()));

        // 填充激励方案
        for (Entry<Long, PolicyTemplate> policyTemplateEntry : policyTemplateMap.entrySet()) {
            Long templateId = policyTemplateEntry.getKey();
            PolicyTemplate policyTemplate = policyTemplateEntry.getValue();
            List<PolicyRuleTemplateDO> policyRuleTemplates = policyRuleGroupMap.get(templateId);
            policyTemplate.setIncentivePlanList(policyTemplateConvertor.toIncentivePlan(policyRuleTemplates));
        }
        return policyTemplateList;

    }

    private PolicyTemplateQueryParam buildPagePolicyTemplateQueryParam(com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyTemplateQueryParam queryParam){
        PolicyTemplateQueryParam param = new PolicyTemplateQueryParam();
        param.setId(queryParam.getId());
        param.setPage(queryParam.getPageIndex());
        param.setSize(queryParam.getPageSize());
        param.setIdList(queryParam.getIdList());
        if (StringUtils.isNotBlank(queryParam.getBizType())){
            param.setBizType(queryParam.getBizType().trim());
        }
        if (StringUtils.isNotBlank(queryParam.getTemplateName())){
            param.setTemplateName(queryParam.getTemplateName().trim());
        }
        if (MapUtils.isEmpty(queryParam.getOrderFieldNameMap())) {
            // 默认按照 创建时间 倒序
            param.addOrderBy(PolicyTempldateSortEnum.GMT_CREATE, false);
        }else {
            for (Entry<String, Boolean> orderEntry : queryParam.getOrderFieldNameMap().entrySet()) {
                PolicyTempldateSortEnum sortEnum = PolicyTempldateSortEnum.getByFieldName(orderEntry.getKey());
                if (sortEnum == null){
                    continue;
                }
                param.addOrderBy(sortEnum, orderEntry.getValue());
            }
        }
        // 根据过期状态进行查询
        PolicyTemplateDurationStatusEnum durationStatusEnum = PolicyTemplateDurationStatusEnum.getByCode(queryParam.getDurationStatus());
        if (durationStatusEnum == null){
            return param;
        }
        switch (durationStatusEnum){
            case NOT_STARTED:
                param.setLeStartTime(LocalDateTime.now());
                break;
            case IN_PROGRESS:
                param.setGtStartTime(LocalDateTime.now());
                param.setLeEndTime(LocalDateTime.now());
                break;
            case EXPIRED:
                param.setGtEndTime(LocalDateTime.now());
                break;
            default:
                break;
        }
        return param;
    }
}
