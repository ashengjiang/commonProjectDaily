package com.cainiao.tp.nm.plan.infra.wrapper.express;

import com.alibaba.cainiao.stationplatform.client.domain.OperatorInfo;
import com.alibaba.cainiao.stationplatform.client.domain.StationExpressDTO;
import com.alibaba.cainiao.stationplatform.client.domain.StationResultDTO;
import com.alibaba.cainiao.stationplatform.client.service.StationExpressService;
import com.cainiao.tp.nm.plan.infra.common.constants.CommonConstants;
import com.cainiao.tp.nm.plan.infra.port.common.exception.ServiceException;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.StationExpressInfoDTO;
import com.cainiao.tp.nm.plan.infra.port.purchase.StationExpressManager;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * 网点服务端口实现 */
@Slf4j
@Component
public class StationExpressManagerImpl implements StationExpressManager {

    @Resource
    private StationExpressService stationExpressService;

    @Override
    public StationExpressInfoDTO queryExpressInfo(Long expressId) {
        if (expressId == null) {
            log.warn("queryExpressInfo expressId 为空");
            return null;
        }

        try {
            StationResultDTO<StationExpressDTO> result = stationExpressService.queryCachedExpressById(
                    expressId, CommonConstants.CLIENT_INFO, OperatorInfo.newEmptyInstance());
            if (result == null || !result.isSuccess() || result.getData() == null) {
                log.warn("queryExpressInfo 调用失败, expressId={}, result={}", expressId, result);
                return null;
            }
            return convertToExpressInfo(result.getData());
        } catch (Exception e) {
            log.error("queryExpressInfo 调用异常, expressId={}", expressId, e);
            throw ServiceException.of("网点信息查询异常");
        }
    }

    private StationExpressInfoDTO convertToExpressInfo(StationExpressDTO source) {
        StationExpressInfoDTO target = new StationExpressInfoDTO();
        target.setExpressId(source.getExpressId());
        target.setExpressName(source.getExpressName());
        target.setContactName(source.getContactName());
        target.setContactMobile(source.getContactMobile());
        target.setCorporationAlipayId(source.getCorporationAlipayId());
        target.setCorporationCnuserId(source.getCorporationCnuserId());
        target.setStatus(source.getStatus());
        return target;
    }
}
