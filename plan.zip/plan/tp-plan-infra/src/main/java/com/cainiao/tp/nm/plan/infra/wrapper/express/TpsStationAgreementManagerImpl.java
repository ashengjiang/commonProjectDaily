package com.cainiao.tp.nm.plan.infra.wrapper.express;

import com.cainiao.aladdin.operation.SystemBizOperation;
import com.cainiao.aladdin.reslut.Result;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.TpsAgreementCreateAndSignDTO;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.TpsAgreementInfoDTO;
import com.cainiao.tp.nm.plan.infra.port.manager.TpsStationAgreementManager;
import com.cainiao.tps.content.client.enums.agreement.AgreementInstanceStatusEnum;
import com.cainiao.tps.content.client.enums.agreement.AgreementOrganizationTypeEnum;
import com.cainiao.tps.content.client.model.agreement.TpsAgreementDTO;
import com.cainiao.tps.content.client.model.agreement.TpsAgreementInstanceDTO;
import com.cainiao.tps.content.client.request.agreement.TpsAgreementDetailQueryRequest;
import com.cainiao.tps.content.client.request.agreement.TpsAgreementInstanceCreateRequest;
import com.cainiao.tps.content.client.request.agreement.TpsAgreementInstanceSignedQueryRequest;
import com.cainiao.tps.content.client.service.agreement.TpsAgreementInstanceQueryService;
import com.cainiao.tps.content.client.service.agreement.TpsAgreementInstanceWriteService;
import com.cainiao.tps.content.client.service.agreement.TpsAgreementQueryService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * TPS 协议查询端口实现 */
@Slf4j
@Component
public class TpsStationAgreementManagerImpl implements TpsStationAgreementManager {

    @Resource
    private TpsAgreementQueryService tpsAgreementQueryService;

    @Resource
    private TpsAgreementInstanceWriteService tpsAgreementInstanceWriteService;

    @Resource
    private TpsAgreementInstanceQueryService tpsAgreementInstanceQueryService;

    @Override
    public TpsAgreementInfoDTO queryDetail(Long agreementId) {
        if (agreementId == null) {
            log.warn("queryDetail agreementId 为空");
            return null;
        }

        try {
            TpsAgreementDetailQueryRequest request = new TpsAgreementDetailQueryRequest();
            request.setId(agreementId);
            SystemBizOperation systemBizOperation = new SystemBizOperation(0L, "tp-nm-plan");
            Result<TpsAgreementDTO> result = tpsAgreementQueryService.queryDetail(
                    request, systemBizOperation);
            if (result == null || !result.isSuccess() || result.getData() == null) {
                log.warn("queryDetail 调用失败, agreementId={}, result={}", agreementId, result);
                return null;
            }
            return convertToAgreementInfo(result.getData());
        } catch (Exception e) {
            log.error("queryDetail 调用异常, agreementId={}", agreementId, e);
            return null;
        }
    }

    @Override
    public TpsAgreementInfoDTO queryByCode(String agreementCode) {
        if (agreementCode == null || agreementCode.trim().isEmpty()) {
            log.warn("queryByCode agreementCode 为空");
            return null;
        }

        try {
            Result<TpsAgreementDTO> result = tpsAgreementQueryService.queryAgreementByCode(agreementCode);
            if (result == null || !result.isSuccess() || result.getData() == null) {
                log.warn("queryByCode 调用失败, agreementCode={}, result={}", agreementCode, result);
                return null;
            }
            return convertToAgreementInfo(result.getData());
        } catch (Exception e) {
            log.error("queryByCode 调用异常, agreementCode={}", agreementCode, e);
            return null;
        }
    }

    private TpsAgreementInfoDTO convertToAgreementInfo(TpsAgreementDTO source) {
        TpsAgreementInfoDTO target = new TpsAgreementInfoDTO();
        target.setId(source.getId());
        target.setTitle(source.getTitle());
        target.setContentUrl(source.getContentUrl());
        target.setAgreementCode(source.getAgreementCode());
        target.setStatus(source.getStatus());
        target.setValidDate(source.getValidDate());
        target.setInvalidDate(source.getInvalidDate());
        target.setSignStartDate(source.getSignStartDate());
        target.setSignEndDate(source.getSignEndDate());
        target.setBizLine(source.getBizLine());
        target.setBizType(source.getBizType());
        target.setDescription(source.getDescription());
        target.setFeature(source.getFeature());
        return target;
    }

    @Override
    public Long createAndSign(TpsAgreementCreateAndSignDTO param) {
        if (param == null) {
            log.warn("createAndSign param 为空");
            return null;
        }
        if (param.getAgreementId() == null) {
            log.warn("createAndSign agreementId 为空");
            return null;
        }
        if (param.getUserId() == null || param.getUserId().trim().isEmpty()) {
            log.warn("createAndSign userId 为空");
            return null;
        }
        if (param.getUserType() == null) {
            log.warn("createAndSign userType 为空");
            return null;
        }


        try {
            TpsAgreementInstanceCreateRequest request = new TpsAgreementInstanceCreateRequest();
            request.setAgreementId(param.getAgreementId());
            request.setUserId(param.getUserId());
            request.setUserType(param.getUserType());

            request.setOrganizationType(AgreementOrganizationTypeEnum.STATION.getIndex());
            request.setOrganizationId(param.getStationId());
            request.setFeature(param.getFeature());
            request.setSource("tp-nm-plan");

            //状态：写死
            request.setStatus(AgreementInstanceStatusEnum.TO_BE_SIGNED.getIndex());

            SystemBizOperation systemBizOperation = new SystemBizOperation(0L, "tp-nm-plan");
            Result<Long> result = tpsAgreementInstanceWriteService.createAndSign(request, systemBizOperation);
            if (result == null || !result.isSuccess() || result.getData() == null) {
                log.warn("createAndSign 调用失败, agreementId={}, userId={}, result={}", param.getAgreementId(), param.getUserId(), result);
                throw new RuntimeException("站点签约异常");
            }
            log.info("createAndSign 成功, agreementId={}, userId={}, instanceId={}", param.getAgreementId(), param.getUserId(), result.getData());
            return result.getData();
        } catch (Exception e) {
            log.error("createAndSign 调用异常, agreementId={}, userId={}", param.getAgreementId(), param.getUserId(), e);
           throw new RuntimeException("站点签约异常");
        }
    }

    @Override
    public boolean isSigned(String agreementCode, Long stationId) {
        if (agreementCode == null || agreementCode.trim().isEmpty() || stationId == null) {
            log.warn("isSigned 入参非法, agreementCode={}, stationId={}", agreementCode, stationId);
            return false;
        }

        try {
            TpsAgreementInstanceSignedQueryRequest request = new TpsAgreementInstanceSignedQueryRequest();
            request.setAgreementCode(agreementCode);
            request.setStationId(stationId);
            SystemBizOperation systemBizOperation = new SystemBizOperation(0L, "tp-nm-plan");
            Result<List<TpsAgreementInstanceDTO>> result = tpsAgreementInstanceQueryService
                    .queryAgreementInstanceSignedList(request, systemBizOperation);
            if (result == null || !result.isSuccess()) {
                log.warn("isSigned 调用失败, agreementCode={}, stationId={}, result={}", agreementCode, stationId, result);
                return false;
            }
            return CollectionUtils.isNotEmpty(result.getData());
        } catch (Exception e) {
            log.error("isSigned 调用异常, agreementCode={}, stationId={}", agreementCode, stationId, e);
            return false;
        }
    }


}
