package com.cainiao.tp.nm.plan.infra.mybatis.dto;

import java.io.Serializable;

/**
 * 可排序接口，可实现该接口提供order by功能 */
public interface OrderQuery<T extends Enum<T>> extends Serializable {
    /**
     * 添加排序
     *
     * @param field 排序字段
     * @param asc   是否升序
     */
    void addOrderBy(T field, boolean asc);
}
