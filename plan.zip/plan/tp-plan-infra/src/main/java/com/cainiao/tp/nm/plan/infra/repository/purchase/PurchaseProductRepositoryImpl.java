package com.cainiao.tp.nm.plan.infra.repository.purchase;

import com.cainiao.tp.nm.plan.infra.repository.purchase.convert.PurchaseProductConvertor;
import com.cainiao.tp.nm.plan.infra.repository.purchase.dto.data.PurchaseProductDO;
import com.cainiao.tp.nm.plan.infra.repository.purchase.dto.param.PurchaseProductQueryParam;
import com.cainiao.tp.nm.plan.infra.repository.purchase.mapper.PurchaseProductMapper;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseProduct;
import com.cainiao.tp.nm.plan.purchase.domain.repository.PurchaseProductRepository;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * 订购商品仓储实现 */
@Repository
public class PurchaseProductRepositoryImpl implements PurchaseProductRepository {

    @Resource
    private PurchaseProductMapper purchaseProductMapper;

    @Resource
    private PurchaseProductConvertor purchaseProductConvertor;

    @Override
    public List<PurchaseProduct> getProductsByIds(List<Long> productIds) {
        if (CollectionUtils.isEmpty(productIds)) {
            return new ArrayList<>();
        }
        
        PurchaseProductQueryParam queryParam = new PurchaseProductQueryParam();
        queryParam.setIdList(productIds);
        queryParam.setSize(productIds.size());
        List<PurchaseProductDO> doList = purchaseProductMapper.selectAll(queryParam);
        return purchaseProductConvertor.doToModelList(doList);
    }

    @Override
    public PurchaseProduct getProductById(Long productId) {
        if (productId == null) {
            return null;
        }
        
        PurchaseProductDO doObj = purchaseProductMapper.selectById(productId);
        if (doObj == null) {
            return null;
        }
        
        return purchaseProductConvertor.doToModel(doObj);
    }

    @Override
    public PurchaseProduct saveProduct(PurchaseProduct product) {
        PurchaseProductDO productDO = purchaseProductConvertor.modelToDO(product);
        purchaseProductMapper.insert(productDO);
        product.setId(productDO.getId());
        return product;
    }

    @Override
    public void deleteProduct(Long productId) {
        if (productId == null) {
            return;
        }
        purchaseProductMapper.deleteById(productId);
    }

    @Override
    public List<PurchaseProduct> getProductsByCategoryId(Integer categoryId) {
        if (categoryId == null) {
            return new ArrayList<>();
        }
        PurchaseProductQueryParam queryParam = new PurchaseProductQueryParam();
        queryParam.setCategoryId(categoryId);
        queryParam.setSize(100);
        List<PurchaseProductDO> doList = purchaseProductMapper.selectAll(queryParam);
        return purchaseProductConvertor.doToModelList(doList);
    }

    @Override
    public void updateProduct(PurchaseProduct product) {
        PurchaseProductDO productDO = purchaseProductConvertor.modelToDO(product);
        productDO.setId(product.getId());
        purchaseProductMapper.update(productDO);
    }
}
