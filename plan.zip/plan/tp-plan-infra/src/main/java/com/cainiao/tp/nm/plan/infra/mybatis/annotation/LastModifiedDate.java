package com.cainiao.tp.nm.plan.infra.mybatis.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 自动审计注解支持，最后修改时间字段，标记该注解的字段，每次更新操作都会自动使用数据库时间戳进行更新 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD) // 只能在字段上使用
public @interface LastModifiedDate {
}