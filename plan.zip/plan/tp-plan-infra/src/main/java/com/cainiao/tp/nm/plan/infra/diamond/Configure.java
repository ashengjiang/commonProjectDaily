package com.cainiao.tp.nm.plan.infra.diamond;

/**
 * 配置器，一个配置器用来映射一套配置文件 */
public interface Configure {

}
