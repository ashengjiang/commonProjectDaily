package com.cainiao.tp.nm.plan.infra.mybatis.dto;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.cainiao.tp.nm.plan.infra.mybatis.annotation.CreatedDate;
import com.cainiao.tp.nm.plan.infra.mybatis.annotation.LastModifiedDate;
import com.cainiao.tp.nm.plan.infra.mybatis.annotation.Transient;
import lombok.Data;

/**
 * DO基础类，可继承该类实现DO */
@Data
public abstract class BaseDO implements Serializable {

    @Transient
    private static final long serialVersionUID = -5714928988970532441L;
    private Long id;

    @CreatedDate
    private LocalDateTime gmtCreate;

    @LastModifiedDate
    private LocalDateTime gmtModified;

}
