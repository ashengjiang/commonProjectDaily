package com.cainiao.tp.nm.plan.infra.repository.purchase;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.cainiao.tp.nm.plan.infra.diamond.PurchaseRuleConfig;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseRule;
import com.cainiao.tp.nm.plan.purchase.domain.repository.PurchaseRuleRepository;
import org.springframework.stereotype.Repository;

import java.util.Collections;
import java.util.List;

/**
 * 订购规则仓储实现
 * 数据来源于 Diamond 配置 */
@Repository
public class PurchaseRuleRepositoryImpl implements PurchaseRuleRepository {

    private final PurchaseRuleConfig purchaseRuleConfig;

    public PurchaseRuleRepositoryImpl(PurchaseRuleConfig purchaseRuleConfig) {
        this.purchaseRuleConfig = purchaseRuleConfig;
    }

    @Override
    public List<PurchaseRule> getAllRules() {
        // 使用 JSON 序列化/反序列化进行深拷贝，防止上层修改底层数据
        List<PurchaseRule> rules = purchaseRuleConfig.getAllRules();
        if (rules == null || rules.isEmpty()) {
            return Collections.emptyList();
        }
        return JSON.parseObject(JSON.toJSONString(rules), new TypeReference<List<PurchaseRule>>() {});
    }

    @Override
    public List<PurchaseRule> getRulesByCategoryId(Integer categoryId) {
        // 使用 JSON 序列化/反序列化进行深拷贝，防止上层修改底层数据
        List<PurchaseRule> rules = purchaseRuleConfig.getRulesByCategoryId(categoryId);
        if (rules == null || rules.isEmpty()) {
            return Collections.emptyList();
        }
        return JSON.parseObject(JSON.toJSONString(rules), new TypeReference<List<PurchaseRule>>() {});
    }
}
