package com.cainiao.tp.nm.plan.infra.metaq.oa;

import java.util.List;
import java.util.Objects;

import javax.annotation.Resource;

import com.alibaba.fastjson.JSON;
import com.alibaba.rocketmq.common.message.MessageExt;

import com.cainiao.aladdin.log.AladdinCommLog;
import com.cainiao.aladdin.log.AladdinMapLog;
import com.cainiao.aladdin.log.BizType;
import com.cainiao.aladdin.log.utils.AladdinLogUtil;
import com.cainiao.aladdin.operation.SystemBizOperation;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.terminal.ticket.client.domain.event.TaskOverDueMqEvent;
import com.cainiao.tp.nm.plan.api.policy.common.constants.OAListenerEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.OAProcessDefinitionKeyEnum;
import com.cainiao.tp.nm.plan.infra.approval.handler.ApprovalListenerHandler;
import com.cainiao.tp.nm.plan.infra.approval.handler.ApprovalListenerHandlerFactory;
import com.cainiao.tp.nm.plan.policy.adaptor.metaq.AbstractMetaQListener;
import com.google.common.base.Charsets;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @Date 2025/6/18 11:17
 */
@Slf4j
@Component(value = "oaTicketTaskTimeoutEventListener")
public class OaTicketTaskTimeoutEventListener extends AbstractMetaQListener<TaskOverDueMqEvent> {

    @Resource
    private ApprovalListenerHandlerFactory approvalListenerHandlerFactory;

    @Override
    protected TaskOverDueMqEvent convert(MessageExt message) {
        AladdinMapLog mapLog = AladdinLogUtil.newMapLog("oaTicketTimeoutEventListener.convert", BizType.DEFAULT);
        try {
            String msgBody = new String(message.getBody(), Charsets.UTF_8);
            return JSON.parseObject(msgBody, TaskOverDueMqEvent.class);
        } catch (Throwable t) {
            mapLog.addParam("convert failed", t.getMessage());
            AladdinLogUtil.log(log, mapLog, t);
            return null;
        }
    }

    @Override
    protected boolean filter(TaskOverDueMqEvent event, MessageExt message) {
        String processKey = event.getProcessKey();
        return OAProcessDefinitionKeyEnum.getAllKey().contains(processKey);
    }

    @Override
    protected boolean doConsume(TaskOverDueMqEvent event, MessageExt message) {
        SystemBizOperation operation = new SystemBizOperation(303544L, "建宇", "监听政策提报工单任务超时事件");
        AladdinCommLog commLog = AladdinLogUtil.newCommLog(BizType.DEFAULT, operation);
        List<Object> logContext = Lists.newArrayList();
        commLog.setContext(logContext);
        commLog.setParams(message.getMsgId());
        logContext.add("msgId : " + message.getMsgId());
        logContext.add("eventBody : " + event);
        try {
            String processKey = event.getProcessKey();
            ApprovalListenerHandler<TaskOverDueMqEvent> listenerHandler = (ApprovalListenerHandler<TaskOverDueMqEvent>)
                approvalListenerHandlerFactory.getListenerHandler(OAListenerEnum.TASK.getCode(),message.getTags(), processKey);
            AssertUtil.notNull(listenerHandler, "OA工单处理器不存在");
            listenerHandler.doConsume(event, message);
        } catch (Throwable t) {
            return AladdinLogUtil.log(log, t, commLog, false);
        }
        return AladdinLogUtil.log(log, commLog, true);
    }
}
