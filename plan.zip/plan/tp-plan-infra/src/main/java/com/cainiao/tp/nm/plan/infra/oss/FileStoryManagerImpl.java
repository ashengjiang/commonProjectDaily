package com.cainiao.tp.nm.plan.infra.oss;

import com.aliyun.oss.OSS;
import com.aliyun.oss.common.utils.BinaryUtil;
import com.aliyun.oss.model.MatchMode;
import com.aliyun.oss.model.OSSObject;
import com.aliyun.oss.model.PolicyConditions;
import com.cainiao.aladdin.utils.CNStationOSSUtils;
import com.cainiao.tp.nm.plan.api.policy.application.dto.OssAuthDTO;
import com.cainiao.tp.nm.plan.infra.port.policy.FileStoryManager;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.UUID;

@Service
public class FileStoryManagerImpl implements FileStoryManager {
    private static final String DEFAULT_DIR = "tp-nm-plan/";


    @Override
    public OssAuthDTO getUploadOssTokenConfig(String fileName, String dirName) {
        String key = DEFAULT_DIR + dirName + "/" + UUID.randomUUID() + fileName;
        OssAuthDTO ossAuthVO = new OssAuthDTO();
        String host = "//" + DEFAULT_BUCKET_NAME + "." + "oss-cn-hangzhou.aliyuncs.com";
        OSS ossClient = CNStationOSSUtils.getOssClient();
        long expireEndTime = System.currentTimeMillis() + 3600L * 1000;
        Date expiration = new Date(expireEndTime);
        PolicyConditions policyCords = new PolicyConditions();
        policyCords.addConditionItem(PolicyConditions.COND_CONTENT_LENGTH_RANGE, 0, 1048576000);
        policyCords.addConditionItem(MatchMode.StartWith, PolicyConditions.COND_KEY, key);
        String postPolicy = ossClient.generatePostPolicy(expiration, policyCords);
        byte[] binaryData = postPolicy.getBytes(StandardCharsets.UTF_8);
        String encodedPolicy = BinaryUtil.toBase64String(binaryData);
        String postSignature = ossClient.calculatePostSignature(postPolicy);

        ossAuthVO.setOssAccessKeyId(CNStationOSSUtils.getAccessKeyId());
        ossAuthVO.setAccessId(CNStationOSSUtils.getAccessKeyId());
        ossAuthVO.setPolicy(encodedPolicy);
        ossAuthVO.setSignature(postSignature);
        ossAuthVO.setDir("");
        ossAuthVO.setKey(key);
        ossAuthVO.setHost(host);
        ossAuthVO.setExpire(expireEndTime / 1000);
        return ossAuthVO;
    }


    @Override
    public String upload(ByteArrayOutputStream outputStream, String dir, String fileName) {
        String fileKey = DEFAULT_DIR + dir + "/"  + fileName;
        try {
            CNStationOSSUtils.putObjectStream(DEFAULT_BUCKET_NAME, fileKey, new ByteArrayInputStream(outputStream.toByteArray()));
            return fileKey;
        } catch (Throwable e) {
            //todo 异常处理方式
            String message = e.getMessage();
            RuntimeException runtimeException = new RuntimeException(message);
            StackTraceElement[] stackTrace = e.getStackTrace();
            runtimeException.setStackTrace(stackTrace);
            throw runtimeException;
        }
    }

    @Override
    public String downloadUrl(String fileKey, Long expireTime) {
        String tempUrlIfObjectExists = CNStationOSSUtils.getTempUrlIfObjectExists(DEFAULT_BUCKET_NAME, fileKey, expireTime);
        if(StringUtils.isNotBlank(tempUrlIfObjectExists)){
            return tempUrlIfObjectExists.replace("http://", "https://");
        }
        return tempUrlIfObjectExists;
    }

    @Override
    public InputStream download(String fileKey) {
        OSSObject object = CNStationOSSUtils.getOssClient().getObject(DEFAULT_BUCKET_NAME, fileKey);
       return object.getObjectContent();
    }

}
