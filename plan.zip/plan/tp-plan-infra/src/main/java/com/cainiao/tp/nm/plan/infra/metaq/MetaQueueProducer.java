package com.cainiao.tp.nm.plan.infra.metaq;

import com.alibaba.metrics.StringUtils;
import com.alibaba.rocketmq.client.producer.SendResult;
import com.alibaba.rocketmq.common.message.Message;
import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.aladdin.exception.AladdinException;
import com.cainiao.aladdin.log.AladdinCommLog;
import com.cainiao.aladdin.log.BizType;
import com.cainiao.aladdin.log.utils.AladdinLogUtil;
import com.taobao.metaq.client.MetaProducer;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Map;
import java.util.Objects;

@Component
@Slf4j
public class MetaQueueProducer {


    @Resource(name = "tpNmPlanBaseProducer")
    private MetaProducer metaProducer;


    /**
     * 发送消息
     *
     * @param topic       主体
     * @param messageInfo 消息内容
     * @param key         消息key 用来后续查询
     */
    public void publishMsg(String topic, String messageInfo, String key) {
        publishMsg(topic, null, messageInfo, null, key, 3);
    }


    /**
     * 发送消息
     *
     * @param topic       主体
     * @param messageInfo 消息内容
     * @param key         消息key 用来后续查询
     */
    public void publishMsg(String topic, String tag, String messageInfo, String key) {
        publishMsg(topic, tag, messageInfo, null, key, 3);
    }

    /**
     * 发送消息
     *
     * @param topic       主体
     * @param messageInfo 消息内容
     * @param key         消息key 用来后续查询
     * @param retryTimes  重试次数
     */
    public void publishMsg(String topic, String messageInfo, String key, int retryTimes) {
        publishMsg(topic, null, messageInfo, null, key, retryTimes);
    }

    /**
     * 发送消息
     *
     * @param topic       主体
     * @param tags        标签
     * @param messageInfo 消息内容
     * @param key         消息key 用来后续查询
     * @param retryTimes  重试次数
     */
    public void publishMsg(String topic, String tags, String messageInfo, String key, int retryTimes) {
        publishMsg(topic, tags, messageInfo, null, key, retryTimes);
    }


    /**
     * 发送metaq消息
     *
     * @param topic       主体
     * @param tags        标签
     * @param messageInfo 消息内容
     * @param propertyMap 自定义配置
     * @param key         消息key 用来后续查询
     * @param retryTimes  重试次数
     */
    public void publishMsg(String topic, String tags, String messageInfo, Map<String, String> propertyMap, String key,
                                     int retryTimes) {
        AladdinCommLog commLog = AladdinLogUtil.newCommLog(BizType.DEFAULT, topic);
        commLog.setParams(messageInfo);
        try {
            Message message = new Message(topic, tags, key, messageInfo.getBytes());
            if (Objects.nonNull(propertyMap)) {
                for (Map.Entry<String, String> entry : propertyMap.entrySet()) {
                    message.putUserProperty(entry.getKey(), entry.getValue());
                }
            }
            commLog.setContext(message);
            SendResult sendResult = metaProducer.send(message);
            commLog.setReturnVal(sendResult);
            AladdinLogUtil.log(log, commLog);
            if (StringUtils.isBlank(sendResult.getMsgId())) {
                throw new AladdinBizException("meta_q_send_error", "metaq消息发送异常");
            }
        } catch (Throwable t) {
            commLog.setContext(commLog.getContext() + String.format(", FAIL_OVER, errorMsg=%s, retryTimes=%d", t.getMessage(), retryTimes));
            AladdinLogUtil.log(log, t, commLog, null);
            if (retryTimes > 0) {
                publishMsg(topic, tags, messageInfo, key, retryTimes - 1);
            } else {
                // 重新抛出
                throw new AladdinException("meta_q_send_error", "metaq消息发送异常", t);
            }
        }
    }

}
