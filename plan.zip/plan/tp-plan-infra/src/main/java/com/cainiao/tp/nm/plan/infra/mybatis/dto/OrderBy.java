package com.cainiao.tp.nm.plan.infra.mybatis.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * 排序字段对象 */
@Data
@AllArgsConstructor
public class OrderBy implements Serializable {
    private static final long serialVersionUID = 3234627508969429949L;
    /**
     * 数据库表中的排序字段名，例如：GMT_CREATE，取枚举类的name()
     */
    private Enum<?> fieldName;
    /**
     * 是否升序，true表示升序
     */
    private boolean asc;

}
