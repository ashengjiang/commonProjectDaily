package com.cainiao.tp.nm.plan.infra.wrapper.express;

import com.alibaba.cainiao.express.outlets.api.result.ResultModel;
import com.alibaba.cainiao.express.outlets.contract.result.PlatContractSimpleDTO;
import com.alibaba.cainiao.express.outlets.contract.service.PlatContractReadService;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.PlatContractSimpleInfoDTO;
import com.cainiao.tp.nm.plan.infra.port.purchase.PlatContractReadManager;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
 * 平台合同查询端口实现
 * <p>
 * 通过 HSF 调用 {@link PlatContractReadService#getSimplePlatContract} 查询平台合同信息，
 * 并将三方 {@link PlatContractSimpleDTO} 转换为 port 层自定义 {@link PlatContractSimpleInfoDTO}。
 * </p> */
@Slf4j
@Component
public class PlatContractReadManagerImpl implements PlatContractReadManager {

    @Resource
    private PlatContractReadService platContractReadService;

    @Override
    public PlatContractSimpleInfoDTO getSimplePlatContract(String serviceCode) {
        log.info("getSimplePlatContract, serviceCode={}", serviceCode);
        ResultModel<List<PlatContractSimpleDTO>> result = platContractReadService.getSimplePlatContract(serviceCode);
        if (!result.isSuccess()) {
            log.error("getSimplePlatContract 调用失败, serviceCode={}, errorMsg={}",
                    serviceCode, result.getErrorMsg());
            throw new RuntimeException("getSimplePlatContract 调用失败, errorMsg=" + result.getErrorMsg());
        }
        List<PlatContractSimpleDTO> dataList = result.getData();
        if (CollectionUtils.isEmpty(dataList)) {
            return null;
        }
        Date now = new Date();
        return dataList.stream()
                .filter(contract -> isSignable(contract, now))
                .findFirst()
                .map(this::convertToPlatContractSimpleInfoDTO)
                .orElse(null);
    }

    /**
     * 判断合同在指定时间是否处于可签署期间
     * （gmtSignableBegin <= now <= gmtSignableEnd）
     */
    private boolean isSignable(PlatContractSimpleDTO contract, Date now) {
        Date signableBegin = contract.getGmtSignableBegin();
        Date signableEnd = contract.getGmtSignableEnd();
        if (signableBegin == null || signableEnd == null) {
            return false;
        }
        return !now.before(signableBegin) && !now.after(signableEnd);
    }

    private PlatContractSimpleInfoDTO convertToPlatContractSimpleInfoDTO(PlatContractSimpleDTO source) {
        PlatContractSimpleInfoDTO target = new PlatContractSimpleInfoDTO();
        target.setServiceCode(source.getServiceCode());
        target.setServiceName(source.getServiceName());
        target.setGmtBegin(source.getGmtBegin());
        target.setGmtEnd(source.getGmtEnd());
        target.setGmtInterimEnd(source.getGmtInterimEnd());
        target.setGmtSignableBegin(source.getGmtSignableBegin());
        target.setGmtSignableEnd(source.getGmtSignableEnd());
        target.setContent(source.getContent());
        target.setContractId(source.getContractId());
        return target;
    }
}
