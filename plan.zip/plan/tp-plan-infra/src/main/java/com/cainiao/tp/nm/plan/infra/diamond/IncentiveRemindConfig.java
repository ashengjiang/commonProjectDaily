package com.cainiao.tp.nm.plan.infra.diamond;

import com.alibaba.boot.diamond.annotation.DiamondListener;
import com.cainiao.aladdin.diamond.AladdinBootDiamondListener;
import com.cainiao.tp.nm.plan.api.policy.application.dto.IncentiveRemindHolder;

@DiamondListener(dataId = "plan.incentive.remind.common.config", executeAfterInit = true)
public class IncentiveRemindConfig extends AladdinBootDiamondListener {
    @Override
    public Object getInstance() {
        return IncentiveRemindHolder.getINSTANCE();
    }
}
