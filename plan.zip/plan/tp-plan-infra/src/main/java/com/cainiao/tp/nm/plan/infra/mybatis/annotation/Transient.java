package com.cainiao.tp.nm.plan.infra.mybatis.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 临时字段标识，持久化层不感知具有该标识的字段 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD) // 只能在字段上使用
public @interface Transient {
}