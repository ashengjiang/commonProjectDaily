package com.cainiao.tp.nm.plan.infra.wrapper.finance;

import com.cainiao.aladdin.reslut.Result;
import com.cainiao.terminal.finance.payment.client.facade.PaymentSignFacade;
import com.cainiao.terminal.finance.payment.client.vo.request.SignRecordQueryReq;
import com.cainiao.terminal.finance.payment.client.vo.response.SignRecordVo;
import com.cainiao.tp.nm.plan.infra.port.common.exception.ServiceException;
import com.cainiao.tp.nm.plan.infra.port.purchase.PaymentSignManager;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * 支付代扣协议签署查询端口实现 */
@Slf4j
@Component
public class PaymentSignManagerImpl implements PaymentSignManager {

    @Resource
    private PaymentSignFacade paymentSignFacade;

   private static final String  FUND_BIZ_TYPE = "CHONG_XIANG_HUI_FULL_UNDERTAKE_DEBT";
    @Override
    public boolean isSigned( Long userId) {
        if ( userId == null) {
            log.warn("isSigned 参数为空, userId={}", userId);
            return false;
        }

        SignRecordQueryReq req = new SignRecordQueryReq();
        req.setFundBizType(FUND_BIZ_TYPE);
        req.setUserId(userId);

        try {
            Result<SignRecordVo> result = paymentSignFacade.querySignRecord(req);
            if (result == null || !result.isSuccess() || result.getData() == null) {
                log.warn("querySignRecord 调用失败, fundBizType={}, userId={}, result={}",
                        FUND_BIZ_TYPE, userId, result);
                return false;
            }
            return result.getData().isSignSuccess();
        } catch (Exception e) {
            log.error("querySignRecord 调用异常, fundBizType={}, userId={}", FUND_BIZ_TYPE, userId, e);
            throw ServiceException.of("代扣协议签署查询异常");
        }
    }
}
