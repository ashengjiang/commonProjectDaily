package com.cainiao.tp.nm.plan.infra.thrd.express;

import com.alibaba.cainiao.express.outlets.base.api.result.org.EmployeeOrgDTO;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.cnmember.client.session.CnSessionWirelessReadClient;
import com.cainiao.cnmember.session.domain.CnMemberSessionDTO;
import com.cainiao.member.common.CnMemberResult;
import com.cainiao.tp.nm.plan.infra.port.policy.ExpressAccessCheckManager;
import com.cainiao.tp.nm.plan.infra.wrapper.express.ExpressOrgServiceWrapper;
import com.cainiao.tp.nm.plan.api.policy.application.dto.ExpressContentDTO;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * @code date 2025年06月26日 16:03
 * @code desc:null
 */
@Component
public class ExpressAccessCheckManagerImpl implements ExpressAccessCheckManager {

    @Resource
    private ExpressOrgServiceWrapper expressOrgServiceWrapper;
    @Resource
    private CnSessionWirelessReadClient cnSessionWirelessReadClient;

    @Override
    public void checkExpAndJVAccess(ExpressContentDTO context) {
        CnMemberResult<CnMemberSessionDTO> cnMemberSessionResult = cnSessionWirelessReadClient.querySession(context.getSessionId(), context.getAppKey());
        AssertUtil.isTrue(cnMemberSessionResult.isSuccess(), "查询session失败");
        CnMemberSessionDTO cnMemberSessionDTO = cnMemberSessionResult.getData();
        AssertUtil.notNull(cnMemberSessionDTO, "session不存在");
        AssertUtil.isTrue(cnMemberSessionDTO.getCnAccountId().equals(context.getUserId()), "session不匹配");
        // 查询当前员工的有权限的网点
        List<EmployeeOrgDTO> orgDTOList = expressOrgServiceWrapper.queryCombineOrgList(cnMemberSessionDTO.getCnAccountId());
        AssertUtil.notEmpty( "无网点权限",orgDTOList);
        // 判断当前网点与员工有权限的网点是否匹配
        boolean match = orgDTOList.stream().anyMatch(orgDTO -> orgDTO.getOrgCode().equals(context.getOrgCode()));
        AssertUtil.isTrue(match, "无网点权限");
    }
}
