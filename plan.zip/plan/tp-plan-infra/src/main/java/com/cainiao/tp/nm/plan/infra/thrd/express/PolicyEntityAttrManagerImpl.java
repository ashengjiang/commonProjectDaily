package com.cainiao.tp.nm.plan.infra.thrd.express;

import com.alibaba.cainiao.express.outlets.contract.result.ServiceOpenRelationDTO;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyEntitySignContractDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiverule.select.EntitySelectRuleDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyEntitySignContractParam;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyCustomTypeEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyEntityAttrEnum;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyEntityAttrManager;
import com.cainiao.tp.nm.plan.infra.port.policy.TgManager;
import com.cainiao.tp.nm.plan.infra.wrapper.express.ServiceProductServiceWrapper;
import com.cainiao.tp.nm.plan.infra.port.utils.ExpressUtils;
import com.cainiao.tp.nm.plan.infra.port.dto.ExpressCodeDTO;
import com.google.common.collect.Maps;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * @code date 2025年06月03日 15:43
 * @code desc: 政策主体属性匹配度
 */
@Component
public class PolicyEntityAttrManagerImpl implements PolicyEntityAttrManager {

    @Resource
    private ServiceProductServiceWrapper serviceProductServiceWrapper;
    @Resource
    private TgManager tgManager;

    @Override
    public Map<String, Boolean> hasAttr(EntitySelectRuleDTO entity, Map<String, List<String>> attrMap) {
        Map<String, Boolean> res = Maps.newHashMap();
        if(MapUtils.isEmpty(attrMap)){
            return res;
        }

        // 目前仅处理网点的协议类型
        List<String> signProtocolList = attrMap.get(PolicyEntityAttrEnum.SIGN_PROTOCOL.getCode());
        if(PolicyCustomTypeEnum.EXPRESS.getType().equals(entity.getType()) && CollectionUtils.isNotEmpty(signProtocolList)){
            String entityId = entity.getEntityId();
            ExpressCodeDTO expressCode = ExpressUtils.unpack(entityId);
            AssertUtil.notNull(expressCode, "网点code格式错误");
            List<ServiceOpenRelationDTO> serviceOpenRelationDTOS = serviceProductServiceWrapper.queryJvExtendServices(expressCode.getCpCode()
                    , expressCode.getExpressCode(),entity.getEntityType(), signProtocolList);

            boolean hasProtocol = CollectionUtils.isNotEmpty(serviceOpenRelationDTOS);
            if(!hasProtocol){
                PolicyEntitySignContractParam signContractParam = new PolicyEntitySignContractParam();
                signContractParam.setServiceCodeList(signProtocolList);
                signContractParam.setEntityCode(expressCode.getExpressCode());
                signContractParam.setSubEntityType(expressCode.getCpCode());
                signContractParam.setPageNum(1);
                signContractParam.setPageSize(1);
                List<PolicyEntitySignContractDTO> listData = tgManager.getListData(signContractParam);
                hasProtocol = CollectionUtils.isNotEmpty(listData);
            }

            res.put(PolicyEntityAttrEnum.SIGN_PROTOCOL.getCode(), hasProtocol);
        }
        return res;
    }
}
