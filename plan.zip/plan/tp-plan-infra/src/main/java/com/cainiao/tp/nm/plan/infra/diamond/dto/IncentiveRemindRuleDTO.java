package com.cainiao.tp.nm.plan.infra.diamond.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * 站点实操激励提醒通知规则 DTO
 * 对应 Diamond 配置中 plan.incentive.notice.rule 的单条规则结构
 *
 * @date 2026-03-27
 */
@Data
public class IncentiveRemindRuleDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 规则编码
     */
    private String ruleCode;

    /**
     * 规则名称，用于 Tair 防重发 Key 的组成部分
     * 示例：未达100单_T到T+2月
     */
    private String ruleName;

    /**
     * QL 规则表达式，用于匹配站点当前激励考核状态
     * 示例：firstOver100ArrDate == null && isSatisfied == false && assessMonthOffset >= 0 && assessMonthOffset <= 2
     * 注：isSatisfied、isDecorationPass 为 Boolean 类型，QL 中用 true/false 比较；cycleNum 为 String 类型，用 "3" 比较
     */
    private String ruleExpression;

    /**
     * 通知触发方案编码
     */
    private String noticeSchemeCode;

    /**
     * 通知文案内容
     */
    private String notifyContent;

    /**
     * 跳转类型
     * ACTIVITY_DETAIL：活动详情页
     * DECORATION_REPORT：装修报备页面
     */
    private String jumpType;
}
