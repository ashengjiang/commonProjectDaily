package com.cainiao.tp.nm.plan.infra.wrapper.org;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.annotation.Resource;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import com.cainiao.aladdin.exception.AladdinParamException;
import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.aladdin.operation.SystemBizOperation;
import com.cainiao.aladdin.reslut.PageResult;
import com.cainiao.aladdin.reslut.Result;
import com.cainiao.aladdin.utils.Safes;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.aladdin.validate.utils.ValidateUtil;
import com.cainiao.terminal.ticket.client.constant.TpTicketTaskStatusEnum;
import com.cainiao.terminal.ticket.client.domain.dto.TpTicketTaskDTO;
import com.cainiao.terminal.ticket.client.domain.request.TicketCancelReq;
import com.cainiao.terminal.ticket.client.domain.request.TicketPushByTaskReq;
import com.cainiao.terminal.ticket.client.domain.request.TpSearchTicketReq;
import com.cainiao.terminal.ticket.client.domain.request.TpStartTicketReq;
import com.cainiao.terminal.ticket.client.domain.request.TpTicketTaskQueryOption;
import com.cainiao.terminal.ticket.client.domain.request.TpTicketTaskQueryReq;
import com.cainiao.terminal.ticket.client.domain.request.TpUpdateTicketReq;
import com.cainiao.terminal.ticket.client.domain.response.TpTicketRep;
import com.cainiao.terminal.ticket.client.service.TpTicketPushService;
import com.cainiao.terminal.ticket.client.service.TpTicketService;
import com.cainiao.terminal.ticket.client.service.TpTicketTaskReadService;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyInstanceLoseEffectParam;
import com.cainiao.tp.nm.plan.api.policy.application.service.PolicyInstanceAppService;
import com.cainiao.tp.nm.plan.api.policy.common.constants.OAProcessCommonConstants;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyConstants;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyFeatureConstants;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyInstanceApprovalStatusEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicySubmissionNodeEnum;
import com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils;
import com.cainiao.tp.nm.plan.infra.wrapper.org.param.TpStartTicketParam;
import com.cainiao.tp.nm.plan.policy.domain.model.PolicyInstance;
import com.cainiao.tp.nm.plan.policy.domain.repository.PolicyInstanceRepository;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

/**
 * @Date 2025/6/3 16:34
 * @code desc: 工单wrapper
 */
@Slf4j
@Component
public class TpTicketWrapper {

    @Resource
    @Qualifier("tpOaTicketService")
    private TpTicketService tpOaTicketService;

    @Resource
    private TpTicketTaskReadService tpTicketTaskReadService;

    @Resource
    private TpTicketPushService tpTicketPushService;

    /**
     * 发起OA流程
     * @param param 参数
     * @return 工单id
     */
    public String startTicket(TpStartTicketParam param) {
        TpStartTicketReq req = new TpStartTicketReq();
        req.setProcessDefKey(param.getProcessDefKey());
        req.setIdempotentId(param.getIdempotentId());
        req.setStartOperatorId(param.getStartOperatorId());
        req.setStartOperatorType(param.getStartOperatorType());
        req.setContext(param.getContext());
        final Result<Long> result = tpOaTicketService.startTicket(req);
        log.info("TpStartTicketReq.startTicket[req={} result={}]", JSON.toJSONString(req), JSON.toJSONString(result));
        ValidateUtil.validateResultSuccessAndThrow(result, "工单发起失败");
        TpTicketRep tpTicket = queryTicketById(result.getData());
        return tpTicket.getProcessInstanceId();
    }
    /**
     * 根据ticketId查询ticket
     * @param ticketId 工单id
     * @return 工单
     */
    public TpTicketRep queryTicketById(Long ticketId) {
        Result<TpTicketRep> result = tpOaTicketService.queryTicketByTicketId(ticketId);
        ValidateUtil.validateResultSuccessAndThrow(result,"查询工单失败，queryTicketById request={}"+ticketId);
        return result.getData();
    }

    /**
     * 根据oaProcessInstanceId查询ticket
     */
    public TpTicketRep queryTicketByProcessId(String oaProcessInstanceId) {
        Result<TpTicketRep> result = tpOaTicketService.queryTicketByProcessId(oaProcessInstanceId);
        ValidateUtil.validateResultSuccessAndThrow(result,"查询工单失败，queryTicketByProcessId request={}"+oaProcessInstanceId);
        return result.getData();
    }

    /**
     * 搜索工单
     * @param searchReq 搜索参数
     * @return 工单列表
     */
    public List<TpTicketRep> searchTicket(TpSearchTicketReq searchReq){
        PageResult<List<TpTicketRep>> listPageResult = tpOaTicketService.searchTicket(searchReq);
        ValidateUtil.validateResultSuccessAndThrow(listPageResult, "元数据查询失败");
        return listPageResult.getData();
    }

    /**
     * 取消工单
     * @param ticketId 工单id
     * @param cancelReason 取消原因
     */
    public void cancelTicket(Long ticketId, String cancelReason) {
        TicketCancelReq req = new TicketCancelReq();
        req.setTicketId(ticketId);
        req.setCancelReason(cancelReason);
        final Result<Void> result = tpOaTicketService.cancelTicket2Reason(req);
        ValidateUtil.validateResultSuccessAndThrow(result,"取消工单失败，searchTicket request={}"+ticketId);
    }

    /**
     * 取消流程
     * @param processInstanceId 流程id
     * @param reason 取消原因
     */
    public void terminateProcessInstance(String processInstanceId, String reason) {
        TpTicketRep tpTicketRep = queryTicketByProcessId(processInstanceId);
        AssertUtil.notNull(tpTicketRep,"工单不存在，无法取消流程");
        cancelTicket(tpTicketRep.getId(), reason);
    }

    /**
     * 修改元数据工单
     * @param ticketId 工单id
     * @param context 上下文
     */
    public void updateTicket(Long ticketId, Map<String, Object> context){
        TpUpdateTicketReq tpUpdateTicketReq = new TpUpdateTicketReq();
        tpUpdateTicketReq.setTicketId(ticketId);
        tpUpdateTicketReq.setContext(context);
        Result<Void> result = tpOaTicketService.updateTicket(tpUpdateTicketReq);
        ValidateUtil.validateResultSuccessAndThrow(result,"修改元数据工单失败，searchTicket request={}" + ticketId);
    }


    /**
     * 通过taskId获取task
     * @param taskId 任务id
     * @return 任务
     */
    public TpTicketTaskDTO queryTask(Long taskId) {
        final Result<TpTicketTaskDTO> result = tpTicketTaskReadService.queryTask(taskId);
        ValidateUtil.validateResultSuccessAndThrow(result,"查询工单任务节点失败，queryTask request={}"+taskId);
        return result.getData();
    }

    /**
     * 任务节点超时推进
     * @param taskId 任务id
     * @param action 动作
     */
    public void timeOutPush(Long taskId,String action) {
        TpTicketTaskDTO taskDTO = queryTask(taskId);
        TicketPushByTaskReq req = new TicketPushByTaskReq();
        req.setTaskId(taskId);
        req.setAction(action);
        req.setResolveAllTask(true);
        req.setOperator(taskDTO.getAssigneeIdentityId());
        req.setOperatorType(taskDTO.getAssigneeIdentityType());
        final Result<Void> result = tpTicketPushService.pushByTaskId(req);
        ValidateUtil.validateResultSuccessAndThrow(result, "工单任务节点推进失败");
    }

    /**
     * 获取审批原因
     * @param ticketId 工单id
     * @param descCodeList 执行节点code列表(倒序)
     * @return 审批原因
     */
    public String getLastReason(Long ticketId,List<String> descCodeList) {
        Map<String, List<TpTicketTaskDTO>> nodeMap = queryProcessTask(ticketId);
        for (String code : descCodeList) {
            List<TpTicketTaskDTO> taskDTOList = nodeMap.get(code);
            if (CollectionUtils.isEmpty(taskDTOList)) {
                continue;
            }
            return getReason(taskDTOList);
        }
        return StringUtils.EMPTY;
    }

    private String getReason(List<TpTicketTaskDTO> taskDTOList){
        if (CollectionUtils.isEmpty(taskDTOList)) {
            return StringUtils.EMPTY;
        }
        TpTicketTaskDTO tpTicketTaskDTO = taskDTOList.stream().findFirst().orElse(null);
        if (tpTicketTaskDTO == null) {
            return StringUtils.EMPTY;
        }
        String content = tpTicketTaskDTO.getContent();
        if (StringUtils.isNotBlank(content) && StringUtils.isNotBlank(getValue(content, OAProcessCommonConstants.REASON))) {
            return getValue(content, OAProcessCommonConstants.REASON);
        }
        return StringUtils.EMPTY;
    }

    /**
     * 查询工单任务节点
     * @param ticketId 工单id
     * @return 任务节点
     */
    public Map<String, List<TpTicketTaskDTO>> queryProcessTask(Long ticketId) {
        ArrayList<TpTicketTaskStatusEnum> statusEnums = Lists.newArrayList(TpTicketTaskStatusEnum.FINISHED, TpTicketTaskStatusEnum.PENDING, TpTicketTaskStatusEnum.TIME_OUT, TpTicketTaskStatusEnum.CANCELED);
        List<TpTicketTaskDTO> taskDTOList = queryTaskList(ticketId, statusEnums);
        return Safes.of(taskDTOList)
            .stream()
            .collect(Collectors.groupingBy(dto -> getValue(dto.getFeature(), OAProcessCommonConstants.OA_PARENT_NODE_ID)));
    }

    /**
     * 查询工单任务节点列表
     * @param ticketId 工单id
     * @param taskStatusList 任务状态列表
     * @return 任务节点列表
     */
    public List<TpTicketTaskDTO> queryTaskList(Long ticketId, List<TpTicketTaskStatusEnum> taskStatusList) {
        TpTicketTaskQueryReq req = new TpTicketTaskQueryReq();
        req.setTicketId(ticketId);
        if(CollectionUtils.isNotEmpty(taskStatusList)){
            req.setTaskStatusList(taskStatusList);
        }
        req.setPageIndex(1);
        req.setPageSize(200);
        TpTicketTaskQueryOption option = new TpTicketTaskQueryOption();
        option.setOnlyCount(false);
        option.setQueryTicket(true);
        PageResult<List<TpTicketTaskDTO>> listPageResult = tpTicketTaskReadService.queryTaskList(req, option);
        ValidateUtil.validateResultSuccessAndThrow(listPageResult,"查询工单任务节点列表失败，queryTaskList request={}"+req);
        return listPageResult.getData();
    }


    private String getValue(String content, String key) {
        if(StringUtils.isBlank(content) || StringUtils.isBlank(key)){
            throw new AladdinParamException("content or key is null");
        }
        JSONObject jsonObject =  JSON.parseObject(content);
        return (String)jsonObject.get(key);
    }

}
