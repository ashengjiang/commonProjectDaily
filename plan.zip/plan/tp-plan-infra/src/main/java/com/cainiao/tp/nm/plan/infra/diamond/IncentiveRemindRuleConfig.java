package com.cainiao.tp.nm.plan.infra.diamond;

import com.alibaba.boot.diamond.annotation.DiamondListener;
import com.alibaba.boot.diamond.listener.DiamondDataCallback;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.cainiao.tp.nm.plan.api.policy.application.dto.IncentiveRemindRuleDTO;
import com.cainiao.tp.nm.plan.infra.port.policy.IncentiveRemindRulePort;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

/**
 * 站点实操激励提醒通知规则 Diamond 配置
 * DataId：plan.incentive.notice.rule，Group：DEFAULT_GROUP
 * 配置格式为 JSON 数组，每个元素包含 ruleName、ruleExpression、notifyContent、jumpType
 *
 * @date 2026-03-27
 */
@Slf4j
@Component
@DiamondListener(dataId = "plan.incentive.notice.rule", executeAfterInit = true)
public class IncentiveRemindRuleConfig implements DiamondDataCallback, IncentiveRemindRulePort {

    /**
     * 当前生效的通知规则列表，使用 AtomicReference 保证并发安全
     */
    private final AtomicReference<List<IncentiveRemindRuleDTO>> ruleListRef =
            new AtomicReference<>(Collections.emptyList());

    /**
     * Diamond 配置变更回调，解析 JSON 数组并更新规则列表
     *
     * @param data Diamond 推送的配置文本
     */
    @Override
    public void received(String data) {
        try {
            List<IncentiveRemindRuleDTO> ruleList = JSON.parseObject(
                    data, new TypeReference<List<IncentiveRemindRuleDTO>>() {});
            if (CollectionUtils.isEmpty(ruleList)) {
                log.warn("IncentiveRemindRuleConfig 解析结果为空，清空规则列表，data={}", data);
                ruleListRef.set(Collections.emptyList());
                return;
            }
            ruleListRef.set(ruleList);
            log.info("IncentiveRemindRuleConfig 加载成功，规则数量={}", ruleList.size());
        } catch (Exception e) {
            log.error("IncentiveRemindRuleConfig 解析失败，清空规则列表，data={}", data, e);
            ruleListRef.set(Collections.emptyList());
        }
    }

    /**
     * 获取当前生效的通知规则列表
     *
     * @return 通知规则列表，若未配置则返回空列表
     */
    @Override
    public List<IncentiveRemindRuleDTO> getRuleList() {
        return ruleListRef.get();
    }
}
