package com.cainiao.tp.nm.plan.infra.thrd.station;

import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.tp.nm.plan.infra.port.dto.context.StationPermissionContext;
import com.cainiao.tp.nm.plan.infra.port.policy.StationPermissionCheckManager;
import com.cainiao.tp.nm.plan.infra.thrd.station.handler.StationPermissionCheckHandler;
import com.google.common.collect.Maps;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * @code date 2025年08月01日 13:54
 * @code desc:null
 */
@Component
public class StationPermissionCheckManagerImpl implements StationPermissionCheckManager, InitializingBean {

    private final Map<String, StationPermissionCheckHandler> handlerMap = Maps.newHashMap();
    @Resource
    private List<StationPermissionCheckHandler> handlerList;

    @Override
    public StationPermissionContext checkPermission(StationPermissionContext context) {
        String source = context.getSource();
        AssertUtil.notNull(source, "source不能为空");
        StationPermissionCheckHandler stationPermissionCheckHandler = handlerMap.get(source);
        AssertUtil.notNull(stationPermissionCheckHandler, "handler不能为空");
        return stationPermissionCheckHandler.checkPermission(context);
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        handlerList.forEach(handler -> handlerMap.put(handler.getSource(), handler));
    }
}
