package com.cainiao.tp.nm.plan.infra.exception;

import com.alibaba.fastjson.JSON;
import com.cainiao.aladdin.exception.AladdinException;
import com.cainiao.sutee.commons.restful.result.CnRestResult;
import com.cainiao.tp.nm.plan.infra.port.common.exception.OutServiceException;
import com.cainiao.tp.nm.plan.infra.port.common.constants.RestErrorCode;
import com.cainiao.tp.nm.plan.infra.port.common.exception.ServiceException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolationException;
import java.util.Map;

/**
 * Rest异常拦截处理模版类，子类继承该类以便于实现全局Rest异常拦截处理能力 */
@Slf4j
public abstract class AbstractRestExceptionHandler {

    /**
     * 兜底处理异常，打印日志信息，并统一按CnRestResult规范返回
     *
     * @param t       Throwable
     * @param request HttpServletRequest
     * @return CnRestResult<Object>
     */
    @ExceptionHandler(Throwable.class)
    public CnRestResult<?> defaultErrorHandler(Throwable t, HttpServletRequest request) {
        String info = getRequestInfo(request);
        CnRestResult<?> cnRestResult = CnRestResult.fail();
        cnRestResult.setErrorMsg(t.getMessage());
        log.error("{},{}", info, JSON.toJSONString(cnRestResult), t);
        return cnRestResult;
    }

    /**
     * 兼容aladdin异常，打印日志信息，并统一按CnRestResult规范返回
     *
     * @param e      AladdinException
     * @param request HttpServletRequest
     * @return CnRestResult<Object>
     */
    @ExceptionHandler(AladdinException.class)
    public CnRestResult<?> aladdinExceptionHandler(AladdinException e, HttpServletRequest request) {
        String info = getRequestInfo(request);
        CnRestResult<?> cnRestResult = CnRestResult.fail(RestErrorCode.SERVICE_ERROR,e.getMessage());
        log.error("{},{}", info, JSON.toJSONString(cnRestResult), e);
        return cnRestResult;
    }

    private static String getRequestInfo(HttpServletRequest request) {
        String uri = "";
        String method = "";
        String params = "";
        if (request != null) {
            uri = request.getRequestURI();
            method = request.getMethod();
            params = JSON.toJSONString(request.getParameterMap());
        }
        return method + " " + uri + " " + params;
    }

    /**
     * 捕获业务异常（业务逻辑执行过程中抛出的自定义异常），转换成规范要求的形式返回给客户端，并打印日志
     *
     * @param e       ServiceException
     * @param request HttpServletRequest
     * @return CnRestResult<Object>
     */
    @ExceptionHandler(ServiceException.class)
    public CnRestResult<?> bizException(ServiceException e, HttpServletRequest request) {
        CnRestResult<?> cnRestResult;
        if (e instanceof OutServiceException) {
            cnRestResult = CnRestResult.fail(RestErrorCode.OUT_SERVICE_ERROR.from(e));
        } else {
            cnRestResult = CnRestResult.fail(RestErrorCode.SERVICE_ERROR.from(e));
        }
        String info = getRequestInfo(request);
        log.warn("{},{}", info, JSON.toJSONString(cnRestResult), e);
        return cnRestResult;
    }

    /**
     * 统一参数校验返回形式
     * 捕获参数校验异常（请求体对象级别的验证错误：在方法中使用 @Valid 注解来验证请求体对象），转换成规范要求的形式返回给客户端，并打印日志
     *
     * @param ex MethodArgumentNotValidException
     * @return CnRestResult<Object>
     */
    @ExceptionHandler({MethodArgumentNotValidException.class})
    public CnRestResult<?> handleMethodArgumentNotValidException(MethodArgumentNotValidException ex,
        HttpServletRequest request) {
        Map<String, Object> errorMap = AbstractRpcExceptionHandler.resolveErrorInfo(ex);
        CnRestResult<?> cnRestResult = CnRestResult.fail(RestErrorCode.ILLEGAL_PARAM);
        cnRestResult.setErrorConstructInfo(errorMap);
        String info = getRequestInfo(request);
        log.warn("{},{}", info, JSON.toJSONString(cnRestResult), ex);
        return cnRestResult;
    }

    /**
     * 统一参数校验返回形式
     * 捕获参数校验异常（方法参数级别的验证错误：直接在方法参数上使用验证注解来验证请求参数），转换成规范要求的形式返回给客户端，并打印日志
     *
     * @param ex MethodArgumentNotValidException
     * @return CnRestResult<Object>
     */
    @ExceptionHandler({ConstraintViolationException.class})
    public CnRestResult<?> handleConstraintViolationException(ConstraintViolationException ex,
        HttpServletRequest request) {
        CnRestResult<?> cnRestResult = CnRestResult.fail(RestErrorCode.ILLEGAL_PARAM);
        Map<String, Object> errorMap = AbstractRpcExceptionHandler.resolveErrorInfo(ex);
        cnRestResult.setErrorConstructInfo(errorMap);
        String info = getRequestInfo(request);
        log.warn("{},{}", info, JSON.toJSONString(cnRestResult), ex);
        return cnRestResult;
    }
   /* @ExceptionHandler({FastValidatorException.class})
    public CnRestResult<?> handleFastValidatorException(FastValidatorException ex, HttpServletRequest request) {
        CnRestResult<?> cnRestResult = CnRestResult.fail(RestErrorCode.ILLEGAL_PARAM);
        Map<String, Object> errorMap = AbstractRpcExceptionHandler.resolveErrorInfo(ex);
        cnRestResult.setErrorConstructInfo(errorMap);
        String info = getRequestInfo(request);
        log.warn("{},{}", info, JSON.toJSONString(cnRestResult), ex);
        return cnRestResult;
    }*/

}
