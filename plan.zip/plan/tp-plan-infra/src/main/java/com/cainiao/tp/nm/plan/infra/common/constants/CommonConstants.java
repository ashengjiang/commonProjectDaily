package com.cainiao.tp.nm.plan.infra.common.constants;

import com.alibaba.cainiao.stationplatform.client.domain.ClientInfo;

/**
 * @code date 2025年07月31日 15:30
 * @code desc:null
 */
public final class CommonConstants {
    public static final ClientInfo CLIENT_INFO= new ClientInfo("tp-nm-plan","政策中心");
    public final static String CITY_TYPE = "MERGE_DISTRICT";
    public final static String STREET = "STREET";
    public final static String SPLIT = "#";
    public final static String CN_LOGIN_CHANNEL = "1";
    public final static String LIGHT_STATION_MODE_FLAG = "POINT_";
    public static final String SESSION_ID = "caiNiaoSessionId";

}
