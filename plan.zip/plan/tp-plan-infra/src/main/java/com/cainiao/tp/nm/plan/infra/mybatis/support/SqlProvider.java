package com.cainiao.tp.nm.plan.infra.mybatis.support;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import com.cainiao.tp.nm.plan.infra.mybatis.annotation.Column;
import com.cainiao.tp.nm.plan.infra.mybatis.annotation.CreatedDate;
import com.cainiao.tp.nm.plan.infra.mybatis.annotation.LastModifiedDate;
import com.cainiao.tp.nm.plan.infra.mybatis.annotation.LogicDelete;
import com.cainiao.tp.nm.plan.infra.mybatis.annotation.OrderByParam;
import com.cainiao.tp.nm.plan.infra.mybatis.annotation.PageNumParam;
import com.cainiao.tp.nm.plan.infra.mybatis.annotation.PageSizeParam;
import com.cainiao.tp.nm.plan.infra.mybatis.annotation.QueryType;
import com.cainiao.tp.nm.plan.infra.mybatis.annotation.Table;
import com.cainiao.tp.nm.plan.infra.mybatis.annotation.Transient;
import com.cainiao.tp.nm.plan.infra.mybatis.annotation.Version;
import com.cainiao.tp.nm.plan.infra.mybatis.dto.OrderBy;
import com.cainiao.tp.nm.plan.infra.util.ReflectUtil;
import com.google.common.base.CaseFormat;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.builder.annotation.ProviderContext;

/**
 * sql provider,用于自动生成mapper代码 */
@Slf4j
public class SqlProvider {
    /**
     * 数据库当前时间戳
     */
    private static final String CURRENT_TIMESTAMP = "CURRENT_TIMESTAMP";
    public static final String SUFFIX_DO = "DO";

    private final Map<Class<?>, String> tableNameCache = new ConcurrentHashMap<>();
    private final Map<Class<?>, List<Field>> allFieldsCache = new ConcurrentHashMap<>();
    private final Map<Field, String> columnNameCache = new ConcurrentHashMap<>();
    private final Map<Class<?>, String> allColumnsCache = new ConcurrentHashMap<>();
    private final Map<Class<?>, String> deleteByIdSqlCache = new ConcurrentHashMap<>();
    private final Map<Class<?>, String> selectByIdSqlCache = new ConcurrentHashMap<>();
    private final Map<Class<?>, String> notDeletedConditionCache = new ConcurrentHashMap<>();
    private final Map<Class<?>, Field> orderByFieldCache = new ConcurrentHashMap<>();
    private final Map<Class<?>, Field> pageNumFieldCache = new ConcurrentHashMap<>();
    private final Map<Class<?>, Field> pageSizeFieldCache = new ConcurrentHashMap<>();

    public String insert(ProviderContext context, Object entity) {
        Class<?> entityClass = this.getEntityClass(context);
        StringBuilder sql = new StringBuilder("INSERT INTO ");
        sql.append(getTableName(entityClass));
        sql.append(" (");
        StringJoiner columns = new StringJoiner(", ");
        StringJoiner values = new StringJoiner(", ");

        // 获取所有字段，包括父类的
        for (Field field : getAllFields(entityClass)) {
            String fieldName = field.getName();
            if ("id".equals(fieldName)) {
                continue;
            }
            String columnName = getColumnName(field);
            if (field.isAnnotationPresent(CreatedDate.class) || field.isAnnotationPresent(LastModifiedDate.class)) {
                columns.add(columnName);
                values.add(CURRENT_TIMESTAMP);
            } else if (field.isAnnotationPresent(Version.class)) {
                columns.add(columnName);
                values.add("0");
            } else {
                try {
                    Object value = ReflectUtil.getFieldValue(entity, field);
                    if (value != null) {
                        columns.add(columnName);
                        values.add("#{" + fieldName + "}");
                    }
                } catch (IllegalAccessException e) {
                    log.error("build insert sql columns error,entity:{},field:{}", entity, field, e);
                }
            }
        }

        // 处理逻辑删除字段，默认插入未删除的值
        LogicDelete logicDelete = entityClass.getAnnotation(LogicDelete.class);
        if (logicDelete != null) {
            columns.add(logicDelete.column());
            values.add(logicDelete.notDeletedValue());
        }

        sql.append(columns).append(") VALUES (").append(values).append(")");
        return sql.toString();
    }

    public String batchInsert(ProviderContext context, @Param("entities") List<?> entities) {
        if (entities == null || entities.isEmpty()) {
            return "";
        }

        Class<?> entityClass = this.getEntityClass(context);
        StringBuilder sql = new StringBuilder("INSERT INTO ");
        sql.append(getTableName(entityClass));
        sql.append(" (");

        StringJoiner columns = new StringJoiner(", ");
        // 获取所有字段，包括父类的
        for (Field field : getAllFields(entityClass)) {
            String fieldName = field.getName();
            if (!"id".equals(fieldName)) {
                columns.add(getColumnName(field));
            }
        }
        // 处理逻辑删除字段，默认插入未删除的值
        LogicDelete logicDelete = entityClass.getAnnotation(LogicDelete.class);
        if (logicDelete != null) {
            columns.add(logicDelete.column());
        }
        sql.append(columns).append(") VALUES ");

        StringJoiner valuesJoiner = new StringJoiner(", ");
        for (int i = 0; i < entities.size(); i++) {
            Object entity = entities.get(i);
            StringJoiner values = new StringJoiner(", ", "(", ")");
            for (Field field : getAllFields(entityClass)) {
                String fieldName = field.getName();
                if ("id".equals(fieldName)) {
                    continue;
                }
                if (field.isAnnotationPresent(CreatedDate.class) || field.isAnnotationPresent(LastModifiedDate.class)) {
                    values.add(CURRENT_TIMESTAMP);
                } else if (field.isAnnotationPresent(Version.class)) {
                    values.add("0");
                } else {
                    try {
                        Object value = ReflectUtil.getFieldValue(entity, field);
                        if (value != null) {
                            values.add("#{entities[" + i + "]." + fieldName + "}");
                        } else {
                            // 如果为null则插入NULL
                            values.add("NULL");
                        }
                    } catch (IllegalAccessException e) {
                        log.error("build batch insert sql values error,entity:{},field:{}", entity, field, e);
                    }
                }
            }
            if (logicDelete != null) {
                values.add(logicDelete.notDeletedValue());
            }
            valuesJoiner.add(values.toString());
        }

        sql.append(valuesJoiner);
        return sql.toString();
    }

    public String deleteById(ProviderContext context, @Param("id") Long id) {
        Class<?> entityClass = getEntityClass(context);
        return deleteByIdSqlCache.computeIfAbsent(entityClass, this::computeDeleteById);
    }

    private String computeDeleteById(Class<?> entityClass) {
        String tableName = getTableName(entityClass);
        LogicDelete logicDelete = entityClass.getAnnotation(LogicDelete.class);
        if (logicDelete != null) {
            String columnName = logicDelete.column();
            String deletedValue = logicDelete.deletedValue();
            String notDeletedValue = logicDelete.notDeletedValue();
            String lastModifiedColumn = getLastModifiedColumn(entityClass);
            return "UPDATE " + tableName + " SET "
                + columnName + " = " + deletedValue
                + (lastModifiedColumn != null ? ", " + lastModifiedColumn + " = " + CURRENT_TIMESTAMP : "")
                + " WHERE id = #{id}"
                + " AND " + columnName + " = " + notDeletedValue;
        }
        return "DELETE FROM " + tableName + " WHERE id = #{id}";
    }

    public String batchDeleteByIds(ProviderContext context, @Param("ids") List<Long> ids) {
        if (ids == null || ids.isEmpty()) {
            return "";
        }

        Class<?> entityClass = getEntityClass(context);
        LogicDelete logicDelete = entityClass.getAnnotation(LogicDelete.class);
        if (logicDelete != null) {
            String columnName = logicDelete.column();
            String deletedValue = logicDelete.deletedValue();
            String notDeletedValue = logicDelete.notDeletedValue();
            String lastModifiedColumn = getLastModifiedColumn(entityClass);
            StringJoiner idJoiner = new StringJoiner(", ", "(", ")");
            for (Long id : ids) {
                idJoiner.add("#{ids[" + ids.indexOf(id) + "]}");
            }
            return "UPDATE " + getTableName(entityClass) + " SET "
                + columnName + " = " + deletedValue
                + (lastModifiedColumn != null ? ", " + lastModifiedColumn + " = " + CURRENT_TIMESTAMP : "")
                + " WHERE id IN " + idJoiner
                + " AND " + columnName + " = " + notDeletedValue;
        }

        StringJoiner idJoiner = new StringJoiner(", ", "(", ")");
        for (Long id : ids) {
            idJoiner.add("#{ids[" + ids.indexOf(id) + "]}");
        }

        return "DELETE FROM " + getTableName(entityClass) + " WHERE id IN " + idJoiner.toString();
    }

    public String update(ProviderContext context, Object entity) {
        Class<?> entityClass = this.getEntityClass(context);
        StringBuilder sql = new StringBuilder("UPDATE ");
        sql.append(getTableName(entityClass)).append(" SET ");
        StringJoiner setClause = new StringJoiner(", ");
        StringJoiner whereClause = new StringJoiner(" AND ", " WHERE ", "");
        whereClause.add("id = #{id}");

        for (Field field : getAllFields(entityClass)) {
            String fieldName = field.getName();
            if (field.isAnnotationPresent(CreatedDate.class) || "id".equals(fieldName)) {
                continue;
            }
            String columnName = getColumnName(field);
            if (field.isAnnotationPresent(LastModifiedDate.class)) {
                setClause.add(columnName + " = " + CURRENT_TIMESTAMP);
            } else if (field.isAnnotationPresent(Version.class)) {
                setClause.add(columnName + " = " + columnName + " + 1");
                whereClause.add(columnName + " = #{" + fieldName + "}");
            } else {
                try {
                    Object value = ReflectUtil.getFieldValue(entity, field);
                    if (value != null) {
                        setClause.add(columnName + " = #{" + fieldName + "}");
                    }
                } catch (IllegalAccessException e) {
                    log.error("build update sql setClause error,entity:{},field:{}", entity, field, e);
                }
            }
        }

        sql.append(setClause).append(whereClause).append(notDeletedCondition(entityClass));
        return sql.toString();
    }

    public String selectById(ProviderContext context, @Param("id") Long id) {
        Class<?> entityClass = getEntityClass(context);
        return selectByIdSqlCache.computeIfAbsent(entityClass, this::computeSelectById);
    }

    private String computeSelectById(Class<?> entityClass) {
        String tableName = getTableName(entityClass);
        return "SELECT " + getAllColumns(entityClass) + " FROM " + tableName
            + " WHERE id = #{id}"
            + notDeletedCondition(entityClass);
    }

    public String selectAll(ProviderContext context, Object queryParam) {
        Class<?> entityClass = getEntityClass(context);
        return "SELECT " + getAllColumns(entityClass) + " FROM " + getTableName(entityClass)
            + buildWhereClause(queryParam)
            + notDeletedCondition(entityClass)
            // 添加排序
            + orderByClause(queryParam)
            // 添加分页条件
            + paginationClause(queryParam);
    }

    private String paginationClause(Object queryParam) {

        Field pageNumField = getPageNumField(queryParam.getClass());
        Field pageSizeField = getPageSizeField(queryParam.getClass());

        if (pageNumField != null && pageSizeField != null) {
            try {
                Integer pageNum = (Integer)ReflectUtil.getFieldValue(queryParam, pageNumField);
                Integer size = (Integer)ReflectUtil.getFieldValue(queryParam, pageSizeField);
                if (pageNum != null && size != null) {
                    int offset = (pageNum - 1) * size;
                    return " LIMIT " + offset + ", " + size;
                }
            } catch (IllegalAccessException e) {
                log.error("Error in appending pagination parameters, queryParam: {}", queryParam, e);
            }
        }
        return "";
    }

    private Field getPageNumField(Class<?> clazz) {
        return pageNumFieldCache.computeIfAbsent(clazz, this::computePageNumField);
    }

    private Field computePageNumField(Class<?> clazz) {
        List<Field> fieldList = getAllFields(clazz).stream().filter(
            field -> field.isAnnotationPresent(PageNumParam.class)).collect(Collectors.toList());
        if (fieldList.isEmpty()) {
            return null;
        }
        if (fieldList.size() != 1) {
            throw new IllegalArgumentException(
                "Only one field can be annotated with @PageNumParam, but found: " + fieldList);
        }
        return fieldList.get(0);
    }

    private Field getPageSizeField(Class<?> clazz) {
        return pageSizeFieldCache.computeIfAbsent(clazz, this::computePageSizeField);
    }

    private Field computePageSizeField(Class<?> clazz) {
        List<Field> fieldList = getAllFields(clazz).stream().filter(
            field -> field.isAnnotationPresent(PageSizeParam.class)).collect(Collectors.toList());
        if (fieldList.isEmpty()) {
            return null;
        }
        if (fieldList.size() != 1) {
            throw new IllegalArgumentException(
                "Only one field can be annotated with @PageSizeParam, but found: " + fieldList);
        }
        return fieldList.get(0);
    }

    public String count(ProviderContext context, Object queryParam) {
        Class<?> entityClass = getEntityClass(context);
        return "SELECT COUNT(*) FROM " + getTableName(entityClass)
            + buildWhereClause(queryParam)
            + notDeletedCondition(entityClass);
    }

    private String buildWhereClause(Object queryParam) {
        // 定义特殊字段的注解类型
        List<Class<? extends Annotation>> ignoreAnnotations = new ArrayList<>();
        ignoreAnnotations.add(PageNumParam.class);
        ignoreAnnotations.add(PageSizeParam.class);
        ignoreAnnotations.add(OrderByParam.class);
        ignoreAnnotations.add(Transient.class);

        StringJoiner whereClause = new StringJoiner(" AND ", " WHERE ", "");
        boolean hasConditions = false;
        for (Field field : getAllFields(queryParam.getClass())) {
            // 跳过包含特殊注解的字段
            if (isFieldAnnotatedWith(field, ignoreAnnotations)) {
                continue;
            }
            try {
                Object value = ReflectUtil.getFieldValue(queryParam, field);
                if (value != null) {
                    hasConditions = true;
                    String columnName = getColumnName(field);
                    QueryType queryType = field.getAnnotation(QueryType.class);
                    if (queryType != null) {
                        switch (queryType.value()) {
                            case EQUAL:
                                whereClause.add(columnName + " = #{" + field.getName() + "}");
                                break;
                            case LIKE:
                                switch (queryType.likeType()) {
                                    case LEFT:
                                        whereClause.add(columnName + " LIKE CONCAT('%', #{" + field.getName() + "})");
                                        break;
                                    case RIGHT:
                                        whereClause.add(columnName + " LIKE CONCAT(#{" + field.getName() + "}, '%')");
                                        break;
                                    case FULL:
                                        whereClause.add(
                                            columnName + " LIKE CONCAT('%', #{" + field.getName() + "}, '%')");
                                        break;
                                    default:

                                }
                                break;
                            case IN:
                                whereClause.add(columnName + buildInClause(field, value));
                                break;
                            case RANGE:
                                switch (queryType.rangeType()) {
                                    case MIN:
                                        whereClause.add(columnName + " >= #{" + field.getName() + "}");
                                        break;
                                    case MAX:
                                        whereClause.add(columnName + " < #{" + field.getName() + "}");
                                        break;
                                    default:
                                }
                                break;
                            default:
                        }
                    } else {
                        whereClause.add(columnName + " = #{" + field.getName() + "}");
                    }
                }
            } catch (IllegalAccessException e) {
                log.error("build buildWhereClause sql error, queryParam: {}, field: {}", queryParam, field, e);
            }
        }
        if (hasConditions) {
            return whereClause.toString();
        }
        return " WHERE 1=1 ";
    }

    /**
     * 检查字段是否带有特定注解
     */
    private boolean isFieldAnnotatedWith(Field field, List<Class<? extends Annotation>> annotations) {
        for (Class<? extends Annotation> annotation : annotations) {
            if (field.isAnnotationPresent(annotation)) {
                return true;
            }
        }
        return false;
    }

    private String buildInClause(Field field, Object value) {
        if (value instanceof Collection) {
            Collection<?> valueList = (Collection<?>)value;
            if (valueList.isEmpty()) {
                return "";
            }
            String fieldName = field.getName();
            StringBuilder result = new StringBuilder(" IN (");
            result.append("#{").append(fieldName).append("[0]}");
            for (int i = 1; i < valueList.size(); i++) {
                result.append(",#{");
                result.append(fieldName).append("[").append(i).append("]}");
            }
            result.append(")");
            return result.toString();
        }
        throw new IllegalArgumentException(
            "IN clause requires a Collection,but: " + field.getType() + ", filed: " + field);
    }

    private String getTableName(Class<?> clazz) {
        return this.tableNameCache.computeIfAbsent(clazz, this::computeTableName);
    }

    private String computeTableName(Class<?> clazz) {
        // 获取 @Table 注解
        Table table = clazz.getAnnotation(Table.class);
        if (table != null && !table.name().isEmpty()) {
            // 如果类上有 @Table 注解且表名不为空，返回注解中的表名
            return table.name();
        }
        String className = clazz.getSimpleName();
        if (className.endsWith(SUFFIX_DO)) {
            className = className.substring(0, className.length() - 2);
        }
        return camelToSnake(className);
    }

    private Class<?> getEntityClass(ProviderContext context) {
        return (Class<?>)((ParameterizedType)context.getMapperType()
            .getGenericInterfaces()[0]).getActualTypeArguments()[0];
    }

    private String camelToSnake(String str) {
        return CaseFormat.LOWER_CAMEL.to(CaseFormat.LOWER_UNDERSCORE, str);
    }

    private String getLastModifiedColumn(Class<?> entityClass) {
        for (Field field : getAllFields(entityClass)) {
            if (field.isAnnotationPresent(LastModifiedDate.class)) {
                return camelToSnake(field.getName());
            }
        }
        return null;
    }

    private String notDeletedCondition(Class<?> clazz) {
        return notDeletedConditionCache.computeIfAbsent(clazz, this::computeNotDeletedCondition);
    }

    private String computeNotDeletedCondition(Class<?> clazz) {
        LogicDelete logicDelete = clazz.getAnnotation(LogicDelete.class);
        if (logicDelete != null) {
            String columnName = logicDelete.column();
            String notDeletedValue = logicDelete.notDeletedValue();
            return " AND " + columnName + " = " + notDeletedValue;
        }
        return "";
    }

    private String orderByClause(Object queryParam) {
        Field orderByField = getOrderByField(queryParam.getClass());
        if (orderByField == null) {
            return "";
        }
        try {
            List<?> orderByList = (List<?>)ReflectUtil.getFieldValue(queryParam, orderByField);
            if (orderByList != null && !orderByList.isEmpty()) {
                StringJoiner orderByClause = new StringJoiner(", ", " ORDER BY ", "");
                for (Object o : orderByList) {
                    orderByClause.add(((OrderBy)o).getFieldName() + " " + (((OrderBy)o).isAsc() ? "ASC" : "DESC"));
                }
                return orderByClause.toString();
            }

        } catch (IllegalAccessException e) {
            log.error("Error in appending ORDER BY clause, queryParam: {}", queryParam, e);
        }
        return "";
    }

    private Field getOrderByField(Class<?> clazz) {
        return orderByFieldCache.computeIfAbsent(clazz, this::computeOrderByField);
    }

    private Field computeOrderByField(Class<?> clazz) {
        List<Field> orderByFields = getAllFields(clazz).stream().filter(
            field -> field.isAnnotationPresent(OrderByParam.class)).collect(Collectors.toList());
        if (orderByFields.isEmpty()) {
            return null;
        }
        if (orderByFields.size() > 1) {
            throw new IllegalArgumentException(
                "Only one field can be annotated with @OrderByParam, but found: " + orderByFields);
        }
        Field orderByField = orderByFields.get(0);
        if (!List.class.isAssignableFrom(orderByField.getType()) || !isOrderByGenericParameter(orderByField)) {
            throw new IllegalArgumentException(
                "The field annotated with @OrderByParam must be a List of OrderBy, but found: " + orderByField);
        }

        return orderByField;
    }

    private boolean isOrderByGenericParameter(Field orderByField) {
        Type genericType = orderByField.getGenericType();
        if (genericType instanceof ParameterizedType) {
            ParameterizedType parameterizedType = (ParameterizedType)genericType;
            Type[] actualTypeArguments = parameterizedType.getActualTypeArguments();
            if (actualTypeArguments.length == 1) {
                return OrderBy.class.isAssignableFrom((Class<?>)actualTypeArguments[0]);
            }
        }
        return false;
    }

    private String getColumnName(Field field) {
        return columnNameCache.computeIfAbsent(field, this::computeColumnName);
    }

    private String computeColumnName(Field field) {
        Column column = field.getAnnotation(Column.class);
        if (column != null && !column.name().isEmpty()) {
            return column.name();
        }
        return camelToSnake(field.getName());
    }

    private String getAllColumns(Class<?> clazz) {
        return allColumnsCache.computeIfAbsent(clazz, this::computeAllColumns);
    }

    private String computeAllColumns(Class<?> clazz) {
        StringJoiner joiner = new StringJoiner(", ");
        for (Field field : getAllFields(clazz)) {
            joiner.add(getColumnName(field));
        }
        return joiner.toString();
    }

    private List<Field> getAllFields(Class<?> clazz) {
        return this.allFieldsCache.computeIfAbsent(clazz, this::computeAllFields);
    }

    private List<Field> computeAllFields(Class<?> clazz) {
        return ReflectUtil.getAllFields(clazz).stream().filter(field -> !field.isAnnotationPresent(Transient.class))
            .collect(Collectors.toList());
    }
}
