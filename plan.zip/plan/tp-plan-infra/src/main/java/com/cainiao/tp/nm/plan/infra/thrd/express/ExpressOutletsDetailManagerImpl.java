package com.cainiao.tp.nm.plan.infra.thrd.express;

import com.alibaba.cainiao.stationplatform.client.cache.StationExpressReadServiceClient;
import com.alibaba.cainiao.stationplatform.client.domain.ClientInfo;
import com.alibaba.cainiao.stationplatform.client.domain.StationExpressDTO;
import com.alibaba.cainiao.stationplatform.client.domain.StationResultDTO;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.sutee.commons.base.result.CnResult;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.ExpressOutletsDetailDTO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.ExpressOutletsDivisionDTO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.ExpressOutletsQueryRequest;
import com.cainiao.tp.nm.plan.api.policy.application.dto.DivisionDTO;
import com.cainiao.tp.nm.plan.api.policy.common.constants.ExpressTypeEnum;
import com.cainiao.tp.nm.plan.infra.port.policy.DivisionManager;
import com.cainiao.tp.nm.plan.infra.port.policy.ExpressOutletsDetailManager;
import com.cainiao.tp.nm.plan.infra.port.utils.ExpressUtils;
import com.xiniao.service.operate.api.station.XnUnmannedStationJvInfoService;
import com.xiniao.service.operate.api.ticket.dto.param.JointVentureInfoDTO;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;

/**
 * @code date 2025年06月10日 10:43
 * @code desc:null
 */
@Component
public class ExpressOutletsDetailManagerImpl implements ExpressOutletsDetailManager {

    private static final ClientInfo CLIENT_INFO = new ClientInfo("tp-nm-plan", "政策中心");
    @Resource
    StationExpressReadServiceClient stationExpressReadServiceClient;
    @Resource
    XnUnmannedStationJvInfoService xnUnmannedStationJvInfoService;
    @Resource
    DivisionManager divisionManager;

    @Override
    public ExpressOutletsDetailDTO queryExpressOutletsDetail(ExpressOutletsQueryRequest request) {
        AssertUtil.notNull(request, "request不能为空");
        AssertUtil.notNull(request.getOrgType(), "orgType不能为空");
        ExpressOutletsDetailDTO expressOutletsDetailDTO = new ExpressOutletsDetailDTO();
        ExpressOutletsDivisionDTO expressDivisionDTO = new ExpressOutletsDivisionDTO();
        if (ExpressTypeEnum.JV.getCode().equals(request.getOrgType())) {
            CnResult<JointVentureInfoDTO> jvInfoByCode = xnUnmannedStationJvInfoService.getJvInfoByCode(request.getOrgCode());
            AssertUtil.isTrue(jvInfoByCode.isSuccess() , "查询服务商失败");
            JointVentureInfoDTO data = jvInfoByCode.getData();
            if(null==data){
                return null;
            }
            expressDivisionDTO.setExpressId(data.getCode());
            expressDivisionDTO.setOrgName(data.getName());
            expressDivisionDTO.setOrgType(ExpressTypeEnum.JV.getCode());
            expressDivisionDTO.setProvinceCode(data.getProvinceId().toString());
            expressDivisionDTO.setProvince(data.getProvinceName());
            expressDivisionDTO.setCityCode(data.getCityId().toString());
            expressDivisionDTO.setCity(data.getCityName());
            expressDivisionDTO.setDistrictCode(data.getCountyId().toString());
            expressDivisionDTO.setDistrict(data.getCountyName());
            expressDivisionDTO.setJvCpCode(data.getCpCode());
            expressDivisionDTO.setJvCpName(data.getCpName());
            expressOutletsDetailDTO.setOrgType(ExpressTypeEnum.JV.getCode());
            expressOutletsDetailDTO.setExpressOutletsDivisionDTO(expressDivisionDTO);
        } else {
            StationResultDTO<List<StationExpressDTO>> listStationResultDTO = stationExpressReadServiceClient.queryExpressByOrgCode(request.getCpCode(), request.getOrgCode(), CLIENT_INFO);
            AssertUtil.isTrue(listStationResultDTO.isSuccess() , "查询网点失败");
            StationExpressDTO stationExpressDTO = listStationResultDTO.getData().stream().findFirst().orElse(null);
            if(stationExpressDTO==null){
                return null;
            }
            expressDivisionDTO.setExpressId(ExpressUtils.build(stationExpressDTO.getOrgCode(),stationExpressDTO.getCpCode()));
            expressDivisionDTO.setOrgName(stationExpressDTO.getExpressName());
            expressDivisionDTO.setOrgType(ExpressTypeEnum.EXPRESS.getCode());
            expressDivisionDTO.setProvinceCode(parseNull(stationExpressDTO.getProvinceCode()));
            expressDivisionDTO.setCityCode(parseNull(stationExpressDTO.getCityCode()));
            expressDivisionDTO.setDistrictCode(parseNull(stationExpressDTO.getAreaCode()));
            expressOutletsDetailDTO.setOrgType(ExpressTypeEnum.EXPRESS.getCode());
            expressOutletsDetailDTO.setExpressOutletsDivisionDTO(expressDivisionDTO);

            Long divisionCode = Objects.isNull(parseLong(stationExpressDTO.getAreaCode())) ? parseLong(stationExpressDTO.getCityCode())
                    : parseLong(stationExpressDTO.getAreaCode());
            DivisionDTO divisionChain = divisionManager.getDivisionChain(divisionCode);

            if (divisionChain != null) {
                expressDivisionDTO.setProvince(divisionChain.getProvince());
                expressDivisionDTO.setCity(divisionChain.getCity());
                expressDivisionDTO.setDistrict(divisionChain.getDistrict());
            }
        }
        return expressOutletsDetailDTO;
    }
    private Long parseLong(String str) {
        if (checkString(str)) {
            return null;
        }
        return Long.parseLong(str);
    }
    private String parseNull(String str) {
        if (checkString(str)) {
            return null;
        }
        return str;
    }

    private Boolean checkString(String str) {
        return str == null || "null".equals(str);
    }
}
