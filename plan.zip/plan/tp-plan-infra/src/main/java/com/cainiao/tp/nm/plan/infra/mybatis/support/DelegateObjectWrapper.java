package com.cainiao.tp.nm.plan.infra.mybatis.support;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.reflection.MetaObject;
import org.apache.ibatis.reflection.factory.ObjectFactory;
import org.apache.ibatis.reflection.property.PropertyTokenizer;
import org.apache.ibatis.reflection.wrapper.ObjectWrapper;

/**
 * 代理类，实现返回结果通过@Column完成字段映射
 */
public class DelegateObjectWrapper implements ObjectWrapper {

    /**
     * 使用@ColumnName注释过的DO字段映射关系
     */
    private final Map<String, String> columnMap;

    private final ObjectWrapper objectWrapper;

    public DelegateObjectWrapper(Map<String, String> columnMap, ObjectWrapper objectWrapper) {
        super();
        this.columnMap = columnMap;
        this.objectWrapper = objectWrapper;
    }

    @Override
    public Object get(PropertyTokenizer prop) {
        return objectWrapper.get(prop);
    }

    @Override
    public void set(PropertyTokenizer prop, Object value) {
        objectWrapper.set(prop, value);
    }

    @Override
    public String findProperty(String name, boolean useCamelCaseMapping) {
        if (columnMap.containsKey(name)) {
            return columnMap.get(name);
        }
        return objectWrapper.findProperty(name, useCamelCaseMapping);
    }

    @Override
    public String[] getGetterNames() {
        return objectWrapper.getGetterNames();
    }

    @Override
    public String[] getSetterNames() {
        return objectWrapper.getSetterNames();
    }

    @Override
    public Class<?> getSetterType(String name) {
        return objectWrapper.getSetterType(name);
    }

    @Override
    public Class<?> getGetterType(String name) {
        return objectWrapper.getGetterType(name);
    }

    @Override
    public boolean hasSetter(String name) {
        return objectWrapper.hasSetter(name);
    }

    @Override
    public boolean hasGetter(String name) {
        return objectWrapper.hasGetter(name);
    }

    @Override
    public MetaObject instantiatePropertyValue(String name, PropertyTokenizer prop, ObjectFactory objectFactory) {
        return objectWrapper.instantiatePropertyValue(name, prop, objectFactory);
    }

    @Override
    public boolean isCollection() {
        return objectWrapper.isCollection();
    }

    @Override
    public void add(Object element) {
        objectWrapper.add(element);
    }

    @Override
    public <E> void addAll(List<E> element) {
        objectWrapper.addAll(element);
    }

}
