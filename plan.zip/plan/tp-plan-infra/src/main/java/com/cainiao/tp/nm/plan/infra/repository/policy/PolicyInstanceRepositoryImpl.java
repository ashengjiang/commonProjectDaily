package com.cainiao.tp.nm.plan.infra.repository.policy;

import com.cainiao.aladdin.utils.Safes;
import com.cainiao.sutee.commons.base.model.CnPage;
import com.cainiao.sutee.commons.base.model.Page;
import com.cainiao.tp.nm.plan.infra.mybatis.dto.PageResult;
import com.cainiao.tp.nm.plan.infra.repository.policy.convert.PolicyInstanceConvertor;
import com.cainiao.tp.nm.plan.infra.repository.policy.dto.data.PolicyInstanceDO;
import com.cainiao.tp.nm.plan.infra.repository.policy.dto.data.PolicyRuleInstanceDO;
import com.cainiao.tp.nm.plan.infra.repository.policy.dto.param.PolicyInstanceQueryParam;
import com.cainiao.tp.nm.plan.infra.repository.policy.dto.param.PolicyRuleInstanceQueryParam;
import com.cainiao.tp.nm.plan.infra.repository.policy.mapper.PolicyInstanceMapper;
import com.cainiao.tp.nm.plan.infra.repository.policy.mapper.PolicyRuleInstanceMapper;
import com.cainiao.tp.nm.plan.infra.repository.policy.sort.PolicyInstanceSortEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyFeatureConstants;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyInstanceStatusEnum;
import com.cainiao.tp.nm.plan.policy.domain.model.PolicyInstance;
import com.cainiao.tp.nm.plan.policy.domain.repository.PolicyInstanceRepository;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

/**
 * @code date 2024年10月28日 17:04
 * @code desc: 政策实例仓储
 */
@Component
@Slf4j
public class PolicyInstanceRepositoryImpl implements PolicyInstanceRepository {

    @Resource
    private PolicyInstanceMapper policyInstanceMapper;
    @Resource
    private PolicyRuleInstanceMapper policyRuleInstanceMapper;
    @Resource
    private PolicyInstanceConvertor policyInstanceConvertor;

    @Override
    public PolicyInstance get(Long instanceId) {
        PolicyInstanceDO policyInstanceDO = policyInstanceMapper.selectById(instanceId);
        if(null == policyInstanceDO){
            return null;
        }

        PolicyRuleInstanceQueryParam param = new PolicyRuleInstanceQueryParam();
        param.setSize(1000);
        param.setInstanceId(instanceId);
        List<PolicyRuleInstanceDO> policyRuleInstanceDOS = policyRuleInstanceMapper.selectAll(param);

        PolicyInstance policyInstance = policyInstanceConvertor.doToModel(policyInstanceDO);
        policyInstance.setIncentiveRuleList(policyInstanceConvertor.doToPolicyRuleInstance(policyRuleInstanceDOS));

        return policyInstance;
    }

    @Override
    public List<PolicyInstance> listByTemplate(Long templateId, String incentivePlanType) {
        PolicyInstanceQueryParam param = new PolicyInstanceQueryParam();
        param.setTemplateId(templateId);
        param.setIncentivePlanType(incentivePlanType);
        param.setStatusList(Lists.newArrayList(PolicyInstanceStatusEnum.WAITING_EFFECT.getCode(), PolicyInstanceStatusEnum.EFFECT.getCode()));
        param.setSize(5000);
        List<PolicyInstanceDO> policyInstanceDOS = policyInstanceMapper.selectAll(param);
        List<PolicyInstance> policyInstances = policyInstanceConvertor.doToModelList(policyInstanceDOS);
        if(CollectionUtils.isEmpty(policyInstances)){
            return policyInstances;
        }

        // 查询规则实例
        PolicyRuleInstanceQueryParam ruleParam = new PolicyRuleInstanceQueryParam();
        ruleParam.setTemplateId(templateId);
        ruleParam.setIncentivePlanType(incentivePlanType);
        ruleParam.setStatusList(Lists.newArrayList(PolicyInstanceStatusEnum.WAITING_EFFECT.getCode(), PolicyInstanceStatusEnum.EFFECT.getCode()));
        ruleParam.setSize(50000);
        List<PolicyRuleInstanceDO> policyRuleInstanceDOS = policyRuleInstanceMapper.selectAll(ruleParam);
        Map<Long, List<PolicyRuleInstanceDO>> policyRuleInstanceDOMap = policyRuleInstanceDOS.stream().collect(Collectors.groupingBy(PolicyRuleInstanceDO::getInstanceId));

        policyInstances.forEach(pi -> {
            pi.setIncentiveRuleList(policyInstanceConvertor.doToPolicyRuleInstance(policyRuleInstanceDOMap.get(pi.getId())));
        });

        return policyInstances;
    }

    @Override
    @Transactional(rollbackFor = Throwable.class)
    public Long create(PolicyInstance policyInstance) {
        PolicyInstanceDO policyInstanceDO = policyInstanceConvertor.doToModel(policyInstance);
        String approvalFollowId = MapUtils.getObject(policyInstance.getFeatureMap(), PolicyFeatureConstants.APPROVAL_FOLLOW_ID);
        if(StringUtils.isNotBlank(approvalFollowId)){
            policyInstanceDO.setApprovalFollowId(Long.valueOf(approvalFollowId));
        }
        // 保存政策实例
        policyInstanceMapper.insert(policyInstanceDO);

        List<PolicyRuleInstanceDO> policyRuleInstanceDOS = policyInstanceConvertor.doToPolicyRuleInstanceDO(policyInstance, policyInstanceDO.getId());
        // 保存政策规则实例
        policyRuleInstanceMapper.batchInsert(policyRuleInstanceDOS);

        return policyInstanceDO.getId();
    }

    @Override
    @Transactional(rollbackFor = Throwable.class)
    public void updateStatus(PolicyInstance policyInstance) {
        PolicyInstanceDO policyInstanceDO = policyInstanceConvertor.doToModel(policyInstance);
        // 更新实例表
        policyInstanceMapper.update(policyInstanceDO);

        // 更新规则实例表
        policyRuleInstanceMapper.updateRuleStatusByInstance(policyInstanceDO);

    }

    @Override
    @Transactional(rollbackFor = Throwable.class)
    public void updateBasic(PolicyInstance policyInstance) {
        PolicyInstanceDO policyInstanceDO = policyInstanceConvertor.doToModel(policyInstance);
        String approvalFollowId = MapUtils.getObject(policyInstance.getFeatureMap(), PolicyFeatureConstants.APPROVAL_FOLLOW_ID);
        if(StringUtils.isNotBlank(approvalFollowId)){
            policyInstanceDO.setApprovalFollowId(Long.valueOf(approvalFollowId));
        }
        policyInstanceMapper.update(policyInstanceDO);
    }


    @Override
    public Page<PolicyInstance> queryPolicyInstanceList(com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyInstanceQueryParam queryParam) {
        PolicyInstanceQueryParam param = buildPagePolicyInstanceQueryParam(queryParam);
        PageResult<PolicyInstanceDO> selectPage = policyInstanceMapper.selectPage(param);
        List<PolicyInstance> policyInstances = policyInstanceConvertor.doToModelList(Safes.of(selectPage.getData()));
        return CnPage.of(queryParam.getPageIndex(), queryParam.getPageSize(), policyInstances, selectPage.getTotal());
    }

    private PolicyInstanceQueryParam buildPagePolicyInstanceQueryParam(com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyInstanceQueryParam queryParam){
        PolicyInstanceQueryParam param = new PolicyInstanceQueryParam();
        param.setPage(queryParam.getPageIndex());
        param.setSize(queryParam.getPageSize());
        param.setBizStatus(queryParam.getApprovalStatus());
        param.setStatus(queryParam.getStatus());
        param.setTemplateId(queryParam.getTemplateId());
        if (MapUtils.isEmpty(queryParam.getOrderFieldNameMap())) {
            // 默认按照 修改时间 倒序
            param.addOrderBy(PolicyInstanceSortEnum.GMT_MODIFIED, false);
            return param;
        }
        for (Entry<String, Boolean> orderEntry : queryParam.getOrderFieldNameMap().entrySet()) {
            PolicyInstanceSortEnum sortEnum = PolicyInstanceSortEnum.getByFieldName(orderEntry.getKey());
            if (sortEnum == null){
                continue;
            }
            param.addOrderBy(sortEnum, orderEntry.getValue());
        }
        return param;
    }
}
