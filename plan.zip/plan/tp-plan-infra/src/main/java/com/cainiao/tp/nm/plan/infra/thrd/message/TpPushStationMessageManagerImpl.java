package com.cainiao.tp.nm.plan.infra.thrd.message;

import com.alibaba.fastjson.JSONObject;
import com.cainiao.aladdin.env.SystemEnvUtil;
import com.cainiao.aladdin.operation.SystemBizOperation;
import com.cainiao.aladdin.reslut.Result;
import com.cainiao.aladdin.utils.DateUtil;
import com.cainiao.aladdin.validate.utils.ValidateUtil;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.NewStaPerformSubsidyPopConfigDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.NewStaPerformNextLadderDTO;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyConfigManager;
import com.cainiao.tp.nm.plan.infra.port.policy.TpPushStationMessageManager;
import com.cainiao.tps.channel.common.constants.common.SourceOrderTypeEnum;
import com.cainiao.tps.channel.common.constants.message.OperationTypeEnum;
import com.cainiao.tps.channel.common.constants.plan.ReceiverTypeEnum;
import com.cainiao.tps.channel.common.domain.message.ContentTemplateDTO;
import com.cainiao.tps.channel.common.domain.message.OperationTypeStyleDTO;
import com.cainiao.tps.channel.common.domain.message.TpMessageContentDTO;
import com.cainiao.tps.channel.common.domain.message.TpMessageDTO;
import com.cainiao.tps.channel.request.TpMessageCreateRequest;
import com.cainiao.tps.channel.service.TpMessageService;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Map;


/**
 * 给站点发消息
 *
 * @date 2021/8/10
 */
@Slf4j
@Component
public class TpPushStationMessageManagerImpl implements TpPushStationMessageManager {

    @Resource
    private TpMessageService tpMessageService;
    @Resource
    private PolicyConfigManager policyConfigManager;

    /**
     * 给驿站掌柜下发新站实操激励活动
     * @return
     */
    @Override
    public void sendNewStaPerformSubsidyPopup(Long stationId) {
        SystemBizOperation opInfo = new SystemBizOperation(0L, "tp-nm-plan", "给驿站掌柜发送消息");

        NewStaPerformSubsidyPopConfigDTO popConfig = policyConfigManager.getNewStaPerformSubsidyPopConfig();
        if (popConfig == null || !Boolean.TRUE.equals(popConfig.getCanSendPop())) {
            return;
        }


        TpMessageCreateRequest createRequest = new TpMessageCreateRequest();
        TpMessageContentDTO contentDTO = new TpMessageContentDTO();
        contentDTO.setTitle(popConfig.getTitle());
        contentDTO.setContent(popConfig.getContent());

        OperationTypeStyleDTO typeStyleDTO = new OperationTypeStyleDTO();
        typeStyleDTO.setOperationType(OperationTypeEnum.CUSTOMIZE_BUTTON.getCode());
        typeStyleDTO.setName("去查看");
        typeStyleDTO.setJumpUrl(popConfig.getGoToUrl());
        contentDTO.setOperationTypeStyleList(Lists.newArrayList(typeStyleDTO));

        contentDTO.setLinkTitle("去查看");
        contentDTO.setLinkUrl(popConfig.getGoToUrl());
        contentDTO.setImageUrl(popConfig.getImageUrl());
        createRequest.setContentDTO(contentDTO);

        String orderDuplicateCode = "newStaPerformSubsidy_" + stationId
                + "_" + (SystemEnvUtil.isOnline() ? DateUtil.getDate2yymmddStr(new Date()) : System.currentTimeMillis());
        createRequest.setReceiverId(String.valueOf(stationId));
        createRequest.setBizDomain(0);
        createRequest.setOrderDuplicateCode(orderDuplicateCode);
        createRequest.setSourceOrderType(SourceOrderTypeEnum.CHANNEL_DEFAULT.getCode());
        createRequest.setSourceOrderCode(popConfig.getSourceCode());

        Result<List<TpMessageDTO>> result = tpMessageService.standardCreateMessage(createRequest, opInfo);
        ValidateUtil.validateResultSuccessAndThrow(result, "给驿站掌柜发送消息失败");
    }

    /**
     * 给驿站掌柜发送实操激励提醒弹窗通知
     * 使用指定模板编码和通知文案，通过驿站掌柜弹窗浮层渠道发送
     */
    @Override
    public void sendIncentiveRemindPopup(Long stationId, String notifyContent, String jumpUrl, String noticeSchemeCode) {
        SystemBizOperation opInfo = new SystemBizOperation(0L, "tp-nm-plan", "发送实操激励提醒弹窗通知");

        TpMessageCreateRequest createRequest = new TpMessageCreateRequest();
        TpMessageContentDTO contentDTO = new TpMessageContentDTO();
        contentDTO.setContent(notifyContent);

        OperationTypeStyleDTO typeStyleDTO = new OperationTypeStyleDTO();
        typeStyleDTO.setOperationType(OperationTypeEnum.CUSTOMIZE_BUTTON.getCode());
        typeStyleDTO.setName("查看详情");
        typeStyleDTO.setJumpUrl(jumpUrl);
        contentDTO.setOperationTypeStyleList(Lists.newArrayList(typeStyleDTO));
        contentDTO.setLinkTitle("查看详情");
        contentDTO.setLinkUrl(jumpUrl);
        createRequest.setContentDTO(contentDTO);

        // 防重发码：模板编码 + 站点ID + 日期，保证同一站点同一模板同一天不重复发送
        String orderDuplicateCode = noticeSchemeCode + "_" + stationId
                + "_" + (SystemEnvUtil.isOnline() ? DateUtil.getDate2yymmddStr(new Date()) : System.currentTimeMillis());
        createRequest.setReceiverType(ReceiverTypeEnum.STATION_TYPE.getCode());
        createRequest.setReceiverId(String.valueOf(stationId));
        createRequest.setOrderDuplicateCode(orderDuplicateCode);
        createRequest.setSourceOrderType(SourceOrderTypeEnum.CHANNEL_DEFAULT.getCode());
        createRequest.setSourceOrderCode(noticeSchemeCode);

        Result<List<TpMessageDTO>> result = tpMessageService.standardCreateMessage(createRequest, opInfo);
        log.info("sendIncentiveRemindPopup request={} result={}", JSONObject.toJSONString(createRequest), JSONObject.toJSONString(result));
        ValidateUtil.validateResultSuccessAndThrow(result, "发送实操激励提醒弹窗通知失败");
    }

    @Override
    public void sendNewStaPerformSubsidySatisfyPopup(Long stationId, NewStaPerformNextLadderDTO nextLadderDTO, String jumpUrl) {
        SystemBizOperation opInfo = new SystemBizOperation(0L, "tp-nm-plan", "给驿站掌柜发送消息");
        TpMessageCreateRequest createRequest = new TpMessageCreateRequest();
        TpMessageContentDTO contentDTO = new TpMessageContentDTO();

        OperationTypeStyleDTO typeStyleDTO = new OperationTypeStyleDTO();
        typeStyleDTO.setOperationType(OperationTypeEnum.CUSTOMIZE_BUTTON.getCode());
        typeStyleDTO.setName("查看活动进度");
        typeStyleDTO.setJumpUrl(jumpUrl);
        contentDTO.setOperationTypeStyleList(Lists.newArrayList(typeStyleDTO));
        contentDTO.setLinkTitle("查看活动进度");
        contentDTO.setLinkUrl(jumpUrl);
        createRequest.setContentDTO(contentDTO);

        String orderDuplicateCode = "newStaPerformSubsidySatisfy_" + stationId
                + "_" + (SystemEnvUtil.isOnline() ? DateUtil.getDate2yymmddStr(new Date()) : System.currentTimeMillis());
        createRequest.setReceiverId(String.valueOf(stationId));
        createRequest.setBizDomain(0);
        createRequest.setOrderDuplicateCode(orderDuplicateCode);
        createRequest.setSourceOrderType(SourceOrderTypeEnum.CHANNEL_DEFAULT.getCode());

        if(Boolean.TRUE.equals(nextLadderDTO.getIsTop())){
            createRequest.setSourceOrderCode("CDZC_kBJWrfbY0cxI");
        }else{
            createRequest.setSourceOrderCode("CDZC_k4seA6PgkQD5");
            ContentTemplateDTO templateDTO = new ContentTemplateDTO();
            Map<String, String> payloads = Maps.newHashMap();
            payloads.put("nextSubOrder", String.valueOf(nextLadderDTO.getNextSubOrder()));
            if(null != nextLadderDTO.getNextSubsidy()){
                payloads.put("nextSubsidy", String.valueOf(nextLadderDTO.getNextSubsidy().intValue()));
            }
            templateDTO.setPayloads(payloads);
            contentDTO.setContentTemplateDTO(templateDTO);
        }

        Result<List<TpMessageDTO>> result = tpMessageService.standardCreateMessage(createRequest, opInfo);
        ValidateUtil.validateResultSuccessAndThrow(result, "给驿站掌柜发送消息失败");
    }
}
