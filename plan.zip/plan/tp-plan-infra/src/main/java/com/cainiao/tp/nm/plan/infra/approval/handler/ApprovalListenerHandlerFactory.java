package com.cainiao.tp.nm.plan.infra.approval.handler;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Component;

/**
 * @Date 2025/6/24 19:04
 */
@Component
public class ApprovalListenerHandlerFactory {

    private final Map<String, ApprovalListenerHandler<?>> approvalHandlerMap = new ConcurrentHashMap<>();

    /**
     * 注册审批处理器
     * @param approvalHandler 审批处理器
     */
    public void register(ApprovalListenerHandler<?> approvalHandler) {
        approvalHandlerMap.put(approvalHandler.getHandlerDefineKey(), approvalHandler);
    }

    /**
     * 获取审批处理器
     * @param type 类型
     * @param processDefinitionKey 流程定义key
     * @param tag tag
     * @return 审批处理器
     */
    public ApprovalListenerHandler<?> getListenerHandler(String type, String tag,String processDefinitionKey) {
        String handlerDefineKey = buildHandlerDefineKey(type, tag, processDefinitionKey);
        return approvalHandlerMap.get(handlerDefineKey);
    }

    /**
     * 构建处理器定义key
     * @param type 类型
     * @param processDefinitionKey 流程定义key
     * @param tag tag
     * @return 处理器定义key
     */
    private String buildHandlerDefineKey(String type, String tag,String processDefinitionKey) {
        return type + "_"  + tag + "_" + processDefinitionKey;
    }
}
