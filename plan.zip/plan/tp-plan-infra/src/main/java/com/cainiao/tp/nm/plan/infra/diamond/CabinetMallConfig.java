package com.cainiao.tp.nm.plan.infra.diamond;

import com.alibaba.boot.diamond.annotation.DiamondListener;
import com.cainiao.aladdin.diamond.AladdinBootJsonDiamondListener;
import com.cainiao.tp.nm.plan.api.purchase.adaptor.dto.CabinetMallConfigDTO;

/**
 * 柜机商城 Diamond 配置监听
 * <p>
 * 对应源仓库 cnt-iot-tickets 的 CabinetMallConfig，迁移后采用 tp-nm-plan 标准范式
 * （{@code @DiamondListener} + {@code AladdinBootJsonDiamondListener}）。
 * </p> */
@DiamondListener(dataId = "com.cainiao.tp.nm.plan.purchase.cabinet.mall.config", executeAfterInit = true)
public class CabinetMallConfig extends AladdinBootJsonDiamondListener<CabinetMallConfigDTO> {


    @Override
    public void setInstance(CabinetMallConfigDTO config) {
        CabinetMallConfigDTO.setINSTANCE(config);
    }

    @Override
    public Class<CabinetMallConfigDTO> getClazz() {
        return CabinetMallConfigDTO.class;
    }

}
