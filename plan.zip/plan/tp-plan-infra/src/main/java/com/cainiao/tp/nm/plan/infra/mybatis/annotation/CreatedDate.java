package com.cainiao.tp.nm.plan.infra.mybatis.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 自动审计注解支持，创建时间字段，标记该注解的字段，记录生成时会自动通过数据库时间戳填充，并且在update时会忽略 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD) // 只能在字段上使用
public @interface CreatedDate {
}