package com.cainiao.tp.nm.plan.infra.common.constants;

import com.cainiao.aladdin.domain.AladdinOSearchApp;

/**
 * OpenSearch 应用实例枚举
 *
 * @date 2026-03-27
 */
public enum OSearchAppEnum implements AladdinOSearchApp {

    /**
     * 站点绩效财务联合表（含入驻时间、激励考核等信息）
     */
    TP_STA_PERFORM_FINANCE_JOIN("tp_sta_perform_finance_join"),
    ;

    private final String appName;

    OSearchAppEnum(String appName) {
        this.appName = appName;
    }

    @Override
    public String getAppName() {
        return appName;
    }
}
