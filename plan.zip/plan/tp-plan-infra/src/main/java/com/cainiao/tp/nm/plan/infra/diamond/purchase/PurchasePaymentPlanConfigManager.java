package com.cainiao.tp.nm.plan.infra.diamond.purchase;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.cainiao.tp.nm.plan.infra.diamond.DiamondConfigure;
import com.cainiao.tp.nm.plan.infra.repository.purchase.dto.data.PurchasePaymentPlanDO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * 支付方案 Diamond 配置管理
 * <p>
 * 通过 Diamond 动态下发支付方案列表，替代数据库查询。
 * dataId: com.cainiao.tp.nm.plan.purchase.payment.plan.config
 * 格式: JSON 数组，每个元素字段同 {@link PurchasePaymentPlanDO}（id, payCode, payName, paymentMode, paymentConfig）
 * </p> */
@Slf4j
@Component
public class PurchasePaymentPlanConfigManager implements DiamondConfigure {

    private volatile List<PurchasePaymentPlanDO> paymentPlanList = Collections.emptyList();

    private volatile Map<Long, PurchasePaymentPlanDO> paymentPlanMap = Collections.emptyMap();

    /**
     * 根据 id 查询支付方案
     */
    public PurchasePaymentPlanDO getById(Long id) {
        if (id == null) {
            return null;
        }
        return paymentPlanMap.get(id);
    }

    /**
     * 根据 id 列表批量查询支付方案
     */
    public List<PurchasePaymentPlanDO> listByIds(List<Long> ids) {
        if (CollectionUtils.isEmpty(ids)) {
            return new ArrayList<>();
        }
        return ids.stream()
                .map(paymentPlanMap::get)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }

    @Override
    public void load(String text) {
        List<PurchasePaymentPlanDO> list = JSON.parseObject(text,
                new TypeReference<List<PurchasePaymentPlanDO>>() {});
        if (list == null) {
            list = Collections.emptyList();
        }
        this.paymentPlanList = list;
        this.paymentPlanMap = list.stream()
                .filter(plan -> plan.getId() != null)
                .collect(Collectors.toMap(PurchasePaymentPlanDO::getId, Function.identity(), (a, b) -> b));
        log.info("PurchasePaymentPlanConfigManager loaded, size={}", list.size());
    }

    @Override
    public String getGroupId() {
        return "DEFAULT_GROUP";
    }

    @Override
    public String getDataId() {
        return "com.cainiao.tp.nm.plan.purchase.payment.plan.config";
    }
}
