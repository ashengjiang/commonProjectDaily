package com.cainiao.tp.nm.plan.infra.mybatis.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 翻页查询结果 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PageResult<T> {
    /**
     * 去除翻页条件的结果总数
     */
    private Long total;
    /**
     * 当前页码，从1开始的正整数
     */
    private Integer page;
    /**
     * 每页大小，从0开始的正整数
     */
    private Integer size;
    /**
     * 翻页结果数据
     */
    private List<T> data;
}
