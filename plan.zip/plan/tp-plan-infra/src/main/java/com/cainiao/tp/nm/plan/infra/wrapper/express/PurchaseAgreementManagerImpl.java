package com.cainiao.tp.nm.plan.infra.wrapper.express;

import com.alibaba.cainiao.express.outlets.contract.result.ServiceOpenRelationDTO;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyEntitySignContractDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyEntitySignContractParam;
import com.cainiao.tp.nm.plan.api.policy.common.constants.ExpressTypeEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyEntityAttrEnum;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.AgreementInfoDTO;
import com.cainiao.tp.nm.plan.infra.port.dto.ExpressCodeDTO;
import com.cainiao.tp.nm.plan.infra.port.dto.param.ExpressAgreementParam;
import com.cainiao.tp.nm.plan.infra.port.purchase.PurchaseAgreementManager;
import com.cainiao.tp.nm.plan.infra.port.utils.ExpressUtils;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * 购买协议查询端口占位实现
 * <p>
 * 下游能力（网点协议中心）尚未在本仓库接入，本实现明确抛出
 * {@link UnsupportedOperationException}，便于后续按
 * {@code .aone_copilot/rules/柜子代码迁移方案.md} 中的迁移步骤替换为真实实现，
 * 避免被静默桩化埋雷。
 * </p> */
@Slf4j
@Component
public class PurchaseAgreementManagerImpl implements PurchaseAgreementManager {

    @Resource
    private ServiceProductServiceWrapper serviceProductServiceWrapper;

    @Override
    public boolean queryPurchaseAgreement(ExpressAgreementParam pram) {
        ExpressCodeDTO expressCode = ExpressUtils.unpack(pram.getExpressCode());
        List<ServiceOpenRelationDTO> serviceOpenRelationDTOS = serviceProductServiceWrapper.queryJvExtendServices(expressCode.getCpCode(), expressCode.getExpressCode(), ExpressTypeEnum.EXPRESS.getCode(), Lists.newArrayList(pram.getAgreementCode()));
        return CollectionUtils.isNotEmpty(serviceOpenRelationDTOS);
    }


}
