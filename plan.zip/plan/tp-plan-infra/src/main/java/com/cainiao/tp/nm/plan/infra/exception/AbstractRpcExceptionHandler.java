package com.cainiao.tp.nm.plan.infra.exception;

import com.alibaba.fastjson.JSON;
import com.cainiao.sutee.commons.base.result.CnResult;
import com.cainiao.tp.nm.plan.infra.port.common.constants.ErrorCode;
import com.cainiao.tp.nm.plan.infra.port.common.exception.ServiceException;
import org.aspectj.lang.ProceedingJoinPoint;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 * RPC异常处理模版类，子类继承该类以便于实现全局RPC异常拦截处理能力 */
public abstract class AbstractRpcExceptionHandler {

    private final Map<Class<?>, Logger> loggerMap = new ConcurrentHashMap<>();

    protected Object around(ProceedingJoinPoint proceedingJoinPoint) {
        Logger logger = getLogger(proceedingJoinPoint.getTarget().getClass());
        try {
            return proceedingJoinPoint.proceed();
        } catch (MethodArgumentNotValidException | ConstraintViolationException e) {
            // 参数校验异常
            Map<String, Object> errorMap = resolveErrorInfo(e);
            String errorJsonString = JSON.toJSONString(errorMap);
            logger.warn("{}:{} method={},param={}", ErrorCode.ILLEGAL_PARAM, errorJsonString, getMethodName(
                proceedingJoinPoint), getParamsJsonString(proceedingJoinPoint), e);
            return CnResult.fail(ErrorCode.ILLEGAL_PARAM.getCode(),
                ErrorCode.ILLEGAL_PARAM.getMessage() + ":" + errorJsonString);
        } catch (ServiceException se) {
            // 业务逻辑校验异常
            logger.warn("AbstractRpcExceptionHandler caught: method={},param={}", getMethodName(proceedingJoinPoint),
                getParamsJsonString(proceedingJoinPoint), se);
            return CnResult.fail(se);
        } catch (Throwable t) {
            // 兜底其它异常情况
            logger.error("AbstractRpcExceptionHandler caught: method={},param={}", getMethodName(proceedingJoinPoint),
                getParamsJsonString(proceedingJoinPoint), t);
            return CnResult.fail(CnResult.SYSTEM_ERROR.getCode(), t.getMessage());
        }
    }

    private Map<String, Object> resolveErrorInfo(Exception ex) {
        if (ex instanceof MethodArgumentNotValidException) {
            return resolveErrorInfo((MethodArgumentNotValidException)ex);
        } else if (ex instanceof ConstraintViolationException) {
            return resolveErrorInfo((ConstraintViolationException)ex);
        } /*else if (ex instanceof FastValidatorException) {
            return resolveErrorInfo((FastValidatorException)ex);
        }*/
        return new HashMap<>();
    }

    static Map<String, Object> resolveErrorInfo(MethodArgumentNotValidException ex) {
        BindingResult bindingResult = ex.getBindingResult();

        return bindingResult.getFieldErrors().stream().collect(
            Collectors.toMap(FieldError::getField, e -> Optional.ofNullable(e.getDefaultMessage()).orElse(""),
                (k1, k2) -> k1));
    }

    static Map<String, Object> resolveErrorInfo(ConstraintViolationException ex) {
        return ex.getConstraintViolations().stream().collect(Collectors.toMap(
            e -> e.getPropertyPath().toString(), ConstraintViolation::getMessage, (k1, k2) -> k1));

    }

   /* static Map<String, Object> resolveErrorInfo(FastValidatorException ex) {
        String code = ex.getCode();
        String message = ex.getMessage();
        Map<String, Object> map = Maps.newHashMap();
        map.put(code, message);
        return map;

    }*/

    private String getParamsJsonString(ProceedingJoinPoint proceedingJoinPoint) {
        return JSON.toJSONString(proceedingJoinPoint.getArgs());
    }

    private String getMethodName(ProceedingJoinPoint proceedingJoinPoint) {
        return proceedingJoinPoint.getSignature().getName();
    }

    private Logger getLogger(Class<?> targetClass) {
        Logger result = loggerMap.get(targetClass);
        if (result == null) {
            result = LoggerFactory.getLogger(targetClass);
            loggerMap.put(targetClass, result);
        }
        return result;
    }

}
