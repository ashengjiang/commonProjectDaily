package com.cainiao.tp.nm.plan.infra.util;
import com.alibaba.cainiao.stationplatform.client.domain.ClientInfo;
import com.alibaba.cainiao.stationplatform.client.domain.StationAuthUserDTO;
import com.alibaba.cainiao.stationplatform.client.domain.StationResultDTO;
import com.alibaba.cainiao.stationplatform.client.service.client.StationAuthUserReadServiceClient;
import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.cnmember.client.session.CnSessionWirelessReadClient;
import com.cainiao.member.common.CnMemberResult;
import com.taobao.eagleeye.EagleEye;
import com.taobao.mtop.api.agent.MtopContext;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import java.util.List;
import java.util.Map;
import java.util.Objects;
/**
 * @code date 2025年08月01日 09:40
 * @code desc:null
 */
@Slf4j
public class MTOPSessionUtil {
    public static StationAuthUserDTO getStationAuthUserDTO(StationAuthUserReadServiceClient stationAuthUserReadServiceClient, CnSessionWirelessReadClient cnSessionWirelessReadClient, ClientInfo clientInfo) {
        String loginChannel = MtopContext.getHeader("loginChannel");
        String loginType = MtopContext.getHeader("loginType");
        Map<String, Object> sessionAttributes = MtopContext.getSessionAttributes();
//        log.info("MTOPSessionUtil.getStationAuthUserDTO, sessionAttributes={}", JSONObject.toJSONString(sessionAttributes));
        String sessionType = String.valueOf(sessionAttributes.get("sessionType"));
        StationAuthUserDTO authUserDTO = null;
        if ("1".equals(loginChannel) && "cainiao".equals(sessionType)) {
            // 获取菜鸟账号ID。可能为空
            Long cnAccountId = null;
            // 登录后用户主动选择的员工身份。可能为空
            Long employeeId = null;
            if (sessionAttributes != null) {
                if (sessionAttributes.containsKey("cnAccountId")) {
                    cnAccountId = (Long) sessionAttributes.get("cnAccountId");
                }
                if (sessionAttributes.containsKey("employeeId")) {
                    employeeId = (Long) sessionAttributes.get("employeeId");
                }
            }
            if (Objects.isNull(cnAccountId)) {
                throw new AladdinBizException("员工id获取失败", "菜鸟登录态失效，需要重新登录");
            }
            //判断登录类型
            if (null == employeeId) {
                //企业ID需要根据AccountId来，正常情况下，企业的accountId只有一个信息
                StationResultDTO<List<StationAuthUserDTO>> stationAuthUserListDTO = stationAuthUserReadServiceClient.queryAuthUserByCnUserAccountId(cnAccountId, clientInfo);
                if (!stationAuthUserListDTO.isSuccess()) {
                    throw new AladdinBizException("查询用户站点失败", "服务异常，请稍后再试");
                }
                if (CollectionUtils.isEmpty(stationAuthUserListDTO.getData())) {
                    throw new AladdinBizException("用户站点为空", "非驿站员工，请重新登录");
                }
                authUserDTO = stationAuthUserListDTO.getData().get(0);
            } else {
                //菜鸟员工ID
                StationResultDTO<StationAuthUserDTO> authUserResultDTO = stationAuthUserReadServiceClient.queryAuthUserByCnEmpId(employeeId, clientInfo);
                if (!authUserResultDTO.isSuccess()) {
                    throw new AladdinBizException("查询用户站点失败", "服务异常，请稍后再试");
                }
                authUserDTO = authUserResultDTO.getData();
            }
        } else {
            if ("2".equals(loginType)) {
                //集团登录态-菜鸟账号登录
                String caiNiaoSessionId = MtopContext.getHeader("caiNiaoSessionId");
                String caiNiaoEmployeeId = MtopContext.getHeader("caiNiaoEmployeeId");
                String caiNiaoAccountId = MtopContext.getHeader("caiNiaoAccountId");
                String caiNiaoAppKey = MtopContext.getAppKey();
                authUserDTO = getStationAuthUserDTO(caiNiaoSessionId, caiNiaoEmployeeId, caiNiaoAccountId, caiNiaoAppKey, stationAuthUserReadServiceClient, cnSessionWirelessReadClient, clientInfo);
            } else {
                //集团登录态-淘宝账号登录进来
                long userId = MtopContext.getUserId();
                if (userId <= 0) {
                    log.error("MTOPSessionUtil:getStationAuthUserDTO meet exception: tranceId:{}, loginChannel:{}, loginType:{}, ttid:{}, errorCase:FAIL_BIZ_USER_NEED_LOGIN.", EagleEye.getTraceId(), loginChannel, loginType, MtopContext.getTtid());
                    throw new AladdinBizException("FAIL_BIZ_USER_NEED_LOGIN", "淘宝登录态失效，需要重新登录");
                } else {
                    StationResultDTO<StationAuthUserDTO> authUserResultDTO = stationAuthUserReadServiceClient.queryAuthUserByUserId(userId, clientInfo);
                    if (!authUserResultDTO.isSuccess()) {
                        log.error("MTOPSessionUtil:getStationAuthUserDTO meet exception: tranceId:{}, loginChannel:{}, loginType:{}, ttid:{}, errorCase:FAIL_BIZ_QUERY_AUTH_USER_EXCEPTION.", EagleEye.getTraceId(), loginChannel, loginType, MtopContext.getTtid());
                        throw new AladdinBizException("FAIL_BIZ_QUERY_AUTH_USER_EXCEPTION", "服务异常，请稍后再试");
                    }
                    authUserDTO = authUserResultDTO.getData();
                }
            }
        }
        if (authUserDTO == null) {
            log.error("MTOPSessionUtil:getStationAuthUserDTO meet exception: tranceId:{}, loginChannel:{}, loginType:{}, ttid:{}, errorCase:FAIL_BIZ_AUTH_USER_NOT_FOUND.", EagleEye.getTraceId(), loginChannel, loginType, MtopContext.getTtid());
            throw new AladdinBizException("FAIL_BIZ_AUTH_USER_NOT_FOUND", "非驿站员工，请重新登录");
        }
        return authUserDTO;
    }
    private static StationAuthUserDTO getStationAuthUserDTO(String caiNiaoSessionId, String caiNiaoEmployeeId, String caiNiaoAccountId, String caiNiaoAppKey, StationAuthUserReadServiceClient stationAuthUserReadServiceClient, CnSessionWirelessReadClient cnSessionWirelessReadClient, ClientInfo clientInfo) {
        if (StringUtils.isBlank(caiNiaoSessionId) || StringUtils.isBlank(caiNiaoAccountId) || StringUtils.isBlank(caiNiaoEmployeeId) || StringUtils.isBlank(caiNiaoAppKey)) {
            log.error("MTOPSessionUtil:private_getStationAuthUserDTO meet exception: tranceId:{}, caiNiaoSessionId:{}, caiNiaoEmployeeId:{}, caiNiaoAccountId:{}, caiNiaoAppKey:{}, errorCase:FAIL_BIZ_USER_NEED_LOGIN.", EagleEye.getTraceId(), caiNiaoSessionId, caiNiaoEmployeeId, caiNiaoAccountId, caiNiaoAppKey);
            throw new AladdinBizException("FAIL_BIZ_USER_NEED_LOGIN", "参数错误需要重新登录");
        }
        CnMemberResult<Void> checkSessionResult = cnSessionWirelessReadClient.checkSession(caiNiaoSessionId, Long.valueOf(caiNiaoEmployeeId), caiNiaoAppKey);
        if (!checkSessionResult.isSuccess()) {
            log.error("MTOPSessionUtil:private_getStationAuthUserDTO meet exception: tranceId:{}, caiNiaoSessionId:{}, caiNiaoEmployeeId:{}, caiNiaoAccountId:{}, caiNiaoAppKey:{}, errorCase:FAIL_BIZ_USER_NEED_LOGIN.", EagleEye.getTraceId(), caiNiaoSessionId, caiNiaoEmployeeId, caiNiaoAccountId, caiNiaoAppKey);
            throw new AladdinBizException("FAIL_BIZ_USER_NEED_LOGIN", "菜鸟登录态鉴权失败");
        }
        StationResultDTO<StationAuthUserDTO> authUserResultDTO = stationAuthUserReadServiceClient.queryAuthUserByCnEmpId(Long.valueOf(caiNiaoEmployeeId), clientInfo);
        if (!authUserResultDTO.isSuccess()) {
            log.error("MTOPSessionUtil:private_getStationAuthUserDTO meet exception: tranceId:{}, caiNiaoSessionId:{}, caiNiaoEmployeeId:{}, caiNiaoAccountId:{}, caiNiaoAppKey:{}, errorCase:FAIL_BIZ_QUERY_EMPLOYEE_EXCEPTION.", EagleEye.getTraceId(), caiNiaoSessionId, caiNiaoEmployeeId, caiNiaoAccountId, caiNiaoAppKey);
            throw new AladdinBizException("FAIL_BIZ_QUERY_EMPLOYEE_EXCEPTION", "系统繁忙，请稍后再试");
        }
        StationAuthUserDTO authUserDTO = authUserResultDTO.getData();
        if (authUserDTO == null) {
            log.error("MTOPSessionUtil:private_getStationAuthUserDTO meet exception: tranceId:{}, caiNiaoSessionId:{}, caiNiaoEmployeeId:{}, caiNiaoAccountId:{}, caiNiaoAppKey:{}, errorCase:FAIL_BIZ_AUTH_USER_NOT_FOUND.", EagleEye.getTraceId(), caiNiaoSessionId, caiNiaoEmployeeId, caiNiaoAccountId, caiNiaoAppKey);
            throw new AladdinBizException("FAIL_BIZ_AUTH_USER_NOT_FOUND", "非驿站员工，请重新登录");
        }
        return authUserDTO;
    }

}