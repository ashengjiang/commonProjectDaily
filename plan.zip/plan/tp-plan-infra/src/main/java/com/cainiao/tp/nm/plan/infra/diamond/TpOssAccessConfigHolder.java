package com.cainiao.tp.nm.plan.infra.diamond;


import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
public class TpOssAccessConfigHolder {

    @Getter
    @Setter
    private  static TpOssAccessConfigHolder INSTANCE = new TpOssAccessConfigHolder();

    private String accessId;

    private String accessKey;


}
