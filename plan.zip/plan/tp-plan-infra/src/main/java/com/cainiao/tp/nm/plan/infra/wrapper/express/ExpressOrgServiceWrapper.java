package com.cainiao.tp.nm.plan.infra.wrapper.express;

import com.alibaba.cainiao.express.outlets.api.result.ResultModel;
import com.alibaba.cainiao.express.outlets.base.api.result.org.EmployeeOrgDTO;
import com.alibaba.cainiao.express.outlets.base.api.result.org.OrgDTO;
import com.alibaba.cainiao.express.outlets.base.api.service.org.ExpressOrgService;
import com.alibaba.cainiao.express.outlets.contract.enums.CloverOrgWhiteListStatusEnum;
import com.alibaba.cainiao.express.outlets.contract.result.CloverOrgWhiteListDTO;
import com.alibaba.cainiao.express.outlets.contract.service.CloverOrgWhiteListService;
import com.alibaba.fastjson.JSON;
import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.aladdin.utils.Safes;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.cnmember.client.organization.CnDepartmentReadClient;
import com.cainiao.cnmember.client.permission.DataPermissionReadClient;
import com.cainiao.cnmember.employee.enums.CnEmployeeDutyTypeEnum;
import com.cainiao.member.common.CnMemberResult;
import com.cainiao.pms.enums.DataPermTypeEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.CpCodeEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.OrgTypeEnum;
import com.google.common.collect.Lists;
import com.taobao.aeap.service.client.domain.CnDepartmentDTO;
import com.taobao.aeap.service.client.enums.CnOrgTypeEnum;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

@Slf4j
@Component
public class ExpressOrgServiceWrapper {


    private static final Integer xnAppOrgTypeName = OrgTypeEnum.JV.getTypeCode();
    @Resource
    private ExpressOrgService expressOrgService;
    @Resource
    private CloverOrgWhiteListService cloverOrgWhiteListService;
    @Resource
    private DataPermissionReadClient dataPermissionReadClient;
    @Resource
    private CnDepartmentReadClient cnDepartmentReadClient;


    public List<EmployeeOrgDTO> queryEmployeeOrgByAccountId(Long accountId) {
        ResultModel<List<EmployeeOrgDTO>> listResultModel = expressOrgService.queryAllDutyEmployeeOrgsByAccountId(accountId);
        AssertUtil.isTrue(listResultModel.isSuccess(), "查询员工信息失败，accountId = " + accountId);
        return listResultModel.getData();
    }

    /**
     * 查询城市网点和溪鸟融合组织列表
     */
    public List<EmployeeOrgDTO> queryCombineOrgList(Long accountId) {
        List<EmployeeOrgDTO> employeeOrgDTOList = queryEmployeeOrgByAccountId(accountId);
        List<EmployeeOrgDTO> destOrgList = Safes.of(employeeOrgDTOList).stream()
                .filter(e -> Objects.nonNull(e) && Objects.nonNull(e.getOrgType()))
                .filter(e -> isValidExpress(e.getCpCode(), e.getOrgCode(), e.getOrgType(), e.getDutyType(), e.getFullOrgCode()))
                .peek(e -> {
                    e.setOrgType(OrgTypeEnum.WANGDIAN.getTypeCode());
                    e.setCpName(CpCodeEnum.resolveName(e.getCpCode()));
                }).collect(Collectors.toList());
        EmployeeOrgDTO xnEmployeeOrg = Safes.of(employeeOrgDTOList).stream().filter(d -> CpCodeEnum.XINIAO.getCode().equals(d.getCpCode())).findFirst().orElse(null);
        if (Objects.nonNull(xnEmployeeOrg)) {
            List<OrgDTO> orgDTOList = queryDataPermissionOrgList(xnEmployeeOrg.getEmployeeId());
            List<EmployeeOrgDTO> xnEmployeeOrgList = Safes.of(orgDTOList).stream()
                    .filter(orgDTO -> xnAppOrgTypeName.equals(orgDTO.getType()))
                    .map(orgDTO -> {
                        EmployeeOrgDTO employeeOrgDTO = new EmployeeOrgDTO();
                        employeeOrgDTO.setCpCode(xnEmployeeOrg.getCpCode());
                        employeeOrgDTO.setOrgCode(orgDTO.getOrgCode());
                        employeeOrgDTO.setOrgName(orgDTO.getName());
                        employeeOrgDTO.setCpName(CpCodeEnum.resolveName(xnEmployeeOrg.getCpCode()));
                        employeeOrgDTO.setOrgType(orgDTO.getType());
                        employeeOrgDTO.setEmployeeId(xnEmployeeOrg.getEmployeeId());
                        employeeOrgDTO.setAccountId(xnEmployeeOrg.getAccountId());
                        employeeOrgDTO.setName(xnEmployeeOrg.getName());
                        employeeOrgDTO.setDutyType(xnEmployeeOrg.getDutyType());
                        employeeOrgDTO.setDutyTypeDesc(xnEmployeeOrg.getDutyTypeDesc());
                        return employeeOrgDTO;
                    }).collect(Collectors.toList());
            destOrgList.addAll(xnEmployeeOrgList);
        }
        return destOrgList;
    }

    /**
     * 查询员工组织数据权限对应的部门列表
     */
    public List<OrgDTO> queryDataPermissionOrgList(Long employeeId) {
        CnMemberResult<List<Long>> dataPermissionResult = dataPermissionReadClient.getUserDataPermissionByUserId(employeeId, DataPermTypeEnum.OrgDataPermType.getTypeValue());
        AssertUtil.isTrue(dataPermissionResult.isSuccess(), "组织数据权限查询失败，employeeId = " + employeeId);
        List<Long> deptIdList = dataPermissionResult.getData();
        if (CollectionUtils.isEmpty(deptIdList)) {
            return Lists.newArrayList();
        }
        List<CnDepartmentDTO> deptAllList = queryDataPermissionListByEmployeeId(employeeId);
        return Safes.of(deptAllList).stream().map(d -> {
            OrgDTO orgDTO = new OrgDTO();
            BeanUtils.copyProperties(d, orgDTO);
            return orgDTO;
        }).collect(Collectors.toList());
    }

    /**
     * 查询员工组织数据权限对应的部门列表
     */
    public List<CnDepartmentDTO> queryDataPermissionListByEmployeeId(Long employeeId) {
        CnMemberResult<List<Long>> dataPermissionResult = dataPermissionReadClient.getUserDataPermissionByUserId(employeeId, DataPermTypeEnum.OrgDataPermType.getTypeValue());
        AssertUtil.isTrue(dataPermissionResult.isSuccess(), "组织数据权限查询失败，employeeId = " + employeeId);
        List<Long> deptIdList = dataPermissionResult.getData();
        if (CollectionUtils.isEmpty(deptIdList)) {
            return Lists.newArrayList();
        }
        return Lists.partition(deptIdList, 100)
                .stream()
                .map(list -> {
                    CnMemberResult<List<CnDepartmentDTO>> deptResult = cnDepartmentReadClient.queryDepartmentsByIdList(list);
                    AssertUtil.isTrue(deptResult.isSuccess(), "组织数据权限查询失败，employeeId = " + employeeId);
                    return deptResult.getData();
                })
                .flatMap(List::stream)
                .collect(Collectors.toList());
    }



    /**
     * 判断组织是否为溪鸟组织或城市网点，如果是城市网点，还需要判断网点/白名单承包区，同时岗位在开放的岗位列表中
     */
    private boolean isValidExpress(String cpCode, String orgCode, Integer orgType, Integer duty,
                                   String fullOrgCode) {
        //先判断组织类型是不是网点
        if (Objects.isNull(orgCode) || orgType == null || orgType <= 0) {
            return false;
        }
        if (CnOrgTypeEnum.BRANCH.getType() == orgType
            // || CnOrgTypeEnum.CONTRACT_AREA.getType() == orgType
        ) {
            return true;
        }
        //如果不是网点，判断组织类型是不是白名单承包区
        ResultModel<CloverOrgWhiteListDTO> whiteListResult = cloverOrgWhiteListService.queryValidOrg(cpCode, orgCode);
        if (!whiteListResult.isSuccess()) {
            throw new AladdinBizException("cloverOrgWhiteListService.queryValidOrg", "查询组织类型异常，请稍后重试");
        }
        CloverOrgWhiteListDTO org = whiteListResult.getData();
        return org != null && CloverOrgWhiteListStatusEnum.VALID.getValue().equals(org.getStatus());
    }


    public EmployeeOrgDTO parseExpressEmployeeOrgDTO(Long employeeId) {
        EmployeeOrgDTO employeeOrgDTO = null;
        if (employeeId != null) {
            // 获取组织信息
            ResultModel<EmployeeOrgDTO> getEmployeeOrgDTO = expressOrgService.queryEmployeeOrgByEmployeeId(employeeId);
            if (!getEmployeeOrgDTO.isSuccess()) {
                throw new AladdinBizException("expressOrgService.queryEmployeeOrgByEmployeeId", "查询员工"+employeeId+"信息失败");
            }
            employeeOrgDTO = getEmployeeOrgDTO.getData();
        }
        if (employeeOrgDTO != null) {
            return employeeOrgDTO;
        } else {
            return null;
        }
    }


}
