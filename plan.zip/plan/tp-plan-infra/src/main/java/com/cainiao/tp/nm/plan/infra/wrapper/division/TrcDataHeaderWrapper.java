package com.cainiao.tp.nm.plan.infra.wrapper.division;

import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.aladdin.reslut.Result;
import com.cainiao.tp.pangu.basic.client.domain.dto.TpDataAllDetailDTO;
import com.cainiao.tp.pangu.basic.client.domain.request.DataTreeDetailRequest;
import com.cainiao.tp.pangu.basic.client.service.TpsDataHeaderService;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;


@Component
public class TrcDataHeaderWrapper {
    @Resource
    private TpsDataHeaderService tpsDataHeaderService;

    /**
     * 获取用户行政区划权限
     *
     * @param employeeId 员工id
     * @param dataValue  数据值 STREET#+站点cityCode
     * @param dataType   数据类型 CITY_TYPE = "MERGE_DISTRICT";
     * @return TpDataAllDetailDTO
     */
    public TpDataAllDetailDTO getAllMultiDivision(Long employeeId, String dataValue, String dataType) {
        DataTreeDetailRequest request = new DataTreeDetailRequest();
        request.setDataHeaderType(dataType);
        request.setDataValue(dataValue);
        request.setEmployeeId(employeeId);
        Result<TpDataAllDetailDTO> result = tpsDataHeaderService.getDataAllDetail(request);
        if (!result.isSuccess()) {
            throw new AladdinBizException("盘古权限查询失败", result.getErrorMsg());
        }
        return result.getData();
    }

}

