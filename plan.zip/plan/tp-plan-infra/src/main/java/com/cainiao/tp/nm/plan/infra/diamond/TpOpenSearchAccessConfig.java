package com.cainiao.tp.nm.plan.infra.diamond;

import com.alibaba.boot.diamond.annotation.DiamondListener;
import com.cainiao.aladdin.diamond.AladdinBootDiamondListener;

@DiamondListener(dataId = "com.cainiao.tp.nm.plan.infra.diamond.TpOpenSearchAccessConfig", executeAfterInit = true)
public class TpOpenSearchAccessConfig extends AladdinBootDiamondListener {


    @Override
    public Object getInstance() {
        return TpOpenSearchAccessConfigHolder.getINSTANCE();
    }
}
