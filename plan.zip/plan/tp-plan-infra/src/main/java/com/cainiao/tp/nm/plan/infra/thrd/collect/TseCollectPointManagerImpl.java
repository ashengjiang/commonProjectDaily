package com.cainiao.tp.nm.plan.infra.thrd.collect;

import com.cainiao.aladdin.operation.SystemBizOperation;
import com.cainiao.aladdin.reslut.Result;
import com.cainiao.aladdin.validate.utils.ValidateUtil;
import com.cainiao.tp.nm.plan.infra.port.collect.CollectPointInfoDTO;
import com.cainiao.tp.nm.plan.infra.port.collect.TseCollectPointManager;
import com.cainiao.tp.scale.expand.client.collect.dto.CollectPointMainDTO;
import com.cainiao.tp.scale.expand.client.collect.service.application.CollectPointMainApplicationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Component
@Slf4j
public class TseCollectPointManagerImpl implements TseCollectPointManager {

    @Resource
    private CollectPointMainApplicationService collectPointMainApplicationService;

    @Override
    public CollectPointInfoDTO queryCollectInfo(String collectPointId) {
        Result<CollectPointMainDTO> result = collectPointMainApplicationService.detailCollectInfo(collectPointId, new SystemBizOperation(0L, "tp-nm-plan"));
        ValidateUtil.validateResultSuccessAndThrow(result, "查询代收点信息失败");
        CollectPointMainDTO data = result.getData();
        if(null == data){
            return null;
        }

        CollectPointInfoDTO collectPointInfoDTO = new CollectPointInfoDTO();
        collectPointInfoDTO.setPointId(data.getPointId());
        collectPointInfoDTO.setName(data.getName());
        collectPointInfoDTO.setSource(data.getSource());
        collectPointInfoDTO.setPointBrandCodes(data.getPointBrandCodes());
        collectPointInfoDTO.setStatus(data.getStatus());
        collectPointInfoDTO.setBizStatus(data.getBizStatus());
        collectPointInfoDTO.setAddress(data.getAddress());
        collectPointInfoDTO.setProvinceCode(data.getProvinceCode());
        collectPointInfoDTO.setCityCode(data.getCityCode());
        collectPointInfoDTO.setDistrictCode(data.getDistrictCode());
        collectPointInfoDTO.setTownCode(data.getTownCode());
        collectPointInfoDTO.setLng(data.getLng());
        collectPointInfoDTO.setLat(data.getLat());
        collectPointInfoDTO.setFeatureMap(data.getFeatureMap());
        return collectPointInfoDTO;
    }
}
