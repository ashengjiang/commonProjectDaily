package com.cainiao.tp.nm.plan.infra.oss.config;

import com.aliyun.oss.OSS;
import com.cainiao.aladdin.utils.CNStationOSSUtils;
import com.cainiao.tp.nm.plan.infra.diamond.TpOssAccessConfigHolder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OssConfig {

    @Bean
    public OSS ossClient() {
        TpOssAccessConfigHolder instance = TpOssAccessConfigHolder.getINSTANCE();
        CNStationOSSUtils.config(instance.getAccessId(), instance.getAccessKey(), "http://oss-cn-hangzhou.aliyuncs.com");
        return CNStationOSSUtils.getOssClient();
    }
}
