package com.cainiao.tp.nm.plan.infra.thrd.station;

import com.cainiao.aladdin.domain.BaseQueryDTO;
import com.cainiao.aladdin.domain.QueryCustomizable;
import com.cainiao.aladdin.domain.condition.CustomCondition;
import com.cainiao.aladdin.opensearch.OSearchIgnore;
import com.google.common.collect.Lists;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * 站点绩效财务联合表 OpenSearch 查询 DTO
 * 对应 OpenSearch 实例：tp_sta_perform_finance_join
 *
 * @date 2026-03-27
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class StaPerformFinanceOSearchQuery extends BaseQueryDTO implements QueryCustomizable {

    /**
     * 自定义查询条件（如范围过滤），由 addCustomCondition 方法维护
     */
    @OSearchIgnore
    private List<CustomCondition> customConditionList;

    public void addCustomCondition(CustomCondition customCondition) {
        if (null == this.customConditionList) {
            this.customConditionList = Lists.newArrayList();
        }
        this.customConditionList.add(customCondition);
    }

    @Override
    public String getOrderByField() {
        return "station_id";
    }

    @Override
    public boolean isDesc() {
        return false;
    }
}
