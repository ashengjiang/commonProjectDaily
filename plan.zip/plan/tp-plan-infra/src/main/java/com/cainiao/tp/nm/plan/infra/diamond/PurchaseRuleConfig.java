package com.cainiao.tp.nm.plan.infra.diamond;

import com.alibaba.boot.diamond.annotation.DiamondListener;
import com.alibaba.boot.diamond.listener.DiamondDataCallback;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseRule;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicReference;

/**
 * 订购规则 Diamond 配置
 * DataId：com.cainiao.tp.nm.plan.purchase.rule，Group：DEFAULT_GROUP
 * 配置格式为 JSON 数组，每个元素包含 productId、categoryId、skuId、customerConfig、agreementConfig、paymentPlanConfig、deliveryTypeList、startTime、endTime、feature */
@Slf4j
@Component
@DiamondListener(dataId = "com.cainiao.tp.nm.plan.purchase.rule", executeAfterInit = true)
public class PurchaseRuleConfig implements DiamondDataCallback {

    /**
     * 当前生效的订购规则列表，使用 AtomicReference 保证并发安全
     */
    private final AtomicReference<List<PurchaseRule>> ruleListRef =
            new AtomicReference<>(Collections.emptyList());

    /**
     * 按类目 ID 索引的规则缓存，key=categoryId, value=List<PurchaseRule>
     */
    private final AtomicReference<Map<Integer, List<PurchaseRule>>> ruleByCategoryMapRef =
            new AtomicReference<>(new ConcurrentHashMap<>());

    /**
     * Diamond 配置变更回调，解析 JSON 数组并更新规则列表
     *
     * @param data Diamond 推送的配置文本
     */
    @Override
    public void received(String data) {
        try {
            List<PurchaseRule> ruleList = JSON.parseObject(
                    data, new TypeReference<List<PurchaseRule>>() {});
            if (CollectionUtils.isEmpty(ruleList)) {
                log.warn("PurchaseRuleConfig 解析结果为空，清空规则列表，data={}", data);
                ruleListRef.set(Collections.emptyList());
                ruleByCategoryMapRef.set(new ConcurrentHashMap<>());
                return;
            }
            ruleListRef.set(ruleList);
            
            // 构建按类目 ID 索引的缓存
            Map<Integer, List<PurchaseRule>> ruleByCategoryMap = new ConcurrentHashMap<>();
            for (PurchaseRule rule : ruleList) {
                if (rule.getCategoryId() != null) {
                    ruleByCategoryMap.computeIfAbsent(rule.getCategoryId(), k -> new java.util.ArrayList<>()).add(rule);
                }
            }
            ruleByCategoryMapRef.set(ruleByCategoryMap);
            
            log.info("PurchaseRuleConfig 加载成功，规则数量={}", ruleList.size());
        } catch (Exception e) {
            log.error("PurchaseRuleConfig 解析失败，清空规则列表，data={}", data, e);
            ruleListRef.set(Collections.emptyList());
            ruleByCategoryMapRef.set(new ConcurrentHashMap<>());
        }
    }

    /**
     * 获取所有订购规则
     *
     * @return 订购规则列表，若未配置则返回空列表
     */
    public List<PurchaseRule> getAllRules() {
        return ruleListRef.get();
    }

    /**
     * 根据类目 ID 获取订购规则列表
     *
     * @param categoryId 类目 ID
     * @return 订购规则列表，若未配置则返回空列表
     */
    public List<PurchaseRule> getRulesByCategoryId(Integer categoryId) {
        Map<Integer, List<PurchaseRule>> map = ruleByCategoryMapRef.get();
        return map.getOrDefault(categoryId, Collections.emptyList());
    }
}
