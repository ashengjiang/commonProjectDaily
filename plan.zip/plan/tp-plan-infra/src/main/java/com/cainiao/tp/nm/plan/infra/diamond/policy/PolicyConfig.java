package com.cainiao.tp.nm.plan.infra.diamond.policy;

import com.cainiao.tp.nm.plan.api.policy.application.dto.config.NewStaPerformSubsidyConfigDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.NewStaPerformSubsidyPopConfigDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.PolicyApproveConfigDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.PolicyIncentivePlanConfigDTO;
import com.google.common.collect.Lists;
import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class PolicyConfig {

    /**
     * 激励方案配置
     */
    private List<PolicyIncentivePlanConfigDTO> policyIncentiveConfigList = Lists.newArrayList();

    /**
     * 政策审批配置
     */
    private List<PolicyApproveConfigDTO> approveConfigList = Lists.newArrayList();

    /**
     * 无权限提示
     */
    private String permissionDeniedPrompt;
    /**
     * 任务超期时间 (月)
     */
    private Integer taskOverDueMonths;

    /**
     * 生效时间
     */
    private String effectTime;

    /**
     * 是否开启配置生效时间
     */
    private Boolean enableConfigEffectTime;

    /**
     * 测试环节mock的站点列表影射
     */
    private Map<String, String> mockStaMappingMap;

    /**
     * 新站实操激励弹窗配置
     */
    private NewStaPerformSubsidyPopConfigDTO newStaPerformSubsidyPopConfig;

    /**
     * 新站实操激励活动配置
     */
    private NewStaPerformSubsidyConfigDTO newStaPerformSubsidyConfig;

}
