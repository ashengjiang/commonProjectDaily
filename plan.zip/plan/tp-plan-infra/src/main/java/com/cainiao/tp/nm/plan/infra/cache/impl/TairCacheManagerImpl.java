package com.cainiao.tp.nm.plan.infra.cache.impl;

import com.alibaba.fastjson.JSONObject;
import com.cainiao.tp.nm.plan.infra.port.policy.CacheManager;
import com.taobao.tair.DataEntry;
import com.taobao.tair.Result;
import com.taobao.tair.ResultCode;
import com.taobao.tair.TairManager;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import javax.annotation.Resource;

@Component
public class TairCacheManagerImpl implements CacheManager {

    /**
     * 默认namespace
     */
    public static final Integer DEFAULT_NAMESPACE = 5978;

    @Resource
    private TairManager tairManager;

    @Override
    public <T> T get(String key, Class<T> clazz) {
        if(StringUtils.isEmpty(key)) {
            return null;
        }
        Result<DataEntry> result = tairManager.get(DEFAULT_NAMESPACE, key);
        Assert.isTrue(result!=null && result.isSuccess(), "get tair cache error");
        if (null == result.getValue() || result.getValue().getValue() == null) {
            return null;
        }
        return JSONObject.parseObject(String.valueOf(result.getValue().getValue()), clazz);
    }

    @Override
    public String getString(String key) {
        if(StringUtils.isEmpty(key)) {
            return null;
        }
        Result<DataEntry> result = tairManager.get(DEFAULT_NAMESPACE, key);
        Assert.isTrue(result!=null && result.isSuccess(), "get tair cache error");
        if (null == result.getValue() || result.getValue().getValue() == null) {
            return null;
        }
        return result.getValue().getValue().toString();
    }

    @Override
    public <T> void set(String key, T value, int expire) {
        Assert.isTrue(value!=null, "value is null");
        String valueStr = JSONObject.toJSONString(value);
        ResultCode resultCode = tairManager.put(DEFAULT_NAMESPACE, key, valueStr, 0, expire);
        Assert.isTrue(resultCode.isSuccess(), "put cache error, msg=：" + JSONObject.toJSONString(resultCode));
    }

    @Override
    public void setStr(String key, String value, int expire) {
        Assert.isTrue(value!=null, "value is null");
        ResultCode resultCode = tairManager.put(DEFAULT_NAMESPACE, key, value, 0, expire);
        Assert.isTrue(resultCode.isSuccess(), "put cache error, msg=：" + JSONObject.toJSONString(resultCode));
    }
}
