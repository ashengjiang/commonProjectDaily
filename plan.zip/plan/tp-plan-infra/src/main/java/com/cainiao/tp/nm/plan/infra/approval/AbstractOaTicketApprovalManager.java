package com.cainiao.tp.nm.plan.infra.approval;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.aladdin.exception.AladdinParamException;
import com.cainiao.terminal.ticket.client.domain.request.FieldParam;
import com.cainiao.terminal.ticket.client.domain.request.TpSearchTicketReq;
import com.cainiao.terminal.ticket.client.domain.response.TicketMetaDataBaseSearchReq;
import com.cainiao.terminal.ticket.client.domain.response.TpTicketRep;
import com.cainiao.terminal.ticket.common.enums.TpTicketStatusEnum;
import com.cainiao.tp.nm.plan.api.policy.application.dto.TpTicketDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.TicketInstanceApprovalStartParam;
import com.cainiao.tp.nm.plan.infra.port.policy.EmployeeRightsLoadManager;
import com.cainiao.tp.nm.plan.infra.port.policy.TicketApprovalManager;
import com.cainiao.tp.nm.plan.infra.wrapper.org.TpTicketWrapper;
import com.cainiao.tp.nm.plan.infra.wrapper.org.param.TpStartTicketParam;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

/**
 * @Date 2025/6/18 20:18
 * @desc: OA工单审批流程端口
 */
@Component
public abstract class AbstractOaTicketApprovalManager implements TicketApprovalManager<TicketInstanceApprovalStartParam,TpTicketDTO> {

    @Resource
    private TpTicketWrapper tpTicketWrapper;

    @Resource
    private EmployeeRightsLoadManager employeeRightsLoadManager;

    private static final String OPERATOR_TYPE = "cainiaobuc";

    @Override
    public String startApproval(TicketInstanceApprovalStartParam startParam){
        String cnUserId = employeeRightsLoadManager.getCnUserId(startParam.getLastOperatorId());
        TpStartTicketParam tpStartTicketParam = new TpStartTicketParam();
        tpStartTicketParam.setProcessDefKey(getProcessDefKey(startParam));
        tpStartTicketParam.setIdempotentId(getIdempotentId(startParam));
        tpStartTicketParam.setStartOperatorId(cnUserId);
        tpStartTicketParam.setStartOperatorType(OPERATOR_TYPE);
        tpStartTicketParam.setContext(startParam.getContext());
        return tpTicketWrapper.startTicket(tpStartTicketParam);
    }

    @Override
    public TpTicketDTO queryTicketById(Long ticketId) {
        try {
            TpTicketRep tpTicketRep = tpTicketWrapper.queryTicketById(ticketId);
            if (tpTicketRep == null){
                throw new AladdinParamException("工单不存在,ticketId=" + ticketId);
            }
            TpTicketDTO tpTicketDTO = new TpTicketDTO();
            BeanUtils.copyProperties(tpTicketRep,tpTicketDTO);
            return tpTicketDTO;
        }catch (Exception e){
            throw new AladdinBizException("queryTicketById error,ticketId=" + ticketId,e);
        }
    }

    @Override
    public void updateTicket(Long ticketId, Map<String, Object> context) {
        tpTicketWrapper.updateTicket(ticketId,context);
    }

    @Override
    public void timeOutPush(Long taskId, String action) {
        tpTicketWrapper.timeOutPush(taskId,action);
    }

    @Override
    public void cancelProcessInstance(String processInstanceId, String cancelReason) {
        tpTicketWrapper.terminateProcessInstance(processInstanceId, cancelReason);
    }


    @Override
    public String getInstanceIdByContextKey(String definitionKey, String contextUniqueId) {
        TicketMetaDataBaseSearchReq searchReq = new TicketMetaDataBaseSearchReq();
        // 设置 contextKey为幂等id
        searchReq.addSearchParam(getContextKey(), FieldParam.Operator.EQUAL,contextUniqueId);
        TpSearchTicketReq searchTicketReq = new TpSearchTicketReq();
        searchTicketReq.setProcessDefKey(definitionKey);
        searchTicketReq.setSearchReq(searchReq);
        searchTicketReq.setPageSize(1);
        searchTicketReq.setPageIndex(1);
        searchTicketReq.setTicketStatusList(Collections.singletonList(TpTicketStatusEnum.START_STATUS.getCode()));

        List<TpTicketRep> listPageResult = tpTicketWrapper.searchTicket(searchTicketReq);
        if (CollectionUtils.isEmpty(listPageResult) || listPageResult.get(0) == null) {
            return null;
        }
        return listPageResult.get(0).getProcessInstanceId();
    }

    /**
     * 获取上下文key
     * @return 上下文key
     */
    public abstract String getContextKey();
    /**
     * 获取流程定义key
     * @param startParam 开启参数
     * @return 流程定义key
     */
    public abstract String getProcessDefKey(TicketInstanceApprovalStartParam startParam);

}
