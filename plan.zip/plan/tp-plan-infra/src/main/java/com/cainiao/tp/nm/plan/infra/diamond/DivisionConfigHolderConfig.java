package com.cainiao.tp.nm.plan.infra.diamond;

import com.alibaba.boot.diamond.annotation.DiamondListener;
import com.cainiao.aladdin.diamond.AladdinBootDiamondListener;
import com.cainiao.tp.nm.plan.api.policy.application.dto.DivisionConfigHolder;

@DiamondListener(dataId = "com.cainiao.tp.nm.plan.infra.diamond.DivisionConfigHolderConfig", executeAfterInit = true)
public class DivisionConfigHolderConfig extends AladdinBootDiamondListener {

    @Override
    public Object getInstance() {
        return DivisionConfigHolder.getINSTANCE();
    }
}
