package com.cainiao.tp.nm.plan.infra.thrd.express;

import com.cainiao.tp.nm.plan.infra.port.dto.context.ExpressPermissionContext;

public interface ExpressPermissionCheckHandler  {


    String getSource();

    ExpressPermissionContext checkPermission(ExpressPermissionContext context);

}
