package com.cainiao.tp.nm.plan.infra.diamond;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.annotation.PostConstruct;

import com.taobao.diamond.client.Diamond;
import com.taobao.diamond.manager.ManagerListenerAdapter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * 基于diamond的配置管理器接口 */
@Component
@Slf4j
public class DiamondConfigureManager implements ConfigureManager<DiamondConfigure> {

    @Autowired(required = false)
    private final Map<String, DiamondConfigure> configureMap = new HashMap<>();

    @Override
    public Set<DiamondConfigure> getAllConfigure() {
        return new HashSet<>(configureMap.values());
    }

    @Override
    public DiamondConfigure getConfigure(String key) {
        return configureMap.values().stream()
            .filter(diamondConfigure -> key.equals(diamondConfigure.getGroupId() + ":" + diamondConfigure.getDataId()))
            .findFirst()
            .orElse(null);

    }

    @PostConstruct
    public void init() {
        this.getAllConfigure().stream()
            .filter(diamondConfigure -> StringUtils.isNotBlank(diamondConfigure.getDataId()) && StringUtils.isNotBlank(
                diamondConfigure.getGroupId()))
            .forEach(
                diamondConfigure -> Diamond.addListener(diamondConfigure.getDataId(), diamondConfigure.getGroupId(),
                    new ManagerListenerAdapter() {
                        @Override
                        public void receiveConfigInfo(String configInfo) {
                            //推空保护
                            if (configInfo == null) {
                                log.warn("diamond config is null, dataId:{}, groupId:{}",
                                    diamondConfigure.getDataId(), diamondConfigure.getGroupId());
                                return;
                            }
                            try {
                                diamondConfigure.load(configInfo);
                                log.info("diamond config load success, dataId:{}, groupId:{}, configInfo:{}",
                                    diamondConfigure.getDataId(), diamondConfigure.getGroupId(), configInfo);
                            } catch (Exception e) {
                                log.error("diamond config load error, dataId:{}, groupId:{}, configInfo:{}",
                                    diamondConfigure.getDataId(), diamondConfigure.getGroupId(), configInfo, e);
                            }
                        }
                    }));
    }
}

