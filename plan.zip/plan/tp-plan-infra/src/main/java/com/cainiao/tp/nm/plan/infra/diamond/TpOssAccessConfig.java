package com.cainiao.tp.nm.plan.infra.diamond;

import com.alibaba.boot.diamond.annotation.DiamondListener;
import com.cainiao.aladdin.diamond.AladdinBootDiamondListener;

@DiamondListener(dataId = "com.cainiao.tp.nm.plan.infra.diamond.TpOssAccessConfig", executeAfterInit = true)
public class TpOssAccessConfig extends AladdinBootDiamondListener {


    @Override
    public Object getInstance() {
        return TpOssAccessConfigHolder.getINSTANCE();
    }
}
