package com.cainiao.tp.nm.plan.infra.approval.handler;

import com.alibaba.rocketmq.common.message.MessageExt;

/**
 * @Date 2025/6/24 18:28
 */
public interface ApprovalListenerHandler<T> {

    /**
     * 处理事件
     * @param event 事件
     * @param message  消息
     */
    void doConsume(T event, MessageExt message);

    /**
     * 获取handler定义key
     * @return 定义key
     */
    String getHandlerDefineKey();
}
