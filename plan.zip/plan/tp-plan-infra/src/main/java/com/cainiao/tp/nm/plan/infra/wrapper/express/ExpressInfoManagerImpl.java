package com.cainiao.tp.nm.plan.infra.wrapper.express;

import com.alibaba.cainiao.express.outlets.api.result.ResultModel;
import com.alibaba.cainiao.express.outlets.api.result.express.ExpressDTO;
import com.alibaba.cainiao.express.outlets.api.service.express.ExpressService;
import com.cainiao.aladdin.exception.AladdinException;
import com.cainiao.tp.nm.plan.infra.port.manager.ExpressInfoManager;
import com.cainiao.tp.nm.plan.infra.port.dto.PlanExpressDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * 网点快递公司编码（cpCode）查询端口占位实现
 * <p>
 * 下游能力尚未在本仓库接入（需调用网点服务根据 expressId 反查 cpCode），
 * 本实现明确抛出 {@link UnsupportedOperationException}，便于后续按
 * {@code .aone_copilot/rules/柜子代码迁移方案.md} 中的迁移步骤替换为真实实现，
 * 避免被静默返回 null 埋雷。
 * </p> */
@Slf4j
@Component
public class ExpressInfoManagerImpl implements ExpressInfoManager {

    @Resource
    private ExpressService expressService;


    public PlanExpressDTO getExpressDTO(String cpCode, String orgCode) {
        ResultModel<ExpressDTO> rs = expressService.queryExpressByOrgCode(cpCode, orgCode);
        if (!rs.isSuccess()) {
            throw new AladdinException("expressService.queryExpressByOrgCode", "查询网点" + cpCode + "-" + orgCode + "信息失败");
        }
        if (rs.getData() == null) {
            return null;
        }
        ExpressDTO data = rs.getData();
        PlanExpressDTO planExpressDTO = new PlanExpressDTO();
        planExpressDTO.setExpressId(data.getExpressId());
        planExpressDTO.setExpressName(data.getExpressName());
        planExpressDTO.setCpCode(data.getCpCode());
        planExpressDTO.setCpName(data.getCpName());
        planExpressDTO.setOrgCode(data.getOrgCode());
        planExpressDTO.setProvinceCode(data.getProvinceCode());
        planExpressDTO.setCityCode(data.getCityCode());
        planExpressDTO.setAreaCode(data.getAreaCode());
        planExpressDTO.setTownCode(data.getTownCode());
        return planExpressDTO;
    }

}
