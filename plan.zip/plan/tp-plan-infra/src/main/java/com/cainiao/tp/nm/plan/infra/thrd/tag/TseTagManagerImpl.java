package com.cainiao.tp.nm.plan.infra.thrd.tag;

import com.cainiao.aladdin.operation.SystemBizOperation;
import com.cainiao.aladdin.reslut.Result;
import com.cainiao.aladdin.validate.utils.ValidateUtil;
import com.cainiao.tp.nm.plan.infra.port.tag.TseTagManager;
import com.cainiao.tp.scale.expand.client.tag.dto.TseTagDTO;
import com.cainiao.tp.scale.expand.client.tag.dto.TseTagDataDTO;
import com.cainiao.tp.scale.expand.client.tag.dto.param.TseTagQueryRequest;
import com.cainiao.tp.scale.expand.client.tag.enums.TseTagEntityTypeEnum;
import com.cainiao.tp.scale.expand.client.tag.service.application.TseTagApplicationService;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.stream.Collectors;

@Component
@Slf4j
public class TseTagManagerImpl implements TseTagManager {


    @Resource
    private TseTagApplicationService tseTagApplicationService;

    @Override
    public List<String> queryCollectTag(String collectPointId, List<String> tagCodeList) {
        TseTagQueryRequest queryRequest = new TseTagQueryRequest();
        queryRequest.setEntityType(TseTagEntityTypeEnum.COLLECT_POINT.getCode());
        queryRequest.setEntityId(collectPointId);
        queryRequest.setTagCodeList(tagCodeList);
        Result<TseTagDTO> tseTagResult = tseTagApplicationService.queryTag(queryRequest, new SystemBizOperation(0L, "tp-nm-plan"));
        ValidateUtil.validateResultSuccessAndThrow(tseTagResult, "查询标签库失败");
        if(null != tseTagResult.getData() && null != tseTagResult.getData().getTagDataList()) {
            return tseTagResult.getData().getTagDataList().stream().map(TseTagDataDTO::getCode).collect(Collectors.toList());
        }

        return Lists.newArrayList();
    }
}
