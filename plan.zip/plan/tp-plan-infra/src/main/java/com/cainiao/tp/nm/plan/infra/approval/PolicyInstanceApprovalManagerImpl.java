package com.cainiao.tp.nm.plan.infra.approval;

import java.util.List;

import javax.annotation.Resource;

import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.terminal.ticket.client.domain.response.TpTicketRep;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.PolicyApproveConfigDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.TicketInstanceApprovalStartParam;
import com.cainiao.tp.nm.plan.api.policy.common.constants.OAProcessContextConstants;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicySubmissionNodeEnum;
import com.cainiao.tp.nm.plan.infra.port.policy.EmployeeRightsLoadManager;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyConfigManager;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyInstanceRuleQueryManager;
import com.cainiao.tp.nm.plan.infra.wrapper.org.TpTicketWrapper;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @code date 2024年10月28日 17:04
 * @code desc: 政策实例仓储
 */
@Slf4j
@Component(value = "policyInstanceApprovalManagerImpl")
public class PolicyInstanceApprovalManagerImpl extends AbstractOaTicketApprovalManager {

    @Resource
    private TpTicketWrapper tpTicketWrapper;

    @Resource
    private PolicyConfigManager policyConfigManager;

    @Resource
    private EmployeeRightsLoadManager employeeRightsLoadManager;

    @Resource
    private PolicyInstanceRuleQueryManager instanceRuleReadQueryManger;

    /**
     * 幂等id前缀
     */
    private static final String IDEMPOTENT_ID_SUBFIX = "policy_instance_";


    @Override
    public String getProcessDefKey(TicketInstanceApprovalStartParam startParam) {
        PolicyApproveConfigDTO approveConfig = policyConfigManager.getApproveConfig(startParam.getBizType(), startParam.getCustomType());
        AssertUtil.isTrue(null != approveConfig && approveConfig.isInsatnceApprove(), "无需审批");
        return approveConfig.getInsatnceProcessCode();
    }

    @Override
    public String getIdempotentId(TicketInstanceApprovalStartParam startParam) {
        return IDEMPOTENT_ID_SUBFIX + startParam.getId();
    }

    @Override
    public String getContextKey() {
        return OAProcessContextConstants.IDEMPOTENT_ID;
    }
}
