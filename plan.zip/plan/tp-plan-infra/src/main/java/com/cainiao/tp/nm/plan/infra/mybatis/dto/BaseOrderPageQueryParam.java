package com.cainiao.tp.nm.plan.infra.mybatis.dto;

import java.util.ArrayList;
import java.util.List;

import com.cainiao.tp.nm.plan.infra.mybatis.annotation.OrderByParam;
import com.cainiao.tp.nm.plan.infra.mybatis.annotation.Transient;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 可排序和翻页的查询参数基础类，可直接继承该类实现即可排序又可翻页的查询参数 */
@EqualsAndHashCode(callSuper = true)
@Data
public abstract class BaseOrderPageQueryParam<T extends Enum<T>> extends BasePageQueryParam implements OrderQuery<T> {
    @Transient
    private static final long serialVersionUID = -2688584726261978358L;
    @OrderByParam
    private final List<OrderBy> orderByList = new ArrayList<>();

    @Override
    public void addOrderBy(T field, boolean asc) {
        orderByList.add(new OrderBy(field, asc));
    }
}
