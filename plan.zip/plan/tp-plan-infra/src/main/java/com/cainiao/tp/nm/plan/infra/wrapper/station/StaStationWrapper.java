package com.cainiao.tp.nm.plan.infra.wrapper.station;

import com.alibaba.cainiao.stationplatform.client.domain.StationResultDTO;
import com.alibaba.cainiao.stationplatform.client.domain.StationStationDTO;
import com.alibaba.cainiao.stationplatform.client.service.StationStationService;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import javax.annotation.Resource;

/**
 * @code date 2025年07月31日 16:48
 * @code desc:null
 */
@Component
public class StaStationWrapper {
    @Resource
    private StationStationService stationStationService;

    /**
     * 根据站点id查询站点
     * @param stationId 站点id
     * @return StationDTO
     */
    public StationStationDTO queryStationByStationId(Long stationId) {
        StationResultDTO<StationStationDTO> stationResult = stationStationService.queryStationByStationId(stationId);
        Assert.isTrue(stationResult.isSuccess(), stationResult.getErrorMessage());
        return stationResult.getData();
    }


    /**
     * 根据站点code查询站点
     * @param stationCode 站点id
     * @return StationDTO
     */
    public StationStationDTO queryStationByStationCode(String stationCode) {
        StationResultDTO<StationStationDTO> stationResult = stationStationService.queryStationByStationCode(stationCode);
        Assert.isTrue(stationResult.isSuccess(), stationResult.getErrorMessage());
        return stationResult.getData();
    }
}
