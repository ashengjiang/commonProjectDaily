package com.cainiao.tp.nm.plan.infra.wrapper.express;

import com.alibaba.cainiao.express.outlets.api.result.ResultModel;
import com.alibaba.cainiao.express.outlets.contract.result.ServiceProductDTO;
import com.alibaba.cainiao.express.outlets.contract.service.ServiceProductInfoService;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.ServiceProductInfoDTO;
import com.cainiao.tp.nm.plan.infra.port.purchase.ServiceProductInfoManager;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 服务产品信息查询端口实现
 * <p>
 * 通过 HSF 调用 {@link ServiceProductInfoService#queryServiceProductInfoByCode} 查询服务产品信息，
 * 并将三方 {@link ServiceProductDTO} 转换为 port 层自定义 {@link ServiceProductInfoDTO}。
 * </p> */
@Slf4j
@Component
public class ServiceProductInfoManagerImpl implements ServiceProductInfoManager {

    @Resource
    private ServiceProductInfoService serviceProductInfoService;

    @Override
    public ServiceProductInfoDTO queryServiceProductInfoByCode(String serviceCode) {
        log.info("queryServiceProductInfoByCode, serviceCode={}", serviceCode);
        ResultModel<ServiceProductDTO> result = serviceProductInfoService.queryServiceProductInfoByCode(serviceCode);
        if (!result.isSuccess()) {
            log.error("queryServiceProductInfoByCode 调用失败, serviceCode={}, errorMsg={}",
                    serviceCode, result.getErrorMsg());
            throw new RuntimeException("queryServiceProductInfoByCode 调用失败, errorMsg=" + result.getErrorMsg());
        }
        ServiceProductDTO data = result.getData();
        if (data == null) {
            return null;
        }
        return convertToServiceProductInfoDTO(data);
    }

    private ServiceProductInfoDTO convertToServiceProductInfoDTO(ServiceProductDTO source) {
        ServiceProductInfoDTO target = new ServiceProductInfoDTO();
        target.setId(source.getId());
        target.setStatus(source.getStatus());
        target.setServiceName(source.getServiceName());
        target.setServiceCode(source.getServiceCode());
        target.setServiceContent(source.getServiceContent());
        target.setMarkedPrice(source.getMarkedPrice());
        target.setActualPrice(source.getActualPrice());
        target.setSlogan(source.getSlogan());
        target.setFeature(source.getFeatrue());
        target.setBizDomain(source.getBizDomain());
        target.setProductType(source.getProductType());
        target.setDefPriceType(source.getDefPriceType());
        target.setBizType(source.getBizType());

        if (CollectionUtils.isNotEmpty(source.getProductVersionList())) {
            List<ServiceProductInfoDTO.ProductVersionDTO> versionList = source.getProductVersionList().stream()
                    .map(this::convertToProductVersionDTO)
                    .collect(Collectors.toList());
            target.setProductVersionList(versionList);
        }
        return target;
    }

    private ServiceProductInfoDTO.ProductVersionDTO convertToProductVersionDTO(
            ServiceProductDTO.ProductVersionDTO source) {
        ServiceProductInfoDTO.ProductVersionDTO target = new ServiceProductInfoDTO.ProductVersionDTO();
        target.setName(source.getName());
        target.setCode(source.getCode());
        target.setValid(source.getValid());
        target.setPrice(source.getPrice());
        return target;
    }
}
