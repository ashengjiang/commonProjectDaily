package com.cainiao.tp.nm.plan.infra.wrapper.division;

import com.alibaba.fastjson.JSON;
import com.cainiao.tp.nm.plan.api.policy.application.dto.DivisionDTO;
import com.cainiao.tp.nm.plan.infra.port.policy.CacheManager;
import com.cainiao.tp.nm.plan.infra.port.policy.DivisionManager;
import com.cainiao.tp.nm.plan.api.policy.application.dto.BaseDivisionInfoDTO;
import com.cainiao.tp.nm.plan.policy.common.util.PlanThreadPoolUtil;
import com.taobao.biz.common.division.newera.vo.DivisionVO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Slf4j
public class CnDivisionManagerImpl implements DivisionManager, InitializingBean {


    @Resource
    CacheManager cacheManager;
    @Resource
    TcsChinaDivisionManagerWrapper tcsChinaDivisionManagerWrapper;
    @Resource
    PlanThreadPoolUtil planThreadPoolUtil;
    private static final String DIVISION_LAT_LNG_CONFIG = "division-base-info.txt";
    private static final String TAIR_KEY = "plan:division:v2:";
    private static final int TAIR_EXPIRE = 60 * 60 * 24 * 90;
    private static final Long CHINA = 1L;
    /**
     * 保存省级信息
     */
    private static final List<BaseDivisionInfoDTO> PROVINCE_LIST = new ArrayList<>();


    @Override
    public List<BaseDivisionInfoDTO> getAllProvinceList() {
        if (PROVINCE_LIST.isEmpty()) {
            init();
        }
        List<BaseDivisionInfoDTO> collect = PROVINCE_LIST.stream().map(this::toNew).collect(Collectors.toList());
        collect.forEach(infoDTO -> infoDTO.setChildrenList(null));
        return collect;
    }

    /**
     * 获取省级信息
     *
     * @param provinceCode 省级信息
     * @return return
     */
    @Override
    public Optional<BaseDivisionInfoDTO> getProvinceByCode(Long provinceCode) {
        if (provinceCode == null) {
            return Optional.empty();
        }
        if (PROVINCE_LIST.isEmpty()) {
            init();
        }
        Optional<BaseDivisionInfoDTO> first = PROVINCE_LIST.stream().filter(baseDivisionInfoDTO -> provinceCode.equals(baseDivisionInfoDTO.getDivisionId())).findFirst();
        if (!first.isPresent()) {
            return Optional.empty();
        }
        BaseDivisionInfoDTO baseDivisionInfoDTO = first.get();
        List<BaseDivisionInfoDTO> childrenList = baseDivisionInfoDTO.getChildrenList();
        if (CollectionUtils.isEmpty(childrenList)) {
            loadingProvinceChildren(baseDivisionInfoDTO, false);
        }
        return Optional.of(toNew(baseDivisionInfoDTO));
    }

    @Override
    public String getDivisionNameByCode(Long divisionCode) {
        if (divisionCode == null) {
            return null;
        }
        DivisionVO divisionDetail = tcsChinaDivisionManagerWrapper.getDivisionDetail(divisionCode);
        if (divisionDetail != null) {
            return divisionDetail.getDivisionName();
        }
        return null;
    }

    @Override
    public DivisionDTO getDivisionChain(Long divisionCode) {
        if (divisionCode == null) {
            return null;
        }
        return tcsChinaDivisionManagerWrapper.getDivisionChain(divisionCode);
    }

    /**
     * 复制一份，注意使用的数据安全
     *
     * @param infoDTO info
     * @return return
     */
    private BaseDivisionInfoDTO toNew(BaseDivisionInfoDTO infoDTO) {
        return JSON.parseObject(JSON.toJSONString(infoDTO), BaseDivisionInfoDTO.class);
    }


    /**
     * 获取省级信息
     *
     * @param provinceName 省级信息
     * @return return
     */
    @Override
    public Optional<BaseDivisionInfoDTO> getProvinceByName(String provinceName) {
        if (StringUtils.isEmpty(provinceName)) {
            return Optional.empty();
        }

        if (PROVINCE_LIST.isEmpty()) {
            init();
        }
        Optional<BaseDivisionInfoDTO> first = PROVINCE_LIST.stream().filter(baseDivisionInfoDTO -> provinceName.equals(baseDivisionInfoDTO.getDivisionName())).findFirst();
        if (!first.isPresent()) {
            return Optional.empty();
        }
        BaseDivisionInfoDTO baseDivisionInfoDTO = first.get();
        List<BaseDivisionInfoDTO> childrenList = baseDivisionInfoDTO.getChildrenList();
        if (CollectionUtils.isEmpty(childrenList)) {
            loadingProvinceChildren(baseDivisionInfoDTO, false);
        }
        return Optional.of(toNew(baseDivisionInfoDTO));
    }


    public synchronized void init() {
        if (!PROVINCE_LIST.isEmpty()) {
            return;
        }
        List<DivisionVO> childDivision = tcsChinaDivisionManagerWrapper.getChildDivision(CHINA);
        //divisionId	divisionLevel   divisionName

        for (DivisionVO data : childDivision) {
            BaseDivisionInfoDTO baseDivisionInfoDTO = new BaseDivisionInfoDTO();
            baseDivisionInfoDTO.setDivisionId(data.getDivisionId());
            baseDivisionInfoDTO.setDivisionLevel(data.getDivisionLevel());
            baseDivisionInfoDTO.setDivisionName(data.getDivisionName());
            PROVINCE_LIST.add(baseDivisionInfoDTO);
        }
    }


    private void loadingProvinceChildren(BaseDivisionInfoDTO provinceInfo, boolean refresh) {
        if (provinceInfo == null) {
            return;
        }
        Long divisionId = provinceInfo.getDivisionId();
        String key = TAIR_KEY + divisionId;

        BaseDivisionInfoDTO baseDivisionInfoDTO = cacheManager.get(key, BaseDivisionInfoDTO.class);
        if (baseDivisionInfoDTO != null && !refresh) {
            List<BaseDivisionInfoDTO> childrenList = baseDivisionInfoDTO.getChildrenList();
            provinceInfo.setChildrenList(childrenList);
            return;
        }

        //刷新数据
        List<DivisionVO> childDivision = tcsChinaDivisionManagerWrapper.getChildDivision(divisionId);
        if (CollectionUtils.isEmpty(childDivision)) {
            return;
        }
        List<BaseDivisionInfoDTO> collect = childDivision.stream().map(this::convertBaseDivisionInfoDTO).collect(Collectors.toList());
        provinceInfo.setChildrenList(collect);
        for (BaseDivisionInfoDTO cityDTO : collect) {
            Long cityId = cityDTO.getDivisionId();
            List<DivisionVO> cityInfoList = tcsChinaDivisionManagerWrapper.getChildDivision(cityId);
            List<BaseDivisionInfoDTO> childList = cityInfoList.stream().map(this::convertBaseDivisionInfoDTO).collect(Collectors.toList());
            cityDTO.setChildrenList(childList);
        }
        cacheManager.set(key, provinceInfo, TAIR_EXPIRE);
    }


    private BaseDivisionInfoDTO convertBaseDivisionInfoDTO(DivisionVO divisionVO) {
        if (divisionVO == null) {
            return null;
        }
        BaseDivisionInfoDTO baseDivisionInfoDTO = new BaseDivisionInfoDTO();
        baseDivisionInfoDTO.setDivisionId(divisionVO.getDivisionId());
        baseDivisionInfoDTO.setDivisionName(divisionVO.getDivisionName());
        baseDivisionInfoDTO.setDivisionLevel(divisionVO.getDivisionLevel());
        return baseDivisionInfoDTO;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        init();
        planThreadPoolUtil.execute(() -> {
            //异步掉
            if (CollectionUtils.isNotEmpty(PROVINCE_LIST)) {
                PROVINCE_LIST.forEach(baseDivisionInfoDTO -> loadingProvinceChildren(baseDivisionInfoDTO, true));
            }
        });
    }
}
