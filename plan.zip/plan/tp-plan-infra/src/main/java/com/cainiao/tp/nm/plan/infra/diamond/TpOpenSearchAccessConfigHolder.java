package com.cainiao.tp.nm.plan.infra.diamond;


import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;

@Data
public class TpOpenSearchAccessConfigHolder {

    @Getter
    @Setter
    private  static TpOpenSearchAccessConfigHolder INSTANCE = new TpOpenSearchAccessConfigHolder();

    private String financeJoin_Host;

    private String financeJoin_ApiKey;

}
