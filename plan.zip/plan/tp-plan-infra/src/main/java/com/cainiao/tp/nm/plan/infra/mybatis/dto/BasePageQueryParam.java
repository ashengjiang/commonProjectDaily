package com.cainiao.tp.nm.plan.infra.mybatis.dto;

import java.io.Serializable;

import com.cainiao.tp.nm.plan.infra.mybatis.annotation.PageNumParam;
import com.cainiao.tp.nm.plan.infra.mybatis.annotation.PageSizeParam;
import com.cainiao.tp.nm.plan.infra.mybatis.annotation.Transient;
import lombok.Data;

/**
 * 翻页查询基础类，可直接继承该类以便于实现翻页查询参数 */
@Data
public abstract class BasePageQueryParam implements Serializable {

    @Transient
    private static final long serialVersionUID = -950720362731717850L;
    /**
     * 当前页码，从1开始的正整数
     */
    @PageNumParam
    private Integer page;
    /**
     * 每页大小，从0开始的正整数
     */
    @PageSizeParam
    private Integer size;

}
