package com.cainiao.tp.nm.plan.infra.wrapper.finance;

import com.cainiao.aladdin.utils.DateUtil;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.terminal.finance.quotation.client.quotation.dto.plan.template.QuotationTemplatePlanDTO;
import com.cainiao.terminal.finance.quotation.client.quotation.service.facade.QuotationTemplatePlanService;
import com.cainiao.terminal.finance.quotation.common.dto.Result;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Date;

/**
 * @Date 2025/6/3 16:34
 * @code desc: 结算费用项wrapper
 */
@Slf4j
@Component
public class QuotationTemplatePlanWrapper {

    @Resource
    private QuotationTemplatePlanService quotationTemplatePlanService;

    public QuotationTemplatePlanDTO getTreeStructure(String expenseItemCode, String startTimeStr, String endTimeStr) {
        Date startDate = DateUtil.getymdStr2SDate(startTimeStr);
        Date endDate = DateUtils.addDays(DateUtil.getymdStr2SDate(endTimeStr), 1);
        Result<QuotationTemplatePlanDTO> treeStructure = quotationTemplatePlanService.getTreeStructure(expenseItemCode, startDate, endDate);
        AssertUtil.isTrue(treeStructure.isSuccess, treeStructure.getErrorMessage());
        return treeStructure.getData();
    }
}
