package com.cainiao.tp.nm.plan.infra.thrd.station;

import com.alibaba.cainiao.stationplatform.client.domain.StationStationDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.StationDTO;
import com.cainiao.tp.nm.plan.infra.port.policy.StaStationReadManager;
import com.cainiao.tp.nm.plan.infra.wrapper.station.StaStationWrapper;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

import static com.cainiao.tp.nm.plan.infra.common.constants.CommonConstants.LIGHT_STATION_MODE_FLAG;

/**
 * @code date 2025年08月04日 15:11
 * @code desc:null
 */
@Component
public class StaStationReadManagerImpl implements StaStationReadManager {

    @Resource
    private StaStationWrapper staStationWrapper;

    @Override
    public StationDTO queryStationById(Long stationId) {
        if (stationId == null) {
            return null;
        }
        StationStationDTO stationStationDTO = staStationWrapper.queryStationByStationId(stationId);
        return convert(stationStationDTO);
    }

    @Override
    public StationDTO queryStationByCode(String stationCode) {
        if (stationCode == null) {
            return null;
        }
        StationStationDTO stationStationDTO = staStationWrapper.queryStationByStationCode(stationCode);
        return convert(stationStationDTO);
    }

    @Override
    public StationDTO queryStation(String stationId) {
        if (stationId == null) {
            return null;
        }
        if (stationId.startsWith(LIGHT_STATION_MODE_FLAG)) {
            return queryStationByCode(stationId);
        }
        return queryStationById(Long.valueOf(stationId));
    }

    private StationDTO convert(StationStationDTO stationStationDTO) {
        StationDTO stationDTO = new StationDTO();
        BeanUtils.copyProperties(stationStationDTO, stationDTO);
        return stationDTO;
    }
}
