package com.cainiao.tp.nm.plan.infra.util;

import com.alibaba.cainiao.express.outlets.base.api.result.org.EmployeeOrgDTO;
import com.cainiao.aladdin.env.SystemEnvUtil;
import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.aladdin.utils.Safes;
import com.cainiao.cnmember.employee.enums.CnEmployeeDutyTypeEnum;
import com.cainiao.express.outlets.common.enums.ErrorCodeEnum;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import java.util.List;

public class MtopAccessCheckUtil {

    /**
     * 角色 - 负责人
     */
    public static final int DUTY_TYPE_ADMIN = CnEmployeeDutyTypeEnum.ZHUGUAN.getDutyValue();

    /**
     * 角色 - 财务
     */
    public static final int DUTY_TYPE_CAIWU = CnEmployeeDutyTypeEnum.CAIWU.getDutyValue();

    /**
     * 角色 - 客服
     */
    public static final int DUTY_TYPE_KEFU = CnEmployeeDutyTypeEnum.KEFU.getDutyValue();

    /**
     * 角色 - 小件员
     */
    public static final int DUTY_TYPE_XIAOJIANYUAN = CnEmployeeDutyTypeEnum.XIAOJIANYUAN.getDutyValue();

    /**
     * 校验用户权限（这里仅会校验是否同人，不通过会抛异常
     *
     * @param loginUserId   当前登录用户id，不能为{@code null}
     * @param paramEmployee 根据请求参数查到的员工，不要传入{@code null}
     */
    public static void checkAccess(Long loginUserId, EmployeeOrgDTO paramEmployee) {
        checkAccess(loginUserId, paramEmployee, null);
    }

    /**
     * 校验用户权限，不通过会抛异常
     *
     * @param loginUserId     当前登录用户id，不能为{@code null}
     * @param paramEmployee   根据请求参数查到的用户，如果为空则不进行校验
     * @param accessDutyTypes 可以访问的角色，为{@code null}或者空列表则不校验角色
     */
    public static void checkAccess(Long loginUserId, EmployeeOrgDTO paramEmployee, List<Integer> accessDutyTypes) {
        // 判断登录环境,日常环境直接放过
        if (SystemEnvUtil.isDaily()) {
            return;
        }
        // 校验登录态
        if (loginUserId == null) {
            throw new AladdinBizException(ErrorCodeEnum.NOT_LOGIN.getCode(), ErrorCodeEnum.NOT_LOGIN.getMsg(), "请先登录！");
        }
        // 校验员工信息和登录信息是否一致
        if (paramEmployee == null) {
            return;
        }
        if (!loginUserId.equals(paramEmployee.getAccountId())) {
            throw new AladdinBizException(ErrorCodeEnum.NO_PERMISSION.getCode(), ErrorCodeEnum.NO_PERMISSION.getMsg(), "您无权访问该账号数据！");
        }
        // 校验当前登录人角色
        if (CollectionUtils.isEmpty(accessDutyTypes)) {
            return;
        }
        // 对比当前网点 和 参数的网点比较

//        if (!accessDutyTypes.contains(paramEmployee.getDutyType())) {
//            throw new AladdinBizException(ErrorCodeEnum.NO_PERMISSION.getCode(), ErrorCodeEnum.NO_PERMISSION.getMsg(), accessDutyTypeNotFoundUserMessage(accessDutyTypes));
//        }
    }

    public static void checkXnJvAccess(List<EmployeeOrgDTO> orgList, String jvCpCode) {
        // 判断登录环境,日常环境直接放过
        if (SystemEnvUtil.isDaily()) {
            return;
        }
        if (StringUtils.isBlank(jvCpCode)) {
            // 没有传服务商code的接口忽略校验
            return;
        }
        if (CollectionUtils.isEmpty(orgList)) {
            throw new AladdinBizException(ErrorCodeEnum.NO_PERMISSION.getCode(), ErrorCodeEnum.NO_PERMISSION.getMsg(), "您无权访问该账号数据！");
        }
        // 校验当前人员是否有jv数权
        if (Safes.of(orgList).stream().noneMatch(orgDTO -> jvCpCode.equals(orgDTO.getOrgCode()))) {
            throw new AladdinBizException(ErrorCodeEnum.NO_PERMISSION.getCode(), ErrorCodeEnum.NO_PERMISSION.getMsg(), "您无权访问该账号数据！");
        }
    }


    /**
     * 获取未找到对应角色的用户错误信息返回
     *
     * @param accessDutyTypes 可以访问的但是当前用户没有的角色
     * @return 对客错误信息
     */
    private static String accessDutyTypeNotFoundUserMessage(List<Integer> accessDutyTypes) {
        StringBuilder sb = new StringBuilder("请联系管理员配置角色：");
        for (int i = 0; i < accessDutyTypes.size(); i++) {
            Integer eachAccessDutyType = accessDutyTypes.get(i);
            if (i != 0) {
                sb.append("、");
            }
            CnEmployeeDutyTypeEnum eachAccessDutyTypeEnum = CnEmployeeDutyTypeEnum.valueOf(eachAccessDutyType);
            sb.append(eachAccessDutyTypeEnum.getDutyName());
        }
        return sb.toString();
    }
}
