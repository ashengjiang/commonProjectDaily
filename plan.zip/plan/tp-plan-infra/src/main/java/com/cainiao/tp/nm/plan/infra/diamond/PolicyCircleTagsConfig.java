package com.cainiao.tp.nm.plan.infra.diamond;

import com.alibaba.boot.diamond.annotation.DiamondListener;
import com.cainiao.aladdin.diamond.AladdinBootJsonDiamondListener;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyCircleTagsHolder;

/**
 * 圈选的标签，用于标签翻译和标签校验，
 * 如果有新增的标签需要这里配置一下
 * 后续最好的方案是有一个统一标签管理的地方
 */
@DiamondListener(dataId = "com.cainiao.tp.nm.plan.infra.diamond.PolicyCircleTagsConfig", executeAfterInit = true)
public class PolicyCircleTagsConfig extends AladdinBootJsonDiamondListener<PolicyCircleTagsHolder> {
    @Override
    public void setInstance(PolicyCircleTagsHolder policyCircleTagsHolder) {
        PolicyCircleTagsHolder.setINSTANCE(policyCircleTagsHolder);
    }

    @Override
    public Class<PolicyCircleTagsHolder> getClazz() {
        return PolicyCircleTagsHolder.class;
    }
}
