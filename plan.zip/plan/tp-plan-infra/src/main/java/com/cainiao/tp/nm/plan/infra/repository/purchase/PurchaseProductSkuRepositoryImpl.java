package com.cainiao.tp.nm.plan.infra.repository.purchase;

import com.cainiao.tp.nm.plan.infra.repository.purchase.convert.PurchaseProductSkuConvertor;
import com.cainiao.tp.nm.plan.infra.repository.purchase.dto.data.PurchaseProductSkuDO;
import com.cainiao.tp.nm.plan.infra.repository.purchase.dto.param.PurchaseProductSkuQueryParam;
import com.cainiao.tp.nm.plan.infra.repository.purchase.mapper.PurchaseProductSkuMapper;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseProductSku;
import com.cainiao.tp.nm.plan.purchase.domain.repository.PurchaseProductSkuRepository;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 产品 SKU 仓储实现 */
@Repository
public class PurchaseProductSkuRepositoryImpl implements PurchaseProductSkuRepository {

    @Resource
    private PurchaseProductSkuMapper purchaseProductSkuMapper;

    @Resource
    private PurchaseProductSkuConvertor purchaseProductSkuConvertor;

    @Override
    public PurchaseProductSku getById(Long id) {
        if (id == null) {
            return null;
        }
        PurchaseProductSkuDO doObj = purchaseProductSkuMapper.selectById(id);
        if (doObj == null) {
            return null;
        }
        return purchaseProductSkuConvertor.doToModel(doObj);
    }

    @Override
    public PurchaseProductSku getBySkuId(String skuId) {
        if (skuId == null || skuId.isEmpty()) {
            return null;
        }
        PurchaseProductSkuQueryParam queryParam = new PurchaseProductSkuQueryParam();
        queryParam.setSkuId(skuId);
        queryParam.setSize(1);
        List<PurchaseProductSkuDO> doList = purchaseProductSkuMapper.selectAll(queryParam);
        if (CollectionUtils.isEmpty(doList)) {
            return null;
        }
        return purchaseProductSkuConvertor.doToModel(doList.get(0));
    }

    @Override
    public List<PurchaseProductSku> listByProductIds(List<Long> productIds) {
        if (CollectionUtils.isEmpty(productIds)) {
            return new ArrayList<>();
        }
        PurchaseProductSkuQueryParam queryParam = new PurchaseProductSkuQueryParam();
        queryParam.setProductIdList(productIds);
        queryParam.setSize(productIds.size() * 10);
        List<PurchaseProductSkuDO> doList = purchaseProductSkuMapper.selectAll(queryParam);
        return purchaseProductSkuConvertor.doToModelList(doList);
    }

    @Override
    public PurchaseProductSku saveProductSku(PurchaseProductSku productSku) {
        PurchaseProductSkuDO skuDO = purchaseProductSkuConvertor.modelToDO(productSku);
        purchaseProductSkuMapper.insert(skuDO);
        return productSku;
    }

    @Override
    public void deleteSkusByProductId(Long productId) {
        if (productId == null) {
            return;
        }
        PurchaseProductSkuQueryParam queryParam = new PurchaseProductSkuQueryParam();
        queryParam.setProductIdList(Collections.singletonList(productId));
        queryParam.setSize(100);
        List<PurchaseProductSkuDO> skuList = purchaseProductSkuMapper.selectAll(queryParam);
        if (CollectionUtils.isNotEmpty(skuList)) {
            List<Long> skuIds = skuList.stream()
                    .map(PurchaseProductSkuDO::getId)
                    .collect(Collectors.toList());
            purchaseProductSkuMapper.batchDeleteByIds(skuIds);
        }
    }

    @Override
    public PurchaseProductSku updateSku(PurchaseProductSku productSku) {
        if (productSku == null || productSku.getId() == null) {
            return null;
        }
        PurchaseProductSkuDO skuDO = purchaseProductSkuConvertor.modelToDO(productSku);
        purchaseProductSkuMapper.update(skuDO);
        return productSku;
    }

    @Override
    public void deleteSkuById(Long skuId) {
        if (skuId == null) {
            return;
        }
        purchaseProductSkuMapper.deleteById(skuId);
    }
}
