package com.cainiao.tp.nm.plan.infra.mybatis.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 标记OrderBy参数，被标记的字段必须时一个OrderBy对象的List，实现查询结果排序 */
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface OrderByParam {
}
