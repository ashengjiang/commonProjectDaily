package com.cainiao.tp.nm.plan.infra.mybatis.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 查询类型标识注解，支持复杂条件查询使用 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface QueryType {

    Type value();

    enum Type {
        /**
         * 查询形式，EQUAL: 等值查询，LIKE: 模糊查询，IN: 范围查询，RANGE: 区间查询
         */
        EQUAL, LIKE, IN, RANGE
    }

    LikeType likeType() default LikeType.RIGHT;

    RangeType rangeType() default RangeType.NONE;

    /**
     * 模糊查询的匹配模式，配合Type.LIKE使用,指定模糊查询的匹配模式
     */
    enum LikeType {
        /**
         * like查询的匹配模式，应尽量使用右匹配配合索引提升性能
         */
        LEFT, RIGHT, FULL
    }

    /**
     * 区间查询的边界，配合Type.RANGE使用
     */
    enum RangeType {
        /**
         * 遵循左闭右开的区间，有需要扩展，先沟通再修改
         * MIN<=column<MAX
         * MIN, MAX可单独设置，NONE表示无限制，等于没这个条件
         */
        MIN, MAX, NONE
    }
}
