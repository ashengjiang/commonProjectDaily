package com.cainiao.tp.nm.plan.infra.tair.policy;

import com.alibaba.fastjson.JSON;
import com.cainiao.tp.nm.plan.infra.port.policy.IncentiveRemindTairPort;
import com.taobao.tair.DataEntry;
import com.taobao.tair.Result;
import com.taobao.tair.ResultCode;
import com.taobao.tair.TairManager;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * 站点实操激励提醒防重发 Tair 管理器
 * Key 格式：incentive_remind_{stationId}_{ruleName}_{triggerDate}
 * 过期时间：90天
 *
 * @date 2026-03-27
 */
@Slf4j
@Component
public class IncentiveRemindTairManager implements IncentiveRemindTairPort {

    /**
     * Tair namespace，与项目其他 Tair 操作保持一致
     */
    private static final int NAMESPACE = 5978;

    /**
     * 防重发 Key 过期时间：90天（单位：秒）
     */
    private static final int EXPIRE_SECONDS = 90 * 24 * 60 * 60;

    /**
     * 防重发 Key 前缀
     */
    private static final String KEY_PREFIX = "incentive_remind_";

    @Resource
    private TairManager tairManager;

    /**
     * 检查指定站点、规则、触发日期的通知是否已发送
     *
     * @param stationId   站点 ID
     * @param ruleName    规则名称
     * @param triggerDate 触发日期，格式 yyyyMMdd
     * @return true=已发送，false=未发送
     */
    public boolean isAlreadySent(String stationId, String ruleName, String triggerDate) {
        String key = buildKey(stationId, ruleName, triggerDate);
        Result<DataEntry> result = null;
        Exception exception = null;
        try {
            result = tairManager.get(NAMESPACE, key);
            return result != null && result.isSuccess() && result.getValue() != null;
        } catch (Exception e) {
            exception = e;
            // Tair 不可用时降级：跳过，不发送通知
            log.error("IncentiveRemindTairManager#isAlreadySent 查询失败，降级跳过，key={}, error={}, result={}",
                    key, e.getMessage(), JSON.toJSONString(result), e);
            return true;
        }
    }

    /**
     * 标记指定站点、规则、触发日期的通知已发送，过期时间 90 天
     *
     * @param stationId   站点 ID
     * @param ruleName    规则名称
     * @param triggerDate 触发日期，格式 yyyyMMdd
     */
    public void markAsSent(String stationId, String ruleName, String triggerDate) {
        String key = buildKey(stationId, ruleName, triggerDate);
        ResultCode resultCode = null;
        Exception exception = null;
        try {
            resultCode = tairManager.put(NAMESPACE, key, "1", 0, EXPIRE_SECONDS);
            if (resultCode == null || !resultCode.isSuccess()) {
                log.warn("IncentiveRemindTairManager#markAsSent 写入失败，key={}, resultCode={}", key, resultCode);
                throw new RuntimeException("IncentiveRemindTairManager#markAsSent 写入失败");
            }
        } catch (Exception e) {
            exception = e;
            log.error("IncentiveRemindTairManager#markAsSent 写入异常，key={}, error={}", key, e.getMessage(), e);
            throw e;
        }
    }

    /**
     * 构建防重发 Key
     *
     * @param stationId   站点 ID
     * @param ruleName    规则名称
     * @param triggerDate 触发日期，格式 yyyyMMdd
     * @return Tair Key
     */
    private String buildKey(String stationId, String ruleName, String triggerDate) {
        return KEY_PREFIX + stationId + "_" + ruleName + "_" + triggerDate;
    }
}
