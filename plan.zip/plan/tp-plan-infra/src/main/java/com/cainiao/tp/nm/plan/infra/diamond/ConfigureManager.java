package com.cainiao.tp.nm.plan.infra.diamond;

import java.util.Set;

/**
 * 配置管理器 */
public interface ConfigureManager<T extends Configure> {

    /**
     * 获取所有配置
     *
     * @return 配置集合
     */
    Set<T> getAllConfigure();

    /**
     * 获取配置
     *
     * @param key 配置key
     * @return 配置
     */
    T getConfigure(String key);
}
