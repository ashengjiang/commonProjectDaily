package com.cainiao.tp.nm.plan.infra.tg;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.PropertyNamingStrategy;
import com.alibaba.fastjson.parser.ParserConfig;
import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.tiangong.rpc.api.model.PaginatedResultDTO;
import com.cainiao.tiangong.rpc.client.TgRpcServiceClient;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.TgBaseParam;
import com.cainiao.tp.nm.plan.infra.port.policy.TgManager;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

@Component
@Slf4j
public class TgManagerImpl implements TgManager {


    @Resource
    TgRpcServiceClient tgRpcServiceClient;

    static final ParserConfig PARSER_CONFIG = new ParserConfig();

    static {
        PARSER_CONFIG.propertyNamingStrategy = PropertyNamingStrategy.SnakeCase;
    }

    /**
     * 获取数据列表
     * @param tgBaseRequest tgBaseRequest
     * @return return
     * @param <T> t
     */
    @Override
    public <T> List<T> getListData(TgBaseParam<T> tgBaseRequest) {
        int pageNum = tgBaseRequest.getPageNum();
        int pageSize = tgBaseRequest.getPageSize();
        int off = (pageNum - 1) * pageSize;

        PaginatedResultDTO<Map<String, Object>> paginatedResult = tgRpcServiceClient.pagination(
                TgConfig.BUSINESS_TG_USER, tgBaseRequest.getGuid(), generateConditionMap(tgBaseRequest), off, tgBaseRequest.getPageSize());

        if (paginatedResult == null || !paginatedResult.isSuccessful()) {
            log.error("TgManager#listData error,param={},result={}", JSON.toJSONString(tgBaseRequest), JSON.toJSON(paginatedResult));
            AssertUtil.isTrue(false, "requestTg error");
        }
        List<Map<String, Object>> data = paginatedResult.getData();
        if (CollectionUtils.isEmpty(data)) {
            return Collections.emptyList();
        }
        Class<T> respClass = tgBaseRequest.getRespClass();
        return (List<T>) data.stream().map(value -> JSON.parseObject(JSON.toJSONString(value), respClass, PARSER_CONFIG)).collect(Collectors.toList());
    }



    private static Map<String, Object> generateConditionMap(TgBaseParam tgBaseRequest) {
        Map<String, Object> condition = new ConcurrentHashMap<>();

        try {
            // 获取所有属性描述符
            PropertyDescriptor[] propertyDescriptors = Introspector.getBeanInfo(tgBaseRequest.getClass()).getPropertyDescriptors();

            for (PropertyDescriptor pd : propertyDescriptors) {
                Method getter = pd.getReadMethod(); // 获取getter方法
                if (getter != null && !"class".equals(pd.getName())) {
                    Object value = getter.invoke(tgBaseRequest);
                    if (value != null) {
                        // 将字段名从驼峰转换为蛇形命名
                        String snakeCaseKey= pd.getName();
                        if (value instanceof Collection) {
                            // 如果是集合，拼接元素的字符串表示
                            @SuppressWarnings("unchecked")
                            Collection<Object> list = (Collection<Object>) value;
                            String concatenated = list.stream()
                                    .map(Object::toString)
                                    .collect(Collectors.joining("','"));
                            condition.put(snakeCaseKey, "'"+concatenated+"'");
                        } else {
                            // 直接使用字段的字符串表示
                            condition.put(snakeCaseKey, value.toString());
                        }
                    }
                }
            }
        } catch (Exception e) {
            throw new AladdinBizException("",e.getMessage());
        }

        return condition;
    }

}
