package com.cainiao.tp.nm.plan.infra.mybatis.support;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.cainiao.tp.nm.plan.infra.mybatis.annotation.Column;
import com.cainiao.tp.nm.plan.infra.util.ReflectUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.reflection.MetaObject;
import org.apache.ibatis.session.Configuration;

/**
 * 自定义Mybatis的配置类，实现返回结果通过@Column完成字段映射 */
@Slf4j
public class MapConfiguration extends Configuration {

    private final Map<String, Map<String, String>> columnMap = new ConcurrentHashMap<>();

    @Override
    public MetaObject newMetaObject(Object object) {
        MetaObject metaObj = super.newMetaObject(object);
        if (object == null) {
            return metaObj;
        }
        // 替换metaObject的ObjectWrapper为自定义的wrapper
        Class<?> metaClass = object.getClass();
        Map<String, String> thisColumnMap = columnMap.get(metaClass.getName());
        if (thisColumnMap == null) {
            // 初始化
            thisColumnMap = new HashMap<>(16);
            Field[] fields = metaClass.getDeclaredFields();
            for (Field field : fields) {
                Column columnAnno = field.getAnnotation(Column.class);
                if (columnAnno != null && StringUtils.isNotEmpty(columnAnno.name())) {
                    thisColumnMap.put(columnAnno.name(), field.getName());
                }
            }
            columnMap.put(metaClass.getName(), thisColumnMap);
        }
        DelegateObjectWrapper myWrapper = new DelegateObjectWrapper(thisColumnMap, metaObj.getObjectWrapper());

        try {
            ReflectUtil.setFieldValue(metaObj, "objectWrapper", myWrapper);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            log.error("MapConfiguration set objectWrapper has error.", e);
        }

        return metaObj;
    }

}
