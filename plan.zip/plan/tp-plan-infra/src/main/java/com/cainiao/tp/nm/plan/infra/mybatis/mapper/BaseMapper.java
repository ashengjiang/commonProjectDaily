package com.cainiao.tp.nm.plan.infra.mybatis.mapper;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.cainiao.tp.nm.plan.infra.mybatis.annotation.PageNumParam;
import com.cainiao.tp.nm.plan.infra.mybatis.annotation.PageSizeParam;
import com.cainiao.tp.nm.plan.infra.mybatis.dto.BaseDO;
import com.cainiao.tp.nm.plan.infra.mybatis.dto.PageResult;
import com.cainiao.tp.nm.plan.infra.mybatis.support.SqlProvider;
import com.cainiao.tp.nm.plan.infra.util.ReflectUtil;
import org.apache.ibatis.annotations.DeleteProvider;
import org.apache.ibatis.annotations.InsertProvider;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.annotations.UpdateProvider;
import org.springframework.lang.NonNull;

/**
 * Mapper基础类，用于自动实现常用方法
 * 约定：
 * 1. 表名：T类名的驼峰转下划线形式，DO结尾会被自动去除，例如：StationDO -> station
 * 2. 字段名：驼峰形式，例如：stationCode -> station_code
 * 3. 主键名：id
 * 4. 特殊定义可使用注解进行指定，例如：@Table(name = "station") */
public interface BaseMapper<T extends BaseDO, Q> {

    /**
     * 插入，数据库生成的ID会自动赋值到entity的id属性中
     *
     * @param entity 不能为空
     */
    @InsertProvider(type = SqlProvider.class, method = "insert")
    @SelectKey(statement = "SELECT LAST_INSERT_ID() as id", keyProperty = "id", before = false, resultType = Long.class)
    void insert(@NonNull T entity);

    /**
     * 批量插入，使用insert into xxx （xxx）values（xxx）,（xxx）形式执行插入操作，性能更好，但是无法返回生成的主键ID
     * 需要返回主键ID的场景请使用{@code batchInsert(List<T>, true)}
     *
     * @param entities 不能为空
     */
    @InsertProvider(type = SqlProvider.class, method = "batchInsert")
    void batchInsert(@Param("entities") @NonNull List<T> entities);

    /**
     * 删除
     *
     * @param id 不能为空
     * @return 删除记录数
     */
    @DeleteProvider(type = SqlProvider.class, method = "deleteById")
    int deleteById(@Param("id") @NonNull Long id);

    /**
     * 批量删除
     *
     * @param ids 不能为空
     */
    @DeleteProvider(type = SqlProvider.class, method = "batchDeleteByIds")
    void batchDeleteByIds(@Param("ids") @NonNull List<Long> ids);

    /**
     * 更新
     *
     * @param entity 不能为空
     * @return 更新记录数
     */
    @UpdateProvider(type = SqlProvider.class, method = "update")
    int update(@NonNull T entity);

    /**
     * 查询
     *
     * @param id 不能为空
     * @return T
     */
    @SelectProvider(type = SqlProvider.class, method = "selectById")
    T selectById(@Param("id") @NonNull Long id);

    /**
     * 查询
     *
     * @param queryParam 查询参数
     * @return List<T>
     */
    @SelectProvider(type = SqlProvider.class, method = "selectAll")
    List<T> selectAll(@NonNull Q queryParam);

    /**
     * 查询数量
     *
     * @param queryParam 查询参数
     * @return 记录数
     */
    @SelectProvider(type = SqlProvider.class, method = "count")
    long count(@NonNull Q queryParam);

    /**
     * 分页查询
     *
     * @param queryParam 查询参数
     * @return 分页结果
     */
    default PageResult<T> selectPage(@NonNull Q queryParam) {
        long count = this.count(queryParam);
        List<T> ts = this.selectAll(queryParam);
        PageResult<T> pageResult = new PageResult<>();
        pageResult.setTotal(count);
        pageResult.setData(ts);
        Map<String, Object> pageNumFieldValues = ReflectUtil.getAnnotatedFieldValues(queryParam, PageNumParam.class);
        pageNumFieldValues.values().stream().findFirst().ifPresent(o -> {
            if (o instanceof Integer) {
                pageResult.setPage((Integer)o);
            }
        });
        Map<String, Object> pageSizeFieldValues = ReflectUtil.getAnnotatedFieldValues(queryParam, PageSizeParam.class);
        pageSizeFieldValues.values().stream().findFirst().ifPresent(o -> {
            if (o instanceof Integer) {
                pageResult.setSize((Integer)o);
            }
        });
        return pageResult;
    }

    /**
     * 批量插入，支持填充ID
     *
     * @param entities 实体列表
     * @param fillIds  是否填充ID,为true会使用循环调用{@code batchInsert(List<T>)}方法
     */
    default void batchInsert(@NonNull List<T> entities, boolean fillIds) {
        if (entities.isEmpty()) {
            return;
        }
        if (fillIds) {
            for (T entity : entities) {
                this.insert(entity);
            }
        } else {
            this.batchInsert(entities);
        }
    }

    /**
     * 批量更新，会比较两个参数集合的对象
     * 如果newEntities中记录id为空，则会插入新的记录
     * 如果newEntities中记录id不为空，且在oldEntities中存在，且equals判断不想等（代表有变化）则会执行更新操作
     * 如果newEntities中记录id不为空，且在oldEntities中不存在，则会执行删除操作
     *
     * @param oldEntities 旧实体列表，不能为空，通常是从数据库中刚刚查询得到
     * @param newEntities 新实体列表，不能为空，通常是业务逻辑进行操作后的结果
     * @param fillIds     是否填充ID
     */
    default void batchUpdate(@NonNull List<T> oldEntities, @NonNull List<T> newEntities, boolean fillIds) {
        Map<Long, T> oldEntityMap = oldEntities.stream().collect(Collectors.toMap(T::getId, item -> item));

        List<T> entitiesToAdd = new ArrayList<>();

        for (T entity : newEntities) {
            if (entity.getId() == null) {
                entitiesToAdd.add(entity);
            } else if (oldEntityMap.containsKey(entity.getId())) {
                // 如果存在相同ID的记录，并且有变动，则更新
                T oldEntity = oldEntityMap.get(entity.getId());
                if (!entity.equals(oldEntity)) {
                    this.update(entity);
                }
                oldEntityMap.remove(entity.getId());
            }
        }

        // 剩下的都是需要删除的
        List<Long> idsToDelete = new ArrayList<>(oldEntityMap.keySet());

        // Execute batch insert and delete
        if (!entitiesToAdd.isEmpty()) {
            this.batchInsert(entitiesToAdd, fillIds);
        }
        if (!idsToDelete.isEmpty()) {
            this.batchDeleteByIds(idsToDelete);
        }
    }

    /**
     * 批量更新，同{@code batchUpdate(List<T>, List<T>, boolean)}，默认insert不填充ID
     *
     * @param oldEntities 旧实体列表
     * @param newEntities 新实体列表
     */
    default void batchUpdate(@NonNull List<T> oldEntities, @NonNull List<T> newEntities) {
        this.batchUpdate(oldEntities, newEntities, false);
    }
}
