package com.cainiao.tp.nm.plan.infra.diamond;

/**
 * 基于diamond的配置器 */
public interface DiamondConfigure extends Configure {

    /**
     * 加载配置
     *
     * @param text 配置原始文本
     */
    void load(String text);

    /**
     * 获取组id
     *
     * @return groupId
     */
    String getGroupId();

    /**
     * 获取dataId
     *
     * @return dataId
     */
    String getDataId();
}
