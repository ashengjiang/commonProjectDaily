package com.cainiao.tp.nm.plan.infra.repository.purchase;

import com.cainiao.tp.nm.plan.infra.diamond.purchase.PurchasePaymentPlanConfigManager;
import com.cainiao.tp.nm.plan.infra.repository.purchase.convert.PurchasePaymentPlanConvertor;
import com.cainiao.tp.nm.plan.infra.repository.purchase.dto.data.PurchasePaymentPlanDO;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchasePaymentPlan;
import com.cainiao.tp.nm.plan.purchase.domain.repository.PurchasePaymentPlanRepository;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * 支付方案仓储实现（数据来源：Diamond 配置） */
@Repository
public class PurchasePaymentPlanRepositoryImpl implements PurchasePaymentPlanRepository {

    @Resource
    private PurchasePaymentPlanConfigManager purchasePaymentPlanConfigManager;

    @Resource
    private PurchasePaymentPlanConvertor purchasePaymentPlanConvertor;

    @Override
    public PurchasePaymentPlan getById(Long id) {
        if (id == null) {
            return null;
        }
        PurchasePaymentPlanDO doObj = purchasePaymentPlanConfigManager.getById(id);
        if (doObj == null) {
            return null;
        }
        return purchasePaymentPlanConvertor.doToModel(doObj);
    }

    @Override
    public List<PurchasePaymentPlan> listByIds(List<Long> ids) {
        if (CollectionUtils.isEmpty(ids)) {
            return new ArrayList<>();
        }
        List<PurchasePaymentPlanDO> doList = purchasePaymentPlanConfigManager.listByIds(ids);
        return purchasePaymentPlanConvertor.doToModelList(doList);
    }
}
