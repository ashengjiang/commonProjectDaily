package com.cainiao.tp.nm.plan.infra.tair.policy;

import com.cainiao.aladdin.exception.AladdinConcurrentException;
import com.cainiao.aladdin.lock.Lock;
import com.cainiao.tp.nm.plan.infra.common.constants.CommonErrorCodeEnum;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyTairLockManager;
import com.taobao.tair.Result;
import com.taobao.tair.TairManager;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * http://tiddo.alibaba-inc.com/saas-tair/#/InstanceDetail?username=d72d7419535d4881
 * @date 2021/01/19
 */
@Component
public class PolicyTairLockManagerImpl implements PolicyTairLockManager {

    /**
     * 默认锁namespace
     */
    private static final Integer DEFAULT_NAMESPACE = 5973;

    /**
     * 默认锁超时时间：30秒自动释放
     */
    private static final Integer DEFAULT_EXPIRE = 30;

    @Resource
    @Qualifier("ldbTtpTrcBusiness")
    private TairManager tairManager;

    /**
     * 尝试加锁
     * @param lock
     */
    @Override
    public void tryLockAndThrow(Lock lock) {
        if (!tryLock(lock)) {
            throw new AladdinConcurrentException(CommonErrorCodeEnum.ERROR_LOCK_FAIL.getErrorCode());
        }
    }

    /**
     * 加锁
     * @param lock
     * @return
     */
    @Override
    public boolean tryLock(Lock lock) {
        try {
            if (null == lock.getNamespace()) {
                lock.setNamespace(DEFAULT_NAMESPACE);
            }
            if (null == lock.getExpire()) {
                lock.setExpire(DEFAULT_EXPIRE);
            }
            Result<Integer> result = tairManager.incr(lock.getNamespace(), lock.getKey(), 1, 0, lock.getExpire(), 0, 1);
            if (result == null || !result.isSuccess() || !Integer.valueOf(1).equals(result.getValue())) {
                return false;
            }
            lock.setLocked(true);
            return true;
        } catch (Throwable t) {
            t.printStackTrace();
            return false;
        }
    }

    /**
     * 释放锁
     * @param lock
     * @return
     */
    @Override
    public boolean release(Lock lock) {
        if (lock == null) {
            return true;
        }
        if (!lock.isLocked()) {
            return true;
        }
        if (null == lock.getNamespace()) {
            lock.setNamespace(DEFAULT_NAMESPACE);
        }
        if (null == lock.getExpire()) {
            lock.setExpire(DEFAULT_EXPIRE);
        }
        try {
            Result<Integer> result = tairManager.decr(lock.getNamespace(), lock.getKey(), 1, 0, lock.getExpire(), 0, 1);
            if (result == null || !result.isSuccess()) {
                //原地重试
                Result<Integer> result2 = tairManager.decr(lock.getNamespace(), lock.getKey(), 1, 0, lock.getExpire(), 0,
                    1);
                if (result2 != null && result2.isSuccess()) {
                    return true;
                }
                return false;
            }
            return true;
        } catch (Throwable t) {
            t.printStackTrace();
            return false;
        }
    }

}
