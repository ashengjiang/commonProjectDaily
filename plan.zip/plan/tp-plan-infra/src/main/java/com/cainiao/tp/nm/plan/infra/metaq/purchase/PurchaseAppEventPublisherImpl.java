package com.cainiao.tp.nm.plan.infra.metaq.purchase;

import com.alibaba.fastjson.JSON;
import com.cainiao.tp.nm.plan.infra.metaq.MetaQueueProducer;
import com.cainiao.tp.nm.plan.purchase.adaptor.metaq.event.PurchaseCustomerSnEvent;
import com.cainiao.tp.nm.plan.purchase.application.event.PurchaseAppEventPublisher;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * 订购模块 MQ 事件发布实现 */
@Slf4j
@Component
public class PurchaseAppEventPublisherImpl implements PurchaseAppEventPublisher {

    private static final String TOPIC_PURCHASE_CUSTOMER_SN = "purchase_customer_sn";
    private static final String TAG_RELATION = "relation";

    @Resource
    private MetaQueueProducer metaQueueProducer;

    @Override
    public void publishCustomerSnRelation(PurchaseCustomerSnEvent event) {
        String messageKey = event.getCustomId() + "_" + event.getSnCode();
        metaQueueProducer.publishMsg(TOPIC_PURCHASE_CUSTOMER_SN, TAG_RELATION,
                JSON.toJSONString(event), messageKey);
    }
}
