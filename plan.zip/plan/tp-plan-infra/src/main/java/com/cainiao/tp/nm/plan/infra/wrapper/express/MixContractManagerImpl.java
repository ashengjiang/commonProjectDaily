package com.cainiao.tp.nm.plan.infra.wrapper.express;

import com.alibaba.cainiao.express.outlets.api.result.ResultModel;
import com.alibaba.cainiao.express.outlets.contract.param.mixcontract.EntityLaunchEditDTO;
import com.alibaba.cainiao.express.outlets.contract.service.MixContractWriteService;
import com.cainiao.tp.nm.plan.infra.port.dto.purchase.EntityLaunchEditParam;
import com.cainiao.tp.nm.plan.infra.port.purchase.MixContractManager;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 混合合同写入端口实现
 * <p>
 * 通过 HSF 调用 {@link MixContractWriteService#editEntityLaunchRelation} 编辑实体投放关系，
 * 并将 port 层自定义参数转换为三方 DTO。
 * </p> */
@Slf4j
@Component
public class MixContractManagerImpl implements MixContractManager {

    @Resource
    private MixContractWriteService mixContractWriteService;

    @Override
    public List<Long> editEntityLaunchRelation(List<EntityLaunchEditParam> editParams) {
        log.info("editEntityLaunchRelation, size={}", editParams != null ? editParams.size() : 0);
        List<EntityLaunchEditDTO> dtoList = convertToEntityLaunchEditDTOList(editParams);
        ResultModel<List<Long>> result = mixContractWriteService.editEntityLaunchRelation(dtoList);
        if (!result.isSuccess()) {
            log.error("editEntityLaunchRelation 调用失败, errorMsg={}", result.getErrorMsg());
            throw new RuntimeException("editEntityLaunchRelation 调用失败, errorMsg=" + result.getErrorMsg());
        }
        return result.getData();
    }

    private List<EntityLaunchEditDTO> convertToEntityLaunchEditDTOList(List<EntityLaunchEditParam> params) {
        return params.stream().map(param -> {
            EntityLaunchEditDTO dto = new EntityLaunchEditDTO();
            dto.setServiceCode(param.getServiceCode());
            dto.setLaunchEntityType(param.getLaunchEntityType());
            dto.setLaunchEntityCode(param.getLaunchEntityCode());
            dto.setEnv(param.getEnv());
            dto.setStatus(param.getStatus());
            return dto;
        }).collect(Collectors.toList());
    }
}
