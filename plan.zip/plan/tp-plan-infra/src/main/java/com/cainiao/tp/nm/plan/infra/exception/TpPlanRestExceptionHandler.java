package com.cainiao.tp.nm.plan.infra.exception;

import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * 站点域REST接口统一异常拦截处理类 */
@Component
@RestControllerAdvice(basePackages = "com.cainiao.tp.nm.plan.policy.adaptor.rest")
public class TpPlanRestExceptionHandler extends AbstractRestExceptionHandler {
}
