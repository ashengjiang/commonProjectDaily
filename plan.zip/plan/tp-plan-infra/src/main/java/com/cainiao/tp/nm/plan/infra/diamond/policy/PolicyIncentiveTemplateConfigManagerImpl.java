package com.cainiao.tp.nm.plan.infra.diamond.policy;

import com.alibaba.fastjson.JSON;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.terminal.finance.quotation.client.quotation.dto.plan.template.EditableElementDTO;
import com.cainiao.terminal.finance.quotation.client.quotation.dto.plan.template.QuotationTemplatePlanDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.PolicyIncentiveExpenseItemDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.PolicyIncentivePlanConfigDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.IncentivePlanContentDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.IncentivePlanDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.IncentivePlanResultDTO;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyIncentiveCoefficientEnum;
import com.cainiao.tp.nm.plan.infra.convert.PolicyIncentivePlanConvert;
import com.cainiao.tp.nm.plan.infra.diamond.DiamondConfigure;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyConfigManager;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyIncentiveTemplateConfigManager;
import com.cainiao.tp.nm.plan.infra.wrapper.finance.QuotationTemplatePlanWrapper;
import com.google.common.collect.Lists;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Optional;

@Component
public class PolicyIncentiveTemplateConfigManagerImpl implements PolicyIncentiveTemplateConfigManager, DiamondConfigure {

    private PolicyIncentiveTemplateConfig policyIncentiveTemplateConfig;

    @Resource
    private QuotationTemplatePlanWrapper quotationTemplatePlanWrapper;
    @Resource
    private PolicyConfigManager policyConfigManager;

    @Override
    public IncentivePlanDTO getIncentivePlanTemplate(String bizType, String customType
            , String incentivePlanType, String incentivePlanCode, String startTimeStr, String endTimeStr) {
        // 政策中心侧目前兜底校验
        PolicyIncentivePlanConfigDTO policyPlanConfig = policyConfigManager.getPlanConfigByPlanType(bizType, customType, incentivePlanType);
        PolicyIncentiveExpenseItemDTO expenseItem = policyPlanConfig.getExpenseItem(incentivePlanCode, startTimeStr, endTimeStr);
        AssertUtil.notNull(expenseItem, "激励费用项未配置");

        // 1.获取基础模版
        IncentivePlanContentDTO planContentDTO = policyIncentiveTemplateConfig.getIncentivePlan(incentivePlanType, incentivePlanCode);

        IncentivePlanDTO planDTO = new IncentivePlanDTO();
        planDTO.setPlanName(expenseItem.getExpenseItemName());
        planDTO.setIncentivePlanType(incentivePlanType);
        planDTO.setIncentivePlanCode(incentivePlanCode);
        planDTO.setContent(planContentDTO);

        // 控制是否读结算，异常情况下可以关闭结算依赖
        if(!Boolean.TRUE.equals(expenseItem.getFromSettlement())){
            return planDTO;
        }

        // 2.获取结算单价树 和 系数限制
        QuotationTemplatePlanDTO treeStructure = quotationTemplatePlanWrapper.getTreeStructure(incentivePlanCode, startTimeStr, endTimeStr);
        AssertUtil.notNull(treeStructure, "结算侧查不到这个费用项，请核实");

        // 3.设置单价树
        if(null == planContentDTO.getPrice() && CollectionUtils.isNotEmpty(treeStructure.getTree())){
            planContentDTO.setPrice(PolicyIncentivePlanConvert.convertPlanFrame(treeStructure.getTree()));
        }

        // 4.设置系数 结果限制信息
        // 这里结算接口当前只支持1个系数，默写写死叫“coefficient”  映射到我们定义的基础系数
        Optional<EditableElementDTO> first = Optional.ofNullable(treeStructure.getPriceExpression().getEditableFiledList())
                .orElse(Lists.newArrayList()).stream().filter(ele -> "coefficient".equals(ele.getCode())).findFirst();
        if(first.isPresent()){
            IncentivePlanResultDTO planResult = PolicyIncentivePlanConvert.convertPlanResult(first.get());
            planContentDTO.updateCoefficientResult(PolicyIncentiveCoefficientEnum.BASIC.getType(), planResult);
        }

        planDTO.setPlanName(treeStructure.getFeeName());
        return planDTO;
    }

    @Override
    public void load(String text) {
        this.policyIncentiveTemplateConfig = JSON.parseObject(text, PolicyIncentiveTemplateConfig.class);
    }

    @Override
    public String getGroupId() {
        return "DEFAULT_GROUP";
    }

    @Override
    public String getDataId() {
        return "com.cainiao.tp.nm.plan.policy.plan.template.config";
    }
}
