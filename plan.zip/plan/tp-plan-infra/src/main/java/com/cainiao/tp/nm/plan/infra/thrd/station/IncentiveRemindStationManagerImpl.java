package com.cainiao.tp.nm.plan.infra.thrd.station;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.cainiao.aladdin.AladdinOSearchManager;
import com.cainiao.aladdin.domain.AladdinOSearchStructureDTO;
import com.cainiao.aladdin.log.AladdinMapLog;
import com.cainiao.aladdin.log.BizType;
import com.cainiao.aladdin.log.utils.AladdinLogUtil;
import com.cainiao.aladdin.opensearch.OSearchQueryCommonCondition;
import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.aladdin.operation.SystemBizOperation;
import com.cainiao.aladdin.operation.SystemJobOperation;
import com.cainiao.aladdin.reslut.PageResult;
import com.cainiao.tp.nm.plan.infra.common.constants.OSearchAppEnum;
import com.cainiao.tp.nm.plan.infra.port.policy.IncentiveRemindStationManager;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import static com.cainiao.tp.nm.plan.infra.port.policy.IncentiveRemindStationManager.ScrollResult;

/**
 * 站点实操激励提醒-站点查询实现
 * 通过 OpenSearch 实例 tp_sta_perform_finance_join 分页查询入驻时间满足条件的站点列表
 *
 * @date 2026-03-27
 */
@Slf4j
@Component
public class IncentiveRemindStationManagerImpl implements IncentiveRemindStationManager {

    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    @Resource(name = "financeJoinAladdinOpenSearchManager")
    private AladdinOSearchManager aladdinOpenSearchManager;

    private static final AbstractOperation opInfo = new SystemBizOperation(0L, "IncentiveRemindStationManager");

    /**
     * 通过 scroll 方式查询入驻时间 >= joinStartDate 的站点信息列表
     * 首次查询 scrollId 传 null，后续查询传上次结果中的 scrollId
     *
     * @param joinStartDate 入驻时间起始日期（含）
     * @param pageSize      每批查询大小
     * @param scrollId      上次查询返回的 scrollId，首次查询传 null
     * @return scroll 查询结果
     */
    @Override
    public ScrollResult scrollStations(LocalDate joinStartDate, int pageSize, String scrollId) {
        AladdinMapLog mapLog = AladdinLogUtil.newMapLog("IncentiveRemindStationManagerImpl.scrollStations", BizType.DEFAULT);
        mapLog.addParam("joinStartDate", joinStartDate.toString());
        mapLog.addParam("pageSize", pageSize);
        mapLog.addParam("scrollId", scrollId);

        List<StationJoinInfo> stationList = null;
        Exception exception = null;
        try {
            StaPerformFinanceOSearchQuery query = new StaPerformFinanceOSearchQuery();
            query.setPageSize(pageSize);

            PageResult<List<StaPerformFinanceOSearchDTO>> osResult = aladdinOpenSearchManager.scollList(
                    query,
                    OSearchAppEnum.TP_STA_PERFORM_FINANCE_JOIN,
                    new TypeReference<AladdinOSearchStructureDTO<StaPerformFinanceOSearchDTO>>() {},
                    opInfo,
                    scrollId,
                    log);

            if (!osResult.isSuccess()) {
                log.error("IncentiveRemindStationManagerImpl scroll 查询失败，joinStartDate={}, scrollId={}, errMsg={}",
                        joinStartDate, scrollId, osResult.getErrorMsg());
                return new ScrollResult(Collections.emptyList(), null,0L);
            }

            List<StaPerformFinanceOSearchDTO> items = osResult.getData();
            String nextScrollId = osResult.getOtherData("scroll_id")!=null? (String) osResult.getOtherData("scroll_id"): null;
            Long totalCount = (Long)osResult.getOtherData("aboutCount");

            if (CollectionUtils.isEmpty(items)) {
                return new ScrollResult(Collections.emptyList(),nextScrollId,totalCount);
            }

            stationList = items.stream()
                    .map(this::convertToStationJoinInfo)
                    .filter(Objects::nonNull)
                    .collect(Collectors.toList());

            return new ScrollResult(stationList, nextScrollId, totalCount);
        } catch (Exception e) {
            exception = e;
            log.error("IncentiveRemindStationManagerImpl scroll 查询异常，joinStartDate={}, scrollId={}", joinStartDate, scrollId, e);
            return new ScrollResult(Collections.emptyList(), null,0L);
        } finally {
            mapLog.addParam("stationCount", stationList == null ? 0 : stationList.size());
            if (exception != null) {
                AladdinLogUtil.log(log, exception, mapLog);
            } else {
                AladdinLogUtil.log(log, mapLog);
            }
        }
    }

    /**
     * 将 OpenSearch 返回的 DTO 转换为站点入驻信息
     *
     * @param dto OpenSearch 返回的单条记录
     * @return 站点入驻信息，解析失败返回 null
     */
    private StationJoinInfo convertToStationJoinInfo(StaPerformFinanceOSearchDTO dto) {
        try {
            if (dto == null || StringUtils.isBlank(dto.getStationId()) || StringUtils.isBlank(dto.getMarginedTime())) {
                return null;
            }
            // 取日期部分（前10位），兼容 "yyyy-MM-dd" 和 "yyyy-MM-dd HH:mm:ss" 两种格式
            String marginedTimeStr = dto.getMarginedTime();
            String datePart = marginedTimeStr.length() >= 10 ? marginedTimeStr.substring(0, 10) : marginedTimeStr;
            LocalDate joinDate = LocalDate.parse(datePart, DATE_FORMATTER);
            return new StationJoinInfo(dto.getStationId(), joinDate);
        } catch (Exception e) {
            log.warn("IncentiveRemindStationManagerImpl 解析站点入驻信息失败，dto={}", JSON.toJSONString(dto), e);
            return null;
        }
    }

    /**
     * OpenSearch tp_sta_perform_finance_join 返回的站点数据 DTO
     */
    @Data
    public static class StaPerformFinanceOSearchDTO {

        /**
         * 站点 ID
         */
        private String stationId;

        /**
         * 入驻时间（格式 yyyy-MM-dd 或 yyyy-MM-dd HH:mm:ss）
         */
        private String marginedTime;
    }
}
