package com.cainiao.tp.nm.plan.infra.mybatis.config;

import com.alibaba.boot.tddl.builder.datasource.TDataSourceBuilder;
import com.alibaba.boot.tddl.config.TddlAutoConfiguration;

import com.cainiao.tp.nm.plan.infra.mybatis.support.MapConfiguration;
import com.taobao.tddl.matrix.jdbc.TDataSource;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.logging.stdout.StdOutImpl;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.mybatis.spring.boot.autoconfigure.SpringBootVFS;
import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * Mybatis配置 */
@Slf4j
@Configuration
@EnableTransactionManagement
@AutoConfigureBefore(TddlAutoConfiguration.class)
@MapperScan(basePackages = {"com.cainiao.tp.nm.plan.infra.repository.policy.mapper","com.cainiao.tp.nm.plan.infra.repository.purchase.mapper"},
    sqlSessionTemplateRef = "tpPlanDefaultSqlSessionTemplate")
public class MybatisConfig {
    @Bean(initMethod = "init", destroyMethod = "destroy")
    public TDataSource tpPlanDefaultDataSource() {
        return TDataSourceBuilder.create()
            .appName("CAINIAO_TERMINAL_CNM_PLAN_BASIC_APP")
            .dynamicRule(true)
            .sharding(false)
            .build();
    }

    @Bean
    public SqlSessionTemplate tpPlanDefaultSqlSessionTemplate() throws Exception {
        return new SqlSessionTemplate(tpPlanDefaultSqlSessionFactory());

    }

    @Bean
    public PlatformTransactionManager txManager() {
        return new DataSourceTransactionManager(tpPlanDefaultDataSource());
    }

    @Bean
    public SqlSessionFactory tpPlanDefaultSqlSessionFactory() throws Exception {
        SqlSessionFactoryBean sqlSessionFactoryBean = new SqlSessionFactoryBean();
        sqlSessionFactoryBean.setDataSource(tpPlanDefaultDataSource());
        sqlSessionFactoryBean.setVfs(SpringBootVFS.class);
        MapConfiguration config = new MapConfiguration();
        //TODO 控制台打印SQL，方便调试，线上需要注释掉
        config.setLogImpl(StdOutImpl.class);
        // resultMap自动下划线转驼峰
        config.setMapUnderscoreToCamelCase(true);
        sqlSessionFactoryBean.setConfiguration(config);
        // PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
        // sqlSessionFactoryBean.setMapperLocations(resolver.getResources("classpath:/mapper/mybatis-config.xml"));

        return sqlSessionFactoryBean.getObject();
    }

}
