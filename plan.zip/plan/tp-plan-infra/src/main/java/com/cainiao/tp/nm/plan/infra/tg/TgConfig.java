package com.cainiao.tp.nm.plan.infra.tg;

import com.cainiao.tiangong.rpc.api.model.User;
import com.cainiao.tiangong.rpc.client.TgRpcServiceClient;
import com.cainiao.tiangong.rpc.client.TgRpcServicesLocator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class TgConfig {

        @Bean
        public TgRpcServiceClient getServiceClient() {
            return TgRpcServicesLocator.getServiceClient();
        }


        public final static User BUSINESS_TG_USER = new User("tp-nm-plan", "MGFmMmR0cC1ubS1wbGFuSU5TSURFMGFmMmQ=");



}
