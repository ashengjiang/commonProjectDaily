package com.cainiao.tp.nm.plan.infra.tair;

import com.taobao.tair.TairManager;
import com.taobao.tair.impl.mc.MultiClusterTairManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @code date 2025年06月04日 14:03
 * @code desc:null
 */
@Configuration
public class TairConfig {

    @Bean(initMethod = "init")
    public TairManager tairManager() {
        //zonekeeper归属的LDB tair。 namespace（线上&日常）= 5978
        MultiClusterTairManager tairManager= new MultiClusterTairManager();
        tairManager.setUserName("9ed882569b0c433a");
        return tairManager;
    }
}
