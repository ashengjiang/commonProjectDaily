package com.cainiao.tp.nm.plan.infra.diamond.policy;

import com.alibaba.fastjson.JSON;
import com.cainiao.aladdin.env.SystemEnvUtil;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.NewStaPerformSubsidyConfigDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.NewStaPerformSubsidyPopConfigDTO;
import com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils;
import com.cainiao.tp.nm.plan.infra.diamond.DiamondConfigure;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.PolicyApproveConfigDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.PolicyIncentivePlanConfigDTO;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyConfigManager;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
public class PolicyConfigManagerImpl implements PolicyConfigManager, DiamondConfigure {

    private PolicyConfig policyConfig;

    @Override
    public PolicyApproveConfigDTO getApproveConfig(String bizType, String customType) {
        Optional<PolicyApproveConfigDTO> first = policyConfig.getApproveConfigList().stream()
                .filter(config -> StringUtils.equals(bizType, config.getBizType()) && StringUtils.equals(customType, config.getCustomType()))
                .findFirst();

        return first.isPresent() ? first.get() : null;
    }

    @Override
    public List<PolicyIncentivePlanConfigDTO> getPlanConfig(String bizType, String customType) {
        return policyConfig.getPolicyIncentiveConfigList().stream()
                .filter(config -> StringUtils.equals(bizType, config.getBizType())
                        && StringUtils.equals(customType, config.getCustomType()))
                .collect(Collectors.toList());
    }

    @Override
    public PolicyIncentivePlanConfigDTO getPlanConfigByPlanType(String bizType, String customType, String incentivePlanType) {
        Optional<PolicyIncentivePlanConfigDTO> first = policyConfig.getPolicyIncentiveConfigList().stream()
                .filter(config -> StringUtils.equals(bizType, config.getBizType())
                        && StringUtils.equals(customType, config.getCustomType())
                        && StringUtils.equals(incentivePlanType, config.getIncentivePlanType()))
                .findFirst();
        AssertUtil.isTrue(first.isPresent(), "激励类型未配置");
        return first.get();
    }

    @Override
    public String getPermissionDeniedPrompt() {
        return policyConfig.getPermissionDeniedPrompt();
    }

    @Override
    public String getPolicySubmitTaskOverTime(LocalDateTime startTime) {
        LocalDateTime lastEndTime= LocalDateTime.now().plusDays(30);
//        if (startTime == null){
//            startTime = LocalDateTime.now().plusMonths(policyConfig.getTaskOverDueMonths());
//        }
//        if (Boolean.TRUE.equals(policyConfig.getEnableConfigEffectTime())){
//            return policyConfig.getEffectTime();
//        }
        return DateUtils.localDateTimeToYmdhmsStr(lastEndTime);
    }



    @Override
    public String getMockStaMapping(String stationId) {
        if(!SystemEnvUtil.hasInited() || SystemEnvUtil.isOnline()){
            return stationId;
        }
        Map<String, String> mockStaMappingMap = policyConfig.getMockStaMappingMap();
        return MapUtils.getObject(mockStaMappingMap, stationId, stationId);
    }

    @Override
    public NewStaPerformSubsidyPopConfigDTO getNewStaPerformSubsidyPopConfig() {
        return policyConfig.getNewStaPerformSubsidyPopConfig();
    }

    @Override
    public NewStaPerformSubsidyConfigDTO getNewStaPerformSubsidyConfig() {
        return policyConfig.getNewStaPerformSubsidyConfig();
    }

    @Override
    public void load(String text) {
        this.policyConfig = JSON.parseObject(text, PolicyConfig.class);
    }

    @Override
    public String getGroupId() {
        return "DEFAULT_GROUP";
    }

    @Override
    public String getDataId() {
        return "com.cainiao.tp.nm.plan.policy.config";
    }
}
