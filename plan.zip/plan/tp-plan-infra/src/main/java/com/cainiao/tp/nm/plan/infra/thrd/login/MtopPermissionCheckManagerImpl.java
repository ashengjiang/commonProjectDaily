package com.cainiao.tp.nm.plan.infra.thrd.login;

import com.cainiao.tp.nm.plan.api.policy.common.constants.RequestSourceEnum;
import com.cainiao.tp.nm.plan.infra.port.common.constants.LoginEntityTypeEnum;
import com.cainiao.tp.nm.plan.infra.port.manager.PermissionLoginManager;
import com.cainiao.tp.nm.plan.infra.port.dto.context.BasePermissionContext;
import com.cainiao.tp.nm.plan.infra.port.dto.context.ExpressPermissionContext;
import com.cainiao.tp.nm.plan.infra.port.dto.context.PermissionContext;
import com.cainiao.tp.nm.plan.infra.port.dto.context.StationPermissionContext;
import com.cainiao.tp.nm.plan.infra.port.policy.StationPermissionCheckManager;
import com.cainiao.tp.nm.plan.infra.thrd.express.ExpressPermissionCheckHandler;
import com.taobao.mtop.api.agent.MtopContext;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.List;

@Component
public class MtopPermissionCheckManagerImpl implements PermissionLoginManager {

    public static List<String> YWT_APP_KEY = Arrays.asList("33471490", "33259236");

    @Resource
    private StationPermissionCheckManager stationPermissionCheckManager;
    @Resource
    private ExpressPermissionCheckHandler expressPermissionCheckHandler;


    public Boolean isExpress() {
        return YWT_APP_KEY.contains(MtopContext.getAppKey());
    }

    @Override
    public PermissionContext<BasePermissionContext> loginPermission() {
        PermissionContext<BasePermissionContext> context = new PermissionContext<>();
        if (isExpress()) {
            ExpressPermissionContext param=new ExpressPermissionContext();
            ExpressPermissionContext result = expressPermissionCheckHandler.checkPermission(param);
            context.setContext(result);
            context.setLoginType(LoginEntityTypeEnum.EXPRESS.getType());
        }else{
            StationPermissionContext param=new StationPermissionContext();
            param.setSource(RequestSourceEnum.STATION_OWNER.getSource());

            StationPermissionContext result = stationPermissionCheckManager.checkPermission(param);
            context.setContext(result);
            context.setLoginType(LoginEntityTypeEnum.STATION.getType());
        }
        return context;
    }
}
