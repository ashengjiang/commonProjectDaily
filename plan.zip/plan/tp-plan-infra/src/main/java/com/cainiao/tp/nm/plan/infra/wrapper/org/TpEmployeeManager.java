package com.cainiao.tp.nm.plan.infra.wrapper.org;


import com.alibaba.cainiao.tp.trc.org.client.domain.employee.input.TpEmployeeDetailSingleQuery;
import com.alibaba.cainiao.tp.trc.org.client.domain.employee.output.TpEmployeeDetailDTO;
import com.alibaba.cainiao.tp.trc.org.client.service.TpEmployeeService;
import com.cainiao.aladdin.exception.AladdinException;
import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.aladdin.reslut.Result;
import com.cainiao.aladdin.validate.utils.ValidateUtil;
import com.cainiao.tps.control.org.client.api.newOrg.TpsNewOrgDeptEmployeeService;
import com.cainiao.tps.control.org.client.model.dto.dept.TpsOrgDeptDTO;
import com.cainiao.tps.control.org.client.model.rep.TpsOrgEmployeeBelongDeptRep;
import com.cainiao.tps.control.org.client.model.request.query.newDept.TpsNewEmployeeDeptQueryReq;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @description:员工信息查询
 */
@Component
public class TpEmployeeManager {

    @Resource
    private TpEmployeeService tpEmployeeService;

    @Resource
    private TpsNewOrgDeptEmployeeService tpsNewOrgDeptEmployeeService;

    /**
     * 查询员工组织信息
     * @param employeeId
     * @param opInfo
     * @return
     */
    public TpEmployeeDetailDTO getEmployee(Long employeeId, AbstractOperation opInfo) {
        TpEmployeeDetailSingleQuery q = new TpEmployeeDetailSingleQuery();
        q.setEmployeeId(employeeId);
        q.setQueryTerritory(true);
        q.setQueryAccount(true);
        Result<TpEmployeeDetailDTO> dtoResult = tpEmployeeService.detailEmployeeInfo(q, opInfo);
        ValidateUtil.validateResultAndThrow(dtoResult);
        return dtoResult.getData();
    }

    /**
     * 根据用户Id查询用户所在的部门
     * @param employeeId 用户Id
     * @return 部门信息
     * @date 2024/7/16
     **/
    public List<TpsOrgDeptDTO> queryDeptByEmployeeId(Long employeeId, String bizDomain) {
        TpsNewEmployeeDeptQueryReq tpsNewEmployeeDeptQueryReq = new TpsNewEmployeeDeptQueryReq();
        tpsNewEmployeeDeptQueryReq.setEmployeeId(employeeId);
        if (StringUtils.isNotEmpty(bizDomain)) {
            tpsNewEmployeeDeptQueryReq.setBizDomain(bizDomain);
        }
        Result<TpsOrgEmployeeBelongDeptRep> repResult = tpsNewOrgDeptEmployeeService.queryBelongDeptByEmployeeId(tpsNewEmployeeDeptQueryReq);
        if (!repResult.isSuccess()) {
            throw new AladdinException(repResult.getErrCode(), "查询用户部门信息失败");
        }
        TpsOrgEmployeeBelongDeptRep tpsOrgEmployeeBelongDeptRep = repResult.getData();
        if (null == tpsOrgEmployeeBelongDeptRep || org.apache.commons.collections.CollectionUtils.isEmpty(tpsOrgEmployeeBelongDeptRep.getAllDeptList())) {
            return new ArrayList<>();
        }
        return tpsOrgEmployeeBelongDeptRep.getAllDeptList();
    }

    /**
     * 根据用户Id查询用户所在最高部门
     * @param employeeId 用户Id
     * @param bizDomain 业务域
     * @return 部门code
     */
    public TpsOrgDeptDTO getEmployeeHighestDept(Long employeeId, String bizDomain){
        TpsNewEmployeeDeptQueryReq tpsNewEmployeeDeptQueryReq = new TpsNewEmployeeDeptQueryReq();
        tpsNewEmployeeDeptQueryReq.setEmployeeId(employeeId);
        if (StringUtils.isNotEmpty(bizDomain)) {
            tpsNewEmployeeDeptQueryReq.setBizDomain(bizDomain);
        }
        Result<TpsOrgEmployeeBelongDeptRep> repResult = tpsNewOrgDeptEmployeeService.queryBelongDeptByEmployeeId(tpsNewEmployeeDeptQueryReq);
        if (!repResult.isSuccess()) {
            throw new AladdinException(repResult.getErrCode(), "查询用户部门信息失败");
        }
        TpsOrgEmployeeBelongDeptRep tpsOrgEmployeeBelongDeptRep = repResult.getData();
        if (null == tpsOrgEmployeeBelongDeptRep || tpsOrgEmployeeBelongDeptRep.getHighestDeptDTO() == null) {
            return null;
        }
        return tpsOrgEmployeeBelongDeptRep.getHighestDeptDTO();
    }

}
