package com.cainiao.tp.nm.plan.infra.diamond;

import com.alibaba.boot.diamond.annotation.DiamondListener;
import com.cainiao.aladdin.diamond.AladdinBootJsonDiamondListener;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyViewConfigHolder;

/**
 * 政策模版和其他页面视图模版关联关系
 */
@DiamondListener(dataId = "com.cainiao.tp.nm.plan.infra.diamond.PolicyViewConfigConfig", executeAfterInit = true)
public class PolicyViewConfigConfig extends AladdinBootJsonDiamondListener<PolicyViewConfigHolder> {
    @Override
    public void setInstance(PolicyViewConfigHolder policyViewConfigHolder) {
        PolicyViewConfigHolder.setINSTANCE(policyViewConfigHolder);
    }

    @Override
    public Class<PolicyViewConfigHolder> getClazz() {
        return PolicyViewConfigHolder.class;
    }
}
