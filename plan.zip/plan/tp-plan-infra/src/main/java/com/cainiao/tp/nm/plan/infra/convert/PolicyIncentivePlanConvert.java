package com.cainiao.tp.nm.plan.infra.convert;

import com.google.common.collect.BoundType;
import com.cainiao.terminal.finance.quotation.client.quotation.dto.plan.template.EditableElementDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.IncentivePlanFactorResultDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.IncentivePlanFrameDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.IncentivePlanResultDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.limit.IncentiveFactorLimitDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.limit.IncentiveResultLimitDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.limit.OptionLimitDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.limit.RangeLimitDTO;
import com.cainiao.tp.nm.plan.api.policy.common.constants.IncentiveArithLogicEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.IncentiveFactorResultTypeEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.IncentiveLimitTypeEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.IncentiveResultValTypeEnum;
import com.google.common.collect.Lists;
import com.google.common.collect.Range;
import org.apache.commons.collections4.CollectionUtils;

import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

/**
 * @Date 2025/6/11 18:27
 * @code desc: 政策激励方案模版和结算费用项转换
 */
public class PolicyIncentivePlanConvert {

    public static IncentivePlanFrameDTO convertPlanFrame(List<EditableElementDTO> rootChildren){
        IncentivePlanFrameDTO frame = new IncentivePlanFrameDTO();
        frame.setChildren(Lists.newArrayList());

        for(EditableElementDTO editableElement : rootChildren){
            IncentivePlanFrameDTO planFrame = new IncentivePlanFrameDTO();
            frame.getChildren().add(planFrame);
            convertPlanFrame(planFrame, editableElement);
        }
        return frame;
    }

    /**
     * 将结算费用项结构 映射到 激励方案树结构上
     * @param frame
     * @param element
     */
    public static void convertPlanFrame(IncentivePlanFrameDTO frame, EditableElementDTO element){
        if(null == element){
            return;
        }

        if(CollectionUtils.isEmpty(element.getChildren())){
            frame.setResult(Lists.newArrayList(convertPlanResult(element)));
        }else{
            frame.setFactorCode(element.getCode());
            frame.setFactorName(element.getName());
            frame.setArithLogic(IncentiveArithLogicEnum.EQUAL.getCode());
            frame.setIncentiveFactorLimit(convertFactorLimit(element));
            frame.setFactorResult(convertFactorResult(element));
            frame.setChildren(Lists.newArrayList());

            if(element.getChildren().size()==1 && CollectionUtils.isEmpty(element.getChildren().get(0).getChildren())){
                frame.setResult(Lists.newArrayList(convertPlanResult(element.getChildren().get(0))));
            }else{
                for(EditableElementDTO editableElement : element.getChildren()){
                    IncentivePlanFrameDTO planFrame = new IncentivePlanFrameDTO();
                    frame.getChildren().add(planFrame);
                    convertPlanFrame(planFrame, editableElement);
                }
            }

        }
    }

    private static IncentiveFactorLimitDTO convertFactorLimit(EditableElementDTO element){
        IncentiveFactorLimitDTO factorLimit = new IncentiveFactorLimitDTO();
        factorLimit.setCanUpdate(Boolean.TRUE.equals(element.getEditable()));
        if(!factorLimit.getCanUpdate()){
            return factorLimit;
        }

        String limitType = element.getEditableLimitType();
        if(EditableElementDTO.EditableLimitType.RANGE.name().equals(limitType)){
            Range<BigDecimal> editLimit = (Range<BigDecimal>) element.getEditLimit();
            RangeLimitDTO rangeLimitDTO = new RangeLimitDTO(editLimit.upperEndpoint().doubleValue()
                    , editLimit.lowerEndpoint().doubleValue()
                    , BoundType.CLOSED.equals(editLimit.upperBoundType())
                    , BoundType.CLOSED.equals(editLimit.lowerBoundType()));
            if(EditableElementDTO.ValueType.RANGE.name().equals(element.getValueType())){
                factorLimit.setLimitType(IncentiveLimitTypeEnum.LADDER.getType());
                factorLimit.setLadderLimit(rangeLimitDTO);
            }else{
                factorLimit.setLimitType(IncentiveLimitTypeEnum.RANGE.getType());
                factorLimit.setRangeLimit(rangeLimitDTO);
            }
        } else if(EditableElementDTO.EditableLimitType.ENUM.name().equals(limitType)){
            Set<String> editLimit = (Set<String>) element.getEditLimit();
            factorLimit.setLimitType(IncentiveLimitTypeEnum.OPTION.getType());
            factorLimit.setOptionLimit(new OptionLimitDTO(Lists.newArrayList(editLimit)));
        }
        return factorLimit;
    }


    private static IncentivePlanFactorResultDTO convertFactorResult(EditableElementDTO element){
        IncentivePlanFactorResultDTO factorResult = new IncentivePlanFactorResultDTO();
        String valueType = element.getValueType();
        if(EditableElementDTO.ValueType.RANGE.name().equals(valueType)){
            Range<BigDecimal> editLimit = (Range<BigDecimal>) element.getValue();
            factorResult.setType(IncentiveFactorResultTypeEnum.LADDER.getType());
            factorResult.setLadderVal(new RangeLimitDTO(editLimit.upperEndpoint().doubleValue()
                    , editLimit.lowerEndpoint().doubleValue()
                    , BoundType.CLOSED.equals(editLimit.upperBoundType())
                    , BoundType.CLOSED.equals(editLimit.lowerBoundType())));
        }else {
            factorResult.setType(IncentiveFactorResultTypeEnum.FIXED.getType());
            factorResult.setFixedVal(String.valueOf(element.getValue()));
        }
        return factorResult;
    }

    public static IncentivePlanResultDTO convertPlanResult(EditableElementDTO element){
        IncentivePlanResultDTO planResultDTO = new IncentivePlanResultDTO();
        planResultDTO.setCode(element.getCode());
        planResultDTO.setName(element.getName());
        if(null != element.getValue()){
            planResultDTO.setVal(String.valueOf(element.getValue()));
        }

        IncentiveResultLimitDTO resultLimit = new IncentiveResultLimitDTO();
        resultLimit.setCanUpdate(Boolean.TRUE.equals(element.getEditable()));
        planResultDTO.setResultLimit(resultLimit);

        if(!resultLimit.getCanUpdate()){
            return planResultDTO;
        }

        // 目前单价和系数 都写死小数
        resultLimit.setValType(IncentiveResultValTypeEnum.DOUBLE.getType());
        String limitType = element.getEditableLimitType();
        if(EditableElementDTO.EditableLimitType.RANGE.name().equals(limitType)){
            Range<BigDecimal> editLimit = (Range<BigDecimal>) element.getEditLimit();
            resultLimit.setLimitType(IncentiveLimitTypeEnum.RANGE.getType());
            resultLimit.setRangeLimit(new RangeLimitDTO(editLimit.upperEndpoint().doubleValue()
                    , editLimit.lowerEndpoint().doubleValue()
                    ,  BoundType.CLOSED.equals(editLimit.upperBoundType())
                    , BoundType.CLOSED.equals(editLimit.lowerBoundType())));
        }else if(EditableElementDTO.EditableLimitType.ENUM.name().equals(limitType)){
            Set<String> editLimit = (Set<String>) element.getEditLimit();
            resultLimit.setLimitType(IncentiveLimitTypeEnum.OPTION.getType());
            resultLimit.setOptionLimit(new OptionLimitDTO(Lists.newArrayList(editLimit)));
        }

        return planResultDTO;
    }

}
