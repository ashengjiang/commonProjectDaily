package com.cainiao.tp.nm.plan.infra.wrapper.division;

import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.aladdin.reslut.Result;
import com.cainiao.tp.nm.plan.api.policy.application.dto.DivisionConfigHolder;
import com.cainiao.tp.nm.plan.api.policy.application.dto.DivisionDTO;
import com.cainiao.tp.nm.plan.api.policy.common.constants.AddressDivisionLevelEnum;
import com.cainiao.tp.nm.plan.infra.port.policy.CacheManager;
import com.cainiao.tps.control.org.client.constant.newDept.TpsOrgNewDeptLevelEnum;
import com.cainiao.tps.pangu.org.client.model.request.TpsDeptQueryWithAddressReq;
import com.cainiao.tps.pangu.org.client.service.TpsPanguOrgDeptService;
import com.taobao.biz.common.division.newera.config.CnDataVersionUtils;
import com.taobao.biz.common.division.newera.managers.division.ChinaDivisionManager;
import com.taobao.biz.common.division.newera.vo.DivisionVO;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import com.cainiao.tps.pangu.org.client.model.dto.TpsOrgDeptDTO;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**ø
 * @Description: 省市区查询
 **/
@Component
public class TcsChinaDivisionManagerWrapper {

    @Resource
    private ChinaDivisionManager chinaDivisionManager;

    @Resource
    private TpsPanguOrgDeptService tpsPanguOrgDeptService;

    @Resource
    private CacheManager cacheManager;

    private static final String REGION_CODE_TAIR_KEY = "plan:regionCode:v2:";

    private static final int REGION_CODE_TAIR_EXPIRE = 60 * 60 * 2;


    /**
     * 查询大区code
     * @param cityCode 城市code
     * @return 大区code
     **/
    public String queryRegionCodeByCityCode(String cityCode){
        if (StringUtils.isBlank(cityCode)) {
            return null;
        }
        String key = REGION_CODE_TAIR_KEY + cityCode;
        String regionCode = cacheManager.get(key, String.class);
        if (StringUtils.isNotBlank(regionCode)) {
            return regionCode;
        }
        try {
            String townId = getArbitraryTownCodeByCityCode(cityCode);
            TpsDeptQueryWithAddressReq req = new TpsDeptQueryWithAddressReq();
            req.setLevelCode(TpsOrgNewDeptLevelEnum.RG_LEVEL.getCode());
            // townCode 经过测试，也支持城市、区县code
            req.setTownCode(townId);
            req.setOrgCode("YZ_MERGE_OPERATE");
            Result<List<TpsOrgDeptDTO>> deptWithAddress = tpsPanguOrgDeptService.getDeptWithAddress(req);
            if (!deptWithAddress.isSuccess() || CollectionUtils.isEmpty(deptWithAddress.getData()) || deptWithAddress.getData().get(0) == null) {
                throw new AladdinBizException("queryRegionCodeByCityCode", "getDeptWithAddress error");
            }
            regionCode = deptWithAddress.getData().get(0).getDeptCode();
            cacheManager.set(key, regionCode, REGION_CODE_TAIR_EXPIRE);
            return regionCode;
        } catch (Exception e) {
            throw new AladdinBizException("queryRegionCodeByCityCode", "getDeptWithAddress error", e);
        }
    }

    /**
     * 查询区划详情
     * @param divisionId 区划Id
     * @return 区划信息
     * @date 2022/10/17
     **/
    public DivisionVO getDivisionDetail(Long divisionId) {
        if (divisionId == null) {
            return null;
        }
        try {
            String addressVersion = DivisionConfigHolder.getINSTANCE().getAddressVersion();
            if(StringUtils.isNotBlank(addressVersion)){
                CnDataVersionUtils.setCnDataVersionContext(addressVersion);
            }
            return chinaDivisionManager.getDivisionById(divisionId);
        } catch (Exception e) {
            throw new AladdinBizException("getDivisionDetail", "getDivisionById error", e);
        }
    }

    /**
     * 查询下级区划信息
     * @param divisionId 区划Id
     * @return 下级列表
     * @date 2022/10/17
     **/
    public List<DivisionVO> getChildDivision(Long divisionId) {
        if (divisionId == null) {
            return null;
        }
        try {
            String addressVersion = DivisionConfigHolder.getINSTANCE().getAddressVersion();
            if(StringUtils.isNotBlank(addressVersion)){
                CnDataVersionUtils.setCnDataVersionContext(addressVersion);
            }
            List<DivisionVO> divisionVOList = chinaDivisionManager.getChildDivisionsById(divisionId);
            return this.convertDivisionVO(divisionVOList);
        } catch (Exception e) {
            throw new AladdinBizException("getChildDivision", "getChildDivisionsById error", e);
        }
    }


    private List<DivisionVO> convertDivisionVO(List<DivisionVO> divisionVOList) {
        List<DivisionVO> divisionVOS = new ArrayList<>();
        if (CollectionUtils.isEmpty(divisionVOList)) {
            return divisionVOS;
        }
        for (DivisionVO divisionVO : divisionVOList) {
            if (null == divisionVO){
                continue;
            }
            divisionVOS.add(divisionVO);
        }
        return divisionVOS;
    }

    /**
     * 获取指定城市下任意街道code
     * @param cityCode 城市code
     * @return 街道code
     */
    public String getArbitraryTownCodeByCityCode(String cityCode) {
        long cityDivisionLevel = Long.parseLong(cityCode);
        // 查询该城市下的区县的区划信息
        List<DivisionVO> districtDivisions = getChildDivision(cityDivisionLevel);
        if (CollectionUtils.isEmpty(districtDivisions) || districtDivisions.get(0) == null) {
            return cityCode;
        }
        for (DivisionVO districtDivision : districtDivisions) {
            if (districtDivision.getDivisionName().contains("其它")){
                continue;
            }
            // 查询该区县下的街道的区划信息
            List<DivisionVO> townDivisions = getChildDivision(districtDivision.getDivisionId());
            if (CollectionUtils.isEmpty(townDivisions) || townDivisions.get(0) == null) {
                continue;
            }
            return String.valueOf(townDivisions.get(0).getDivisionId());
        }
        // 如果该城市下的区县都没有街道，则返回第一个区县的code
        return String.valueOf(districtDivisions.get(0).getDivisionId());
    }

    public DivisionDTO getDivisionChain(Long divisionId) {
        try {
            List<DivisionVO> divisionVOList = chinaDivisionManager.getDivisionChainById(divisionId);
            if (CollectionUtils.isEmpty(divisionVOList)) {
                return null;
            }
            DivisionDTO divisionDTO = new DivisionDTO();
            divisionVOList.forEach(divisionVO -> {
                if (divisionVO == null) {
                    return;
                }
                if (AddressDivisionLevelEnum.DIVISION_LEVEL_PROVINECE.getLevel().equals(divisionVO.getDivisionLevel())) {
                    divisionDTO.setProvinceCode(divisionVO.getDivisionId() + "");
                    divisionDTO.setProvince(divisionVO.getDivisionName());
                }
                if (AddressDivisionLevelEnum.DIVISION_LEVEL_CITY.getLevel().equals(divisionVO.getDivisionLevel())) {
                    divisionDTO.setCityCode(divisionVO.getDivisionId() + "");
                    divisionDTO.setCity(divisionVO.getDivisionName());
                }
                if (AddressDivisionLevelEnum.DIVISION_LEVEL_DISTRICT.getLevel().equals(divisionVO.getDivisionLevel())) {
                    divisionDTO.setDistrictCode(divisionVO.getDivisionId() + "");
                    divisionDTO.setDistrict(divisionVO.getDivisionName());
                }
                if (AddressDivisionLevelEnum.DIVISION_LEVEL_TOWN.getLevel().equals(divisionVO.getDivisionLevel())) {
                    divisionDTO.setTownCode(divisionVO.getDivisionId() + "");
                    divisionDTO.setTown(divisionVO.getDivisionName());
                }
            });
            String districtCode = divisionDTO.getDistrictCode();
            if (StringUtils.isNotBlank(districtCode) && StringUtils.isBlank(divisionDTO.getCityCode())) {
                divisionDTO.setCityCode(districtCode);
            }
            String cityCode = divisionDTO.getCityCode();
            if (StringUtils.isNotBlank(divisionDTO.getCityCode()) && StringUtils.isNotBlank(divisionDTO.getTownCode())) {
                if (StringUtils.isBlank(districtCode)) {
                    divisionDTO.setDistrictCode(cityCode);
                }
            }
            return divisionDTO;
        } catch (Exception e) {
            throw new AladdinBizException("getDivisionChain", "getDivisionChain error", e);
        }
    }
}
