package com.cainiao.tp.nm.plan.infra.mybatis.dto;

import java.util.ArrayList;
import java.util.List;

import com.cainiao.tp.nm.plan.infra.mybatis.annotation.OrderByParam;
import com.cainiao.tp.nm.plan.infra.mybatis.annotation.Transient;
import lombok.Data;

/**
 * 排序查询，可继承该接口实现可排序的查询 */

@Data
public abstract class BaseOrderQueryParam<T extends Enum<T>> implements OrderQuery<T> {
    @Transient
    private static final long serialVersionUID = 4860420439961785665L;
    @OrderByParam
    private final List<OrderBy> orderByList = new ArrayList<>();

    @Override
    public void addOrderBy(T field, boolean asc) {
        orderByList.add(new OrderBy(field, asc));
    }
}
