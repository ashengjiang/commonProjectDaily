package com.cainiao.tp.nm.plan.infra.os.config;

import com.cainiao.aladdin.AladdinOSearchManager;
import com.cainiao.tp.nm.plan.infra.diamond.TpOpenSearchAccessConfig;
import com.cainiao.tp.nm.plan.infra.diamond.TpOpenSearchAccessConfigHolder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;

import javax.annotation.Resource;


@DependsOn("tpOpenSearchAccessConfig")
@Configuration
public class OpenSearchConfig {

    @Resource
    private TpOpenSearchAccessConfig tpOpenSearchAccessConfig;

    @Bean(name = "financeJoinAladdinOpenSearchManager", initMethod = "init")
    public AladdinOSearchManager aladdinOpenSearchManager() throws Exception {
        TpOpenSearchAccessConfigHolder configHolder = TpOpenSearchAccessConfigHolder.getINSTANCE();
        AladdinOSearchManager aladdinOpenSearchManager = new AladdinOSearchManager();
        aladdinOpenSearchManager.setUseApiKey(true);
        aladdinOpenSearchManager.setApiKey(configHolder.getFinanceJoin_ApiKey());
        aladdinOpenSearchManager.setHost(configHolder.getFinanceJoin_Host());
        return aladdinOpenSearchManager;
    }
}
