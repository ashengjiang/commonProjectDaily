package com.cainiao.tp.nm.plan.infra.diamond;

import com.alibaba.boot.diamond.annotation.DiamondListener;
import com.cainiao.aladdin.diamond.AladdinBootJsonDiamondListener;
import com.cainiao.tp.nm.plan.api.policy.application.dto.StationIncentivePageConfigHolder;

/**
 * @code date 2025年08月05日 11:17
 * @code desc:站点激励页面字段展示/（过滤）配置
 */
@DiamondListener(dataId = "plan.station.incentive.page.config", executeAfterInit = true)
public class TpPlanStationIncentivePageConfig extends AladdinBootJsonDiamondListener<StationIncentivePageConfigHolder> {
    @Override
    public void setInstance(StationIncentivePageConfigHolder stationIncentivePageConfigHolder) {
        StationIncentivePageConfigHolder.setINSTANCE(stationIncentivePageConfigHolder);
    }

    @Override
    public Class<StationIncentivePageConfigHolder> getClazz() {
        return StationIncentivePageConfigHolder.class;
    }
}
