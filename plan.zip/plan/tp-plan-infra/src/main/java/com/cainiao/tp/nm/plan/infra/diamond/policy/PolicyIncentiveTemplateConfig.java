package com.cainiao.tp.nm.plan.infra.diamond.policy;

import com.alibaba.fastjson.JSONObject;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.IncentivePlanContentDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.IncentivePlanTypeDTO;
import com.cainiao.tp.nm.plan.infra.diamond.policy.dto.IncentivePlanTemplateConfigDTO;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lombok.Data;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.Map;

@Data
public class PolicyIncentiveTemplateConfig {

    /**
     * 激励方案模版，是激励方案的基础模版
     */
    private List<IncentivePlanTemplateConfigDTO> templateList = Lists.newArrayList();


    /**
     * 根据激励类型和激励code获取模版
     * @param incentivePlanType
     * @param incentivePlanCode
     * @return
     */
    public IncentivePlanContentDTO getIncentivePlan(String incentivePlanType, String incentivePlanCode){
        Map<String, IncentivePlanContentDTO> templateMap = Maps.newHashMap();
        for(IncentivePlanTemplateConfigDTO templateConfig : templateList){
            for(IncentivePlanTypeDTO planType : templateConfig.getIncentivePlanTypeList()){
                String key = planType.getIncentivePlanType() + "_" + StringUtils.defaultString(planType.getIncentivePlanCode());
                templateMap.put(key, templateConfig.getContent());
            }
        }

        IncentivePlanContentDTO planContentDTO = ObjectUtils.defaultIfNull(templateMap.get(incentivePlanType + "_" + incentivePlanCode), templateMap.get(incentivePlanType + "_"));
        AssertUtil.notNull(planContentDTO, "未配置激励方案模版");
        // 这里先简单实现，对象太深
        return JSONObject.parseObject(JSONObject.toJSONString(planContentDTO), IncentivePlanContentDTO.class);
    }

}
