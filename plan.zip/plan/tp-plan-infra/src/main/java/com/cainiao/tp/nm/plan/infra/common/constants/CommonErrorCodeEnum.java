package com.cainiao.tp.nm.plan.infra.common.constants;

import lombok.Getter;

/**
 * @date 2019/03/05
 */
@Getter
public enum CommonErrorCodeEnum {

    /**
     * 错误码枚举
     */
    PARAM_CHECK_ERROR("PARAM_CHECK_ERROR", "参数校验错误"),

    OPERATION_FAIL("OPERATION_FAIL", "操作失败"),

    CALL_ERROR("CALL_ERROR", "调用外部接口异常"),

    IGNORE_BIZ_EXCEPTION("IGNORE_BIZ_EXCEPTION","可忽略业务异常"),

    DATA_NOT_EQUAL("DATA_NOT_EQUAL","数据不一致异常"),

    METAQ_SEND_ERROR("METAQ_SEND_ERROR", "消息发送失败"),

    ERROR_LOCK_FAIL("ERROR_LOCK_FAIL", "加锁失败"),

    USER_HAS_NOT_AUTH("USER_HAS_NOT_AUTH", "登陆失效"),
    ;
    private String errorCode;

    private String displayMessage;

    CommonErrorCodeEnum(String errorCode, String displayMessage) {
        this.errorCode = errorCode;
        this.displayMessage = displayMessage;
    }
}
