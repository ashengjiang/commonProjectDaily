package com.cainiao.tp.nm.plan.infra.hsf;

import com.alibaba.boot.hsf.annotation.HSFConsumer;
import com.alibaba.cainiao.express.outlets.api.service.express.ExpressService;
import com.alibaba.cainiao.express.outlets.base.api.service.org.ExpressOrgService;
import com.alibaba.cainiao.express.outlets.contract.api.certify.service.EnterpriseCertifyService;
import com.alibaba.cainiao.express.outlets.contract.service.*;
import com.alibaba.cainiao.stationplatform.client.service.StationAuthUserService;
import com.alibaba.cainiao.stationplatform.client.service.StationExpressService;
import com.alibaba.cainiao.stationplatform.client.service.StationPartnerService;
import com.alibaba.cainiao.stationplatform.client.service.StationStationService;
import com.alibaba.cainiao.tp.trc.org.client.service.TpEmployeeService;
import com.cainiao.terminal.element.center.client.service.ElementReadService;
import com.cainiao.terminal.finance.quotation.client.quotation.service.facade.QuotationTemplatePlanService;
import com.cainiao.terminal.iot.aftersales.api.service.duoniu.DuoNiuQueryService;
import com.cainiao.terminal.ticket.client.service.TpTicketPushService;
import com.cainiao.terminal.ticket.client.service.TpTicketService;
import com.cainiao.terminal.ticket.client.service.TpTicketTaskReadService;
import com.cainiao.tp.pangu.basic.client.service.TpsDataHeaderService;
import com.cainiao.terminal.finance.payment.client.facade.PaymentSignFacade;
import com.cainiao.tp.scale.expand.client.collect.service.application.CollectPointMainApplicationService;
import com.cainiao.tp.scale.expand.client.tag.service.application.TseTagApplicationService;
import com.cainiao.tps.channel.service.TpMessageService;
import com.cainiao.tps.content.client.service.agreement.TpsAgreementInstanceQueryService;
import com.cainiao.tps.content.client.service.agreement.TpsAgreementInstanceWriteService;
import com.cainiao.tps.content.client.service.agreement.TpsAgreementQueryService;
import com.cainiao.tps.control.org.client.api.newOrg.TpsNewOrgDeptEmployeeService;
import com.cainiao.tps.control.org.client.api.newOrg.TpsNewOrgDeptService;
import com.cainiao.tps.pangu.org.client.service.TpsPanguOrgDeptService;
import com.xiniao.service.operate.api.station.XnUnmannedStationJvInfoService;
import org.springframework.context.annotation.Configuration;

/**
 * HSF服务调用配置类
 */
@Configuration
public class HSFConsumerConfig {

    @HSFConsumer(serviceVersion = "${hsf.version}")
    private TpEmployeeService tpEmployeeService;

    @HSFConsumer(serviceVersion = "${hsf.version}")
    private TpsNewOrgDeptEmployeeService tpsNewOrgDeptEmployeeService;

    @HSFConsumer(serviceVersion = "${hsf.version}",clientTimeout = 5000)
    private TpTicketService tpOaTicketService;

    @HSFConsumer(serviceVersion = "${xn.hsf.version}")
    private XnUnmannedStationJvInfoService xnUnmannedStationJvInfoService;

    @HSFConsumer(serviceVersion = "${station.hsf.version}")
    private StationExpressService stationExpressService;

    @HSFConsumer
    private ServiceProductService serviceProductService;

    @HSFConsumer
    private TpsNewOrgDeptService tpsNewOrgDeptService;


    @HSFConsumer
    private TpTicketTaskReadService tpTicketTaskReadService;

    @HSFConsumer
    private TpTicketPushService tpTicketPushService;

    @HSFConsumer
    private ElementReadService elementReadService;

    @HSFConsumer
    private TpsPanguOrgDeptService tpsPanguOrgDeptService;

    @HSFConsumer
    private QuotationTemplatePlanService quotationTemplatePlanService;

    @HSFConsumer
    private ExpressOrgService expressOrgService;

    @HSFConsumer
    private CloverOrgWhiteListService cloverOrgWhiteListService;

    @HSFConsumer(serviceVersion = "${station.hsf.version}", clientTimeout = 5000)
    private StationStationService stationStationService;

    @HSFConsumer(serviceVersion = "${station.hsf.version}", clientTimeout = 5000)
    private StationPartnerService stationPartnerService;

    @HSFConsumer(serviceVersion = "${station.hsf.version}")
    private TpsDataHeaderService tpsDataHeaderService;

    @HSFConsumer(serviceVersion = "${station.hsf.version}", clientTimeout = 3000)
    private StationAuthUserService stationAuthUserService;

    @HSFConsumer
    private TseTagApplicationService tseTagApplicationService;
    @HSFConsumer
    private CollectPointMainApplicationService collectPointMainApplicationService;

    @HSFConsumer
    private TpMessageService tpMessageService;

    @HSFConsumer
    private EnterpriseCertifyService enterpriseCertifyService;

    @HSFConsumer
    private PaymentSignFacade paymentSignFacade;

    @HSFConsumer
    private ExpressService expressService;

    @HSFConsumer
    private DuoNiuQueryService duoNiuQueryService;

    @HSFConsumer
    private MixContractWriteService mixContractWriteService;

    @HSFConsumer
    private ServiceProductInfoService serviceProductInfoService;
    @HSFConsumer
    private PlatContractReadService platContractReadService;
    @HSFConsumer
    private TpsAgreementQueryService tpsAgreementQueryService;
    @HSFConsumer
    private TpsAgreementInstanceWriteService tpsAgreementInstanceWriteService;
    @HSFConsumer
    private TpsAgreementInstanceQueryService tpsAgreementInstanceQueryService;

}
