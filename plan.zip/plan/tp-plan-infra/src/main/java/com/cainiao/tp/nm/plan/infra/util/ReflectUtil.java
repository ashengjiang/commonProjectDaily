package com.cainiao.tp.nm.plan.infra.util;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 反射工具 */
public class ReflectUtil {
    public static Object getFieldValue(Object obj, String fieldName)
        throws NoSuchFieldException, IllegalAccessException {
        Field field = getFieldFromClassHierarchy(obj.getClass(), fieldName);

        return getFieldValue(obj, field);
    }

    public static Object getFieldValue(Object obj, Field field) throws IllegalAccessException {
        field.setAccessible(true);
        return field.get(obj);
    }

    public static void setFieldValue(Object obj, String fieldName, Object value)
        throws NoSuchFieldException, IllegalAccessException {
        Field field = getFieldFromClassHierarchy(obj.getClass(), fieldName);
        field.setAccessible(true);
        field.set(obj, value);
    }

    private static Field getFieldFromClassHierarchy(Class<?> clazz, String fieldName) throws NoSuchFieldException {
        for (Class<?> currentClass = clazz; currentClass != Object.class; currentClass = currentClass.getSuperclass()) {
            try {
                return currentClass.getDeclaredField(fieldName);
            } catch (NoSuchFieldException ignored) {
                // Continue to search in superclass
            }
        }
        throw new NoSuchFieldException(fieldName);
    }

    public static List<Field> getAllFields(Class<?> clazz) {
        List<Field> fields = new ArrayList<>();
        while (clazz != null && clazz != Object.class) {
            fields.addAll(Arrays.asList(clazz.getDeclaredFields()));
            clazz = clazz.getSuperclass();
        }
        return fields;
    }

    public static Map<String, Object> getAnnotatedFieldValues(Object obj, Class<? extends Annotation> annotationClass) {
        Map<String, Object> resultMap = new HashMap<>();
        Class<?> clazz = obj.getClass();

        for (Field field : getAllFields(clazz)) {
            if (field.isAnnotationPresent(annotationClass)) {
                try {
                    resultMap.put(field.getName(), getFieldValue(obj, field));
                } catch (IllegalAccessException e) {
                    throw new RuntimeException("Unable to access field value", e);
                }
            }
        }

        return resultMap;
    }

    public static boolean isPrimitiveOrWrapper(Class<?> clazz) {
        if (clazz == null) {
            return false;
        }
        return clazz.isPrimitive() ||
            clazz == Byte.class || clazz == Short.class || clazz == Integer.class ||
            clazz == Long.class || clazz == Float.class || clazz == Double.class ||
            clazz == Character.class || clazz == Boolean.class || clazz == String.class;
    }

}
