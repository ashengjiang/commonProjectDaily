package com.cainiao.tp.nm.plan.infra.wrapper.enums;

import com.alibaba.cainiao.express.outlets.contract.enums.BizDomainEnum;
import com.alibaba.cainiao.express.outlets.contract.enums.EntityTypeEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.ExpressTypeEnum;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

@Getter
public enum ExpressTypeMapperEnum {
    JV(ExpressTypeEnum.JV, BizDomainEnum.XN_SERVE, EntityTypeEnum.XN_JV_CODE),
    EXPRESS(ExpressTypeEnum.EXPRESS, BizDomainEnum.EXP_SERVE, EntityTypeEnum.EXPRESS_ENTITY),
    ;

    ExpressTypeMapperEnum(ExpressTypeEnum customerTypeEnum, BizDomainEnum bizDomainEnum, EntityTypeEnum expressEntityTypeEnum) {
        this.customerTypeEnum = customerTypeEnum;
        this.bizDomainEnum = bizDomainEnum;
        this.expressEntityTypeEnum = expressEntityTypeEnum;
    }

    private final ExpressTypeEnum customerTypeEnum;

    private final BizDomainEnum bizDomainEnum;
    private final EntityTypeEnum expressEntityTypeEnum;


    public static ExpressTypeMapperEnum ofCustomerType(String customerType) {
        if (StringUtils.isBlank(customerType)) {
            return null;
        }
        ExpressTypeMapperEnum[] values = ExpressTypeMapperEnum.values();
        for (ExpressTypeMapperEnum value : values) {
            ExpressTypeEnum customerTypeEnum = value.getCustomerTypeEnum();
            if (customerTypeEnum.getCode().equals(customerType)) {
                return value;
            }
        }
        return null;
    }
}
