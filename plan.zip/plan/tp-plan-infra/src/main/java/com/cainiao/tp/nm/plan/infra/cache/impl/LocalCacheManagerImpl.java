package com.cainiao.tp.nm.plan.infra.cache.impl;

import com.cainiao.tp.nm.plan.infra.port.policy.LocalCacheManager;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.concurrent.TimeUnit;

/**
 * @code date 2025年06月04日 17:19
 * @code desc:null
 */
@Component
public class LocalCacheManagerImpl implements LocalCacheManager {

    public static Cache<String, Serializable> cache;

    public LocalCacheManagerImpl() {
        cache = Caffeine.newBuilder()
                .expireAfterWrite(10, TimeUnit.MINUTES)
                .maximumSize(1000)
                .build();
    }

    /**
     * 获取缓存
     *
     * @param key
     * @param clazz 返回值类型
     * @return 缓存
     */
    @Override
    public <T> T get(String key, Class<T> clazz) {
        Serializable value = cache.getIfPresent(key);
        if (clazz.isInstance(value)) {
            return clazz.cast(value);
        }
        return null;
    }

    /**
     * 设置缓存
     *
     * @param key    缓存key
     * @param value  缓存值
     */
    @Override
    public void set(String key, Serializable value) {
        cache.put(key, value);
    }
}
