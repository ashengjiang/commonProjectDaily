package com.cainiao.tp.nm.plan.infra.metaq.policy;

import com.alibaba.fastjson.JSON;
import com.cainiao.tp.nm.plan.infra.metaq.MetaQueueProducer;
import com.cainiao.tp.nm.plan.policy.application.event.PolicyInstanceAppEventPublisher;
import com.cainiao.tp.nm.plan.policy.application.event.event.PolicyInstanceCreateEvent;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyMetaqEventEnum;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * http://tiddo.alibaba-inc.com/saas-tair/#/InstanceDetail?username=d72d7419535d4881
 * @date 2021/01/19
 */
@Component
public class PolicyInstanceAppEventPublisherImpl implements PolicyInstanceAppEventPublisher {


    @Resource
    private MetaQueueProducer metaQueueProducer;

    @Override
    public void create(PolicyInstanceCreateEvent policyInstanceCreateEvent) {
        metaQueueProducer.publishMsg(
                PolicyMetaqEventEnum.POLICY_INSTANCE_CREATE.getTopic()
                , PolicyMetaqEventEnum.POLICY_INSTANCE_CREATE.getTag()
                , JSON.toJSONString(policyInstanceCreateEvent)
                , String.valueOf(policyInstanceCreateEvent.getInstanceId())
        );
    }
}
