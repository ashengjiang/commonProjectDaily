package com.cainiao.tp.nm.plan.infra.diamond;

import com.alibaba.boot.diamond.annotation.DiamondListener;
import com.cainiao.aladdin.diamond.AladdinBootJsonDiamondListener;
import com.cainiao.tp.nm.plan.api.policy.application.dto.TpExportHeadHolder;

@DiamondListener(dataId = "com.cainiao.tp.nm.plan.infra.diamond.TpExportHeadConfig", executeAfterInit = true)
public class TpExportHeadConfig extends AladdinBootJsonDiamondListener<TpExportHeadHolder> {


    @Override
    public void setInstance(TpExportHeadHolder tpExportHeadHolder) {
        TpExportHeadHolder.setINSTANCE(tpExportHeadHolder);
    }

    @Override
    public Class<TpExportHeadHolder> getClazz() {
        return TpExportHeadHolder.class;
    }
}
