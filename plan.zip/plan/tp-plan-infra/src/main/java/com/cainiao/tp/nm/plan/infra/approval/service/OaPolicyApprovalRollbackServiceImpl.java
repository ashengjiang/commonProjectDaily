package com.cainiao.tp.nm.plan.infra.approval.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.fastjson.JSON;

import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.aladdin.operation.SystemBizOperation;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.terminal.ticket.client.domain.response.TpTicketRep;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyInstanceEffectParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyInstanceLoseEffectParam;
import com.cainiao.tp.nm.plan.api.policy.application.service.PolicyInstanceAppService;
import com.cainiao.tp.nm.plan.api.policy.common.constants.OAProcessContextConstants;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyConstants;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyFeatureConstants;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyInstanceApprovalStatusEnum;
import com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils;
import com.cainiao.tp.nm.plan.infra.wrapper.org.TpTicketWrapper;
import com.cainiao.tp.nm.plan.api.policy.application.service.approval.OaPolicyApprovalRollbackService;
import com.cainiao.tp.nm.plan.policy.domain.model.PolicyInstance;
import com.cainiao.tp.nm.plan.policy.domain.repository.PolicyInstanceRepository;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import javax.annotation.Resource;

/**
 * @Date 2025/6/5 20:02
 * @code desc: 政策审批回调接口实现
 */
@Slf4j
@HSFProvider(serviceInterface = OaPolicyApprovalRollbackService.class)
public class OaPolicyApprovalRollbackServiceImpl implements OaPolicyApprovalRollbackService {

    @Resource
    private TpTicketWrapper tpTicketWrapper;

    @Resource
    private PolicyInstanceRepository policyInstanceRepository;


    @Resource
    private PolicyInstanceAppService policyInstanceAppService;



    @Override
    public void agree(String processInstanceId) {
        log.info("OaPolicyApprovalRollbackServiceImpl.agree.processInstanceId={}",processInstanceId);
        AbstractOperation opInfo = new SystemBizOperation(0L, "OA流程审批回调");
        TpTicketRep tpTicketRep = getTpTicketRep(processInstanceId);
        String operatorId = (String)tpTicketRep.getContext().get(OAProcessContextConstants.OPERATOR_ID);
        opInfo.setOperatorId(operatorId);
        PolicyInstance policyInstance = getPolicyInstance(tpTicketRep);
        if (policyInstance == null) {
            return;
        }
        if (!PolicyInstanceApprovalStatusEnum.APPROVALING.getCode().equals(policyInstance.getApprovalStatus())){
            return;
        }
        effect(policyInstance,opInfo);
//        if (policyInstance.getStartTime() == null || LocalDateTime.now().isBefore(policyInstance.getStartTime())) {
//            // 未过期,生效政策实例
//            effect(policyInstance,opInfo);
//            return;
//        }
//        if (policyInstance.getStartTime() != null && LocalDateTime.now().isAfter(policyInstance.getStartTime())) {
//            // 已过期,失效政策实例
//            loseEffect(policyInstance, PolicyInstanceApprovalStatusEnum.OVERTIME_AUTO_REFUSE,opInfo);
//        }
    }


    @Override
    public void disagree(String processInstanceId) {
        log.info("OaPolicyApprovalRollbackServiceImpl.disagree.processInstanceId={}",processInstanceId);
        AbstractOperation opInfo = new SystemBizOperation(0L, "OA流程审批回调");
        TpTicketRep tpTicketRep = getTpTicketRep(processInstanceId);
        String operatorId = (String)tpTicketRep.getContext().get(OAProcessContextConstants.OPERATOR_ID);
        opInfo.setOperatorId(operatorId);
        PolicyInstance policyInstance = getPolicyInstance(tpTicketRep);
        if (policyInstance == null) {
            return;
        }
        if (!PolicyInstanceApprovalStatusEnum.APPROVALING.getCode().equals(policyInstance.getApprovalStatus())){
            return;
        }
        if (policyInstance.getStartTime() == null || LocalDateTime.now().isBefore(policyInstance.getStartTime())) {
            // 未过期,失效政策实例-拒绝
            loseEffect(policyInstance,PolicyInstanceApprovalStatusEnum.REFUSE,opInfo);
            return;
        }
        if (policyInstance.getStartTime() != null && LocalDateTime.now().isAfter(policyInstance.getStartTime())){
            // 已过期,失效政策实例-超时
            loseEffect(policyInstance,PolicyInstanceApprovalStatusEnum.OVERTIME_AUTO_REFUSE,opInfo);
        }
    }

    @Override
    public void timeoutAutoReject(String processInstanceId) {
        log.info("OaPolicyApprovalRollbackServiceImpl.handleTimeoutAutoReject.processInstanceId={}",processInstanceId);
        AbstractOperation opInfo = new SystemBizOperation(0L, "OA流程审批回调");
        TpTicketRep tpTicketRep = getTpTicketRep(processInstanceId);
        String operatorId = (String)tpTicketRep.getContext().get(OAProcessContextConstants.OPERATOR_ID);
        opInfo.setOperatorId(operatorId);
        PolicyInstance policyInstance = getPolicyInstance(tpTicketRep);
        if (policyInstance == null) {
            return;
        }
        if (!PolicyInstanceApprovalStatusEnum.APPROVALING.getCode().equals(policyInstance.getApprovalStatus())){
            return;
        }
        // 失效政策实例
        loseEffect(policyInstance,PolicyInstanceApprovalStatusEnum.OVERTIME_AUTO_REFUSE,opInfo);
    }

    private TpTicketRep getTpTicketRep(String processInstanceId){
        TpTicketRep tpTicketRep = tpTicketWrapper.queryTicketByProcessId(processInstanceId);
        AssertUtil.notNull(tpTicketRep,"工单不存在");
        return tpTicketRep;
    }

    private PolicyInstance getPolicyInstance(TpTicketRep tpTicketRep){
        String policyInstanceId = (String)tpTicketRep.getContext().get(OAProcessContextConstants.POLICY_INSTANCE_ID);
        if (policyInstanceId == null) {
            return null;
        }
        // 查询提报的政策实例
        return policyInstanceRepository.get(Long.valueOf(policyInstanceId));
    }

    /**
     * 生效政策实例
     * @param policyInstance 政策实例
     * @param operation 操作人
     */
    private void effect(PolicyInstance policyInstance,AbstractOperation operation){
        if (policyInstance == null) {
            return;
        }
        try {
            PolicyInstanceEffectParam param = new PolicyInstanceEffectParam();
            param.setInstanceId(policyInstance.getId());
            param.setApprovalStatus(PolicyInstanceApprovalStatusEnum.PASS.getCode());
            param.setFeatureMap(policyInstance.getFeatureMap());
            policyInstanceAppService.effect(param, operation);
        } catch (Exception e) {
            log.error("OaPolicyApprovalRollbackServiceImpl#effect error,policyInstance={}", JSON.toJSONString(policyInstance), e);
        }
    }
    /**
     * 失效政策实例
     * @param policyInstance 政策实例
     * @param approvalStatusEnum 审批状态
     * @param operation 操作人
     */
    private void loseEffect(PolicyInstance policyInstance,PolicyInstanceApprovalStatusEnum approvalStatusEnum,AbstractOperation operation){
        if (policyInstance == null) {
            return;
        }
        try {
            // 失效政策实例
            PolicyInstanceLoseEffectParam param = new PolicyInstanceLoseEffectParam();
            param.setInstanceId(policyInstance.getId());
            param.setApprovalStatus(approvalStatusEnum.getCode());
            String cancelReason = StringUtils.EMPTY;
            if (approvalStatusEnum == PolicyInstanceApprovalStatusEnum.OVERTIME_AUTO_REFUSE) {
                cancelReason = buildTimeOutReason(policyInstance);
            }
            Map<String, String> featureMap = Optional.ofNullable(policyInstance.getFeatureMap()).orElse(Maps.newHashMap());
            featureMap.put(PolicyFeatureConstants.CANCEL_REASON, cancelReason);
            param.setFeatureMap(featureMap);
            policyInstanceAppService.loseEffect(param, operation);
        } catch (Exception e) {
            log.error("OaPolicyApprovalRollbackServiceImpl#loseEffect error,policyInstance={}", JSON.toJSONString(policyInstance), e);
        }
    }

    private String buildTimeOutReason(PolicyInstance policyInstance){
        String cancelReason;
        if (policyInstance.getEffectTime() == null) {
            cancelReason = String.format(PolicyConstants.LOSE_EFFECT_REASON, DateUtils.localDateTimeToYmdhmsStr(LocalDateTime.now()));
        }else {
            cancelReason = String.format(
                PolicyConstants.LOSE_EFFECT_REASON_CONTAIN_EFFECT_TIME,
                DateUtils.localDateTimeToYmdhmsStr(LocalDateTime.now()),
                DateUtils.localDateTimeToYmdhmsStr(policyInstance.getEffectTime())
            );
        }
        return cancelReason;
    }


}
