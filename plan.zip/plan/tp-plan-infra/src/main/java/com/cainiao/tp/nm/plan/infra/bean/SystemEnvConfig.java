package com.cainiao.tp.nm.plan.infra.bean;

import com.cainiao.aladdin.env.SystemEnvUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SystemEnvConfig {

    @Value("${spring.tp.env}")
    public String env;

    @Bean
    public SystemEnvUtil env() {
        return SystemEnvUtil.initEnv(env);
    }
}
