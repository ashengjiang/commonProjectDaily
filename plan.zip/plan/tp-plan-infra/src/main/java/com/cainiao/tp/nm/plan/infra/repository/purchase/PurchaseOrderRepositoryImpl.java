package com.cainiao.tp.nm.plan.infra.repository.purchase;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.cainiao.tp.nm.plan.infra.repository.purchase.convert.PurchaseOrderConvertor;
import com.cainiao.tp.nm.plan.infra.repository.purchase.dto.data.PurchaseOrderDO;
import com.cainiao.tp.nm.plan.infra.repository.purchase.dto.data.PurchaseOrderProductSnapshotDO;

import com.cainiao.tp.nm.plan.infra.repository.purchase.dto.param.PurchaseOrderProductSnapshotQueryParam;
import com.cainiao.tp.nm.plan.infra.repository.purchase.dto.param.PurchaseOrderQueryParam;
import com.cainiao.tp.nm.plan.infra.repository.purchase.mapper.PurchaseOrderMapper;
import com.cainiao.tp.nm.plan.infra.repository.purchase.mapper.PurchaseOrderProductSnapshotMapper;
import com.cainiao.tp.nm.plan.purchase.domain.model.PurchaseOrder;
import com.cainiao.tp.nm.plan.purchase.domain.repository.PurchaseOrderRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 订购订单仓储实现
 */
@Repository
@Slf4j
public class PurchaseOrderRepositoryImpl implements PurchaseOrderRepository {

    @Resource
    private PurchaseOrderMapper purchaseOrderMapper;

    @Resource
    private PurchaseOrderProductSnapshotMapper purchaseOrderProductSnapshotMapper;

    @Resource
    private PurchaseOrderConvertor purchaseOrderConvertor;

    @Override
    public PurchaseOrder findByFulfillmentPlatformOrderId(String fulfillmentPlatformOrderId) {
        if (fulfillmentPlatformOrderId == null || fulfillmentPlatformOrderId.isEmpty()) {
            return null;
        }
        PurchaseOrderQueryParam queryParam = new PurchaseOrderQueryParam();
        queryParam.setFulfillmentPlatformOrderId(fulfillmentPlatformOrderId);
        queryParam.setPage(1);
        queryParam.setSize(1);
        List<PurchaseOrderDO> list = purchaseOrderMapper.selectAll(queryParam);
        if (null == list || list.isEmpty()) {
            return null;
        }
        return purchaseOrderConvertor.doToModel(list.get(0));
    }

    @Override
    public PurchaseOrder findById(Long orderId) {
        PurchaseOrderDO purchaseOrderDO = purchaseOrderMapper.selectById(orderId);
        if (null == purchaseOrderDO) {
            return null;
        }

        PurchaseOrder purchaseOrder = purchaseOrderConvertor.doToModel(purchaseOrderDO);

        // 查询商品快照列表
        PurchaseOrderProductSnapshotQueryParam orderProductSnapshotQueryParam=new PurchaseOrderProductSnapshotQueryParam();
        orderProductSnapshotQueryParam.setOrderId(orderId);
        orderProductSnapshotQueryParam.setPage(1);
        orderProductSnapshotQueryParam.setSize(100);
        List<PurchaseOrderProductSnapshotDO> snapshotDOList = purchaseOrderProductSnapshotMapper.selectAll(orderProductSnapshotQueryParam);
        purchaseOrder.setProductSnapshotList(purchaseOrderConvertor.doToProductSnapshotList(snapshotDOList));

        return purchaseOrder;
    }

    @Override
    @Transactional(rollbackFor = Throwable.class)
    public void save(PurchaseOrder order) {
        PurchaseOrderDO purchaseOrderDO = purchaseOrderConvertor.doToModel(order);
        // 保存订单
        purchaseOrderMapper.insert(purchaseOrderDO);
        // 保存商品快照列表
        List<PurchaseOrderProductSnapshotDO> snapshotDOList = purchaseOrderConvertor.doToProductSnapshotDOList(
                order.getProductSnapshotList(), purchaseOrderDO.getId());
        order.setId(purchaseOrderDO.getId());
        if (null != snapshotDOList && !snapshotDOList.isEmpty()) {
            purchaseOrderProductSnapshotMapper.batchInsert(snapshotDOList);
        }
    }

    @Override
    @Transactional(rollbackFor = Throwable.class)
    public void update(PurchaseOrder order) {
        PurchaseOrderDO purchaseOrderDO = purchaseOrderConvertor.doToModel(order);
        // 更新订单
        purchaseOrderMapper.update(purchaseOrderDO);
    }

    @Override
    @Transactional(rollbackFor = Throwable.class)
    public void deleteOrder(Long orderId) {
        // 1. 查询订单关联的所有快照
        PurchaseOrderProductSnapshotQueryParam queryParam = new PurchaseOrderProductSnapshotQueryParam();
        queryParam.setOrderId(orderId);
        queryParam.setPage(1);
        queryParam.setSize(100);
        List<PurchaseOrderProductSnapshotDO> snapshotDOList = purchaseOrderProductSnapshotMapper.selectAll(queryParam);

        // 2. 删除快照
        if (snapshotDOList != null && !snapshotDOList.isEmpty()) {
            List<Long> snapshotIds = snapshotDOList.stream()
                    .map(PurchaseOrderProductSnapshotDO::getId)
                    .collect(Collectors.toList());
            purchaseOrderProductSnapshotMapper.batchDeleteByIds(snapshotIds);
        }

        // 3. 删除订单
        purchaseOrderMapper.deleteById(orderId);
        log.info("deleteOrder 完成，orderId={}, 删除快照数={}", orderId, snapshotDOList != null ? snapshotDOList.size() : 0);
    }

    @Override
    @Transactional(rollbackFor = Throwable.class)
    public void updateOrderStatusAndSnapshotFeature(Long orderId, Integer status, Long snapshotId, Map<String, String> additionalFeature) {
        // 1. 更新订单状态
        PurchaseOrderDO orderDO = purchaseOrderMapper.selectById(orderId);
        if (orderDO == null) {
            log.warn("updateOrderStatusAndSnapshotFeature 订单不存在, orderId={}", orderId);
            return;
        }
        orderDO.setStatus(status);
        purchaseOrderMapper.update(orderDO);

        // 2. 查询指定快照并追加 feature 内容
        PurchaseOrderProductSnapshotDO snapshotDO = purchaseOrderProductSnapshotMapper.selectById(snapshotId);
        if (snapshotDO == null) {
            log.warn("updateOrderStatusAndSnapshotFeature 快照不存在, snapshotId={}", snapshotId);
            return;
        }
        // 合并已有 feature 和新增内容
        Map<String, String> existingFeature = new HashMap<>();
        if (snapshotDO.getFeature() != null && !snapshotDO.getFeature().isEmpty()) {
            existingFeature = JSON.parseObject(snapshotDO.getFeature(), new TypeReference<Map<String, String>>() {});
        }
        if (additionalFeature != null) {
            existingFeature.putAll(additionalFeature);
        }
        snapshotDO.setFeature(JSON.toJSONString(existingFeature));
        purchaseOrderProductSnapshotMapper.update(snapshotDO);
        log.info("updateOrderStatusAndSnapshotFeature 完成, orderId={}, status={}, snapshotId={}", orderId, status, snapshotId);
    }

    @Override
    public void updateSnapshotFeature(Long snapshotId, Map<String, String> additionalFeature) {
        PurchaseOrderProductSnapshotDO snapshotDO = purchaseOrderProductSnapshotMapper.selectById(snapshotId);
        if (snapshotDO == null) {
            log.warn("updateSnapshotFeature 快照不存在, snapshotId={}", snapshotId);
            return;
        }
        // 合并已有 feature 和新增内容
        Map<String, String> existingFeature = new HashMap<>();
        if (snapshotDO.getFeature() != null && !snapshotDO.getFeature().isEmpty()) {
            existingFeature = JSON.parseObject(snapshotDO.getFeature(), new TypeReference<Map<String, String>>() {});
        }
        if (additionalFeature != null) {
            existingFeature.putAll(additionalFeature);
        }
        snapshotDO.setFeature(JSON.toJSONString(existingFeature));
        purchaseOrderProductSnapshotMapper.update(snapshotDO);
        log.info("updateSnapshotFeature 完成, snapshotId={}", snapshotId);
    }
}
