package com.cainiao.tp.nm.plan.policy.common.util;

import com.cainiao.aladdin.lock.Lock;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import org.apache.commons.lang3.StringUtils;


/**
 *
 * http://tiddo.alibaba-inc.com/saas-tair/#/InstanceDetail?username=d72d7419535d4881
 */
public class PolicyLockUtils {

    /**
     * 分布式锁超时时间 单位是秒
     */
    public static final int LOCK_EXPIRE_TPS_HESTIA_MSG = 30;

    /**
     * http://tiddo.alibaba-inc.com/saas-tair/#/InstanceDetail?username=d72d7419535d4881
     */
    public static final int CNM_PLAN_LDB_NAMESPACE = 5783;

    public static final String POLICY_INSTANCE_LOCK_PREFIX = "tp_cnm_plan_policy_instance_lock_";
    public static final String POLICY_TEMPLATE_LOCK_PREFIX = "tp_cnm_plan_policy_template_lock_";

    public static Lock getPolicyInstanceLock(Long templateId) {
        AssertUtil.isTrue(null != templateId, "参数不能为空");
        String key = POLICY_INSTANCE_LOCK_PREFIX + templateId;
        Lock lock = new Lock(key);
        lock.setNamespace(CNM_PLAN_LDB_NAMESPACE);
        lock.setExpire(LOCK_EXPIRE_TPS_HESTIA_MSG);
        return lock;
    }

    public static Lock getPolicyTemplateLock(String bizType) {
        AssertUtil.isTrue(StringUtils.isNotBlank(bizType), "参数不能为空");
        String key = POLICY_TEMPLATE_LOCK_PREFIX + bizType;
        Lock lock = new Lock(key);
        lock.setNamespace(CNM_PLAN_LDB_NAMESPACE);
        lock.setExpire(LOCK_EXPIRE_TPS_HESTIA_MSG);
        return lock;
    }
}
