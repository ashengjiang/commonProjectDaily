package com.cainiao.tp.nm.plan.policy.application.event.event;

import com.cainiao.aladdin.domain.BaseBean;
import lombok.Data;

/**
 * @code date 2024年10月28日 18:00
 * @code desc:
 */
@Data
public class PolicyInstanceCreateEvent extends BaseBean {

    /**
     * 模版id
     */
    private Long templateId;

    /**
     * 实例id
     */
    private Long instanceId;

    /**
     * 激励方案类型
     */
    private String incentivePlanType;

    /**
     * 开始时间
     * 格式如"2025-01-01"
     */
    private String startTime;

    /**
     * 提报人
     */
    private Long operatorId;

}
