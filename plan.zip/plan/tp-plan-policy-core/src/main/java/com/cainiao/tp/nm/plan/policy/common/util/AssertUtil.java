package com.cainiao.tp.nm.plan.policy.common.util;

import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.aladdin.exception.AladdinParamException;
import com.cainiao.aladdin.log.AladdinErrorCode;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.Collection;

public class AssertUtil {
    public AssertUtil() {
    }

    public static void notNull(Object object) {
        notNull(object, "参数校验失败");
    }

    public static void notNull(Object object, String message) {
        if (object == null) {
            //todo 异常统一修改转变
            throw new RuntimeException(message);
        }
    }


    public static void notBlank(String str, String message) {
        if (StringUtils.isBlank(str)) {
            //todo 异常统一修改转变
            throw new RuntimeException(message);
        }
    }

    public static void notEmpty(Collection list, String message) {
        if (CollectionUtils.isEmpty(list)) {
            //todo 异常统一修改转变
            throw new RuntimeException(message);
        }
    }

    public static void notEmpty(String message, Object... objects) {
        notEmpty(message, message, objects);
    }

    public static void notEmpty(String errorCode, String message, Object... objects) {
        Object[] objs = objects;
        int len = objects.length;

        for (int i = 0; i < len; ++i) {
            Object object = objs[i];
            if (object == null) {
                throw new AladdinBizException(errorCode, message);
            }

            if (object instanceof String && StringUtils.isEmpty((String) object)) {
                throw new AladdinBizException(errorCode, message);
            }

            if (object instanceof Collection && CollectionUtils.isEmpty((Collection) object)) {
                throw new AladdinBizException(errorCode, message);
            }
        }

    }

    public static void empty(String message, Object... objects) {
        empty(message, message, objects);
    }

    public static void empty(String errorCode, String message, Object... objects) {
        Object[] var3 = objects;
        int var4 = objects.length;

        for (int var5 = 0; var5 < var4; ++var5) {
            Object object = var3[var5];
            if (object instanceof String && StringUtils.isNotEmpty((String) object)) {
                throw new AladdinBizException(errorCode, message);
            }

            if (object instanceof Collection && CollectionUtils.isNotEmpty((Collection) object)) {
                throw new AladdinBizException(errorCode, message);
            }

            if (object != null) {
                throw new AladdinBizException(errorCode, message);
            }
        }

    }

    public static void isTrue(boolean expression, String message) {
        isTrue(expression, null, message);
    }

    public static void isTrue(boolean expression, String errorCode, String message) {
        if (!expression) {
            throw new AladdinBizException(errorCode, message);
        }
    }

}
