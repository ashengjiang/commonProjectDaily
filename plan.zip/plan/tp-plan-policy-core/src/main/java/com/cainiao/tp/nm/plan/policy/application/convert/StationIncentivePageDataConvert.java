package com.cainiao.tp.nm.plan.policy.application.convert;


import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.tp.nm.plan.api.policy.application.dto.StationIncentivePageConfigHolder;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.StationIncentiveBillDetailDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.heavy.IncentiveCardDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.heavy.IncentiveTipDTO;
import com.cainiao.tp.nm.plan.api.policy.common.constants.StationIncentivePlanEnum;
import com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.cainiao.tp.nm.plan.api.policy.common.constants.IncentivePageConstants.TAG_INVALID;
import static com.cainiao.tp.nm.plan.api.policy.common.constants.IncentivePageConstants.TAG_PRIMARY;
import static com.cainiao.tp.nm.plan.api.policy.common.constants.IncentivePageConstants.TAG_SECONDARY;
import static com.cainiao.tp.nm.plan.api.policy.common.constants.IncentivePageConstants.TAG_SUCCESS;
import static com.cainiao.tp.nm.plan.api.policy.common.constants.IncentivePageConstants.TAG_WARNING;
import static com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils.CHECK_DATE_PATTERN;
import static com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils.CHECK_DATE_TIME_PATTERN;
import static com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils.DATE_PATTERN;
import static com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils.DS_DATETIME_PATTERN;
import static com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils.DS_DATE_PATTERN;
import static com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils.MON_DAY_PATTERN;
import static com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils.getCurrentYearMonthDifference;


/**
 * @code date 2025年07月04日 17:30
 * @code desc:站点激励页面数据转化
 */
public class StationIncentivePageDataConvert {


    public static IncentiveTipDTO assembleTip(List<IncentiveCardDTO> cardDTOList,String source) {
        if (CollectionUtils.isEmpty(cardDTOList)) {
            return null;
        }
        IncentiveCardDTO cardDTO = cardDTOList.stream().min(Comparator.comparing(IncentiveCardDTO::getPeriod)).orElse(null);
        if (cardDTO == null) {
            return null;
        }
        StationIncentivePageConfigHolder instance = StationIncentivePageConfigHolder.getINSTANCE();
        String tipTitle = instance.getTipTitle(source);
        IncentiveTipDTO tipVO = new IncentiveTipDTO();
        String content = String.format(tipTitle, cardDTO.getPeriod(), cardDTO.getIncentiveAmount());
        tipVO.setContent(content);
        return tipVO;
    }

    public static IncentiveCardDTO assembleCard(List<StationIncentiveBillDetailDTO> detailList, String quarter) {
        if (CollectionUtils.isEmpty(detailList)) {
            return null;
        }
        List<String> cycleNumList = detailList.stream().map(StationIncentiveBillDetailDTO::getCycleNum).distinct().collect(Collectors.toList());
        AssertUtil.isTrue(cycleNumList.size() == 1, "站点考核期数不唯一");
        String cycleNum = cycleNumList.stream().findAny().orElseThrow(() -> new AladdinBizException("Err", "站点考核期数获取失败"));
        IncentiveCardDTO cardDTO = new IncentiveCardDTO();
        cardDTO.setTitle(String.format("第%s期补贴", cycleNum));
        cardDTO.setPeriod(cycleNum);
        Map<String, StationIncentiveBillDetailDTO> detailDTOMap = detailList.stream().collect(Collectors.toMap(StationIncentiveBillDetailDTO::getIncentivePlanType, Function.identity(), (v1, v2) -> v1));
        List<IncentiveCardDTO.DataItem> dataItems = null;
        if (quarter.startsWith("fy25")) {
            dataItems = buildIncentiveCardDataItemWithoutFlexible(detailDTOMap, cardDTO);
        } else {
            dataItems = buildIncentiveCardDataItem(detailDTOMap, cardDTO);
        }
        List<IncentiveCardDTO.Tag> tags = buildIncentiveCardTag(detailDTOMap);
        cardDTO.setData(dataItems);
        cardDTO.setTags(tags);
        return cardDTO;
    }



    private static List<IncentiveCardDTO.DataItem> buildIncentiveCardDataItem(Map<String, StationIncentiveBillDetailDTO> detailMap, IncentiveCardDTO cardDTO) {
        if (MapUtils.isEmpty(detailMap)) {
            return Lists.newArrayList();
        }
        if (detailMap.size() > 1) {
            LinkedHashMap<String, StationIncentiveBillDetailDTO> linkedHashMap = Maps.newLinkedHashMap();
            linkedHashMap.put(StationIncentivePlanEnum.BASE.getType(), detailMap.get(StationIncentivePlanEnum.BASE.getType()));
            linkedHashMap.put(StationIncentivePlanEnum.FLEXIBLE.getType(), detailMap.get(StationIncentivePlanEnum.FLEXIBLE.getType()));
            detailMap = linkedHashMap;
        }
        List<String> billShowBnt = Lists.newArrayList();
        List<IncentiveCardDTO.DataItem> dataItemsList = Lists.newArrayList();
        BigDecimal incentiveAmount = getIncentiveAmount(detailMap);
        cardDTO.setIncentiveAmount(incentiveAmount.toString());
        AtomicReference<IncentiveCardDTO.DataItem> baseExamineDate = new AtomicReference<>();
        detailMap.forEach((incentiveType, detailDTO) -> {
            // 控制前端是否展示账单按钮
            billShowBnt.add(incentiveType);
            incentiveType = StationIncentivePlanEnum.getDesc(incentiveType);
            LocalDate checkStartDate = DateUtils.strToLocalDate(detailDTO.getCycleRange().split("~")[0], CHECK_DATE_PATTERN);
            LocalDate checkEndDate = DateUtils.strToLocalDate(detailDTO.getCycleRange().split("~")[1] + " 235959", CHECK_DATE_TIME_PATTERN);
            boolean inCheckRange = checkStartDate.isBefore(LocalDate.now()) && checkEndDate.isAfter(LocalDate.now());
            BigDecimal amountYuan = getBillAmountCent(detailDTO);
            boolean meetFinance = detailDTO.getIsSatisfied();
            // 已付款: 金额大于0 有账单日期
            if (incentiveAmount.compareTo(BigDecimal.ZERO) > 0 && StringUtils.isNotBlank(detailDTO.getChargeOffBillTime())) {
                // 已支付
                cardDTO.setPaid(billShowBnt);
                // 账单日期
                LocalDate billDate = DateUtils.strToLocalDate(detailDTO.getBillTime(), DS_DATETIME_PATTERN);
                cardDTO.setBillDate(DateUtils.localDateToStr(billDate, DS_DATE_PATTERN));
                // 到账日期
                dataItemsList.add(buildContentItem(incentiveType + "金额", amountYuan + "元"));
                dataItemsList.add(buildContentItem(incentiveType + "到账时间", detailDTO.getChargeOffBillTime()));
            } else {
                // 未支付
                // 是否有未发放原因
                if (amountYuan.equals(BigDecimal.ZERO) && StringUtils.isNotBlank(detailDTO.getNoSatisfyReason())) {
                    if (meetFinance && !inCheckRange) {
                        dataItemsList.add(buildContentItem(incentiveType + "到账时间", "等待到账"));
                    } else if (!meetFinance) {
                        dataItemsList.add(buildContentItem(incentiveType + "未发原因", formatNoStatSatisfyReason(detailDTO.getNoSatisfyReason())));
                    } else {
                        dataItemsList.add(buildContentItem(incentiveType + "未发原因", "在考核期中"));
                    }
                } else if (!amountYuan.equals(BigDecimal.ZERO) && StringUtils.isBlank(detailDTO.getNoSatisfyReason())) {
                    dataItemsList.add(buildContentItem(incentiveType + "未发原因", "等待到账"));
                }
            }
            if (StationIncentivePlanEnum.BASE.getDesc().equals(incentiveType)) {
                baseExamineDate.set(buildContentItem("考核日期", DateUtils.localDateToStr(checkStartDate, DATE_PATTERN) + "~" + DateUtils.localDateToStr(checkEndDate, MON_DAY_PATTERN)));
            }
        });
        // 将基础考核日期放到最后
        dataItemsList.add(baseExamineDate.get());
        return dataItemsList;
    }

    /**
     * 构建激励卡数据项，不包含灵活激励
     *
     * @param detailMap 激励明细
     * @param cardDTO   激励卡
     * @return 激励卡数据项
     */
    private static List<IncentiveCardDTO.DataItem> buildIncentiveCardDataItemWithoutFlexible(Map<String, StationIncentiveBillDetailDTO> detailMap, IncentiveCardDTO cardDTO) {
        if (MapUtils.isEmpty(detailMap)) {
            return Lists.newArrayList();
        }
        List<String> billShowBnt = Lists.newArrayList();
        List<IncentiveCardDTO.DataItem> dataItemsList = Lists.newArrayList();
        BigDecimal incentiveAmount = getIncentiveAmount(detailMap);
        cardDTO.setIncentiveAmount(incentiveAmount.toString());
        AtomicReference<IncentiveCardDTO.DataItem> baseExamineDate = new AtomicReference<>();

        // 此处只会有基础激励
        detailMap.forEach((incentiveType, detailDTO) -> {
            // 控制前端是否展示账单按钮
            billShowBnt.add(incentiveType);
            incentiveType = StationIncentivePlanEnum.getDesc(incentiveType);
            LocalDate checkStartDate = DateUtils.strToLocalDate(detailDTO.getCycleRange().split("~")[0], CHECK_DATE_PATTERN);
            LocalDate checkEndDate = DateUtils.strToLocalDate(detailDTO.getCycleRange().split("~")[1] + " 235959", CHECK_DATE_TIME_PATTERN);
            boolean inCheckRange = checkStartDate.isBefore(LocalDate.now()) && checkEndDate.isAfter(LocalDate.now());
            BigDecimal amountYuan = getBillAmountCent(detailDTO);
            boolean meetFinance = detailDTO.getIsSatisfied();
            // 已付款: 金额大于0 有账单日期
            if (incentiveAmount.compareTo(BigDecimal.ZERO) > 0 && StringUtils.isNotBlank(detailDTO.getChargeOffBillTime())) {
                // 已支付
                cardDTO.setPaid(billShowBnt);
                // 账单日期 与fy26不同
                LocalDate billDate = DateUtils.strToLocalDate(detailDTO.getChargeOffBillTime(), DS_DATETIME_PATTERN);
                cardDTO.setBillDate(DateUtils.localDateToStr(billDate, DS_DATE_PATTERN));
                // 到账日期
                dataItemsList.add(buildContentItem("到账时间", detailDTO.getChargeOffBillTime()));
            } else {
                // 是否有未发放原因
                if (amountYuan.equals(BigDecimal.ZERO) && StringUtils.isNotBlank(detailDTO.getNoSatisfyReason())) {
                    if (meetFinance && !inCheckRange) {
                        dataItemsList.add(buildContentItem("到账时间", "等待到账"));
                    } else if (!meetFinance) {
                        dataItemsList.add(buildContentItem("未发原因", formatNoStatSatisfyReason(detailDTO.getNoSatisfyReason())));
                    } else {
                        dataItemsList.add(buildContentItem("未发原因", "在考核期中"));
                    }
                } else if (!amountYuan.equals(BigDecimal.ZERO) && StringUtils.isBlank(detailDTO.getNoSatisfyReason())) {
                    dataItemsList.add(buildContentItem("未发原因", "等待到账"));
                }
            }
            if (StationIncentivePlanEnum.BASE.getDesc().equals(incentiveType)) {
                baseExamineDate.set(buildContentItem("考核日期", DateUtils.localDateToStr(checkStartDate, DATE_PATTERN) + "~" + DateUtils.localDateToStr(checkEndDate, MON_DAY_PATTERN)));
            }
        });
        dataItemsList.add(baseExamineDate.get());
        return dataItemsList;
    }

    private static BigDecimal getBillAmountCent(StationIncentiveBillDetailDTO detailDTO) {
        // 已经下发金额，如过已经下发的金额为空 则使用 amountCent
        String theoreticalAmount = detailDTO.getTheoreticalAmount();
        if (StringUtils.isNotBlank(theoreticalAmount)) {
            return BigDecimal.valueOf(Long.parseLong(theoreticalAmount)).divide(BigDecimal.valueOf(100), 0, RoundingMode.DOWN);
        }
        //如果没有到账时间和 判断是账单统计月份是否在当前月份之前
        // <= 1 表示结算测最迟2个月会发放金额，如果2个月都没有发放，代表以后也不会发放，就算后续计算出改月需要发放的金额 也不会发放，展示为金额0
        boolean condition = getCurrentYearMonthDifference(detailDTO.getStatsMonth()) <= 1;
        if (!condition && StringUtils.isBlank(detailDTO.getChargeOffBillTime())) {
            return BigDecimal.ZERO;
        }
        long amountCent = detailDTO.getAmountCent() == null ? 0 : Long.parseLong(detailDTO.getAmountCent());
        return BigDecimal.valueOf(amountCent).divide(BigDecimal.valueOf(100), 0, RoundingMode.DOWN);
    }


    private static List<IncentiveCardDTO.Tag> buildIncentiveCardTag(Map<String, StationIncentiveBillDetailDTO> detailMap) {
        List<IncentiveCardDTO.Tag> tags = Lists.newArrayList();
        BigDecimal incentiveAmount = getIncentiveAmount(detailMap);
        Boolean inCheckRange = checkIsInCheckRange(detailMap);
        Boolean hasChargeOffBillTime = hasChargeOffBillTime(detailMap);
        if (incentiveAmount.compareTo(BigDecimal.ZERO) > 0 && hasChargeOffBillTime) {
            tags.add(buildTagItem(TAG_SUCCESS, "已发放", TAG_PRIMARY));
            tags.add(buildTagItem(TAG_SUCCESS, "+" + incentiveAmount + "元", TAG_SECONDARY));
        } else {
            // 设置标签
            String tagStatus = inCheckRange ? TAG_INVALID : TAG_WARNING;
            tags.add(buildTagItem(tagStatus, "未发放", TAG_PRIMARY));
            tags.add(buildTagItem(tagStatus, "预计+" + incentiveAmount + "元", TAG_SECONDARY));
        }
        return tags;
    }

    private static Boolean checkIsInCheckRange(Map<String, StationIncentiveBillDetailDTO> detailMap) {
        if (MapUtils.isEmpty(detailMap)) {
            return false;
        }
        return detailMap.values().stream().map(StationIncentiveBillDetailDTO::getCycleRange)
                .allMatch(range -> {
                    // 考核范围时间
                    LocalDate checkStartDate = DateUtils.strToLocalDate(range.split("~")[0], CHECK_DATE_PATTERN);
                    LocalDate checkEndDate = DateUtils.strToLocalDate(range.split("~")[1] + " 235959", CHECK_DATE_TIME_PATTERN);
                    // 是否在考核期
                    return checkStartDate.isBefore(LocalDate.now()) && checkEndDate.isAfter(LocalDate.now());
                });
    }

    private static Boolean hasChargeOffBillTime(Map<String, StationIncentiveBillDetailDTO> detailMap) {
        if (MapUtils.isEmpty(detailMap)) {
            return false;
        }
        // 特殊情况会出现 通一期账单数据，基础有到账时间，灵活没有，当前一期中只要有到账时间 就表示改期已经下发过金额
        // 灵活没有账单时间，但却有金额，表示本期账单中没有灵活补贴，存在的金额为后期计算不作数
        return detailMap.values().stream().map(StationIncentiveBillDetailDTO::getChargeOffBillTime)
                .anyMatch(StringUtils::isNotBlank);
    }


    private static BigDecimal getIncentiveAmount(Map<String, StationIncentiveBillDetailDTO> detailMap) {
        if (MapUtils.isEmpty(detailMap)) {
            return BigDecimal.ZERO;
        }
        Long reduce = detailMap.values().stream()
                .map(dto -> {
                    String theoreticalAmount = dto.getTheoreticalAmount();
                    if (StringUtils.isNotBlank(theoreticalAmount)) {
                        return theoreticalAmount;
                    }
                    // 如果没有到账时间和 判断是账单统计月份是否在当前月份之前
                    // <= 1 表示结算测最迟2个月会发放金额，如果2个月都没有发放，代表以后也不会发放，就算后续计算出改月需要发放的金额 也不会发放，展示为金额0
                    boolean condition = getCurrentYearMonthDifference(dto.getStatsMonth()) <= 1;
                    if (!condition && StringUtils.isBlank(dto.getChargeOffBillTime())) {
                        return "0";
                    }
                    return StringUtils.isBlank(dto.getAmountCent()) ? "0" : dto.getAmountCent();
                })
                .filter(StringUtils::isNotBlank)
                .map(Long::parseLong)
                .reduce(0L, Long::sum);
        return BigDecimal.valueOf(reduce).divide(BigDecimal.valueOf(100), 0, RoundingMode.DOWN);
    }


    private static IncentiveCardDTO.DataItem buildContentItem(String label, String content) {
        IncentiveCardDTO.DataItem dataItem = new IncentiveCardDTO.DataItem();
        dataItem.setLabel(label);
        dataItem.setContent(content);
        dataItem.setType("text");
        dataItem.setHasArrow(false);
        return dataItem;
    }

    private static IncentiveCardDTO.Tag buildTagItem(String status, String text, String type) {
        IncentiveCardDTO.Tag tag = new IncentiveCardDTO.Tag();
        tag.setStatus(status);
        tag.setText(text);
        tag.setType(type);
        return tag;
    }

    /**
     * 格式化不满足结算的原因
     */
    private static String formatNoStatSatisfyReason(String noSatisfyReason) {
        if (StringUtils.isBlank(noSatisfyReason)) {
            return "暂无原因";
        }
        List<String> collect = Arrays.stream(StringUtils.split(noSatisfyReason, "/")).filter(StringUtils::isNotBlank).collect(Collectors.toList());
        return StringUtils.join("、", collect);
    }

}
