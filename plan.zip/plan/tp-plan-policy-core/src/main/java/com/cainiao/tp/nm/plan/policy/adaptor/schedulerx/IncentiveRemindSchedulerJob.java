package com.cainiao.tp.nm.plan.policy.adaptor.schedulerx;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.schedulerx.worker.domain.JobContext;
import com.alibaba.schedulerx.worker.processor.JavaProcessor;
import com.alibaba.schedulerx.worker.processor.ProcessResult;
import com.cainiao.aladdin.log.AladdinMapLog;
import com.cainiao.aladdin.log.BizType;
import com.cainiao.aladdin.log.utils.AladdinLogUtil;
import com.cainiao.tp.nm.plan.infra.port.policy.IncentiveRemindStationManager;
import com.cainiao.tp.nm.plan.infra.port.policy.IncentiveRemindStationManager.ScrollResult;
import com.cainiao.tp.nm.plan.infra.port.policy.IncentiveRemindStationManager.StationJoinInfo;
import com.cainiao.tp.nm.plan.policy.application.service.IncentiveRemindApplicationService;
import com.taobao.eagleeye.EagleEye;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * 站点实操激励提醒定时任务
 * Cron：0 0 7 * * ?（每日凌晨7点触发）
 * 功能：分页查询入驻时间 >= 2026-01-01 的站点，逐站点判断是否需要发送激励提醒通知
 *
 * @date 2026-03-27
 */
@Slf4j
@Component
public class IncentiveRemindSchedulerJob extends JavaProcessor {

    /**
     * 每页查询站点数量
     */
    private static final int PAGE_SIZE = 500;

    /**
     * 激励提醒起始入驻时间（仅处理该日期及之后入驻的站点）
     */
    private static final LocalDate STATION_JOIN_START_DATE = LocalDate.of(2026, 1, 1);

    @Resource
    private IncentiveRemindStationManager incentiveRemindStationManager;

    @Resource
    private IncentiveRemindApplicationService incentiveRemindApplicationService;

    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd");

    @Override
    public ProcessResult process(JobContext jobContext) throws Exception {

        String traceId = EagleEye.generateTraceId(null);
        EagleEye.startTrace(traceId, "schedulerx", EagleEye.TYPE_CUSTOM_TRACE);
        AladdinMapLog jobLog = AladdinLogUtil.newMapLog("IncentiveRemindSchedulerJob.process", BizType.DEFAULT);
        String jobParameters = jobContext.getJobParameters();
        log.info("IncentiveRemindSchedulerJob 开始执行，traceId={} jobParameters={}", traceId,jobParameters);
        if(StringUtils.isNotBlank(jobParameters)) {
            JobParameterDTO jobParameterDTO = JSONObject.parseObject(jobParameters, JobParameterDTO.class);
            if(jobParameterDTO.getStationId() != null) {
                LocalDate joinDate = LocalDate.parse(jobParameterDTO.getJoinDate(), DATE_FORMATTER);
                processStation(new StationJoinInfo(jobParameterDTO.getStationId(),joinDate));
                return new ProcessResult(true);
            }
        }
        int batchIndex =0;
        try {
            String scrollId = null;
            while (true) {
                AladdinMapLog pageLog = AladdinLogUtil.newMapLog("IncentiveRemindSchedulerJob.processPage", BizType.DEFAULT);
                pageLog.addContext("batchIndex", batchIndex);
                pageLog.addContext("scrollId", scrollId);

                // scroll 查询站点列表（含入驻日期），首次 scrollId 为 null
                ScrollResult scrollResult = incentiveRemindStationManager.scrollStations(
                        STATION_JOIN_START_DATE, PAGE_SIZE, scrollId);
                log.info("IncentiveRemindSchedulerJob 站点列表查询结果，scrollId={},batchIndex={}, size={}, total={}",scrollId,batchIndex, scrollResult.getStationList().size(), scrollResult.getTotalCount());

                List<StationJoinInfo> stationList = scrollResult.getStationList();
                pageLog.addParam("stationCount", stationList == null ? 0 : stationList.size());
                AladdinLogUtil.log(log, pageLog);
                //第一次scroll，不返回任何数据
                if (batchIndex!=0 && (stationList == null || stationList.isEmpty())) {
                    log.info("IncentiveRemindSchedulerJob 站点列表为空，结束 scroll，batchIndex={}", batchIndex);
                    break;
                }
                
                // 逐站点处理，单站点异常不阻塞整体任务
                for (StationJoinInfo stationJoinInfo : stationList) {
                    processStation(stationJoinInfo);
                    Thread.sleep(300L);
                }
                
                // 获取下次查询的 scrollId
                scrollId = scrollResult.getScrollId();
                if (scrollId == null) {
                    log.info("IncentiveRemindSchedulerJob scrollId 为空，scroll 结束，batchIndex={}", batchIndex);
                    break;
                }
                batchIndex++;
            }

            jobLog.addParam("result", "success");
            AladdinLogUtil.log(log, jobLog);
            return new ProcessResult(true);
        } catch (Exception e) {
            AladdinLogUtil.log(log, e, jobLog);
            return new ProcessResult(false);
        }
    }

    /**
     * 处理单个站点的激励提醒逻辑，异常捕获后记录日志，不向上抛出
     *
     * @param stationJoinInfo 站点入驻信息（含站点ID和入驻日期）
     */
    private void processStation(StationJoinInfo stationJoinInfo) {
        AladdinMapLog stationLog = AladdinLogUtil.newMapLog("IncentiveRemindSchedulerJob.processStation", BizType.DEFAULT);
        stationLog.addParam("stationId", stationJoinInfo.getStationId());
        stationLog.addParam("joinDate", stationJoinInfo.getJoinDate().toString());
        try {
            incentiveRemindApplicationService.processIncentiveRemind(
                    stationJoinInfo.getStationId(), stationJoinInfo.getJoinDate());
            AladdinLogUtil.log(log, stationLog);
        } catch (Exception e) {
            AladdinLogUtil.log(log, e, stationLog);
        }
    }

    @lombok.Data
    public static class JobParameterDTO {
        private String stationId;

        private String joinDate;
    }
}
