package com.cainiao.tp.nm.plan.policy.application.event;

import com.cainiao.tp.nm.plan.policy.application.event.event.PolicyInstanceCreateEvent;

/**
 * @code date 2025年3月10日
 * @code desc:政策实例 应用事件发布
 */
public interface PolicyInstanceAppEventPublisher {

    /**
     * 政策实例创建事件
     * @return
     */
    void create(PolicyInstanceCreateEvent policyInstanceCreateEvent);
}
