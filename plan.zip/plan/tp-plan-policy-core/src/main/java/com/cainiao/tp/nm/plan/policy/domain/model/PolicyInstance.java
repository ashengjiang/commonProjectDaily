package com.cainiao.tp.nm.plan.policy.domain.model;

import com.cainiao.aladdin.domain.BaseBean;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyInstanceCreateParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyInstanceEffectParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyInstanceLoseEffectParam;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyFeatureConstants;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyInstanceApprovalStatusEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyInstanceStatusEnum;
import com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils;
import com.cainiao.tp.nm.plan.policy.domain.model.valobj.incentiveplan.IncentivePlan;
import com.cainiao.tp.nm.plan.policy.domain.model.valobj.incentiverule.IncentiveRule;
import com.google.common.collect.Maps;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @code date 2025年05月29日 13:56
 * @code desc: 政策实例实体类
 */
@Getter
@Builder
public class PolicyInstance extends BaseBean {

    /**
     * 实例id
     */
    private Long id;

    /**
     * 模版id
     */
    private Long templateId;

    /**
     * 客户类型
     */
    private String customType;

    /**
     * 业务类型
     */
    private String bizType;

    /**
     * 激励方案类型
     */
    private String incentivePlanType;

    /**
     * 激励方案code
     */
    private String incentivePlanCode;

    /**
     * 开始时间
     */
    private LocalDateTime startTime;

    /**
     * 结束时间
     */
    private LocalDateTime endTime;

    /**
     * 生效时间
     */
    private LocalDateTime effectTime;

    /**
     * 失效时间
     */
    private LocalDateTime loseEffectTime;

    /**
     * 状态
     */
    private Byte status;

    /**
     * 审批状态
     */
    private Byte approvalStatus;

    /**
     * 最后操作人ID
     */
    private Long lastOperatorId;

    /**
     * 激励规则
     */
    @Setter
    private List<IncentiveRule> incentiveRuleList;

    /**
     * feature
     */
    private Map<String, String> featureMap;

    /**
     * 创建时间
     */
    private LocalDateTime gmtCreate;

    /**
     * 修改时间
     */
    private LocalDateTime gmtModified;

    /**
     * 创建一个实例
     * @return
     */
    public static PolicyInstance create(PolicyTemplate policyTemplate, PolicyInstanceCreateParam param){
        LocalDateTime startTime = StringUtils.isNotBlank(param.getStartTime())
                ? DateUtils.toLocalDateTimeYmdStart(param.getStartTime()) : null;

        Optional<IncentivePlan> first = policyTemplate.getIncentivePlanList().stream()
                .filter(plan -> plan.getIncentivePlanType().equals(param.getIncentivePlanType())).findFirst();
        AssertUtil.isTrue(first.isPresent(), "激励类型不存在");
        IncentivePlan incentivePlan = first.get();

        // 创建激励规则
        List<IncentiveRule> ruleList = param.getFillList().stream()
                .map(fill -> IncentiveRule.create(incentivePlan, fill)).collect(Collectors.toList());

        PolicyInstanceBuilder builder = PolicyInstance.builder()
                .templateId(policyTemplate.getId())
                .customType(policyTemplate.getCustomType())
                .bizType(policyTemplate.getBizType())
                .incentivePlanType(param.getIncentivePlanType())
                .incentivePlanCode(incentivePlan.getIncentivePlanCode())
                .startTime(startTime)
                .endTime(policyTemplate.getEndTime())
                .status(PolicyInstanceStatusEnum.WAITING_EFFECT.getCode())
                .lastOperatorId(param.getOperatorId())
                .featureMap(param.getFeatureMap())
                .incentiveRuleList(ruleList);
        return builder.build();
    }

    /**
     * 生效
     */
    public void effect(PolicyInstanceEffectParam param){
        AssertUtil.isTrue(PolicyInstanceStatusEnum.WAITING_EFFECT.getCode().equals(this.status)
                , "状态机异常");
        AssertUtil.isTrue(null == param.getApprovalStatus()
                        || PolicyInstanceApprovalStatusEnum.PASS.getCode().equals(param.getApprovalStatus())
                , "状态机异常");

        LocalDateTime now = LocalDateTime.now();
        this.status = PolicyInstanceStatusEnum.EFFECT.getCode();
        this.approvalStatus = param.getApprovalStatus();
        this.effectTime = now;
        addFeature(param.getFeatureMap());
        if(null == startTime){
            String effectOpportunity = MapUtils.getObject(featureMap, PolicyFeatureConstants.EFFECT_OPPORTUNITY);
            AssertUtil.isTrue(PolicyFeatureConstants.EFFECT_OPPORTUNITY_PASS_MORROW.equals(effectOpportunity), "数据异常");
            this.startTime = DateUtils.getTomorrowStartDateTime(now.toLocalDate());
        }
        AssertUtil.isTrue(this.endTime.compareTo(this.startTime)>0, "政策周期已结束，不允许变更状态");
    }

    public void effect(){
        AssertUtil.isTrue(PolicyInstanceStatusEnum.WAITING_EFFECT.getCode().equals(this.status)
                , "状态机异常");

        LocalDateTime now = LocalDateTime.now();
        this.status = PolicyInstanceStatusEnum.EFFECT.getCode();
        this.effectTime = now;
        if(null == startTime){
            String effectOpportunity = MapUtils.getObject(featureMap, PolicyFeatureConstants.EFFECT_OPPORTUNITY);
            AssertUtil.isTrue(PolicyFeatureConstants.EFFECT_OPPORTUNITY_PASS_MORROW.equals(effectOpportunity), "数据异常");
            this.startTime = DateUtils.getTomorrowStartDateTime(now.toLocalDate());
        }
        AssertUtil.isTrue(this.endTime.compareTo(this.startTime)>0, "政策周期已结束，不允许变更状态");
    }

    /**
     * 失效
     */
    public void loseEffect(PolicyInstanceLoseEffectParam param){
        AssertUtil.isTrue(PolicyInstanceStatusEnum.WAITING_EFFECT.getCode().equals(this.status)
                , "状态机异常");
        AssertUtil.isTrue(null == param.getApprovalStatus()
                        || PolicyInstanceApprovalStatusEnum.REFUSE.getCode().equals(param.getApprovalStatus())
                        || PolicyInstanceApprovalStatusEnum.OVERTIME_AUTO_REFUSE.getCode().equals(param.getApprovalStatus())
                , "状态机异常");

        this.status = PolicyInstanceStatusEnum.LOSE_EFFECT.getCode();
        this.approvalStatus = param.getApprovalStatus();
        this.loseEffectTime = LocalDateTime.now();
        addFeature(param.getFeatureMap());
    }

    /**
     * 设置审批状态是审批中
     */
    public void approvaling(){
        AssertUtil.isTrue(PolicyInstanceStatusEnum.WAITING_EFFECT.getCode().equals(this.status), "状态机异常");
        this.approvalStatus = PolicyInstanceApprovalStatusEnum.APPROVALING.getCode();
    }

    public void addFeature(Map<String, String> featureMap){
        if(MapUtils.isEmpty(featureMap)){
            return;
        }

        if(null == this.featureMap){
            this.featureMap = Maps.newHashMap();
        }

        this.featureMap.putAll(featureMap);
    }

}
