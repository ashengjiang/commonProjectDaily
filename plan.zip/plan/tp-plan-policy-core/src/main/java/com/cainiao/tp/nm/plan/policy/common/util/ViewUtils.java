package com.cainiao.tp.nm.plan.policy.common.util;

import com.alibaba.fastjson.JSONObject;
import com.cainiao.tp.nm.plan.api.policy.application.dto.ViewHeadDTO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.*;

@Slf4j
public class ViewUtils {

    private final static String SPLIT = "[.]";


    public static LinkedHashMap<String, Object> getViewData(List<ViewHeadDTO> header, JSONObject sourceData) {
        LinkedHashMap<String, Object> resultMap = new LinkedHashMap<>();
        if (CollectionUtils.isEmpty(header) || null == sourceData) {
            return resultMap;
        }
        header.forEach(head -> {
            Object value = getValue(head, sourceData);
            if (null == value) {
                value = head.getDefaultValue();
            }
            resultMap.put(head.getKey(), value);
        });
        return resultMap;
    }

    /**
     * 可以在这里扩展支持更多能力
     *
     * @param head       表头
     * @param sourceData 源数据
     * @return return
     */
    private static Object getValue(ViewHeadDTO head, JSONObject sourceData) {
        String obtainValueKey = head.getObtainValueKey();
        if (StringUtils.isBlank(obtainValueKey)) {
            obtainValueKey = head.getKey();
        }
        String[] segments = obtainValueKey.split(SPLIT);
        JSONObject initJson = sourceData;
        Object value = null;
        for (int i = 0; i < segments.length; i++) {
            String segment = segments[i];
            Object objectValue = initJson.get(segment);
            if (segments.length == i + 1) {
                value = objectValue;
                break;
            }
            if (objectValue instanceof JSONObject) {
                initJson = (JSONObject) objectValue;
            } else {
                log.error("ViewUtils#getValue|error=config error,obtainValueKey={},sourceData={}", obtainValueKey, sourceData);
                break;
            }
        }
        return value;
    }

}
