package com.cainiao.tp.nm.plan.policy.application.extension.definition;

import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.aladdin.utils.Safes;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.tp.nm.plan.api.policy.application.dto.*;
import com.cainiao.tp.nm.plan.api.policy.application.dto.base.BaseTableDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.base.ColumnDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiverule.IncentiveRuleDetailDTO;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyCustomTypeEnum;
import com.cainiao.tp.nm.plan.infra.port.policy.DivisionManager;
import com.cainiao.tp.nm.plan.api.policy.common.constants.DashBoardViewTypeEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.IncentivePlanStationTypeEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyBizTypeEnum;
import com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils;
import com.google.common.collect.Lists;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.cainiao.tp.nm.plan.policy.application.convert.PolicyInstanceRuleApplicationConvert.buildDivisionMap;
import static com.cainiao.tp.nm.plan.policy.application.convert.PolicyInstanceRuleApplicationConvert.buildExpressOutletsBaseInfo;
import static com.cainiao.tp.nm.plan.policy.application.convert.PolicyInstanceRuleApplicationConvert.buildIncentiveRuleDetail;
import static com.cainiao.tp.nm.plan.policy.application.convert.PolicyInstanceRuleApplicationConvert.buildRuleColumn;
import static com.cainiao.tp.nm.plan.policy.application.convert.PolicyInstanceRuleApplicationConvert.markMergeDivisionInstanceRule;
import static com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyCommonConstants.SPLICING;

/**
 * @code date 2025年06月09日 14:50
 * @code desc:规模主表-政策看板视图转换
 */
@Component
public class ScaleMainTableDashboardTransform implements PolicyDashBoardViewTransform {
    @Resource
    private DivisionManager divisionManager;

    @Override
    public String getTransformType() {
        return PolicyBizTypeEnum.SCALE.getType() + SPLICING + DashBoardViewTypeEnum.MAIN_TABLE.getViewType();
    }

    @Override
    public BaseTableDTO transform(List<PolicyInstanceRuleDTO> ruleDTOList) {
        if (CollectionUtils.isEmpty(ruleDTOList)) {
            return null;
        }
        PolicyInstanceRuleDTO policyInstanceRuleDTO = ruleDTOList.stream().findFirst().orElseThrow(() -> new AladdinBizException("error_code", "没有需要转化的数据"));
        String customType = policyInstanceRuleDTO.getCustomType();
        List<PolicyRuleDetailDTO> dataSource = buildPolicyRuleDataSource(ruleDTOList);
        dataSource = markMergeDivisionInstanceRule(dataSource, customType);
        PolicyInstanceRuleDetailDTO table = new PolicyInstanceRuleDetailDTO();
        table.setColumns(buildRuleColumn(customType));
        table.setDataSource(Lists.newArrayList(dataSource));
        return table;
    }

    private List<PolicyRuleDetailDTO> buildPolicyRuleDataSource(List<PolicyInstanceRuleDTO> ruleDTOList) {
        return Safes.of(ruleDTOList).stream()
                .map(ruleDTO -> {
                    PolicyRuleDetailDTO detailDTO = new PolicyRuleDetailDTO();
                    BeanUtils.copyProperties(ruleDTO, detailDTO);
                    // 加载激励规则
                    List<IncentiveRuleDetailDTO> incentiveRuleDetaiLList = buildIncentiveRuleDetail(ruleDTO);

                    Map<String, List<IncentiveRuleDetailDTO>> incentiveMap = Safes.of(incentiveRuleDetaiLList).stream()
                            .collect(Collectors.groupingBy(IncentiveRuleDetailDTO::getIncentiveType, Collectors.toList()));
                    // 基础激励
                    IncentiveRuleDetailDTO base = new IncentiveRuleDetailDTO();
                    base.setResultVal("1");
                    base.setPeriodValue("6");
                    // 灵活激励
                    List<IncentiveRuleDetailDTO> flexibleIncentive = incentiveMap.get(ruleDTO.getIncentivePlanType());
                    Map<String, IncentiveRuleDetailDTO> flexible = flexibleIncentive.stream()
                            .collect(Collectors.toMap(
                                    IncentiveRuleDetailDTO::getIncentiveStationCode,
                                    Function.identity(),
                                    (v1, v2) -> v1
                            ));

                    // 构建省市区
                    Long provCode =  Objects.isNull(ruleDTO.getProvinceCode()) ? null : Long.valueOf(ruleDTO.getProvinceCode());
                    Optional<BaseDivisionInfoDTO> provinceByCode = divisionManager.getProvinceByCode(provCode);
                    BaseDivisionInfoDTO baseDivisionInfoDTO = provinceByCode.orElse(null);
                    Map<String, String> divisionMap = buildDivisionMap(baseDivisionInfoDTO);
                    detailDTO.setId(ruleDTO.getId());
                    detailDTO.setProvince(divisionMap.get(ruleDTO.getProvinceCode()));
                    detailDTO.setCity(divisionMap.get(ruleDTO.getCityCode()));
                    detailDTO.setDistrict(divisionMap.get(ruleDTO.getDistrictCode()));
                    // 加载网点基本信息
                    ExpressOutletsBaseInfoDTO expressOutletsBaseInfo = buildExpressOutletsBaseInfo(ruleDTO);
                    if (expressOutletsBaseInfo != null) {
                        detailDTO.setOrgCode(expressOutletsBaseInfo.getOrgCode());
                        detailDTO.setOrgType(expressOutletsBaseInfo.getOrgType());
                        detailDTO.setOrgName(expressOutletsBaseInfo.getOrgName());
                        detailDTO.setCpCode(expressOutletsBaseInfo.getCpCode());
                    }
                    // 基础激励
                    detailDTO.setBaseAmount(base.getResultVal());
                    detailDTO.setBaseCycle(base.getPeriodValue());
                    // 灵活激励
                    IncentiveRuleDetailDTO nonStation = flexible.getOrDefault(IncentivePlanStationTypeEnum.NON_STATION.getType(), new IncentiveRuleDetailDTO());
                    AssertUtil.notNull(nonStation, "无人站激励为空");
                    IncentiveRuleDetailDTO lightStation = flexible.getOrDefault(IncentivePlanStationTypeEnum.LIGHT_STATION.getType(), new IncentiveRuleDetailDTO());
                    AssertUtil.notNull(nonStation, "灯条站激励为空");
                    IncentiveRuleDetailDTO normalStation = flexible.getOrDefault(IncentivePlanStationTypeEnum.NORMAL_STATION.getType(), new IncentiveRuleDetailDTO());
                    AssertUtil.notNull(nonStation, "基础站激励为空");
                    detailDTO.setSelfServiceStationAmount(nonStation.getResultVal());
                    detailDTO.setSelfServiceStationCycle(nonStation.getPeriodValue());
                    detailDTO.setLightBarStationAmount(lightStation.getResultVal());
                    detailDTO.setLightBarStationCycle(lightStation.getPeriodValue());
                    detailDTO.setBaseStationAmount(normalStation.getResultVal());
                    detailDTO.setBaseStationCycle(normalStation.getPeriodValue());

                    detailDTO.setEffectTime(DateUtils.localDateTimeToYmdStr(ruleDTO.getStartTime()));
                    detailDTO.setDeadlineTime(DateUtils.localDateTimeToYmdStr(DateUtils.addOrSubtractDays(ruleDTO.getEndTime(), -1)));
                    detailDTO.setReportTime(DateUtils.localDateTimeToYmdhmsStr(ruleDTO.getGmtCreate()));
                    return detailDTO;
                }).collect(Collectors.toList());
    }

    public List<ColumnDTO> buildRuleColumn(String customType){
        if(StringUtils.isBlank(customType)){
            return Lists.newArrayList();
        }
        List<ExcelHead> excelHead = getExcelHead(customType);
      return  excelHead.stream().map(head->{
            ColumnDTO columnDTO = new ColumnDTO();
            columnDTO.setTitle(head.getHeadName());
            columnDTO.setDataIndex(head.getFieldKey());
            return columnDTO;
        }).collect(Collectors.toList());
    }

    private List<ExcelHead> getExcelHead(String customType) {
        String tempCode = getTempCode(customType);
        return TpExportHeadHolder.getINSTANCE().getHead(tempCode);
    }
    /**
     * 获取导出的模版code
     *
     * @return return
     */
    private String getTempCode(String customType) {
        if ( PolicyCustomTypeEnum.STATION.getType().equals(customType)) {
            return "ScaleStationExport";
        }
        if ( PolicyCustomTypeEnum.EXPRESS.getType().equals(customType)) {
            return "ScaleExpressExport";
        }
        //todo 异常统一处理
        throw new RuntimeException("未配置展示模版,请联系管理员配置");
    }

}
