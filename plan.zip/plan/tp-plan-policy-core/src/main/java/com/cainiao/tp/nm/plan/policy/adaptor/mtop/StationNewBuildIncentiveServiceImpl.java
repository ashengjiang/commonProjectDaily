package com.cainiao.tp.nm.plan.policy.adaptor.mtop;

import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.cainiao.sutee.commons.base.result.CnResult;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.base.BaseStationPermissionRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.NewStaPerformSubsidyRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.StationIncentiveRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.station.heavy.NewStaPerformMonthSubsidyVO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.station.heavy.NewStaPerformSubsidyActivityVO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.station.heavy.StationAssessmentVO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.station.heavy.StationIncentiveVO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.service.StationNewBuildIncentiveService;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.station.NewStaPerformSubsidyMonthQueryParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.station.NewStaPerformSubsidyQueryParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.station.StationIncentiveQueryParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.NewStaPerformSubsidyActivityDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.heavy.StationAssessmentDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.heavy.StationIncentiveDTO;
import com.cainiao.tp.nm.plan.api.policy.application.service.station.StationIncentiveAppService;
import com.cainiao.tp.nm.plan.policy.adaptor.component.station.StationPermissionCheck;
import com.cainiao.tp.nm.plan.policy.adaptor.convert.StationIncentiveConvert;
import com.cainiao.tp.nm.plan.policy.common.util.AssertUtil;
import org.apache.commons.lang3.StringUtils;

import javax.annotation.Resource;

/**
 * @code date 2025年07月31日 11:06
 * @code desc:站点新建激励透传接口实现
 */
@HSFProvider(serviceInterface = StationNewBuildIncentiveService.class)
public class StationNewBuildIncentiveServiceImpl implements StationNewBuildIncentiveService {

    @Resource
    private StationIncentiveAppService stationIncentiveAppService;

    /**
     * 站点新建激励透传
     *
     * @param request 季度
     * @return 站点新建激励透传
     */
    @Override
    @StationPermissionCheck
    public CnResult<StationIncentiveVO> queryStationNewBuildBillDetail(StationIncentiveRequest request) {
        AssertUtil.notNull(request,"请求参数不能为空");
        AssertUtil.notNull(request.getQuarter(), "季度不能为空");
        AssertUtil.notNull(request.getStationId(),"站点ID不能为空");
        StationIncentiveQueryParam queryParam = buildIncentiveQueryParam(request);
        StationIncentiveDTO incentiveDTO = stationIncentiveAppService.queryStationIncentive(queryParam);
        return CnResult.succeed(StationIncentiveConvert.stationIncentiveVO(incentiveDTO));
    }

    /**
     * 站点激励考核详情查询
     *
     * @param request 季度 周期
     */
    @Override
    @StationPermissionCheck
    public CnResult<StationAssessmentVO> queryStationIncentiveAssessment(StationIncentiveRequest request) {
        AssertUtil.notNull(request,"请求参数不能为空");
        AssertUtil.notNull(request.getQuarter(), "季度不能为空");
        AssertUtil.notNull(request.getPeriod(), "账单周期不能为空");
        AssertUtil.notNull(request.getStationId(),"站点ID不能为空");
        StationIncentiveQueryParam queryParam = buildIncentiveQueryParam(request);
        StationAssessmentDTO assessmentDTO = stationIncentiveAppService.queryStationAssessment(queryParam);
        return CnResult.succeed(StationIncentiveConvert.convertAssessmentVO(assessmentDTO));
    }

    @Override
    @StationPermissionCheck
    public CnResult<NewStaPerformSubsidyActivityVO> queryNewStaPerformAssessment(BaseStationPermissionRequest request) {
        String stationId = request.getStationId();
        AssertUtil.notNull(stationId,"站点ID不能为空");

        NewStaPerformSubsidyQueryParam param = new NewStaPerformSubsidyQueryParam();
        param.setStationId(Long.valueOf(stationId));
        NewStaPerformSubsidyActivityDTO staPerformSubsidy = stationIncentiveAppService.queryNewStaPerformSubsidy(param);
        return CnResult.succeed(StationIncentiveConvert.convertNewStaPerformSubsidyVO(staPerformSubsidy));
    }

    @Override
    @StationPermissionCheck
    public CnResult<NewStaPerformMonthSubsidyVO> queryNewStaPerformMonthAssessment(NewStaPerformSubsidyRequest request) {
        String stationId = request.getStationId();
        com.cainiao.aladdin.validate.utils.AssertUtil.notNull(StringUtils.isNotBlank(stationId),"站点ID不能为空");
        com.cainiao.aladdin.validate.utils.AssertUtil.isTrue(StringUtils.isNotBlank(request.getMonth()),"考核月份不能为空");

        NewStaPerformSubsidyMonthQueryParam param = new NewStaPerformSubsidyMonthQueryParam();
        param.setStationId(Long.valueOf(stationId));
        param.setAssessMonth(request.getMonth());
        NewStaPerformSubsidyActivityDTO staPerformSubsidy = stationIncentiveAppService.queryNewStaPerformMonthSubsidy(param);
        return CnResult.succeed(StationIncentiveConvert.convertNewStaPerformMonthSubsidyVO(staPerformSubsidy));
    }

    private StationIncentiveQueryParam buildIncentiveQueryParam(StationIncentiveRequest request) {
        StationIncentiveQueryParam queryParam = new StationIncentiveQueryParam();
        queryParam.setStationId(request.getStationId());
        queryParam.setPeriod(request.getPeriod());
        queryParam.setQuarter(request.getQuarter());
        queryParam.setSource(request.getSource());
        return queryParam;
    }
}
