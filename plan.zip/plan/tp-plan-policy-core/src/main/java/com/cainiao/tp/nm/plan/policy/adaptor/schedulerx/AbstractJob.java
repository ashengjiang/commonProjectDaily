package com.cainiao.tp.nm.plan.policy.adaptor.schedulerx;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.schedulerx.worker.processor.JavaProcessor;
import com.alibaba.schedulerx.worker.processor.ProcessResult;
import com.alibaba.schedulerx.worker.domain.JobContext;

import com.cainiao.tp.nm.plan.policy.common.util.JobExecuteResultUtils;
import lombok.extern.slf4j.Slf4j;


/**
 * @Date 2025/6/6 11:11
 * @code desc: 定时任务抽象封装
 */
@Slf4j
public abstract class AbstractJob<T> extends JavaProcessor {


    @Override
    public ProcessResult process(JobContext context) {
        long startTime = System.currentTimeMillis();
        try {
            JobExecuteResultUtils.init();
            T param = parseParam(context);
            return handle(param, context);
        } finally {
            JobExecuteResultUtils.remove();
            log.info("AbstractJob job execute result,classname={},cost={}", this.getClass().getSimpleName(), System.currentTimeMillis() - startTime);
        }
    }

    /**
     * job处理逻辑
     *
     * @param t       参数
     * @param context 内容
     * @return return
     */
    public abstract ProcessResult handle(T t, JobContext context);

    public T parseParam(JobContext context) {
        log.info("SchedulerAbstractJob param={}", context.getJobParameters());
        Class<T> className = getClassName();
        if (null == className) {
            return null;
        }
        return JSONObject.parseObject(context.getJobParameters(), getClassName());
    }

    /**
     * 获取类名
     *
     * @return 类
     */
    public abstract Class<T> getClassName();

}