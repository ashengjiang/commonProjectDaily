package com.cainiao.tp.nm.plan.policy.common.util;

import java.time.LocalDate;
import java.time.Month;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;

/**
 * @code date 2025年03月24日 17:20
 * @code desc:财年日期计算
 */
public class FiscalQuarterComputeUtil {

    public static String getFiscalQuarter(Date currentDate) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(currentDate);

        int month = cal.get(Calendar.MONTH) + 1;
        int year = cal.get(Calendar.YEAR);

        String fiscalQuarter;
        if (month >= 4 && month <= 6) {
            fiscalQuarter = "q1";
        } else if (month >= 7 && month <= 9) {
            fiscalQuarter = "q2";
        } else if (month >= 10 && month <= 12) {
            fiscalQuarter = "q3";
        } else {
            fiscalQuarter = "q4";
        }
        if (month > 3) {
            year += 1;
        }
        String yearStr = String.valueOf(year).substring(2);
        return "fy" + yearStr + fiscalQuarter;
    }
}
