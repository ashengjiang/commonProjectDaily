package com.cainiao.tp.nm.plan.policy.common.util.query;

import com.google.common.collect.Lists;
import org.apache.commons.collections4.CollectionUtils;

import java.util.List;

public class BatchQueryUtils {
    /**
     * 批量处理数据
     * 默认从第一页开始
     *
     * @param handler  后置处理
     * @param <T>      类型
     */
    public static <T> void queryUntilNoData(List<T> resultList, PostProcessHandler<T> handler) {
        if (CollectionUtils.isEmpty(resultList)) {
            return;
        }
        resultList.forEach(handler::postProcess);
    }

    /**
     * 批量处理数据
     * 默认从第一页开始
     *
     * @param handler  后置处理
     * @param pageSize 分页数量
     * @param <T>      类型
     */
    public static <T> void queryUntilNoData(List<T> resultList, BatchPostProcessHandler<T> handler, final int pageSize) {
        if (CollectionUtils.isEmpty(resultList)) {
            return;
        }
        List<List<T>> partitionList = Lists.partition(resultList, pageSize);
        partitionList.forEach(handler::postProcess);
    }

    /**
     * 批量处理数据
     * 默认从第一页开始
     * 注意jap是从第0页开始的
     *
     * @param callback 回调
     * @param handler  后置处理
     * @param pageSize 分页数量
     * @param <T>      类型
     */
    public static <T> void queryUntilNoData(QueryResultCallBack<T> callback, BatchPostProcessHandler<T> handler, final int pageSize) {
        queryUntilNoData(callback, handler, pageSize, 1);
    }

    /**
     * 批量处理数据
     * 注意jap是从第0页开始的
     *
     * @param callback     回调
     * @param handler      后置处理
     * @param pageSize     分页数量
     * @param startPageNum 开始页
     * @param <T>          类型
     */
    public static <T> void queryUntilNoData(QueryResultCallBack<T> callback, BatchPostProcessHandler<T> handler, final int pageSize, int startPageNum) {
        int num = pageSize;
        while (num == pageSize) {
            List<T> query = callback.query(startPageNum, pageSize);
            if (query == null || query.isEmpty()) {
                return;
            }
            num = query.size();
            handler.postProcess(query);
            ++startPageNum;
        }
    }


}
