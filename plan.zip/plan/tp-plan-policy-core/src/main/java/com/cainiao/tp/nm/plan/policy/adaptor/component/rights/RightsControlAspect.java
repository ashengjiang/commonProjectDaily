package com.cainiao.tp.nm.plan.policy.adaptor.component.rights;

import com.alibaba.fastjson.JSONObject;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.sutee.commons.restful.result.CnRestResult;
import com.cainiao.tp.boot.utils.TpWebUtil;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.RightsUserMockHolderDTO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.PolicyOpRightsVO;
import com.cainiao.tp.nm.plan.infra.port.policy.EmployeeRightsLoadManager;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyConfigManager;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

/**
 * 权限管控切面
 */
@Slf4j
@Component
@Aspect
@Order
public class RightsControlAspect {

    @Resource
    private EmployeeRightsLoadManager employeeRightsLoadService;

    @Resource
    private PolicyConfigManager policyConfigManager;

    @Around("rightsControlPointcut()")
    public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
        try {
            //检查权限
            MethodSignature signature = (MethodSignature) joinPoint.getSignature();
            Method method = signature.getMethod();
            RightsControl rightsControl = method.getAnnotation(RightsControl.class);
            if (rightsControl != null) {
                RightsControlContext.RightsControlContextBuilder contextBuilder = RightsControlContext.builder();
                Long employeeId =Long.parseLong(TpWebUtil.getWebOperation().getOperatorId());
                Long mockEmployeeId = RightsUserMockHolderDTO.getMockUserId(employeeId);
                if(mockEmployeeId != null){
                    employeeId = mockEmployeeId;
                }

                //检查角色权限
                String[] roleCodeArray = rightsControl.roleCodeArray();
                //无需校验角色权限
                if(roleCodeArray==null || roleCodeArray.length == 0){
                    contextBuilder.hasRoleRights(true);
                }else{
                    List<String> roleCodes = employeeRightsLoadService.getEmployeeRoles(employeeId,new HashSet<>(Arrays.asList(roleCodeArray)));
                    if(!CollectionUtils.isEmpty(roleCodes) && new HashSet<>(roleCodes).containsAll(Arrays.asList(roleCodeArray))){
                        contextBuilder.hasRoleRights(true);
                    }
                }
                //加载城市权限
                PolicyOpRightsVO opRightsVO = employeeRightsLoadService.getDivisionRights(employeeId);
                contextBuilder.hasCnRights(opRightsVO.isHasCnRights());
                contextBuilder.cityCodeList(opRightsVO.getCityCodes());
                RightsControlUtils.setRightsControlContext(contextBuilder.build());
                //检查角色权限
                AssertUtil.isTrue(RightsControlUtils.get().isHasRoleRights(),policyConfigManager.getPermissionDeniedPrompt());
            }
            log.info("RightsControlAspect around method={},context={}", method.getName(), JSONObject.toJSONString(RightsControlUtils.get()));
            return joinPoint.proceed();
        } catch (Throwable throwable) {
            throw throwable;
        }finally {
            RightsControlUtils.clear();
        }
    }

    /**
     * 管控com.cainiao.tp.nm.plan.policy.adaptor.service.web包下所有RightsControl注解的方法
     */
    @Pointcut("execution(* com.cainiao.tp.nm.plan.policy.adaptor.rest..*.*(..)) && @annotation(com.cainiao.tp.nm.plan.policy.adaptor.component.rights.RightsControl)")
    public void rightsControlPointcut() {
    }
}
