package com.cainiao.tp.nm.plan.policy.adaptor.service;

import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.cainiao.aladdin.utils.DateUtil;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.sutee.commons.base.result.CnResult;
import com.cainiao.tp.nm.plan.api.policy.application.dto.StationDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.NewStaPerformSubsidyConfigDTO;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyConfigManager;
import com.cainiao.tp.nm.plan.infra.port.policy.StaStationReadManager;
import com.cainiao.tp.nm.plan.infra.port.policy.TpPushStationMessageManager;
import com.cainiao.tp.nm.plan.policy.application.convert.NewStaPerformSubsidyConvert;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;

import javax.annotation.Resource;
import java.util.Date;

/**
 * @code date 2025年05月29日 16:28
 * @code desc:
 */
@Slf4j
@HSFProvider(serviceInterface = PolicyBizTestService.class)
public class PolicyBizTestServiceImpl implements PolicyBizTestService {

    @Resource
    private StaStationReadManager staStationReadManager;
    @Resource
    private TpPushStationMessageManager tpPushStationMessageManager;
    @Resource
    private PolicyConfigManager policyConfigManager;

    @Override
    public CnResult<Void> sendNewStaPerformSubsidyPopup(Long stationId) {
        // 1.查询站点信息
        StationDTO stationDTO = staStationReadManager.queryStationById(stationId);
        AssertUtil.notNull(stationDTO, "站点不存在");

        // 2.查询激励活动配置数据
        NewStaPerformSubsidyConfigDTO subsidyConfig = policyConfigManager.getNewStaPerformSubsidyConfig();

        boolean judgeBasicCond = NewStaPerformSubsidyConvert.judgeBasicCond(stationDTO, subsidyConfig);
        if(!judgeBasicCond){
            return CnResult.fail("不满足发消息的基础条件", "不满足发消息的基础条件");
        }
        Date fy26Q4Date = DateUtil.getStr2SDate(subsidyConfig.getFy26Q4StartDate());
        boolean isEntryFy26Q4 = stationDTO.getGmtCreate().after(fy26Q4Date);
        boolean isTop100City = CollectionUtils.isNotEmpty(subsidyConfig.getRuleDetailTop100CityCodeList())
                && subsidyConfig.getRuleDetailTop100CityCodeList().contains(stationDTO.getCityCode());
        if(isEntryFy26Q4){
            if(!isTop100City){
                return CnResult.fail("不支持该城市", "不支持该城市");
            }
        }else{
            boolean judgeBuildStaCond = NewStaPerformSubsidyConvert.judgeBuildStaCond(stationDTO);
            if(!judgeBuildStaCond){
                return CnResult.fail("不满足发消息的建站条件", "不满足发消息的建站条件");
            }
        }
        // 发送消息弹窗
        tpPushStationMessageManager.sendNewStaPerformSubsidyPopup(stationId);
        return CnResult.succeed();
    }
}
