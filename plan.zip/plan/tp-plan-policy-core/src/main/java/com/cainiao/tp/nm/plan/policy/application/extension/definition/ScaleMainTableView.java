package com.cainiao.tp.nm.plan.policy.application.extension.definition;

import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.tp.nm.plan.api.policy.application.dto.*;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyCustomTypeEnum;
import com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils;
import com.google.common.collect.Lists;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class ScaleMainTableView extends AbstractMainTableView {


    @Override
    protected String getTempCode(PolicyTemplateDTO policyTemplateDTO) {
        String tempCode = super.getTempCode(policyTemplateDTO);
        if (StringUtils.isNotBlank(tempCode)) {
            return tempCode;
        }
        String customType = policyTemplateDTO.getCustomType();
        if (PolicyCustomTypeEnum.STATION.getType().equals(customType)) {
            return PolicyViewConfigHolder.getINSTANCE().getStationDefaultConfig().getExportTempCode();
        }
        if (PolicyCustomTypeEnum.EXPRESS.getType().equals(customType)) {
            return PolicyViewConfigHolder.getINSTANCE().getExpressDefaultConfig().getExportTempCode();
        }
        throw new RuntimeException("未配置展示视图模版，请联系管理员，政策模版ID=" + policyTemplateDTO.getId());
    }

    @Override
    public String getCode() {
        return AbstractMainTableView.CODE_DEFAULT;
    }


    @Override
    protected List<PolicyRuleRecordDTO> postProcess(List<PolicyRuleRecordDTO> resultList) {
        if (CollectionUtils.isEmpty(resultList)) {
            return resultList;
        }
        resultList=super.postProcess(resultList);
        PolicyRuleRecordDTO policyRuleRecordDTO = resultList.get(0);
        String customType = policyRuleRecordDTO.getCustomType();

        //站点
        if (PolicyCustomTypeEnum.STATION.getType().equals(customType)) {
            return markStationInstanceRule(resultList);
        }

        //网点
        if (PolicyCustomTypeEnum.EXPRESS.getType().equals(customType)) {
            List<PolicyRuleRecordDTO> data = Lists.newArrayList();
            Map<String, List<PolicyRuleRecordDTO>> orgMap = resultList.stream().collect(Collectors.groupingBy(dto -> dto.getScaleObjectDTO().getEntityId(), Collectors.toList()));
            AssertUtil.notEmpty("没有网点数据", orgMap);
            orgMap.forEach((orgCode, list) -> {
                List<PolicyRuleRecordDTO> orgDetails = list.stream().sorted(Comparator.comparing(PolicyRuleRecordDTO::getEffectTime).reversed()).collect(Collectors.toList());
                markInstanceRule(orgDetails);
                mergeRuleDetailStartTimeToEndTime(orgDetails);
                data.addAll(orgDetails);
            });
            data.stream().filter(rule -> Objects.isNull(rule.getDistrict())).forEach(rule -> {
                rule.setDistrict("全城");
            });
            return data;
        }
        throw new RuntimeException("未知的业务类型，无法解析，请联系管理员" + customType);
    }


    private static void markInstanceRule(List<PolicyRuleRecordDTO> dataSource) {
        if (CollectionUtils.isEmpty(dataSource)) {
            return;
        }
        PolicyRuleRecordDTO firstRule = dataSource.stream().findFirst().orElseThrow(() -> new AladdinBizException("error_code", "根据城市分组后的数据为空"));
        // 分组后的rule list 只有一个表示不需要合并，不需要合并 rowSpan默认为 0。多个表示需要合并，则rowSpan默认为集合的size
        int rowSpan = dataSource.size() == 1 ? 0 : dataSource.size();
        firstRule.setCityRowSpan(rowSpan);
    }


    public static void mergeRuleDetailStartTimeToEndTime(List<PolicyRuleRecordDTO> ruleDetailDTOList) {
        if (CollectionUtils.isEmpty(ruleDetailDTOList)) {
            return;
        }
        // 特殊处理第一条
        if (ruleDetailDTOList.size() == 1) {
            PolicyRuleRecordDTO policyRuleDetailDTO = ruleDetailDTOList.stream().findFirst().orElseThrow(() -> new AladdinBizException("error_code", "没有需要合并时间的数据"));
            policyRuleDetailDTO.setEffectCycle(policyRuleDetailDTO.getEffectTime() + "至" + policyRuleDetailDTO.getDeadlineTime());
        }
        // 遍历数据源，从第二条开始
        for (int i = 1; i < ruleDetailDTOList.size(); i++) {
            PolicyRuleRecordDTO current = ruleDetailDTOList.get(i);
            PolicyRuleRecordDTO previous = ruleDetailDTOList.get(i - 1);
            // 第二条 和 第一条 数据的开始生效时间相同 表示通一天生效的
            if (current.getEffectTime().equals(previous.getEffectTime())) {
                continue;
            }
            // 将当前数据的结束时间设置为前一条数据的开始时间-1 (前一条数据的开始时间)
            current.setEffectCycle(current.getEffectTime() + "至" + DateUtils.localDateTimeToYmdStr(DateUtils.addOrSubtractDays(DateUtils.toLocalDateTimeYmdStart(previous.getEffectTime()), -1)));
            if (i == 1) {
                previous.setEffectCycle(previous.getEffectTime() + "至" + previous.getDeadlineTime());
            }
        }
    }


    public static List<PolicyRuleRecordDTO> markStationInstanceRule(List<PolicyRuleRecordDTO> resultList) {
        if (CollectionUtils.isEmpty(resultList)) {
            return Collections.emptyList();
        }
        // 省维度
        Map<String, List<PolicyRuleRecordDTO>> provinceMap = resultList.stream().collect(Collectors.groupingBy(PolicyRuleRecordDTO::getProvince, Collectors.toList()));
        List<PolicyRuleRecordDTO> markResult = Lists.newArrayList();
        provinceMap.forEach((province, provinceList) -> {
            // 市维度
            List<PolicyRuleRecordDTO> tmpProvince = Lists.newArrayList();
            Map<String, List<PolicyRuleRecordDTO>> cityDivisionMap = provinceList.stream().collect(Collectors.groupingBy(rule -> rule.getProvince() + "-" + rule.getCity(), Collectors.toList()));
            cityDivisionMap.forEach((provinceCity, list) -> {
                ArrayList<PolicyRuleRecordDTO> tmp = Lists.newArrayList();
                // 找到城市维度的数据
                List<PolicyRuleRecordDTO> cityNode = list.stream().filter(rule -> Objects.isNull(rule.getDistrict())).sorted(Comparator.comparing(PolicyRuleRecordDTO::getEffectTime).reversed()).collect(Collectors.toList());
                tmp.addAll(cityNode);
                mergeRuleDetailStartTimeToEndTime(cityNode);
                // 城市下对应的区
                List<PolicyRuleRecordDTO> districtNode = list.stream().filter(rule -> Objects.nonNull(rule.getDistrict())).collect(Collectors.toList());
                Map<String, List<PolicyRuleRecordDTO>> districtMap = districtNode.stream().collect(Collectors.groupingBy(rule -> rule.getProvince() + "-" + rule.getCity() + "-" + rule.getDistrict(), Collectors.toList()));
                districtMap.forEach((district, districtList) -> {
                    List<PolicyRuleRecordDTO> districts = districtList.stream().sorted(Comparator.comparing(PolicyRuleRecordDTO::getEffectTime).reversed()).collect(Collectors.toList());
                    PolicyRuleRecordDTO districtFirstRule = districts.stream().findFirst().orElseThrow(() -> new AladdinBizException("error_code", "根据区县分组后的数据为空"));
                    districtFirstRule.setDistrictRowSpan(districts.size() == 1 ? 0 : districts.size());
                    tmp.addAll(districts);
                    mergeRuleDetailStartTimeToEndTime(districts);
                });
                // 每一次循环代表一个省市，最后需要计算对应的省市需要合并的单元格个数
                PolicyRuleRecordDTO cityFirstRule = tmp.stream().findFirst().orElseThrow(() -> new AladdinBizException("error_code", "根据城市分组后的数据为空"));
                cityFirstRule.setCityRowSpan(tmp.size() == 1 ? 0 : tmp.size());
                tmpProvince.addAll(tmp);
                tmpProvince.stream().filter(rule -> Objects.isNull(rule.getDistrict())).forEach(rule -> rule.setDistrict("全城"));
            });
            PolicyRuleRecordDTO provinceFirstRule = tmpProvince.stream().findFirst().orElseThrow(() -> new AladdinBizException("error_code", "根据省分组后的数据为空"));
            provinceFirstRule.setProvinceRowSpan(tmpProvince.size() == 1 ? 0 : tmpProvince.size());
            markResult.addAll(tmpProvince);
        });
        return markResult;
    }

}
