package com.cainiao.tp.nm.plan.policy.adaptor.service;


import com.cainiao.sutee.commons.base.result.CnResult;

/**
 * @code date 2025年05月29日 16:28
 * @code desc: 测试工具service 接口不对外暴露
 */
public interface PolicyBizTestService {

    /**
     * 给驿站掌柜下发新站实操激励活动
     * @return
     */
    CnResult<Void> sendNewStaPerformSubsidyPopup(Long stationId);
}
