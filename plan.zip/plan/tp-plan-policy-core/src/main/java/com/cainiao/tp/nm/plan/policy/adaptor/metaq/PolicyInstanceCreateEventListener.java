package com.cainiao.tp.nm.plan.policy.adaptor.metaq;

import com.alibaba.fastjson.JSON;
import com.alibaba.rocketmq.common.message.MessageExt;
import com.cainiao.aladdin.log.AladdinCommLog;
import com.cainiao.aladdin.log.AladdinMapLog;
import com.cainiao.aladdin.log.BizType;
import com.cainiao.aladdin.log.utils.AladdinLogUtil;
import com.cainiao.aladdin.operation.SystemBizOperation;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyInstanceDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyInstanceRuleDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyTemplateDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.TpTicketDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.PolicyApproveConfigDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyInstanceFeatureParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.TicketInstanceApprovalStartParam;
import com.cainiao.tp.nm.plan.api.policy.common.constants.OAProcessContextConstants;
import com.cainiao.tp.nm.plan.api.policy.common.constants.OAProcessDefinitionKeyEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicySubmitEffectOpportunityEnum;
import com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils;
import com.cainiao.tp.nm.plan.infra.port.policy.EmployeeRightsLoadManager;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyInstanceRuleQueryManager;
import com.cainiao.tp.nm.plan.infra.port.policy.TicketApprovalManager;
import com.cainiao.tp.nm.plan.policy.application.event.event.PolicyInstanceCreateEvent;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyConfigManager;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyInstanceQueryManager;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyTemplateQueryManager;
import com.cainiao.tp.nm.plan.api.policy.application.service.PolicyInstanceAppService;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyFeatureConstants;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyMetaqEventEnum;
import com.google.common.base.Charsets;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * 政策实例创建事件
 */
@Slf4j
@Component(value = "policyInstanceCreateEventListener")
public class PolicyInstanceCreateEventListener extends AbstractMetaQListener<PolicyInstanceCreateEvent> {

    @Resource
    private PolicyInstanceAppService policyInstanceAppService;
    @Resource
    private PolicyInstanceQueryManager policyInstanceQueryManager;
    @Resource
    private PolicyTemplateQueryManager policyTemplateQueryManager;
    @Resource
    private PolicyConfigManager policyConfigManager;

    @Resource
    private PolicyInstanceRuleQueryManager instanceRuleReadQueryManger;

    @Resource
    private EmployeeRightsLoadManager employeeRightsLoadManager;

    @Resource(name = "policyInstanceApprovalManagerImpl")
    private TicketApprovalManager<TicketInstanceApprovalStartParam, TpTicketDTO> policyInstanceApprovalManager;

    @Override
    protected PolicyInstanceCreateEvent convert(MessageExt message) {
        AladdinMapLog mapLog = AladdinLogUtil.newMapLog("policyInstanceCreateEventListener.convert", BizType.DEFAULT);
        try {
            String msgBody = new String(message.getBody(), Charsets.UTF_8);
            PolicyInstanceCreateEvent event = JSON.parseObject(msgBody, PolicyInstanceCreateEvent.class);
            return event;
        } catch (Throwable t) {
            mapLog.addParam("convert failed", t.getMessage());
            AladdinLogUtil.log(log, mapLog, t);
            return null;
        }
    }
    @Override
    protected boolean filter(PolicyInstanceCreateEvent event, MessageExt message) {
        return true;
    }

    /**
     * 接收到家变更消息
     */
    @Override
    protected boolean doConsume(PolicyInstanceCreateEvent event, MessageExt message) {
        SystemBizOperation operation = new SystemBizOperation(303544L, "建宇", "监听政策实例创建事件");
        operation.setOperatorId(String.valueOf(event.getOperatorId()));
        AladdinCommLog commLog = AladdinLogUtil.newCommLog(BizType.DEFAULT, operation);
        List<Object> logContext = Lists.newArrayList();
        commLog.setContext(logContext);
        commLog.setParams(message.getMsgId());
        logContext.add("msgId : " + message.getMsgId());
        logContext.add("eventBody : " + event);
        try {
            String tags = message.getTags();
            if(PolicyMetaqEventEnum.POLICY_INSTANCE_CREATE.getTag().equals(tags)){
                PolicyInstanceDTO policyInstanceDTO = policyInstanceQueryManager.queryPolicyInstanceById(event.getInstanceId());
                AssertUtil.notNull(policyInstanceDTO, "实例不存在");
                PolicyTemplateDTO policyTemplateDTO = policyTemplateQueryManager.queryPolicyTemplateById(event.getTemplateId());
                AssertUtil.notNull(policyTemplateDTO, "模版不存在");

                PolicyApproveConfigDTO approval = policyConfigManager.getApproveConfig(policyTemplateDTO.getBizType(), policyTemplateDTO.getCustomType());
                if(null != approval && approval.isInsatnceApprove()){
                    // 发起审批流程
                    TicketInstanceApprovalStartParam approvalStartParam = buildStartParam(policyTemplateDTO, policyInstanceDTO,event.getOperatorId());
                    String processInstanceId = policyInstanceApprovalManager.startApproval(approvalStartParam);
                    if (StringUtils.isBlank(processInstanceId)) {
                        // 根据幂等id重新查询
                        String idempotentId = (String) approvalStartParam.getContext().get(OAProcessContextConstants.IDEMPOTENT_ID);
                        processInstanceId = policyInstanceApprovalManager.getInstanceIdByContextKey(approval.getInsatnceProcessCode(),idempotentId);
                    }
                    // 保存审批流程id
                    Map<String, String> featureMap = Maps.newHashMap();
                    featureMap.put(PolicyFeatureConstants.APPROVAL_FOLLOW_ID, processInstanceId);
                    PolicyInstanceFeatureParam featureParam = new PolicyInstanceFeatureParam();
                    featureParam.setInstanceId(event.getInstanceId());
                    featureParam.setFeatureMap(featureMap);
                    policyInstanceAppService.updateFeature(featureParam, operation);
                }

            }
        } catch (Throwable t) {
            return AladdinLogUtil.log(log, t, commLog, false);
        }
        return AladdinLogUtil.log(log, commLog, true);
    }

    private TicketInstanceApprovalStartParam buildStartParam(PolicyTemplateDTO template, PolicyInstanceDTO instance, Long operatorId){
        TicketInstanceApprovalStartParam startParam = new TicketInstanceApprovalStartParam();
        startParam.setId(instance.getId());
        startParam.setTemplateName(template.getTemplateName());
        startParam.setCustomType(instance.getCustomType());
        startParam.setBizType(instance.getBizType());
        startParam.setTemplateStartTime(template.getStartTime());
        startParam.setTemplateEndTime(template.getEndTime());
        startParam.setInstanceStartTime(instance.getStartTime());
        startParam.setInstanceEndTime(instance.getEndTime());
        startParam.setLastOperatorId(operatorId);
        startParam.setFeatureMap(instance.getFeatureMap());
        Map<String, Object> context = buildStartTicketContext(template, instance,operatorId);
        context.put(OAProcessContextConstants.IDEMPOTENT_ID, policyInstanceApprovalManager.getIdempotentId(startParam));
        startParam.setContext(context);
        return startParam;
    }

    private Map<String,Object> buildStartTicketContext(PolicyTemplateDTO policyTemplate , PolicyInstanceDTO policyInstance, Long operatorId){
        // 周期
        String startTimeStr = policyTemplate.getStartTimeStr();
        String endTimeStr = policyTemplate.getEndTimeStr();
        LocalDateTime startTime = DateUtils.toLocalDateTimeYmdStart(startTimeStr);
        LocalDateTime endTime = DateUtils.toLocalDateTimeYmdEnd(endTimeStr);
        String policyCycle = DateUtils.periodFormat(startTime, endTime);
        Map<String,Object> context = Maps.newHashMap();

        String approvalDownUrl = MapUtils.getObject(policyInstance.getFeatureMap(), PolicyFeatureConstants.APPROVAL_DOWN_URL);
        // 获取其中某个政策规则实例的城市code
        PolicyInstanceRuleDTO policyInstanceRuleDTO = instanceRuleReadQueryManger.queryFirstPolicyInstanceRuleByInstanceId(policyInstance.getId());
        AssertUtil.notNull(policyInstanceRuleDTO, "政策规则实例不存在");

//        String regionDeptCode = employeeRightsLoadManager.queryRegionCodeByCityCode(policyInstanceRuleDTO.getCityCode());
        String effectOpportunity = PolicySubmitEffectOpportunityEnum.getDescByStartTime(policyInstance.getStartTime());
        // 生效时机
        context.put(OAProcessContextConstants.EFFECT_OPPORTUNITY,effectOpportunity);
        // 生效时间
        if (policyInstance.getStartTime() != null){
            String effectTime = DateUtils.localDateTimeToYmdhmsStr(policyInstance.getStartTime());
            context.put(OAProcessContextConstants.EFFECT_TIME,effectTime);
        }
        String taskOverDue = policyConfigManager.getPolicySubmitTaskOverTime(policyInstance.getStartTime());
        context.put(OAProcessContextConstants.TASK_OVER_DUE,taskOverDue);
        // 下载提报链接
        context.put(OAProcessContextConstants.DOWNLOAD_URL, approvalDownUrl);
        // 政策周期
        context.put(OAProcessContextConstants.POLICY_CYCLE, policyCycle);
        //// 政策名称
        context.put(OAProcessContextConstants.POLICY_NAME, policyTemplate.getTemplateName());
        // 表单code
        context.put(OAProcessContextConstants.TICKET_FORM, OAProcessDefinitionKeyEnum.BATCH_SUBMISSION_OF_POLICIES.getFormCode());
        // 大区部门code
//        context.put(OAProcessContextConstants.REGION_DEPT_CODE, regionDeptCode);
        // 政策实例id
        context.put(OAProcessContextConstants.POLICY_INSTANCE_ID, String.valueOf(policyInstance.getId()));
        // 操作人id
        context.put(OAProcessContextConstants.OPERATOR_ID, String.valueOf(operatorId));
        return context;
    }
}
