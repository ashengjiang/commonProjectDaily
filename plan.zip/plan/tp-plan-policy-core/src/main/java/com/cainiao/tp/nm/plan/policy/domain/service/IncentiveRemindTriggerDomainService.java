package com.cainiao.tp.nm.plan.policy.domain.service;

import java.time.LocalDate;

/**
 * 站点实操激励提醒推送触发日计算领域服务
 * 根据站点入驻时间和当前日期，判断当日是否为推送触发日，并计算考核月偏移量
 *
 * @date 2026-03-27
 */
public interface IncentiveRemindTriggerDomainService {

    /**
     * 判断当日是否为该站点的推送触发日
     * 推送规则：
     * - T月（入驻当月）：S+1、S+10、S+20、S+30 日（S 为入驻日）
     * - T+1月：1日、10日、20日
     * - T+2月：1日、10日、20日
     * - T+3月：1日、10日
     * - 超过 T+3月最后推送日（10日）则不再推送
     *
     * @param joinDate  站点入驻日期
     * @param today     当前日期
     * @return true=当日是推送触发日，false=不触发
     */
    boolean isTriggerDay(LocalDate joinDate, LocalDate today);

    /**
     * 计算当前日期相对于入驻月的考核月偏移量
     * 0=T月（入驻当月），1=T+1月，2=T+2月，3=T+3月
     *
     * @param joinDate  站点入驻日期
     * @param today     当前日期
     * @return 考核月偏移量（0~3），若超出考核期则返回 -1
     */
    int calcAssessMonthOffset(LocalDate joinDate, LocalDate today);
}
