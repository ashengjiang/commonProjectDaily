package com.cainiao.tp.nm.plan.policy.application.dto;

import lombok.Builder;
import lombok.Data;

/**
 * 站点激励考核数据上下文 DTO
 * 作为 QL 规则表达式匹配的上下文数据载体，字段名与规则表达式中的变量名保持一致
 *
 * @date 2026-03-27
 */
@Data
@Builder
public class IncentiveAssessContextDTO {

    /**
     * 站点 ID
     */
    private String stationId;

    /**
     * 当前考核月相对于入驻月的偏移量
     * 0=T月（入驻当月），1=T+1月，2=T+2月，3=T+3月
     */
    private Integer assessMonthOffset;

    /**
     * 首次实操超过100单的日期，null 表示未达标
     */
    private String firstOver100ArrDate;

    /**
     * 是否进入首月激励
     */
    private Boolean isSatisfied;

    /**
     * 考核期数（"1"/"2"/"3"/"4"）
     */
    private String cycleNum;

    /**
     * 是否完成装修认证
     */
    private Boolean isDecorationPass;
}
