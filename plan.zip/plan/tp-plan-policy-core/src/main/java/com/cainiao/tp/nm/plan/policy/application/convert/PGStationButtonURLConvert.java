package com.cainiao.tp.nm.plan.policy.application.convert;

import com.cainiao.aladdin.env.SystemEnvEnum;
import com.cainiao.aladdin.env.SystemEnvUtil;
import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.tp.nm.plan.api.policy.common.constants.StationModeEnum;
import com.cainiao.tp.pangu.basic.client.enums.TpsPgButtonTypeEnum;
import com.cainiao.tps.pangu.management.common.model.dto.element.TpsPgElementButtonDTO;
import com.google.common.collect.Maps;
import org.apache.commons.collections4.MapUtils;
import org.apache.ecs.html.S;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * @code date 2025年08月04日 16:22
 * @code desc:null
 */
public class PGStationButtonURLConvert {


    private static final String DD_DOMAIN_PRE_STATION_INCENTIVE = "https://pre-h.cainiao-inc.com/pangu/next/cone/xiaoer-work-manager/directional-fy26q1/subsidyIndex?source=%s&quarter=%s&stationId=%s&employeeId=%s&date=%s";
    private static final String DD_DOMAIN_ONLINE_STATION_INCENTIVE = "https://h.cainiao-inc.com/pangu/next/cone/xiaoer-work-manager/directional-fy26q1/subsidyIndex?source=%s&quarter=%s&stationId=%s&employeeId=%s&date=%s";

    private static final String XN_DOMAIN_PRE_STATION_INCENTIVE = "https://pre-tp.cainiao.com/pangu/next/cone/xiaoer-work-manager/directional-fy26q1/subsidyIndex?source=%s&quarter=%s&stationId=%s&employeeId=%s&date=%s";
    private static final String XN_DOMAIN_ONLINE_STATION_INCENTIVE = "https://tp.cainiao.com/pangu/next/cone/xiaoer-work-manager/directional-fy26q1/subsidyIndex?source=%s&quarter=%s&stationId=%s&employeeId=%s&date=%s";

    private static final String DD_DOMAIN_PRE_XN_STA_INCENTIVE = "https://pre-h.cainiao-inc.com/pangu/h5/last-mile-fe/xn-earning/index.html?fullScreen=YES&immerse=true&isJv=true&source=%s&quarter=%s&stationId=%s&employeeId=%s&date=%s#/xn-incentive-activity";
    private static final String DD_DOMAIN_ONLINE_XN_STA_INCENTIVE = "https://h.cainiao-inc.com/pangu/h5/last-mile-fe/xn-earning/index.html?fullScreen=YES&immerse=true&isJv=true&source=%s&quarter=%s&stationId=%s&employeeId=%s&date=%s#/xn-incentive-activity";

    private static final String XN_DOMAIN_PRE_XN_STA_INCENTIVE = "https://pre-tp.cainiao.com/pangu/h5/last-mile-fe/xn-earning/index.html?fullScreen=YES&immerse=true&isJv=true&source=%s&quarter=%s&stationId=%s&employeeId=%s&date=%s#/xn-incentive-activity";
    private static final String XN_DOMAIN_ONLINE_XN_STA_INCENTIVE = "https://tp.cainiao.com/pangu/h5/last-mile-fe/xn-earning/index.html?fullScreen=YES&immerse=true&isJv=true&source=%s&quarter=%s&stationId=%s&employeeId=%s&date=%s#/xn-incentive-activity";

    private static final Map<String, Map<String, Map<String, String>>> STATION_INCENTIVE_URL_MAP = Maps.newHashMap();

    static {
        HashMap<String, Map<String, String>> ddMap = Maps.newHashMap();
        HashMap<String, String> DDHeavy = Maps.newHashMap();
        DDHeavy.put(SystemEnvEnum.PRE.getEnv(), DD_DOMAIN_PRE_STATION_INCENTIVE);
        DDHeavy.put(SystemEnvEnum.ONLINE.getEnv(), DD_DOMAIN_ONLINE_STATION_INCENTIVE);
        ddMap.put(StationModeEnum.HEAVY.getType(),DDHeavy);
        HashMap<String, String> DDLight = Maps.newHashMap();
        DDLight.put(SystemEnvEnum.PRE.getEnv(), DD_DOMAIN_PRE_XN_STA_INCENTIVE);
        DDLight.put(SystemEnvEnum.ONLINE.getEnv(), DD_DOMAIN_ONLINE_XN_STA_INCENTIVE);
        ddMap.put(StationModeEnum.LIGHT.getType(),DDLight);

        STATION_INCENTIVE_URL_MAP.put("DD",ddMap);

        HashMap<String, Map<String, String>> xnMap = Maps.newHashMap();
        HashMap<String, String> XNHeavy = Maps.newHashMap();
        XNHeavy.put(SystemEnvEnum.PRE.getEnv(), XN_DOMAIN_PRE_STATION_INCENTIVE);
        XNHeavy.put(SystemEnvEnum.ONLINE.getEnv(), XN_DOMAIN_ONLINE_STATION_INCENTIVE);
        xnMap.put(StationModeEnum.HEAVY.getType(),XNHeavy);
        HashMap<String, String> XNLight = Maps.newHashMap();
        XNLight.put(SystemEnvEnum.PRE.getEnv(), XN_DOMAIN_PRE_XN_STA_INCENTIVE);
        XNLight.put(SystemEnvEnum.ONLINE.getEnv(), XN_DOMAIN_ONLINE_XN_STA_INCENTIVE);
        xnMap.put(StationModeEnum.LIGHT.getType(),XNLight);

        STATION_INCENTIVE_URL_MAP.put("XN",xnMap);


    }


    public static String getUlr(String stationMode,String source) {
        Optional<String> url = Optional.of(STATION_INCENTIVE_URL_MAP)
                .map(sourceMap -> sourceMap.get(source))
                .map(modeMap -> modeMap.get(stationMode))
                .map(envMap -> envMap.get(SystemEnvUtil.getEnv().getEnv()));
//                .map(envMap -> envMap.get("PRE"));
        return url.orElseThrow(() -> new AladdinBizException("error", "配置的跳转站点接力页面链接错误"));
    }

    public static String assembleStaIncentiveJumpButton(String stationMode, String source, String quarter, String stationId, String employeeId, String date) {
        String url = getUlr(stationMode,source);
        return String.format(url, source, quarter, stationId, employeeId, date);
    }

}
