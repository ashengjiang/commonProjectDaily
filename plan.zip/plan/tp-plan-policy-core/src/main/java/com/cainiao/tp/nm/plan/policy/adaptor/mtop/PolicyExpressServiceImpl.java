package com.cainiao.tp.nm.plan.policy.adaptor.mtop;

import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.aladdin.utils.Safes;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.aladdin.validate.utils.ValidateUtil;
import com.cainiao.sutee.commons.base.result.CnResult;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.ExpressOutletsDetailDTO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.ExpressOutletsDivisionDTO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.PolicyExpressDTO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.ExpressOutletsQueryRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.PolicyExpressQueryRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.service.PolicyExpressService;
import com.cainiao.tp.nm.plan.api.policy.application.dto.ExpressOutletsBaseInfoDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyInstanceRuleDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyTemplateDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiverule.IncentiveRuleDetailDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyInstanceRuleQueryParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyTemplateQueryParam;
import com.cainiao.tp.nm.plan.api.policy.common.constants.IncentivePlanTypeEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyCustomTypeEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyInstanceApprovalStatusEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyInstanceStatusEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyTemplateDurationStatusEnum;
import com.cainiao.tp.nm.plan.infra.port.policy.ExpressAccessCheckManager;
import com.cainiao.tp.nm.plan.infra.port.policy.ExpressOutletsDetailManager;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyInstanceRuleQueryManager;
import com.cainiao.tp.nm.plan.policy.application.convert.PolicyInstanceRuleApplicationConvert;
import com.cainiao.tp.nm.plan.policy.common.util.ExpressAccessUtils;
import com.cainiao.tp.nm.plan.infra.port.utils.ExpressUtils;
import com.cainiao.tp.nm.plan.api.policy.application.dto.ExpressContentDTO;
import com.cainiao.tp.nm.plan.policy.domain.repository.PolicyTemplateRepository;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;

import javax.annotation.Resource;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @code date 2025年06月03日 11:19
 * @code desc:null
 */
@Slf4j
@HSFProvider(serviceInterface = PolicyExpressService.class)
public class PolicyExpressServiceImpl implements PolicyExpressService {

    @Resource
    private PolicyInstanceRuleQueryManager instanceRuleReadAppService;
    @Resource
    private ExpressOutletsDetailManager expressOutletsDetailManager;
    @Resource
    private PolicyTemplateRepository policyTemplateRepository;
    @Resource
    private ExpressAccessCheckManager expressAccessCheckManager;

    /**
     * 查询网点政策
     *
     * @param request 查询请求
     * @return 网点政策
     */
    @Override
    public CnResult<PolicyExpressDTO> queryOutletsPolicy(PolicyExpressQueryRequest request) {
        PolicyExpressDTO policyExpressDTO = new PolicyExpressDTO();
        try {
            ValidateUtil.validate(request, true);
            // 权限校验
            ExpressContentDTO context = ExpressAccessUtils.getContext();
            context.setCpCode(request.getCpCode());
            context.setOrgCode(request.getOrgCode());
            expressAccessCheckManager.checkExpAndJVAccess(context);
            ExpressOutletsDetailDTO expressOutletsDetailDTO = expressOutletsDetailManager.queryExpressOutletsDetail(buildExpressOutletsQueryRequest(request));
            ExpressOutletsDivisionDTO outletsDivisionDTO = expressOutletsDetailDTO.getExpressOutletsDivisionDTO();
            PolicyInstanceRuleQueryParam param = buildPolicyInstanceRuleQueryParam(request, outletsDivisionDTO);
            List<PolicyInstanceRuleDTO> ruleDTOList = instanceRuleReadAppService.queryPolicyInstanceRuleByParam(param);

            PolicyTemplateDTO template = getInProgressTemplate(ruleDTOList);
            if (template == null) {
                policyExpressDTO.setHasPolicy(false);
                return CnResult.succeed(policyExpressDTO);
            }
            ruleDTOList = ruleDTOList.stream().filter(rule -> rule.getTemplateId().equals(template.getId())).collect(Collectors.toList());
            List<PolicyExpressDTO.IncentiveDetail> incentiveDetails = assembleIncentiveAmount(ruleDTOList, request);
            if (CollectionUtils.isEmpty(ruleDTOList)) {
                policyExpressDTO.setHasPolicy(false);
                return CnResult.succeed(policyExpressDTO);
            }
            policyExpressDTO.setHasPolicy(true);
            policyExpressDTO.setTitle(template.getTemplateName());
            policyExpressDTO.setIncentiveAmount(incentiveDetails);
            return CnResult.succeed(policyExpressDTO);
        }catch (Exception e) {
            log.warn("查询网点政策异常,request:{}", request, e);
            policyExpressDTO.setHasPolicy(false);
            return CnResult.succeed(policyExpressDTO);
        }
    }

    private PolicyTemplateDTO getInProgressTemplate(List<PolicyInstanceRuleDTO> ruleDTOList) {
        if (CollectionUtils.isEmpty(ruleDTOList)) {
            return null;
        }
        List<Long> templateIdList = ruleDTOList.stream().map(PolicyInstanceRuleDTO::getTemplateId).distinct().collect(Collectors.toList());
        PolicyTemplateQueryParam queryParam = new PolicyTemplateQueryParam();
        queryParam.setIdList(templateIdList);
        queryParam.setDurationStatus(PolicyTemplateDurationStatusEnum.IN_PROGRESS.getCode());
        List<PolicyTemplateDTO> templateDTOList = policyTemplateRepository.selectAll(queryParam);
        if (CollectionUtils.isEmpty(templateDTOList)) {
            return null;
        }
        templateDTOList = templateDTOList.stream().filter(tem -> PolicyCustomTypeEnum.EXPRESS.getType().equals(tem.getCustomType())).collect(Collectors.toList());
        AssertUtil.isTrue(templateDTOList.size() == 1, "生效的网点政策模版数量不唯一");
        return templateDTOList.stream().findFirst().orElseThrow(() -> new AladdinBizException("error_code", "获取生效的网点政策模版失败"));
    }

    private List<PolicyExpressDTO.IncentiveDetail> assembleIncentiveAmount(List<PolicyInstanceRuleDTO> ruleDTOList, PolicyExpressQueryRequest request) {
        if (CollectionUtils.isEmpty(ruleDTOList)) {
            return null;
        }
        List<PolicyInstanceRuleDTO> tmpDTOList = ruleDTOList.stream().filter(ruleDTO -> {
                    ExpressOutletsBaseInfoDTO expressOutletsBaseInfo = PolicyInstanceRuleApplicationConvert.buildExpressOutletsBaseInfo(ruleDTO);
                    String expressId = ExpressUtils.build(request.getOrgCode(),request.getCpCode());
                    return expressId.equals(expressOutletsBaseInfo.getOrgCode());
                }).distinct()
                .sorted(Comparator.comparing(PolicyInstanceRuleDTO::getEffectTime).reversed())
                .collect(Collectors.toList());
        // 合并起止时间
        PolicyInstanceRuleApplicationConvert.mergeRuleStartTimeToEndTime(tmpDTOList);

        return tmpDTOList.stream().map(dto -> {
            PolicyExpressDTO.IncentiveDetail incentiveDetail = new PolicyExpressDTO.IncentiveDetail();
            List<IncentiveRuleDetailDTO> ruleDetailDTOS = PolicyInstanceRuleApplicationConvert.buildIncentiveRuleDetail(dto);
            List<String> incentiveList = Safes.of(ruleDetailDTOS).stream()
                    .filter(incentive -> IncentivePlanTypeEnum.FLEXIBLE.getType().equals(incentive.getIncentiveType()))
                    .map(incentive -> incentive.getIncentiveStationName() + ":" + incentive.getResultVal())
                    .collect(Collectors.toList());
            incentiveDetail.setPolicyCycle(dto.getEffectCycle());
            incentiveDetail.setPolicyAmount(incentiveList);
            return incentiveDetail;
        }).collect(Collectors.toList());
    }

    private PolicyInstanceRuleQueryParam buildPolicyInstanceRuleQueryParam(PolicyExpressQueryRequest request, ExpressOutletsDivisionDTO outletsDivisionDTO) {
        PolicyInstanceRuleQueryParam param = new PolicyInstanceRuleQueryParam();
        param.setCustomType(PolicyCustomTypeEnum.EXPRESS.getType());
        param.setStatus(PolicyInstanceStatusEnum.EFFECT.getCode());
        param.setApprovalStatus(PolicyInstanceApprovalStatusEnum.PASS.getCode());
        param.setProvinceCode(outletsDivisionDTO.getProvinceCode());
        param.setCityCode(outletsDivisionDTO.getCityCode());
        param.setExpressId(ExpressUtils.build(request.getOrgCode(),request.getCpCode()));
        return param;
    }

    private ExpressOutletsQueryRequest buildExpressOutletsQueryRequest(PolicyExpressQueryRequest request) {
        ExpressOutletsQueryRequest queryRequest = new ExpressOutletsQueryRequest();
        queryRequest.setOrgType(request.getOrgType());
        queryRequest.setOrgCode(request.getOrgCode());
        queryRequest.setCpCode(request.getCpCode());
        return queryRequest;
    }
}
