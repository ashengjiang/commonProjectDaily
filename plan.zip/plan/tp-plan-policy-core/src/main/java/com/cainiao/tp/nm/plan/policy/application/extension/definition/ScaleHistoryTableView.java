package com.cainiao.tp.nm.plan.policy.application.extension.definition;

import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyRuleRecordDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyTemplateDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyViewConfigHolder;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyCustomTypeEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyInstanceStatusEnum;
import com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;


@Service
public class ScaleHistoryTableView extends AbstractHistoryTableView{

    /**
     * 获取展示视图模版编码
     *
     * <p>根据政策模版DTO获取展示视图模版编码，如果未配置则抛出异常
     *
     * @param policyTemplateDTO 政策模版DTO
     * @return 返回展示视图模版编码，如果未配置则抛出异常
     */
    @Override
    protected String getTempCode(PolicyTemplateDTO policyTemplateDTO) {
        String tempCode = super.getTempCode(policyTemplateDTO);
        if (StringUtils.isNotBlank(tempCode)) {
            return tempCode;
        }
        String customType = policyTemplateDTO.getCustomType();
        if (PolicyCustomTypeEnum.STATION.getType().equals(customType)) {
            return PolicyViewConfigHolder.getINSTANCE().getStationDefaultConfig().getHistoryLogViewCode();
        }
        if (PolicyCustomTypeEnum.EXPRESS.getType().equals(customType)) {
            return PolicyViewConfigHolder.getINSTANCE().getExpressDefaultConfig().getHistoryLogViewCode();
        }
        throw new RuntimeException("未配置展示视图模版，请联系管理员，政策模版ID=" + policyTemplateDTO.getId());
    }

    @Override
    public String getCode() {
        return AbstractHistoryTableView.CODE_DEFAULT;
    }

    @Override
    protected List<PolicyRuleRecordDTO> postProcess(List<PolicyRuleRecordDTO> resultList) {
        if(CollectionUtils.isEmpty(resultList)){
            return resultList;
        }
        resultList=super.postProcess(resultList);
        resultList.stream().filter(rule -> Objects.isNull(rule.getDistrict())).forEach(rule -> rule.setDistrict("全城"));
        return mergeHistoryCycleTime(resultList);
    }


    private List<PolicyRuleRecordDTO> mergeHistoryCycleTime(List<PolicyRuleRecordDTO> dataSource) {
        if (CollectionUtils.isEmpty(dataSource)) {
            return dataSource;
        }
        Map<Byte, List<PolicyRuleRecordDTO>> statusMap = dataSource.stream().collect(Collectors.groupingBy(PolicyRuleRecordDTO::getStatus));
        statusMap.forEach((status, ruleList) -> {
            if (CollectionUtils.isEmpty(ruleList)) {
                return;
            }
            ruleList =  ruleList.stream().sorted(Comparator.comparing(PolicyRuleRecordDTO::getReportTime).reversed()).collect(Collectors.toList());
            if (PolicyInstanceStatusEnum.EFFECT.getCode().equals(status)) {
                mergeHistoryRuleDetailStartTimeToEndTime(ruleList);
            }else {
                mergeTime(ruleList);
            }
        });
        return statusMap.values()
                .stream()
                .flatMap(List::stream)
                .sorted(Comparator.comparing(PolicyRuleRecordDTO::getReportTime).reversed())
                .collect(Collectors.toList());
    }

    public static void mergeTime(List<PolicyRuleRecordDTO> historyDetailDTOList) {
        if (CollectionUtils.isEmpty(historyDetailDTOList)) {
            return;
        }
        historyDetailDTOList.forEach(dto -> {
            if (Objects.isNull(dto.getEffectTime())) {
                return;
            }
            dto.setEffectCycle(dto.getEffectTime() + "至" + dto.getEndTime());
        });
    }


    public static void mergeHistoryRuleDetailStartTimeToEndTime(List<PolicyRuleRecordDTO> historyDetailDTOList) {
        if (CollectionUtils.isEmpty(historyDetailDTOList)) {
            return;
        }
        // 特殊处理第一条
        if (historyDetailDTOList.size() == 1) {
            PolicyRuleRecordDTO policyRuleDetailDTO = historyDetailDTOList.stream().findFirst().orElseThrow(() -> new AladdinBizException("error_code", "没有需要合并时间的数据"));
            if (Objects.isNull(policyRuleDetailDTO.getEffectTime())) {
                return;
            }
            policyRuleDetailDTO.setEffectCycle(policyRuleDetailDTO.getEffectTime() + "至" + policyRuleDetailDTO.getEndTime());
        }
        // 遍历数据源，从第二条开始
        for (int i = 1; i < historyDetailDTOList.size(); i++) {
            PolicyRuleRecordDTO current = historyDetailDTOList.get(i);
            PolicyRuleRecordDTO previous = historyDetailDTOList.get(i - 1);
            // 第二条 和 第一条 数据的开始生效时间相同 表示通一天生效的
            if (current.getEffectTime().equals(previous.getEffectTime())) {
                continue;
            }
            // 将当前数据的结束时间设置为前一条数据的开始时间-1 (前一条数据的开始时间)
            if (i ==1){
                previous.setEffectCycle(previous.getEffectTime() + "至" + previous.getEndTime());
            }
            current.setEffectCycle(current.getEffectTime() + "至" + DateUtils.localDateTimeToYmdStr(DateUtils.addOrSubtractDays(DateUtils.toLocalDateTimeYmdStart(previous.getEffectTime()), -1)));
        }
    }
}
