package com.cainiao.tp.nm.plan.policy.common.util;

import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.aladdin.utils.Safes;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.StationIncentiveBillDetailDTO;
import com.google.common.collect.Maps;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @code date 2025年08月05日 16:40
 * @code desc:null
 */
public class ReflectUtils {

    public static Map<String, Field> flatFieldMap(List<Field> fieldList) {
        return Safes.of(fieldList).stream().collect(Collectors.toMap(
                Field::getName,
                field -> field,
                (existing, replacement) -> existing));
    }


    public static List<Field> getFieldList(Object object, Class<? extends Annotation> annotationClass) {
        return Arrays.stream(object.getClass().getDeclaredFields()).
                filter(field -> field.isAnnotationPresent(annotationClass))
                .peek(field -> field.setAccessible(true))
                .collect(Collectors.toList());
    }

    public static String getFieldValueString(Object obj, Field field) {
        try {
            if (field == null) {
                return null;
            }
            return String.valueOf(field.get(obj));
        } catch (Exception e) {
            throw new AladdinBizException("获取字段值失败", e);
        }
    }

    public static Object getFieldValue(Object obj, Field field) {
        try {
            if (field == null) {
                return null;
            }
            return field.get(obj);
        } catch (Exception e) {
            throw new AladdinBizException("获取字段值失败", e);
        }
    }
    public static Map<String,Object> buildQlContextMap(Map<String, Field> flatFieldMap, StationIncentiveBillDetailDTO detail){
        if (flatFieldMap == null){
            return null;
        }
        HashMap<String, Object> contextMap = Maps.newHashMap();
        flatFieldMap.forEach((k,v)->{
            contextMap.put(k,getFieldValue(detail,v));
        });
        return contextMap;
    }
}
