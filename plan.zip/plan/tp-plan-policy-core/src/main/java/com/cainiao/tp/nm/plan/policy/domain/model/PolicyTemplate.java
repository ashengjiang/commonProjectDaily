package com.cainiao.tp.nm.plan.policy.domain.model;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cainiao.aladdin.domain.BaseBean;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyTemplateCreateParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyTemplateDeleteParam;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyInstanceApprovalStatusEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyTemplateStatusEnum;
import com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils;
import com.cainiao.tp.nm.plan.policy.domain.model.valobj.incentiveplan.IncentivePlan;
import com.cainiao.tp.nm.plan.policy.domain.model.valobj.launchplan.LaunchPlan;
import com.google.common.collect.Maps;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.collections4.MapUtils;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * @code date 2025年05月29日 13:56
 * @code desc: 政策模版实体类
 */
@Getter
@Builder
public class PolicyTemplate extends BaseBean {

    /**
     * 模版id
     */
    private Long id;

    /**
     * 模版id
     */
    private String templateName;

    /**
     * 客户类型
     */
    private String customType;

    /**
     * 业务类型
     */
    private String bizType;

    /**
     * 开始时间
     */
    private LocalDateTime startTime;

    /**
     * 结束时间
     */
    private LocalDateTime endTime;

    /**
     * 状态
     */
    private Byte status;

    /**
     * 审批状态
     */
    private Byte approvalStatus;

    /**
     * 版本号
     */
    private Long version;

    /**
     * 最后操作人ID
     */
    private Long lastOperatorId;

    /**
     * 投放方案
     */
    private LaunchPlan launchPlan;

    /**
     * 激励方案
     */
    @Setter
    private List<IncentivePlan> incentivePlanList;

    /**
     * feature
     */
    private Map<String, String> featureMap;

    /**
     * 创建时间
     */
    private LocalDateTime gmtCreate;


    /**
     * 创建一个新模版
     * @return
     */
    public static PolicyTemplate create(PolicyTemplateCreateParam param){
        // 这里字段一样 先简单点实现
        LaunchPlan launchPlan = JSONObject.parseObject(JSONObject.toJSONString(param.getLaunchPlan()), LaunchPlan.class);
        List<IncentivePlan> incentivePlanList = JSONArray.parseArray(JSONArray.toJSONString(param.getIncentivePlanList()), IncentivePlan.class);
        // 填充空code
        incentivePlanList.forEach(plan -> plan.getContent().fillCode());

        LocalDateTime startTime = DateUtils.toLocalDateTimeYmdStart(param.getStartTimeStr());
        LocalDateTime endTime = DateUtils.addOrSubtractDays(DateUtils.toLocalDateTimeYmdStart(param.getEndTimeStr()), 1);

        return PolicyTemplate.builder()
                .templateName(param.getTemplateName())
                .customType(param.getCustomType())
                .bizType(param.getBizType())
                .startTime(startTime)
                .endTime(endTime)
                .status(PolicyTemplateStatusEnum.WAITING_EFFECT.getCode())
                .version(1L)
                .lastOperatorId(param.getOperatorId())
                .launchPlan(launchPlan)
                .incentivePlanList(incentivePlanList)
                .featureMap(param.getFeatureMap())
                .build();
    }

    /**
     * 生效
     */
    public void effect(){
        AssertUtil.isTrue(PolicyTemplateStatusEnum.WAITING_EFFECT.getCode().equals(this.status)
                , "状态机异常");

        LocalDateTime now = LocalDateTime.now();
        AssertUtil.isTrue(now.isBefore(this.endTime), "政策周期已结束");

        this.status = PolicyTemplateStatusEnum.EFFECT.getCode();
    }

    /**
     * 失效
     */
    public void loseEffect(){
        AssertUtil.isTrue(PolicyTemplateStatusEnum.WAITING_EFFECT.getCode().equals(this.status)
                , "状态机异常");

        this.status = PolicyTemplateStatusEnum.LOSE_EFFECT.getCode();
    }

    /**
     * 设置审批状态是审批中
     */
    public void approvaling(){
        AssertUtil.isTrue(PolicyTemplateStatusEnum.WAITING_EFFECT.getCode().equals(this.status), "状态机异常");
        this.approvalStatus = PolicyInstanceApprovalStatusEnum.APPROVALING.getCode();
    }

    /**
     * 逻辑删除政策，不修改状态
     * @param param
     */
    public void delete(PolicyTemplateDeleteParam param){
        AssertUtil.isTrue(LocalDateTime.now().isBefore(this.startTime), "政策周期已开始，不允许删除");
        this.lastOperatorId = param.getOperatorId();
        addFeature(param.getFeatureMap());
    }

    public void addFeature(Map<String, String> featureMap){
        if(MapUtils.isEmpty(featureMap)){
            return;
        }

        if(null == this.featureMap){
            this.featureMap = Maps.newHashMap();
        }

        this.featureMap.putAll(featureMap);
    }

}
