package com.cainiao.tp.nm.plan.policy.adaptor.component.rights;

import lombok.Builder;
import lombok.Data;

import java.util.List;
import java.util.Set;

/**
 * @description: 权限控制上下文
 */
@Data
@Builder
public class RightsControlContext {

    /**
     * 是否拥有角色权限(true-拥有RightsControl注解的全部角色权限)
     */
    private boolean hasRoleRights;

    /**
     * 是否拥有全国地区权限
     */
    private boolean hasCnRights;

    /**
     * 拥有的城市权限列表
     */
    private Set<Long> cityCodeList;

}
