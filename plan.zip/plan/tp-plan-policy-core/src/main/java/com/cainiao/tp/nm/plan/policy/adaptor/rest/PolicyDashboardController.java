package com.cainiao.tp.nm.plan.policy.adaptor.rest;

import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.aladdin.utils.Safes;
import com.cainiao.sutee.commons.restful.result.CnRestResult;
import com.cainiao.tp.boot.annotation.TpController;
import com.cainiao.tp.boot.annotation.access.TpBucAccess;
import com.cainiao.tp.boot.annotation.access.TpMoziAccess;
import com.cainiao.tp.boot.utils.TpWebUtil;
import com.cainiao.tp.nm.plan.policy.adaptor.component.rights.RightsControl;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.base.ColumnVO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.PolicyInstanceQueryRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.PolicyInstanceRuleHistoryQueryRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.PolicyTemplateDashboardQueryRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.BaseTableVO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.PolicyStatisticsVO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.PolicyTemplateDetailVO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyInstanceStatisticsDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyTemplateDetailDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.base.BaseTableDTO;
import com.cainiao.tp.nm.plan.api.policy.application.service.dashboard.PolicyDashboardAppService;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @code date 2025年06月03日 13:49
 * @code desc: 政策看板接口层
 */
@TpBucAccess
@TpController
@TpMoziAccess(allowAliEmployee = true)
@RequestMapping("/policy/dashboard")
public class PolicyDashboardController {

    @Resource
    private PolicyDashboardAppService policyDashboardAppService;

    /**
     * 查询政策实例详情
     *
     * @param request 查询请求
     * @return 政策实例详情
     */
    @RightsControl(roleCodeArray = {"scale_policy_admin"})
    @GetMapping("/queryPolicyDetail")
    public CnRestResult<List<PolicyTemplateDetailVO>> queryPolicyInstanceDetail(PolicyTemplateDashboardQueryRequest request) {
        AbstractOperation operation = TpWebUtil.getWebOperation();
        List<PolicyTemplateDetailDTO> templateDetails = policyDashboardAppService.queryPolicyInstanceDetail(request, operation);
        return CnRestResult.succeed(Safes.of(templateDetails).stream().map(this::convertTemplateDetailVO).collect(Collectors.toList()));
    }

    /**
     * 查询政策实例统计
     *
     * @param request 查询请求
     * @return 政策实例统计
     */
    @RightsControl(roleCodeArray = {"scale_policy_admin"})
    @GetMapping("/queryPolicyInstanceStatistics")
    public CnRestResult<List<PolicyStatisticsVO>> queryPolicyInstanceStatistics(PolicyInstanceQueryRequest request) {
        AbstractOperation operation = TpWebUtil.getWebOperation();
        List<PolicyInstanceStatisticsDTO> dtoList = policyDashboardAppService.queryPolicyInstanceStatistics(request, operation);
        return CnRestResult.succeed(Safes.of(dtoList).stream().map(this::convertPolicyStatisticsVO).collect(Collectors.toList()));
    }

    /**
     * 查询政策实例项详情
     *
     * @param request 查询请求
     * @return 政策实例项详情
     */
    @RightsControl(roleCodeArray = {"scale_policy_admin"})
    @PostMapping("/queryApprovedPolicyItem")
    public CnRestResult<BaseTableVO> queryApprovedPolicyInstanceItem(@RequestBody PolicyInstanceQueryRequest request) {
        AbstractOperation operation = TpWebUtil.getWebOperation();
        BaseTableDTO baseTableDTO = policyDashboardAppService.queryApprovedPolicyInstanceRule(request, operation);
        return CnRestResult.succeed(convertInstanceRuleVO(baseTableDTO));
    }


    /**
     * 查询政策实例项历史
     *
     * @param request 查询请求
     * @return 政策实例项历史
     */
    @RightsControl(roleCodeArray = {"scale_policy_admin"})
    @GetMapping("/queryPolicyItemReportHistory")
    public CnRestResult<BaseTableVO> queryPolicyInstanceItemReportHistory(PolicyInstanceRuleHistoryQueryRequest request) {
        AbstractOperation operation = TpWebUtil.getWebOperation();
        BaseTableDTO tableDTO = policyDashboardAppService.queryPolicyInstanceInstanceRuleReportHistory(request, operation);
        return CnRestResult.succeed(convertInstanceRuleVO(tableDTO));
    }

    /**
     * 下载导出
     *
     * @param request 查询请求
     * @return 政策实例项详情
     */
    @GetMapping("/export")
    @RightsControl(roleCodeArray = {"scale_policy_admin"})
    public CnRestResult<String> export(PolicyInstanceQueryRequest request) {
        AbstractOperation operation = TpWebUtil.getWebOperation();
        return CnRestResult.succeed(policyDashboardAppService.export(request, operation));
    }

    private PolicyTemplateDetailVO convertTemplateDetailVO(PolicyTemplateDetailDTO dto) {
        PolicyTemplateDetailVO vo = new PolicyTemplateDetailVO();
        BeanUtils.copyProperties(dto, vo);
        return vo;
    }

    private PolicyStatisticsVO convertPolicyStatisticsVO(PolicyInstanceStatisticsDTO dto) {
        PolicyStatisticsVO policyStatisticsVO = new PolicyStatisticsVO();
        BeanUtils.copyProperties(dto, policyStatisticsVO);
        return policyStatisticsVO;
    }

    private BaseTableVO convertInstanceRuleVO(BaseTableDTO dto) {
        if (dto == null) {
            return null;
        }
        BaseTableVO vo = new BaseTableVO();
        BeanUtils.copyProperties(dto, vo);
        List<ColumnVO> columnVOS = Safes.of(dto.getColumns()).stream().map(columnDTO -> {
            ColumnVO columnVO = new ColumnVO();
            BeanUtils.copyProperties(columnDTO, columnVO);
            return columnVO;
        }).collect(Collectors.toList());
        vo.setColumns(columnVOS);
        return vo;
    }
}
