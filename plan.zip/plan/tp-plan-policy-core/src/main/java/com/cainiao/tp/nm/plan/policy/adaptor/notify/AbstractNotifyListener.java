package com.cainiao.tp.nm.plan.policy.adaptor.notify;

import com.cainiao.aladdin.log.AladdinCommLog;
import com.cainiao.aladdin.log.BizType;
import com.cainiao.aladdin.log.utils.AladdinLogUtil;
import com.taobao.notify.message.Message;
import com.taobao.notify.remotingclient.MessageListener;
import com.taobao.notify.remotingclient.MessageStatus;
import com.taobao.notify.utils.UniqId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 接收消息基类
 * @date 2020/12/05 23:32
 */
public abstract class AbstractNotifyListener<T> implements MessageListener {

    private static final Logger LOGGER = LoggerFactory.getLogger(AbstractNotifyListener.class);


    /**
     * 消息转换为实体
     * @param message
     * @return
     */
    protected abstract T convert(Message message);

    /**
     * 消息处理
     * 1、根据消息体匹配所有事件处理器
     * 2、事件处理器顺序执行，失败不阻塞，直至所有事件执行完成
     * 3、所有事件处理器执行成功则返回成功，任意失败则消息回滚
     * 4、具体消息处理器，需保证逻辑幂等
     * @param message
     * @param messageStatus
     * @return
     */
    @Override
    public void receiveMessage(Message message, MessageStatus messageStatus) {
        AladdinCommLog commLog = AladdinLogUtil.newCommLog(BizType.DEFAULT, "AbstractMessageListener#receiveMessage");
        commLog.setParams(UniqId.getInstance().bytes2string(message.getMessageId()));

        try {
            //1.获取消息实体
            T event = this.convert(message);
            if(null == event){
                return;
            }

            //2.消息直接过滤掉
            if(!this.filter(event,message)){
                return;
            }

            //3.返回结果，任意失败事件处理器执行失败则返回失败
            boolean result = doConsume(event, message);
            if(!result){
                messageStatus.setRollbackOnly();
            }
            AladdinLogUtil.log(LOGGER, commLog);
        } catch (Throwable e) {
            messageStatus.setRollbackOnly();
            AladdinLogUtil.log(LOGGER, e, commLog);
        }
    }

    /**
     * 消息过滤
     * @param event
     * @param message
     * @return
     */
    protected abstract boolean filter(T event,Message message);

    /**
     * 业务逻辑
     * @param event
     * @param message
     * @return
     */
    protected abstract boolean doConsume(T event,Message message);
}
