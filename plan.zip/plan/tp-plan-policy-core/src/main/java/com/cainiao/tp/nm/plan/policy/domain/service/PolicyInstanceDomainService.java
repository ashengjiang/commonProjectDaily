package com.cainiao.tp.nm.plan.policy.domain.service;

import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyInstanceCreateParam;
import com.cainiao.tp.nm.plan.policy.domain.model.PolicyInstance;
import com.cainiao.tp.nm.plan.policy.domain.model.PolicyTemplate;

/**
 * @code date 2025年3月10日
 * @code desc: 政策实例领域服务
 */
public interface PolicyInstanceDomainService {

    /**
     * 创建政策实例
     */
    PolicyInstance createInstance(PolicyTemplate policyTemplate, PolicyInstanceCreateParam createRequest);
}
