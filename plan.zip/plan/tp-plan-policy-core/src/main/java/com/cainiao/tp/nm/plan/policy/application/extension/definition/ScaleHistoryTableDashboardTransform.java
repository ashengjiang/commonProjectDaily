package com.cainiao.tp.nm.plan.policy.application.extension.definition;

import com.alibaba.fastjson.JSONObject;
import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.aladdin.utils.Safes;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.tp.nm.plan.api.policy.application.dto.*;
import com.cainiao.tp.nm.plan.api.policy.application.dto.base.ColumnDTO;
import com.cainiao.tp.nm.plan.api.policy.common.constants.*;
import com.cainiao.tp.nm.plan.policy.application.convert.PolicyInstanceRuleApplicationConvert;
import com.cainiao.tp.nm.plan.api.policy.application.dto.base.BaseTableDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiverule.IncentiveRuleDetailDTO;
import com.cainiao.tp.nm.plan.infra.port.policy.DivisionManager;
import com.cainiao.tp.nm.plan.infra.port.policy.LocalCacheManager;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyInstanceQueryManager;
import com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils;
import com.google.common.collect.Lists;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.cainiao.tp.nm.plan.policy.application.convert.PolicyInstanceRuleApplicationConvert.buildDivisionMap;
import static com.cainiao.tp.nm.plan.policy.application.convert.PolicyInstanceRuleApplicationConvert.buildHistoryRuleColumn;
import static com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyCommonConstants.SPLICING;
import static com.cainiao.tp.nm.plan.policy.application.convert.PolicyInstanceRuleApplicationConvert.mergeHistoryRuleDetailStartTimeToEndTime;
import static com.cainiao.tp.nm.plan.policy.application.convert.PolicyInstanceRuleApplicationConvert.mergeTime;

/**
 * @code date 2025年06月09日 15:52
 * @code desc: 规模历史表-政策看板视图转换
 */
@Component
public class ScaleHistoryTableDashboardTransform implements PolicyDashBoardViewTransform {
    @Resource
    private DivisionManager divisionManager;
    @Resource
    private LocalCacheManager localCacheManager;
    @Resource
    private PolicyInstanceQueryManager instanceQueryManager;

    @Override
    public String getTransformType() {
        return PolicyBizTypeEnum.SCALE.getType() + SPLICING + DashBoardViewTypeEnum.HISTORY_TABLE.getViewType();
    }

    @Override
    public BaseTableDTO transform(List<PolicyInstanceRuleDTO> ruleDTOList) {
        if (CollectionUtils.isEmpty(ruleDTOList)) {
            return null;
        }
        PolicyInstanceRuleDTO policyInstanceRuleDTO = ruleDTOList.stream().findFirst().orElseThrow(() -> new AladdinBizException("error_code", "没有需要转化的数据"));
        String customType = policyInstanceRuleDTO.getCustomType();
        List<PolicyInstanceRuleHistoryDetailDTO> dataSource = buildHistoryRuleDataSource(ruleDTOList);
        dataSource.stream().filter(rule -> Objects.isNull(rule.getDistrict())).forEach(rule -> rule.setDistrict("全城"));
        dataSource = mergeHistoryCycleTIme(dataSource);
        PolicyRuleHistoryDetailDTO table = new PolicyRuleHistoryDetailDTO();
        table.setColumns(buildRuleColumn(customType));
        table.setDataSource(Lists.newArrayList(dataSource));
        return table;
    }

    private List<PolicyInstanceRuleHistoryDetailDTO> mergeHistoryCycleTIme(List<PolicyInstanceRuleHistoryDetailDTO> dataSource) {
        if (CollectionUtils.isEmpty(dataSource)) {
            return dataSource;
        }
        Map<Byte, List<PolicyInstanceRuleHistoryDetailDTO>> statusMap = dataSource.stream().collect(Collectors.groupingBy(PolicyInstanceRuleHistoryDetailDTO::getInstanceStatus));
        statusMap.forEach((status, ruleList) -> {
            if (CollectionUtils.isEmpty(ruleList)) {
                return;
            }
            ruleList =  ruleList.stream().sorted(Comparator.comparing(PolicyInstanceRuleHistoryDetailDTO::getReportTime).reversed()).collect(Collectors.toList());
            if (PolicyInstanceStatusEnum.EFFECT.getCode().equals(status)) {
                mergeHistoryRuleDetailStartTimeToEndTime(ruleList);
            }else {
                mergeTime(ruleList);
            }
        });
        return statusMap.values()
                .stream()
                .flatMap(List::stream)
                .sorted(Comparator.comparing(PolicyInstanceRuleHistoryDetailDTO::getReportTime).reversed())
                .collect(Collectors.toList());
    }

    private List<PolicyInstanceRuleHistoryDetailDTO> buildHistoryRuleDataSource(List<PolicyInstanceRuleDTO> ruleDTOList) {
        return Safes.of(ruleDTOList).stream()
                .map(ruleDTO -> {
                    PolicyInstanceRuleHistoryDetailDTO detailDTO = new PolicyInstanceRuleHistoryDetailDTO();
                    BeanUtils.copyProperties(ruleDTO, detailDTO);

                    // 加载激励规则详情
                    List<IncentiveRuleDetailDTO> incentiveRuleDetaiLList = PolicyInstanceRuleApplicationConvert.buildIncentiveRuleDetail(ruleDTO);
                    Map<String, IncentiveRuleDetailDTO> incentiveMap = Safes.of(incentiveRuleDetaiLList)
                            .stream()
                            .filter(incentive -> ruleDTO.getIncentivePlanType().equals(incentive.getIncentiveType()))
                            .collect(Collectors.toMap(
                                    IncentiveRuleDetailDTO::getIncentiveStationCode,
                                    Function.identity(),
                                    (v1, v2) -> v1
                            ));
                    // 构建省市区
                    Optional<BaseDivisionInfoDTO> provinceByCode = divisionManager.getProvinceByCode(Long.valueOf(ruleDTO.getProvinceCode()));
                    BaseDivisionInfoDTO baseDivisionInfoDTO = provinceByCode.orElse(null);
                    Map<String, String> divisionMap = buildDivisionMap(baseDivisionInfoDTO);

                    PolicyInstanceDTO policyInstanceDTO = getPolicyInstanceDTO(ruleDTO.getInstanceId());
                    AssertUtil.notNull(policyInstanceDTO, "政策实例不存在");
                    Map<String, String> featureMap = policyInstanceDTO.getFeatureMap();
                    if (featureMap != null) {
                        detailDTO.setSubmitter(featureMap.getOrDefault(PolicyInstanceFeature.SUBMISSION_USER_NAME.getKey(), ""));
                        detailDTO.setReason(featureMap.getOrDefault(PolicyFeatureConstants.CANCEL_REASON, ""));
                    }
                    detailDTO.setProvince(divisionMap.get(ruleDTO.getProvinceCode()));
                    detailDTO.setCity(divisionMap.get(ruleDTO.getCityCode()));
                    detailDTO.setDistrict(divisionMap.get(ruleDTO.getDistrictCode()));

                    // 加载网点基本信息
                    ExpressOutletsBaseInfoDTO expressOutletsBaseInfo = PolicyInstanceRuleApplicationConvert.buildExpressOutletsBaseInfo(ruleDTO);
                    if (expressOutletsBaseInfo != null) {
                        detailDTO.setOrgCode(expressOutletsBaseInfo.getOrgCode());
                        detailDTO.setOrgType(expressOutletsBaseInfo.getOrgType());
                        detailDTO.setCpCode(expressOutletsBaseInfo.getCpCode());
                        detailDTO.setOrgName(expressOutletsBaseInfo.getOrgName());
                    }
                    detailDTO.setSelfServiceStationAmount(incentiveMap.getOrDefault(IncentivePlanStationTypeEnum.NON_STATION.getType(), new IncentiveRuleDetailDTO()).getResultVal());
                    detailDTO.setLightBarStationAmount(incentiveMap.getOrDefault(IncentivePlanStationTypeEnum.LIGHT_STATION.getType(), new IncentiveRuleDetailDTO()).getResultVal());
                    detailDTO.setBaseStationAmount(incentiveMap.getOrDefault(IncentivePlanStationTypeEnum.NORMAL_STATION.getType(), new IncentiveRuleDetailDTO()).getResultVal());
                    detailDTO.setStatus(PolicyInstanceApprovalStatusEnum.getDescByCode(ruleDTO.getApprovalStatus()));
                    detailDTO.setInstanceStatus(ruleDTO.getStatus());
                    if(Objects.nonNull(ruleDTO.getStartTime())){
                        detailDTO.setEffectTime(DateUtils.localDateTimeToYmdStr(ruleDTO.getStartTime()));
                    }
                    detailDTO.setEndTime(DateUtils.localDateTimeToYmdStr(DateUtils.addOrSubtractDays(ruleDTO.getEndTime(), -1)));
                    detailDTO.setReportTime(DateUtils.localDateTimeToYmdhmsStr(ruleDTO.getGmtCreate()));
                    return detailDTO;
                }).collect(Collectors.toList());
    }

    private PolicyInstanceDTO getPolicyInstanceDTO(Long instanceId) {
        if (instanceId == null) {
            return null;
        }
        PolicyInstanceDTO instanceCacheDTO = localCacheManager.get(instanceId.toString(), PolicyInstanceDTO.class);
        if (instanceCacheDTO != null) {
            return instanceCacheDTO;
        }
        PolicyInstanceDTO instanceDTO = instanceQueryManager.queryPolicyInstanceById(instanceId);
        localCacheManager.set(instanceId.toString(), instanceDTO);
        return instanceDTO;
    }

    public List<ColumnDTO> buildRuleColumn(String customType){
        if(StringUtils.isBlank(customType)){
            return Lists.newArrayList();
        }
        List<ExcelHead> excelHead = getExcelHead(customType);
        return  excelHead.stream().map(head->{
            ColumnDTO columnDTO = new ColumnDTO();
            columnDTO.setTitle(head.getHeadName());
            columnDTO.setDataIndex(head.getFieldKey());
            return columnDTO;
        }).collect(Collectors.toList());
    }

    public List<ExcelHead> getExcelHead(String customType) {
        String tempCode = getTempCode(customType);
        return TpExportHeadHolder.getINSTANCE().getHead(tempCode);
    }

    public String getTempCode(String customType) {
        if ( PolicyCustomTypeEnum.STATION.getType().equals(customType)) {
            return "ScaleStationHistoryTableTemp";
        }
        if ( PolicyCustomTypeEnum.EXPRESS.getType().equals(customType)) {
            return "ScaleExpressHistoryTableTemp";
        }
        //todo 异常统一处理
        throw new RuntimeException("未配置展示模版,请联系管理员配置");
    }

}
