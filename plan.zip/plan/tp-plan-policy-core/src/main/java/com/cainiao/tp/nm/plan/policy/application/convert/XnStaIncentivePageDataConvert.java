package com.cainiao.tp.nm.plan.policy.application.convert;

import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.aladdin.utils.Safes;
import com.cainiao.tp.nm.plan.api.policy.application.dto.StationIncentivePageConfigHolder;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.StationIncentiveBillDetailDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.XnStationOptCntStatsDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.light.ActivityConditionDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.light.ActivityStatsDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.light.OptCntHistoryDTO;
import com.cainiao.tp.nm.plan.api.policy.common.constants.StationIncentivePlanEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.XnStaActivityCardStatusEnum;
import com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils;
import com.google.common.collect.Lists;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import static com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils.DS_DATE_PATTERN;

/**
 * @code date 2025年08月08日 11:00
 * @code desc:null
 */
public class XnStaIncentivePageDataConvert {

    private static final List<String> needFlexibleQuarterList = Lists.newArrayList("fy26q1");

    public static BigDecimal getXnIncentiveAmount(List<StationIncentiveBillDetailDTO> detailDTOList) {
        if (CollectionUtils.isEmpty(detailDTOList)) {
            return BigDecimal.ZERO;
        }
        Long reduce = detailDTOList.stream()
                .map(StationIncentiveBillDetailDTO::getAmountCent)
                .filter(StringUtils::isNotBlank)
                .map(Long::parseLong)
                .reduce(0L, Long::sum);
        return BigDecimal.valueOf(reduce).divide(BigDecimal.valueOf(100), 0, RoundingMode.DOWN);
    }

    public static String getXnOptCnt(List<StationIncentiveBillDetailDTO> detailDTOList) {
        if (CollectionUtils.isEmpty(detailDTOList)) {
            return "0";
        }
        StationIncentiveBillDetailDTO baseDetail = Safes.of(detailDTOList).stream().findFirst().orElseThrow(() -> new AladdinBizException("Err", "溪鸟站点基础激励不存在"));
        String arrCnt = baseDetail.getStatsMonthAvgVaildArrCnt();
        return new BigDecimal(arrCnt).setScale(0, RoundingMode.HALF_UP).toString();
    }

    public static ActivityStatsDTO buildActivityStats(List<StationIncentiveBillDetailDTO> detailDTOList) {
        if (CollectionUtils.isEmpty(detailDTOList)) {
            return null;
        }
        BigDecimal incentiveAmount = getXnIncentiveAmount(detailDTOList);
        String xnOptCnt = getXnOptCnt(detailDTOList);
        String cardStatus = getXnActivityCardStatus(detailDTOList);

        ActivityStatsDTO activityStats = new ActivityStatsDTO();
        activityStats.setAmount(incentiveAmount.toString());
        activityStats.setOptCnt(xnOptCnt);
        activityStats.setUnIssuedReason(formatNoStatSatisfyReason(detailDTOList));
        activityStats.setInspireLevel(xnOptCnt);
        activityStats.setInspireRange(buildInspireRange(detailDTOList));
        activityStats.setStatus(cardStatus);
        return activityStats;
    }

    public static String getXnActivityCardStatus(List<StationIncentiveBillDetailDTO> detailDTOList) {
        if (CollectionUtils.isEmpty(detailDTOList)) {
            return null;
        }
        StationIncentiveBillDetailDTO detailDTO = detailDTOList.stream().findFirst().orElseThrow(() -> new AladdinBizException("Err", "获取溪鸟站点激励数据失败"));
        // 考核月巴枪入库率
        Boolean bqIsReach = checkIsReach(detailDTO.getStatsMonthBqArrRate());
        // 考核月高拍仪出库率
        Boolean gpyIsReach = checkIsReach(detailDTO.getStatsMonthGpyPickupRate());
        // 站点类型，是否灯条站
        Boolean isLightStation = detailDTO.getIsLightStationNew();
        // 判断是否发放账单
        Boolean isIssued = Objects.nonNull(detailDTO.getIsSubsidy()) ? detailDTO.getIsSubsidy() : false;
        return XnStaActivityCardStatusEnum.getCardStatus(isIssued, bqIsReach && gpyIsReach && isLightStation);
    }

    private static boolean checkIsReach(String rate) {
        if (StringUtils.isBlank(rate)) {
            return false;
        }
        return Double.parseDouble(rate) > 0.5;
    }

    private static String formatNoStatSatisfyReason(List<StationIncentiveBillDetailDTO> detailDTOList) {
        if (CollectionUtils.isEmpty(detailDTOList)) {
            return "暂无原因";
        }
        StationIncentiveBillDetailDTO detailDTO = detailDTOList.stream().findFirst().orElseThrow(() -> new AladdinBizException("Err", "获取溪鸟站点激励数据失败"));

        if (StringUtils.isBlank(detailDTO.getNoSatisfyReason())) {
            return "暂无原因";
        }
        List<String> collect = Arrays.stream(StringUtils.split(detailDTO.getNoSatisfyReason(), "/")).filter(StringUtils::isNotBlank).collect(Collectors.toList());
        return String.join("、", collect);
    }

    public static List<ActivityStatsDTO.PracticeInspireRangeDO> buildInspireRange(List<StationIncentiveBillDetailDTO> detailDTOList) {
        StationIncentivePageConfigHolder instance = StationIncentivePageConfigHolder.getINSTANCE();
        List<StationIncentivePageConfigHolder.BaseInspire> inspireRange = instance.getInspireRange();
        if (CollectionUtils.isEmpty(detailDTOList)) {
            return inspireRange.stream().map(baseInspire -> {
                ActivityStatsDTO.PracticeInspireRangeDO practiceInspireRangeDO = new ActivityStatsDTO.PracticeInspireRangeDO();
                practiceInspireRangeDO.setOptCnt(baseInspire.getOptCnt());
                practiceInspireRangeDO.setAmount(baseInspire.getAmount());
                return practiceInspireRangeDO;
            }).collect(Collectors.toList());
        }
        Double coefficient = detailDTOList.stream().peek(detailDTO -> {
                    if (StationIncentivePlanEnum.BASE.getType().equals(detailDTO.getIncentivePlanType()) && StringUtils.isBlank(detailDTO.getCoefficient())) {
                        detailDTO.setCoefficient("1");
                    }
                }).map(StationIncentiveBillDetailDTO::getCoefficient)
                .filter(StringUtils::isNotBlank)
                .map(Double::parseDouble)
                .reduce(0.0, Double::sum);
        return Safes.of(inspireRange).stream().map(baseInspire -> {
            ActivityStatsDTO.PracticeInspireRangeDO practiceInspireRangeDO = new ActivityStatsDTO.PracticeInspireRangeDO();
            practiceInspireRangeDO.setOptCnt(baseInspire.getOptCnt());
            practiceInspireRangeDO.setAmount(new BigDecimal(baseInspire.getAmount()).multiply(BigDecimal.valueOf(coefficient)).setScale(0, RoundingMode.CEILING).toString());
            return practiceInspireRangeDO;
        }).collect(Collectors.toList());
    }

    public static List<ActivityConditionDTO> buildStaTypeCondition(StationIncentiveBillDetailDTO detailDTO) {
        if (detailDTO == null || !needFlexibleQuarterList.contains(detailDTO.getFiscalQuarter())) {
            return null;
        }
        List<ActivityConditionDTO> conditions = Lists.newArrayList();
        ActivityConditionDTO condition = new ActivityConditionDTO();
        condition.setName("站点类型");
        condition.setCurrent(detailDTO.getIsLightStationNew() ? "灯条站" : "普通站");
        condition.setTarget("灯条站");
        condition.setIsReach(detailDTO.getIsLightStationNew());
        conditions.add(condition);
        return conditions;
    }

    public static List<ActivityConditionDTO> buildHardwareCondition(StationIncentiveBillDetailDTO detailDTO) {
        if (detailDTO == null) {
            return null;
        }

        List<ActivityConditionDTO> conditions = Lists.newArrayList();
        // 考核月巴枪入库率
        BigDecimal bqBigDecimal = new BigDecimal(detailDTO.getStatsMonthBqArrRate()).multiply(new BigDecimal("100")).setScale(2, RoundingMode.HALF_UP);
        // 考核月高拍仪出库率
        BigDecimal gpyBigDecimal = new BigDecimal(detailDTO.getStatsMonthGpyPickupRate()).multiply(new BigDecimal("100")).setScale(2, RoundingMode.HALF_UP);
        ActivityConditionDTO bqCondition = new ActivityConditionDTO();
        bqCondition.setName("巴枪使用率");
        bqCondition.setCurrent(bqBigDecimal + "%");
        bqCondition.setTarget("50%");
        bqCondition.setIsReach(bqBigDecimal.compareTo(new BigDecimal("50")) > 0);
        conditions.add(bqCondition);

        ActivityConditionDTO gpyCondition = new ActivityConditionDTO();
        gpyCondition.setName("高拍仪出库率");
        gpyCondition.setCurrent(gpyBigDecimal + "%");
        gpyCondition.setTarget("50%");
        gpyCondition.setIsReach(gpyBigDecimal.compareTo(new BigDecimal("50")) > 0);
        conditions.add(gpyCondition);

        return conditions;
    }

    public static List<OptCntHistoryDTO> buildOptCntHistory(List<XnStationOptCntStatsDTO> optCntStatsDTOS) {
        if (CollectionUtils.isEmpty(optCntStatsDTOS)) {
            return null;
        }
        return optCntStatsDTOS.stream().map(dto -> {
            OptCntHistoryDTO optCntHistory = new OptCntHistoryDTO();
            optCntHistory.setDate(DateUtils.convertToDashFormat(dto.getStatsDate(), DS_DATE_PATTERN));
            if (new BigDecimal(dto.getStatsMonthAvgVaildArrCnt()).compareTo(BigDecimal.ZERO) < 0) {
                optCntHistory.setOptCnt("0");
                return optCntHistory;
            }
            String optAvgCnt = new BigDecimal(dto.getStatsMonthAvgVaildArrCnt()).setScale(0, RoundingMode.HALF_UP).toString();
            optCntHistory.setOptCnt(optAvgCnt);
            return optCntHistory;
        }).collect(Collectors.toList());
    }


}
