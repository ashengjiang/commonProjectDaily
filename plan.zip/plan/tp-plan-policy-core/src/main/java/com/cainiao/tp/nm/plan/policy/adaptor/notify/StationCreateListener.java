package com.cainiao.tp.nm.plan.policy.adaptor.notify;

import com.alibaba.cainiao.stationplatform.client.domain.StationStationDTO;
import com.alibaba.cainiao.stationplatform.common.constants.StationConstants;
import com.alibaba.cainiao.stationplatform.common.notify.StationModifyEvent;
import com.cainiao.aladdin.log.AladdinCommLog;
import com.cainiao.aladdin.log.AladdinMapLog;
import com.cainiao.aladdin.log.BizType;
import com.cainiao.aladdin.log.utils.AladdinLogUtil;
import com.cainiao.aladdin.operation.SystemBizOperation;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.tp.nm.plan.api.policy.application.dto.StationDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.NewStaPerformSubsidyConfigDTO;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyConfigManager;
import com.cainiao.tp.nm.plan.infra.port.policy.StaStationReadManager;
import com.cainiao.tp.nm.plan.infra.port.policy.TpPushStationMessageManager;
import com.cainiao.tp.nm.plan.policy.application.convert.NewStaPerformSubsidyConvert;
import com.google.common.collect.Lists;
import com.taobao.notify.message.Message;
import com.taobao.notify.message.ObjectMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;


/**
 * 站点状态变更消息处理
 */
@Slf4j
@Service(value = "stationCreateListener")
public class StationCreateListener extends AbstractNotifyListener<StationModifyEvent> {

    @Resource
    private StaStationReadManager staStationReadManager;
    @Resource
    private TpPushStationMessageManager tpPushStationMessageManager;
    @Resource
    private PolicyConfigManager policyConfigManager;

    @Override
    protected StationModifyEvent convert(Message message) {
        AladdinMapLog mapLog = AladdinLogUtil.newMapLog("StationCreateListener.convert", BizType.DEFAULT);
        try {
            ObjectMessage objectMessage = (ObjectMessage) message;
            StationModifyEvent event = (StationModifyEvent) objectMessage.getObject();
            return event;
        } catch (Throwable t) {
            mapLog.addParam("convert failed", t.getMessage());
            AladdinLogUtil.log(log, mapLog, t);
            return null;
        }
    }

    @Override
    protected boolean filter(StationModifyEvent event, Message message) {
        Integer bizType = event.getBizType();
        Integer operationType = event.getOperationType();
        // 只监听站点修改新增的消息
        if (StationConstants.BizType.STATION.getValue().equals(bizType)
                && StationConstants.OpType.ADD.getValue().equals(operationType)) {
            return true;
        }
        return false;
    }

    /**
     * 接收库存变更消息
     */
    @Override
    protected boolean doConsume(StationModifyEvent event, Message message) {
        SystemBizOperation operation = new SystemBizOperation(303544L, "建宇", "监听站点创建的消息");
        AladdinCommLog commLog = AladdinLogUtil.newCommLog(BizType.DEFAULT, operation);
        List<Object> logContext = Lists.newArrayList();
        commLog.setContext(logContext);
        commLog.setParams(message.getMessageId());
        logContext.add("eventBody : " + event);
        try {
            StationStationDTO newStation = (StationStationDTO)event.getBodyAfter();
//            StationStationDTO oldStation = (StationStationDTO)event.getBodyBefore();
            Long stationId = newStation.getStationId();

            // 1.查询站点信息
            StationDTO stationDTO = staStationReadManager.queryStationById(stationId);
            AssertUtil.notNull(stationDTO, "站点不存在");

            // 2.查询激励活动配置数据
            NewStaPerformSubsidyConfigDTO subsidyConfig = policyConfigManager.getNewStaPerformSubsidyConfig();

            boolean judgeBasicCond = NewStaPerformSubsidyConvert.judgeBasicCond(stationDTO, subsidyConfig);
//            boolean judgeBuildStaCond = NewStaPerformSubsidyConvert.judgeBuildStaCond(stationDTO);
            if(subsidyConfig.getRuleDetailTop100CityCodeList().contains(stationDTO.getCityCode()) && judgeBasicCond){
                // 发送消息弹窗
                tpPushStationMessageManager.sendNewStaPerformSubsidyPopup(stationId);
            }

        } catch (Throwable t) {
            return AladdinLogUtil.log(log, t, commLog, false);
        }
        return AladdinLogUtil.log(log, commLog, true);
    }

}
