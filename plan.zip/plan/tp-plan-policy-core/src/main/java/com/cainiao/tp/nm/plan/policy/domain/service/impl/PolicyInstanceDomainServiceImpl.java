package com.cainiao.tp.nm.plan.policy.domain.service.impl;

import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyInstanceCreateParam;
import com.cainiao.tp.nm.plan.policy.domain.component.PolicyInstanceDefinition;
import com.cainiao.tp.nm.plan.policy.domain.component.factory.PolicyInstanceDefinitionFactory;
import com.cainiao.tp.nm.plan.policy.domain.model.PolicyInstance;
import com.cainiao.tp.nm.plan.policy.domain.model.PolicyTemplate;
import com.cainiao.tp.nm.plan.policy.domain.service.PolicyInstanceDomainService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * @description: 政策实例领域服务
 * @date: 2025/3/10
 */
@Service
public class PolicyInstanceDomainServiceImpl implements PolicyInstanceDomainService {

    @Resource
    private PolicyInstanceDefinitionFactory policyInstanceDefinitionFactory;

    @Override
    public PolicyInstance createInstance(PolicyTemplate template, PolicyInstanceCreateParam param) {
        PolicyInstanceDefinition definition = policyInstanceDefinitionFactory.getDefinition(template.getBizType(), template.getCustomType());
        // 1.校验政策实例
        definition.validCreate(template, param);

        // 2.构建政策实例
        PolicyInstance policyInstance = PolicyInstance.create(template, param);

        // 3.设置实例优先级
        definition.decisionPriority(template, policyInstance);

        return policyInstance;
    }
}
