package com.cainiao.tp.nm.plan.policy.common.util;

import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.aladdin.log.AladdinErrorCode;
import com.ql.util.express.DefaultContext;
import com.ql.util.express.ExpressRunner;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Map;
import java.util.Optional;

/**
 * @code date 2025年08月04日 11:01
 * @code desc:ql工具
 */
public class QlUtils {

    private static final ExpressRunner RUNNER = new ExpressRunner(true, false);

    public static Object executeQlScript(String qlScript, Map<String, Object> contextMap) {
        try {
            DefaultContext<String, Object> defaultContext = new DefaultContext<>();
            defaultContext.putAll(contextMap);
            return RUNNER.execute(qlScript, defaultContext, null, true, false);
        } catch (Exception e) {
            throw new AladdinBizException(AladdinErrorCode.STA_BIZ_WARN.getCode(), e.getMessage());
        }

    }

    /**
     * 表单式使用 数字转百分比
     * @param number 数字
     * @return 百分比
     */
    public static String rateFormat(String number) {
        if (StringUtils.isBlank(number) || BigDecimal.ZERO.toString().equals(number)) {
            return BigDecimal.ZERO.toString();
        }
        return new BigDecimal(number).multiply(new BigDecimal("100")).setScale(2, RoundingMode.DOWN).toString();
    }


    /**
     * 表单式使用 数字转百分比
     * @param bqRate 数字
     * @return 百分比
     */
    public static String maxRateFormat(String bqRate,String gpyRate) {
        Double bqValue = Optional.ofNullable(bqRate).map(Double::valueOf).orElse(0d);
        Double gpyValue = Optional.ofNullable(gpyRate).map(Double::valueOf).orElse(0d);
        double max = Math.max(bqValue, gpyValue) * 100;
        return new BigDecimal(max).setScale(2, RoundingMode.DOWN).toString();
    }

    /**
     * 表单式使用 数字转百分比
     * @param bqRate 数字
     * @return 百分比
     */
    public static Boolean maxRateIsQualified(String bqRate,String gpyRate) {
        Double bqValue = Optional.ofNullable(bqRate).map(Double::valueOf).orElse(0d);
        Double gpyValue = Optional.ofNullable(gpyRate).map(Double::valueOf).orElse(0d);
        return Math.max(bqValue, gpyValue) > 0.5;
    }




}
