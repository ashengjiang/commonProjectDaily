package com.cainiao.tp.nm.plan.policy.adaptor.component.station;

import com.cainiao.tp.nm.plan.infra.port.dto.context.StationPermissionContext;

/**
 * @code date 2025年07月31日 14:55
 * @code desc:null
 */
public class StationPermissionUtils {

    private static final ThreadLocal<StationPermissionContext> tl = new ThreadLocal<>();

    public static void setContent(StationPermissionContext context) {
        tl.set(context);
    }

    public static StationPermissionContext getContent() {
        return tl.get();
    }

    public static void remove() {
        tl.remove();
    }
}
