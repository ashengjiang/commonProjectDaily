package com.cainiao.tp.nm.plan.policy.adaptor.mtop;

import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.sutee.commons.base.result.CnResult;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.XnStationIncentiveRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.station.light.XnStationIncentiveCardVO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.station.light.XnStationIncentiveStatsVO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.service.XnStationNewBuildIncentiveService;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.station.XnStaIncentiveQueryParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.light.XnStaPracticeIncentiveDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.light.XnStaPracticeIncentiveStatsDetailDTO;
import com.cainiao.tp.nm.plan.api.policy.application.service.station.XnStaIncentiveAppService;
import com.cainiao.tp.nm.plan.policy.adaptor.component.station.StationPermissionCheck;
import com.cainiao.tp.nm.plan.policy.adaptor.convert.StationIncentiveConvert;

import javax.annotation.Resource;

/**
 * @code date 2025年08月08日 09:58
 * @code desc:null
 */
@HSFProvider(serviceInterface = XnStationNewBuildIncentiveService.class)
public class XnStationNewBuildIncentiveServiceImpl implements XnStationNewBuildIncentiveService {

    @Resource
    private XnStaIncentiveAppService xnStaIncentiveAppService;


    /**
     * 判断站点激励卡片是否需要展示
     *
     * @param request 统计月份
     * @return 激励条件
     */
    @Override
    @StationPermissionCheck
    public CnResult<XnStationIncentiveCardVO> checkIncentiveActivityCard(XnStationIncentiveRequest request) {
        AssertUtil.notNull(request,"请求参数不能为空");
        AssertUtil.notNull(request.getStatsMonth(), "统计月份不能为空");
        request.setStatsMonth(request.getStatsMonth().replace("-", ""));
        XnStaIncentiveQueryParam param = buildIncentiveQueryParam(request);
        XnStaPracticeIncentiveDTO incentiveDTO = xnStaIncentiveAppService.queryStaPracticeIncentiveBaseInfo(param);
        return CnResult.succeed(StationIncentiveConvert.convertXnIncentiveVO(incentiveDTO));
    }

    /**
     * 查询激励统计详情
     *
     * @param request 统计月份
     * @return 激励统计详情
     */
    @Override
    @StationPermissionCheck
    public CnResult<XnStationIncentiveStatsVO> queryIncentiveStatsDetail(XnStationIncentiveRequest request) {
        AssertUtil.notNull(request.getStatsMonth(), "统计月份不能为空");
        request.setStatsMonth(request.getStatsMonth().replace("-", ""));
        XnStaIncentiveQueryParam param = buildIncentiveQueryParam(request);
        XnStaPracticeIncentiveStatsDetailDTO statsDetailDTO = xnStaIncentiveAppService.queryStaPracticeIncentiveStatsDetail(param);
        return CnResult.succeed(StationIncentiveConvert.convertXnIncentiveStatsVO(statsDetailDTO));
    }

    private XnStaIncentiveQueryParam buildIncentiveQueryParam(XnStationIncentiveRequest request) {
        XnStaIncentiveQueryParam queryParam = new XnStaIncentiveQueryParam();
        queryParam.setStatsMonth(request.getStatsMonth());
        queryParam.setStationId(request.getStationId());
        return queryParam;
    }
}
