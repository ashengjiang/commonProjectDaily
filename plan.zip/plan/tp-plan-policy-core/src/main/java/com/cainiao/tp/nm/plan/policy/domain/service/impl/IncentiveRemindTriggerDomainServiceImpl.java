package com.cainiao.tp.nm.plan.policy.domain.service.impl;

import com.cainiao.tp.nm.plan.api.policy.application.dto.IncentiveRemindHolder;
import com.cainiao.tp.nm.plan.policy.domain.service.IncentiveRemindTriggerDomainService;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

/**
 * 站点实操激励提醒推送触发日计算领域服务实现
 *
 * @date 2026-03-27
 */
@Component
public class IncentiveRemindTriggerDomainServiceImpl implements IncentiveRemindTriggerDomainService {

    @Override
    public boolean isTriggerDay(LocalDate joinDate, LocalDate today) {
        int assessMonthOffset = calcAssessMonthOffset(joinDate, today);
        if (assessMonthOffset < 0) {
            // 超出考核期，不触发
            return false;
        }

        int todayDayOfMonth = today.getDayOfMonth();

        if (assessMonthOffset == 0) {
            // T月：推送日为 S+偏移量（偏移量由 Diamond 配置决定）
            return isTMonthTriggerDay(joinDate, today);
        } else if (assessMonthOffset <= 2) {
            // T+1月、T+2月：固定推送日由 Diamond 配置决定
            return IncentiveRemindHolder.getINSTANCE().getT1T2TriggerDayList().contains(todayDayOfMonth);
        } else {
            // T+3月：固定推送日由 Diamond 配置决定
            return IncentiveRemindHolder.getINSTANCE().getT3TriggerDayList().contains(todayDayOfMonth);
        }
    }

    @Override
    public int calcAssessMonthOffset(LocalDate joinDate, LocalDate today) {
        // 以入驻月第一天为基准，计算当前月与入驻月的月份差
        LocalDate joinMonthStart = joinDate.withDayOfMonth(1);
        LocalDate todayMonthStart = today.withDayOfMonth(1);
        long monthOffset = ChronoUnit.MONTHS.between(joinMonthStart, todayMonthStart);

        int maxAssessMonthOffset = IncentiveRemindHolder.getINSTANCE().getMaxAssessMonthOffsetValue();
        if (monthOffset < 0 || monthOffset > maxAssessMonthOffset) {
            return -1;
        }

        // T+3月超过最后推送日后不再触发，最后推送日取 T3 推送日列表的最大值
        if (monthOffset == maxAssessMonthOffset) {
            List<Integer> t3TriggerDayList = IncentiveRemindHolder.getINSTANCE().getT3TriggerDayList();
            if (t3TriggerDayList.isEmpty()) {
                // T3 推送日列表为空，视为考核期已结束
                return -1;
            }
            int lastT3TriggerDay = t3TriggerDayList.stream().mapToInt(Integer::intValue).max().getAsInt();
            if (today.getDayOfMonth() > lastT3TriggerDay) {
                return -1;
            }
        }

        return (int) monthOffset;
    }

    /**
     * 判断 T月（入驻当月）是否为推送触发日
     * 推送日为 S+偏移量，若超出当月自然日则取当月最后一天，偏移量由 Diamond 配置决定
     *
     * @param joinDate 入驻日期
     * @param today    当前日期
     * @return true=是推送触发日
     */
    private boolean isTMonthTriggerDay(LocalDate joinDate, LocalDate today) {
        int joinDay = joinDate.getDayOfMonth();
        int lastDayOfMonth = today.lengthOfMonth();
        int todayDayOfMonth = today.getDayOfMonth();

        for (int offset : IncentiveRemindHolder.getINSTANCE().getTMonthDayOffsetList()) {
            // 计算推送日，超出当月最后一天则取最后一天
            int triggerDay = Math.min(joinDay + offset, lastDayOfMonth);
            if (triggerDay == todayDayOfMonth) {
                return true;
            }
        }
        return false;
    }
}
