package com.cainiao.tp.nm.plan.policy.domain.service;

import com.cainiao.tp.nm.plan.api.policy.application.dto.IncentiveRemindRuleDTO;
import com.cainiao.tp.nm.plan.policy.application.dto.IncentiveAssessContextDTO;

import java.util.List;

/**
 * 站点实操激励提醒 QL 规则匹配领域服务
 * 使用 QLExpress 表达式引擎，按顺序匹配规则列表，返回第一条满足条件的规则
 *
 * @date 2026-03-27
 */
public interface IncentiveRemindRuleMatchDomainService {

    /**
     * 按顺序匹配通知规则，返回第一条满足条件的规则（短路匹配）
     * 若无规则匹配则返回 null，不发送通知
     *
     * @param ruleList 通知规则列表（来自 Diamond 配置）
     * @param context  站点激励考核数据上下文
     * @return 匹配到的规则，未匹配返回 null
     */
    IncentiveRemindRuleDTO matchRule(List<IncentiveRemindRuleDTO> ruleList, IncentiveAssessContextDTO context);
}
