package com.cainiao.tp.nm.plan.policy.application.component.station;

import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.aladdin.utils.Safes;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.tp.nm.plan.api.policy.application.annotation.Validate;
import com.cainiao.tp.nm.plan.api.policy.application.dto.StationIncentivePageConfigHolder;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.StationIncentiveBillDetailDTO;
import com.cainiao.tp.nm.plan.policy.common.util.QlUtils;
import com.cainiao.tp.nm.plan.policy.common.util.ReflectUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import static com.cainiao.tp.nm.plan.policy.common.util.ReflectUtils.flatFieldMap;
import static com.cainiao.tp.nm.plan.policy.common.util.ReflectUtils.getFieldList;
import static com.cainiao.tp.nm.plan.policy.common.util.ReflectUtils.getFieldValueString;

/**
 * @code date 2025年08月05日 16:20
 * @code desc:站点激励数据校验
 */
public class StationIncentiveDataValidate {
    private static final Map<String, List<Field>> validateFieldCache = new ConcurrentHashMap<>();

    private static final List<String> specialQuarterList = Arrays.asList("fy25q2", "fy25q3");
    public static String validate(List<StationIncentiveBillDetailDTO> detailList, String quarter) {
        if (CollectionUtils.isEmpty(detailList)) {
            return null;
        }
        StationIncentiveBillDetailDTO detail = detailList.stream().findFirst().orElseThrow(() -> new AladdinBizException("error", "站点激励数据为空"));
        List<Field> validateField = getValidateField(detail.getStationId(), detail);
        Map<String, Field> flatFieldMap = flatFieldMap(validateField);
        Map<String, Object> contextMap = ReflectUtils.buildQlContextMap(flatFieldMap, detail);

        // 正常验证逻辑
        StationIncentivePageConfigHolder instance = StationIncentivePageConfigHolder.getINSTANCE();
        List<StationIncentivePageConfigHolder.ValidateField> validateFieldConfig = instance.getValidateFieldList(quarter);
        AssertUtil.notNull(validateFieldConfig, "站点激励页面字段验证信息为空");
        for (StationIncentivePageConfigHolder.ValidateField validateConfig : validateFieldConfig) {
            if (StringUtils.isNotBlank(validateConfig.getValidQl())){
                Object value = QlUtils.executeQlScript(validateConfig.getValidQl(), contextMap);
                if (value == null) {
                    continue;
                }
                return value.toString();
            }else {
                if (CollectionUtils.isNotEmpty(validateConfig.getComposeFieldName())) {
                    boolean anyMatch = validateConfig.getComposeFieldName().stream().anyMatch(f -> {
                        Field composeField = flatFieldMap.get(f);
                        AssertUtil.notNull(composeField, validateConfig.getErrMsg());
                        return validateConfig.getExpectValue().equals(getFieldValueString(detail, composeField));
                    });
                    if (anyMatch) {
                        continue;
                    }
                    return validateConfig.getErrMsg();
                }
                Field field = flatFieldMap.get(validateConfig.getFieldName());
                AssertUtil.notNull(field, validateConfig.getErrMsg());
                if (StringUtils.equals(validateConfig.getExpectValue(), getFieldValueString(detail, field))) {
                    return validateConfig.getErrMsg();
                }
            }
        }
        // 特殊处理fy25q2和q3
        if (specialQuarterList.contains(quarter)) {
            boolean allReasonContains = detailList.stream().allMatch(item -> {
                String itemReason = Optional.ofNullable(item.getNoSatisfyReason()).orElse("");
                return itemReason.contains("首月激励考核未达标");
            });
            if (allReasonContains) {
                return "您的站点未进入首月激励（实操入库天数<15天/菜鸟设备使用不达标/日均入库单量<100单 ）";
            }
        }
        return null;
    }


    private static List<Field> getValidateField(String stationId, StationIncentiveBillDetailDTO detail) {
        return validateFieldCache.computeIfAbsent(stationId, func -> getFieldList(detail, Validate.class));
    }
}
