package com.cainiao.tp.nm.plan.policy.application.service;

import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.cainiao.aladdin.lock.Lock;
import com.cainiao.aladdin.log.AladdinCommLog;
import com.cainiao.aladdin.log.utils.AladdinLogUtil;
import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.aladdin.utils.Safes;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.aladdin.validate.utils.ValidateUtil;
import com.cainiao.sutee.commons.base.model.CnPage;
import com.cainiao.sutee.commons.base.model.Page;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.PolicyInstanceQueryRequest;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyInstanceDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.PolicyApproveConfigDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyInstanceCreateParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyInstanceEffectParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyInstanceFeatureParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyInstanceLoseEffectParam;
import com.cainiao.tp.nm.plan.api.policy.application.service.PolicyInstanceAppService;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyConfigManager;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyTairLockManager;
import com.cainiao.tp.nm.plan.policy.application.convert.PolicyInstanceApplicationConvert;
import com.cainiao.tp.nm.plan.policy.application.event.PolicyInstanceAppEventPublisher;
import com.cainiao.tp.nm.plan.policy.common.util.PolicyLockUtils;
import com.cainiao.tp.nm.plan.policy.domain.component.PolicyInstanceDefinition;
import com.cainiao.tp.nm.plan.policy.domain.component.factory.PolicyInstanceDefinitionFactory;
import com.cainiao.tp.nm.plan.policy.domain.model.PolicyInstance;
import com.cainiao.tp.nm.plan.policy.domain.model.PolicyTemplate;
import com.cainiao.tp.nm.plan.policy.domain.repository.PolicyInstanceRepository;
import com.cainiao.tp.nm.plan.policy.domain.repository.PolicyTemplateRepository;
import com.cainiao.tp.nm.plan.policy.domain.service.PolicyInstanceDomainService;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @code date 2025年3月10日
 * @code desc:政策实例 appservice
 */
@Slf4j
@HSFProvider(serviceInterface = PolicyInstanceAppService.class)
public class PolicyInstanceAppServiceImpl implements PolicyInstanceAppService {

    @Resource
    private PolicyTairLockManager policyTairLockManager;
    @Resource
    private PolicyConfigManager policyConfigManager;
    @Resource
    private PolicyTemplateRepository policyTemplateRepository;
    @Resource
    private PolicyInstanceRepository policyInstanceRepository;
    @Resource
    private PolicyInstanceDomainService policyInstanceDomainService;
    @Resource
    private PolicyInstanceDefinitionFactory policyInstanceDefinitionFactory;
    @Resource
    private PolicyInstanceAppEventPublisher policyInstanceAppEventPublisher;

    @Override
    public void create(PolicyInstanceCreateParam param, AbstractOperation operation) {
        AladdinCommLog aladdinCommLog = AladdinLogUtil.newCommLog(operation);
        Map<String,Object> logContext = Maps.newHashMap();
        aladdinCommLog.setParams(param);
        aladdinCommLog.setContext(logContext);
        Lock lock = null;
        try {
            // 基础非空校验
            ValidateUtil.validateAndThrow(param);
            lock = PolicyLockUtils.getPolicyInstanceLock(param.getTemplateId());
            policyTairLockManager.tryLockAndThrow(lock);

            // 获取政策模版
            PolicyTemplate policyTemplate = policyTemplateRepository.get(param.getTemplateId());
            AssertUtil.isTrue(null != policyTemplate, "模版不存在");

            // 调用领域服务
            PolicyInstance policyInstance = policyInstanceDomainService.createInstance(policyTemplate, param);

            // 获取是否需要审批
            PolicyApproveConfigDTO approval = policyConfigManager.getApproveConfig(policyTemplate.getBizType(), policyTemplate.getCustomType());
            if(null != approval && approval.isInsatnceApprove()){
                // 需要审批，审批中
                policyInstance.approvaling();
            }else{
                // 无需审批，直接生效
                policyInstance.effect();
            }

            // 调用仓储
            Long instanceId = policyInstanceRepository.create(policyInstance);

            // 发送应用事件
            policyInstanceAppEventPublisher.create(PolicyInstanceApplicationConvert.createEvent(param, instanceId));

            AladdinLogUtil.log(log, aladdinCommLog);
        } catch (Throwable e) {
            AladdinLogUtil.log(log, e, aladdinCommLog);
            throw e;
        } finally {
            if (lock != null) {
                policyTairLockManager.release(lock);
            }
        }
    }

    @Override
    public void validBeforeCreate(PolicyInstanceCreateParam param, AbstractOperation operation) {
        AladdinCommLog aladdinCommLog = AladdinLogUtil.newCommLog(operation);
        Map<String,Object> logContext = Maps.newHashMap();
        aladdinCommLog.setParams(param);
        aladdinCommLog.setContext(logContext);
        try {
            // 基础非空校验
            ValidateUtil.validateAndThrow(param);

            // 获取政策模版
            PolicyTemplate template = policyTemplateRepository.get(param.getTemplateId());
            AssertUtil.isTrue(null != template, "模版不存在");

            PolicyInstanceDefinition definition = policyInstanceDefinitionFactory.getDefinition(template.getBizType(), template.getCustomType());
            // 校验
            definition.validCreate(template, param);

            AladdinLogUtil.log(log, aladdinCommLog);
        } catch (Throwable e) {
            AladdinLogUtil.log(log, e, aladdinCommLog);
            throw e;
        }
    }

    @Override
    public void effect(PolicyInstanceEffectParam param, AbstractOperation operation) {
        AladdinCommLog aladdinCommLog = AladdinLogUtil.newCommLog(operation);
        Map<String,Object> logContext = Maps.newHashMap();
        aladdinCommLog.setParams(param);
        aladdinCommLog.setContext(logContext);
        Lock lock = null;
        try {
            // 参数校验
            ValidateUtil.validateAndThrow(param);
            PolicyInstance policyInstance = policyInstanceRepository.get(param.getInstanceId());
            AssertUtil.notNull(policyInstance, "实例不存在");

            lock = PolicyLockUtils.getPolicyInstanceLock(policyInstance.getTemplateId());
            policyTairLockManager.tryLockAndThrow(lock);

            // 调用实体
            policyInstance.effect(param);

            // 调用仓储
            policyInstanceRepository.updateStatus(policyInstance);

            AladdinLogUtil.log(log, aladdinCommLog);
        } catch (Throwable e) {
            AladdinLogUtil.log(log, e, aladdinCommLog);
            throw e;
        } finally {
            if (lock != null) {
                policyTairLockManager.release(lock);
            }
        }
    }

    @Override
    public void loseEffect(PolicyInstanceLoseEffectParam param, AbstractOperation operation) {
        AladdinCommLog aladdinCommLog = AladdinLogUtil.newCommLog(operation);
        Map<String,Object> logContext = Maps.newHashMap();
        aladdinCommLog.setParams(param);
        aladdinCommLog.setContext(logContext);
        Lock lock = null;
        try {
            // 参数校验
            ValidateUtil.validateAndThrow(param);
            PolicyInstance policyInstance = policyInstanceRepository.get(param.getInstanceId());
            AssertUtil.notNull(policyInstance, "实例不存在");

            lock = PolicyLockUtils.getPolicyInstanceLock(policyInstance.getTemplateId());
            policyTairLockManager.tryLockAndThrow(lock);

            // 调用实体
            policyInstance.loseEffect(param);

            // 调用仓储
            policyInstanceRepository.updateStatus(policyInstance);

            AladdinLogUtil.log(log, aladdinCommLog);
        } catch (Throwable e) {
            AladdinLogUtil.log(log, e, aladdinCommLog);
            throw e;
        } finally {
            if (lock != null) {
                policyTairLockManager.release(lock);
            }
        }
    }

    @Override
    public void updateFeature(PolicyInstanceFeatureParam param, AbstractOperation operation) {
        AladdinCommLog aladdinCommLog = AladdinLogUtil.newCommLog(operation);
        Map<String,Object> logContext = Maps.newHashMap();
        aladdinCommLog.setParams(param);
        aladdinCommLog.setContext(logContext);
        Lock lock = null;
        try {
            // 参数校验
            ValidateUtil.validateAndThrow(param);
            PolicyInstance policyInstance = policyInstanceRepository.get(param.getInstanceId());
            AssertUtil.notNull(policyInstance, "实例不存在");

            lock = PolicyLockUtils.getPolicyInstanceLock(policyInstance.getTemplateId());
            policyTairLockManager.tryLockAndThrow(lock);

            // 调用实体
            policyInstance.addFeature(param.getFeatureMap());

            // 调用仓储
            policyInstanceRepository.updateBasic(policyInstance);
            AladdinLogUtil.log(log, aladdinCommLog);
        } catch (Throwable e) {
            AladdinLogUtil.log(log, e, aladdinCommLog);
            throw e;
        } finally {
            if (lock != null) {
                policyTairLockManager.release(lock);
            }
        }
    }

    @Override
    public Page<PolicyInstanceDTO> queryPolicyInstanceList(PolicyInstanceQueryRequest request, AbstractOperation operation) {
        Page<PolicyInstance> policyInstancePage = policyInstanceRepository.queryPolicyInstanceList(
            PolicyInstanceApplicationConvert.queryParamConvert(request));
        List<PolicyInstanceDTO> policyInstanceDTOList = Safes.of(policyInstancePage.getPageItems())
            .stream()
            .map(PolicyInstanceApplicationConvert::modelToDto)
            .collect(Collectors.toList());
        return CnPage.of(request.getPageIndex(), request.getPageSize(), policyInstanceDTOList, policyInstancePage.getItemTotal());
    }

}
