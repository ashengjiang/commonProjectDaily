package com.cainiao.tp.nm.plan.policy.application.service.station;

import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.aladdin.log.AladdinCommLog;
import com.cainiao.aladdin.log.BizType;
import com.cainiao.aladdin.log.utils.AladdinLogUtil;
import com.cainiao.aladdin.utils.DateUtil;
import com.cainiao.aladdin.utils.Safes;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.aladdin.validate.utils.ValidateUtil;
import com.cainiao.tp.nm.plan.api.policy.application.dto.StationDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.NewStaPerformSubsidyConfigDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.PolicyIncentivePlanConfigDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.NewStaPerformSubsidyParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.StationIncentiveSubsidyBillParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.station.NewStaPerformSubsidyMonthQueryParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.station.NewStaPerformSubsidyQueryParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.station.StationIncentiveQueryParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.NewStaPerformSubsidyActivityDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.NewStaPerformSubsidyDataDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.StationIncentiveBillDetailDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.heavy.*;
import com.cainiao.tp.nm.plan.api.policy.application.service.station.StationIncentiveAppService;
import com.cainiao.tp.nm.plan.api.policy.common.constants.StationModeEnum;
import com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils;
import com.cainiao.tp.nm.plan.infra.port.policy.CacheManager;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyConfigManager;
import com.cainiao.tp.nm.plan.infra.port.policy.StaStationReadManager;
import com.cainiao.tp.nm.plan.infra.port.policy.TgManager;
import com.cainiao.tp.nm.plan.policy.application.component.station.StationIncentiveDataValidate;
import com.cainiao.tp.nm.plan.policy.application.convert.NewStaPerformSubsidyConvert;
import com.cainiao.tp.nm.plan.policy.application.convert.StationIncentiveAssessmentConvert;
import com.cainiao.tp.nm.plan.policy.application.convert.StationIncentivePageDataConvert;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.cainiao.tp.nm.plan.api.policy.common.constants.IncentivePageConstants.STATS_Y;
import static com.cainiao.tp.nm.plan.api.policy.common.constants.StationCommonConstants.ONE_DAY_EXPIRE;
import static com.cainiao.tp.nm.plan.api.policy.common.constants.StationCommonConstants.STATION_INCENTIVE_BILL_CACHE_KEY;
import static com.cainiao.tp.nm.plan.api.policy.common.constants.StationCommonConstants.STATION_INCENTIVE_METRICS_CACHE_KEY;
import static com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils.DS_DATE_PATTERN;


/**
 * @code date 2025年08月05日 14:12
 * @code desc:null
 */
@Component
@Slf4j
public class StationIncentiveAppServiceImpl implements StationIncentiveAppService {

    @Resource
    private TgManager tgManager;
    @Resource
    private StaStationReadManager staStationReadManager;
    @Resource
    private PolicyConfigManager policyConfigManager;
    @Resource
    private CacheManager cacheManager;

    private List<String> showCycleNum = Lists.newArrayList("1","2","3","4","5","6");
    @Override
    public StationIncentiveDTO queryStationIncentive(StationIncentiveQueryParam param) {
        ValidateUtil.validate(param);
        StationIncentiveDTO cacheDTO = cacheManager.get(buildBillCacheKey(param), StationIncentiveDTO.class);
        if (Objects.nonNull(cacheDTO)) {
            return cacheDTO;
        }
        StationIncentiveDTO incentiveDTO = new StationIncentiveDTO();
        List<StationIncentiveBillDetailDTO> billDetailList = queryIncentiveDetail(param);
        if (CollectionUtils.isEmpty(billDetailList)) {
            incentiveDTO.setNotActiveStation(STATS_Y);
            return incentiveDTO;
        }
        String validateErrMsg = StationIncentiveDataValidate.validate(billDetailList, param.getQuarter());
        if (StringUtils.isNotBlank(validateErrMsg)) {
            incentiveDTO.setResultFeedbackMsg(validateErrMsg);
            return incentiveDTO;
        }
        billDetailList = billDetailList.stream().filter(match -> StringUtils.isNotBlank(match.getCycleNum()) && showCycleNum.contains(match.getCycleNum())).collect(Collectors.toList());
        if (CollectionUtils.isEmpty(billDetailList)) {
            incentiveDTO.setNotActiveStation(STATS_Y);
            return incentiveDTO;
        }
        StationIncentiveBillDetailDTO lastAmountRecord = findLastAmountRecord(billDetailList);
        String dataDate = DateUtils.localDateToStr(DateUtils.strToLocalDate(lastAmountRecord.getDs(), DS_DATE_PATTERN), DS_DATE_PATTERN);

        Map<String, List<StationIncentiveBillDetailDTO>> cycleDetails = billDetailList.stream().collect(Collectors.groupingBy(StationIncentiveBillDetailDTO::getCycleNum));
        List<IncentiveCardDTO> cardList = Lists.newArrayList();
        cycleDetails.forEach((cycle, details) -> {
            cardList.add(StationIncentivePageDataConvert.assembleCard(details, param.getQuarter()));
        });
        IncentiveTipDTO tipDTO = StationIncentivePageDataConvert.assembleTip(cardList,param.getSource());
        incentiveDTO.setDataDate(dataDate);
        incentiveDTO.setTip(tipDTO);
        incentiveDTO.setCardList(cardList);
        cacheManager.set(buildBillCacheKey(param),incentiveDTO,ONE_DAY_EXPIRE);
        return incentiveDTO;
    }


    @Override
    public StationAssessmentDTO queryStationAssessment(StationIncentiveQueryParam param) {
        ValidateUtil.validate(param);
        StationAssessmentDTO cacheDTO = cacheManager.get(buildMetricsCacheKey(param), StationAssessmentDTO.class);
        if (Objects.nonNull(cacheDTO)) {
            return cacheDTO;
        }
        StationAssessmentDTO assessmentDTO = new StationAssessmentDTO();
        List<StationIncentiveBillDetailDTO> billDetailList = queryIncentiveDetail(param);
        if (CollectionUtils.isEmpty(billDetailList)) {
            assessmentDTO.setNotActiveStation(STATS_Y);
            return assessmentDTO;
        }
        StationIncentiveBillDetailDTO detailDTO = billDetailList.stream()
                .findFirst()
                .orElseThrow(() -> new AladdinBizException("VALIDATE_ERROR", "站点未查询到结算数据,stationId:", param.getStationId()));
        String validateErrMsg = StationIncentiveDataValidate.validate(billDetailList, param.getQuarter());

        if (StringUtils.isNotBlank(validateErrMsg)) {
            assessmentDTO.setResultFeedbackMsg(validateErrMsg);
            return assessmentDTO;
        }
        // 没有期数的数据不展示页面
        billDetailList = billDetailList.stream().filter(match -> StringUtils.isNotBlank(match.getCycleNum()) && showCycleNum.contains(match.getCycleNum())).collect(Collectors.toList());
        if (CollectionUtils.isEmpty(billDetailList)) {
            assessmentDTO.setNotActiveStation(STATS_Y);
            return assessmentDTO;
        }
        // 判断是否预计达标
        boolean anyMatch = Safes.of(billDetailList).stream().anyMatch(match -> Objects.nonNull(match.getChargeOffBillTime()));
        assessmentDTO.setIsPass(anyMatch);
        List<AssessmentCardDTO> assessmentCardDTOS = StationIncentiveAssessmentConvert.buildAssessment(detailDTO, param.getQuarter());
        if (CollectionUtils.isEmpty(assessmentCardDTOS)) {
            assessmentDTO.setNotActiveStation(STATS_Y);
            return assessmentDTO;
        }
        Map<String, AssessmentCardDTO> cardMap = assessmentCardDTOS.stream().collect(Collectors.toMap(AssessmentCardDTO::getCode, Function.identity(), (v1, v2) -> v1));
        assessmentDTO.setEquipmentUseDetailsCard(cardMap.get("equipmentUse"));
        assessmentDTO.setStationTypeCard(cardMap.get("stationType"));
        assessmentDTO.setStationBaseConditionCard(cardMap.get("stationBase"));
        assessmentDTO.setWarehouseOperationCard(cardMap.get("warehouseOperation"));
        assessmentDTO.setKeyStationCard(cardMap.get("keyStation"));
        cacheManager.set(buildMetricsCacheKey(param),assessmentDTO,ONE_DAY_EXPIRE);
        return assessmentDTO;
    }

    @Override
    public NewStaPerformSubsidyActivityDTO queryNewStaPerformSubsidy(NewStaPerformSubsidyQueryParam param) {
        AladdinCommLog aladdinCommLog = AladdinLogUtil.newCommLog(BizType.DEFAULT, "stationIncentiveAppServiceImpl.queryNewStaPerformSubsidy");
        Map<String,Object> logContext = Maps.newHashMap();
        aladdinCommLog.setParams(param);
        aladdinCommLog.setContext(logContext);
        try {
            ValidateUtil.validate(param);
            // 1.查询站点信息
            StationDTO stationDTO = staStationReadManager.queryStationById(param.getStationId());
            AssertUtil.notNull(stationDTO, "站点不存在");

            // 2.查询激励活动配置数据
            NewStaPerformSubsidyConfigDTO subsidyConfig = policyConfigManager.getNewStaPerformSubsidyConfig();

            // 3.查询结算数据
            List<NewStaPerformSubsidyDataDTO> subsidyData = null;
            boolean judgeBasicCond = NewStaPerformSubsidyConvert.judgeBasicCond(stationDTO, subsidyConfig);
//            boolean judgeBuildStaCond = NewStaPerformSubsidyConvert.judgeBuildStaCond(stationDTO);
            logContext.put("judgeBasicCond",judgeBasicCond);
//            logContext.put("judgeBuildStaCond",judgeBuildStaCond);
            if(judgeBasicCond) {
                // 这里先判断了基础条件，不满足的话就不用查询天宫了, 少一次查询
                NewStaPerformSubsidyParam subsidyParam = new NewStaPerformSubsidyParam();
                subsidyParam.setStationId(String.valueOf(param.getStationId()));
                subsidyData = tgManager.getListData(subsidyParam);
                logContext.put("subsidyDataIsNull", CollectionUtils.isEmpty(subsidyData));
            }

            // 4.构建新站激励数据
            NewStaPerformSubsidyActivityDTO activityDTO = StationIncentiveAssessmentConvert.buildNewStaPerformAssessment(subsidyData
                    , stationDTO, subsidyConfig);

            AladdinLogUtil.log(log, aladdinCommLog);
            return activityDTO;
        } catch (Throwable e) {
            AladdinLogUtil.log(log, e, aladdinCommLog);
            throw e;
        }
    }

    @Override
    public NewStaPerformSubsidyActivityDTO queryNewStaPerformMonthSubsidy(NewStaPerformSubsidyMonthQueryParam param) {
        AladdinCommLog aladdinCommLog = AladdinLogUtil.newCommLog(BizType.DEFAULT, "stationIncentiveAppServiceImpl.queryNewStaPerformMonthSubsidy");
        Map<String,Object> logContext = Maps.newHashMap();
        aladdinCommLog.setParams(param);
        aladdinCommLog.setContext(logContext);
        try {
            ValidateUtil.validate(param);
            // 1.查询结算数据
            NewStaPerformSubsidyParam subsidyParam = new NewStaPerformSubsidyParam();
            subsidyParam.setStationId(String.valueOf(param.getStationId()));
            subsidyParam.setStatsMonth(param.getAssessMonth());
            List<NewStaPerformSubsidyDataDTO> subsidyData = tgManager.getListData(subsidyParam);
            AssertUtil.isTrue(CollectionUtils.isNotEmpty(subsidyData), "考核月份不存在结算数据");
            subsidyData.sort(Comparator.comparing(NewStaPerformSubsidyDataDTO::getDs).reversed());

            // 2.查询配置数据
            NewStaPerformSubsidyConfigDTO subsidyConfig = policyConfigManager.getNewStaPerformSubsidyConfig();

            // 3.构建月新站激励数据
            NewStaPerformSubsidyActivityDTO activityDTO = StationIncentiveAssessmentConvert.buildOnlyMonthNewStaPerformAssessment(subsidyData.get(0)
                    ,subsidyConfig.getNewStaPerformSubsidyPriceQlExpress());

            StationDTO stationDTO = staStationReadManager.queryStationById(param.getStationId());
            Date fy26Q4Date = DateUtil.getStr2SDate(subsidyConfig.getFy26Q4StartDate());
            boolean isEntryFy26Q4 = stationDTO.getGmtCreate().after(fy26Q4Date);
            //FY26Q4之前达标条件删除【其它达标条件】
            if(!isEntryFy26Q4){
                activityDTO.removeSubsidyCond("noneRiskStaCondition");
            }
            AladdinLogUtil.log(log, aladdinCommLog);
            return activityDTO;
        } catch (Throwable e) {
            AladdinLogUtil.log(log, e, aladdinCommLog);
            throw e;
        }
    }

    private List<StationIncentiveBillDetailDTO> queryIncentiveDetail(StationIncentiveQueryParam param) {
        StationIncentiveSubsidyBillParam request = new StationIncentiveSubsidyBillParam();
        request.setFiscalQuarter(param.getQuarter());
        request.setCycleNum(param.getPeriod());
        request.setStationMode(StationModeEnum.HEAVY.getType());
        request.setStationId(param.getStationId());
        return tgManager.getListData(request);
    }

    /**
     * 取最新的一条有付款的详情信息
     */
    private static StationIncentiveBillDetailDTO findLastAmountRecord(List<StationIncentiveBillDetailDTO> details) {
        return details.stream()
                .filter(StationIncentiveAppServiceImpl::checkAmount)
                .max(Comparator.comparingInt(detail -> Integer.parseInt(detail.getCycleNum())))
                .orElse(details.get(0)); // 如果没有符合条件的记录，返回第一个
    }

    private static Boolean checkAmount(StationIncentiveBillDetailDTO detailDTO) {
        return detailDTO.getAmountCent() != null
                && new BigDecimal(detailDTO.getAmountCent()).longValue() > BigDecimal.ZERO.longValue()
                && detailDTO.getChargeOffBillTime() != null;
    }

    private String buildMetricsCacheKey(StationIncentiveQueryParam param) {
        return STATION_INCENTIVE_METRICS_CACHE_KEY + param.getStationId()+":"+param.getQuarter()+":"+param.getPeriod();
    }

    private String buildBillCacheKey(StationIncentiveQueryParam param) {
        return STATION_INCENTIVE_BILL_CACHE_KEY + param.getStationId()+":"+param.getQuarter();
    }
}
