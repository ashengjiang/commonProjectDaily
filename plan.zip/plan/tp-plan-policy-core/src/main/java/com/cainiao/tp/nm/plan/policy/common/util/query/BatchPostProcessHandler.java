package com.cainiao.tp.nm.plan.policy.common.util.query;

import java.util.List;

/**
 * 后置处理 */
public interface BatchPostProcessHandler<T> {

    /**
     * 后置处理
     *
     * @param t 数据
     */
    void postProcess(List<T> t);

}
