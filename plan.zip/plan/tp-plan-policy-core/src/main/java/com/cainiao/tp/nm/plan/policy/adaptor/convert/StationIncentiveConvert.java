package com.cainiao.tp.nm.plan.policy.adaptor.convert;

import com.cainiao.aladdin.utils.Safes;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.station.heavy.*;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.station.light.*;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.NewStaPerformSubsidyActivityDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.heavy.AssessmentCardDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.heavy.IncentiveTipDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.heavy.StationAssessmentDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.heavy.StationIncentiveDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.light.ActivityStatsDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.light.XnStaPracticeIncentiveDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.light.XnStaPracticeIncentiveStatsDetailDTO;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import static com.cainiao.tp.nm.plan.api.policy.common.constants.IncentivePageConstants.STATS_Y;

/**
 * @code date 2025年08月06日 10:07
 * @code desc:null
 */
public class StationIncentiveConvert {

    public static StationIncentiveVO stationIncentiveVO(StationIncentiveDTO dto) {
        StationIncentiveVO vo = new StationIncentiveVO();
        if (Objects.isNull(dto) || StringUtils.isNotBlank(dto.getNotActiveStation())) {
            vo.setNotActiveStation(STATS_Y);
            return vo;
        }
        if (StringUtils.isNotBlank(dto.getResultFeedbackMsg())) {
            vo.setResultFeedbackMsg(dto.getResultFeedbackMsg());
            return vo;
        }
        IncentiveTipDTO tip = dto.getTip();
        IncentiveTipVO tipVO = new IncentiveTipVO();
        BeanUtils.copyProperties(tip, tipVO);
        List<IncentiveCardVO> cardVOList = Safes.of(dto.getCardList()).stream().map(cardDTO -> {
            IncentiveCardVO cardVO = new IncentiveCardVO();
            List<IncentiveCardVO.Tag> tagList = Safes.of(cardDTO.getTags()).stream().map(tagDto -> {
                IncentiveCardVO.Tag tagVO = new IncentiveCardVO.Tag();
                BeanUtils.copyProperties(tagDto, tagVO);
                return tagVO;
            }).collect(Collectors.toList());

            List<IncentiveCardVO.DataItem> dataItemList = Safes.of(cardDTO.getData()).stream().map(dataItem -> {
                IncentiveCardVO.DataItem dataVO = new IncentiveCardVO.DataItem();
                BeanUtils.copyProperties(dataItem, dataVO);
                return dataVO;
            }).collect(Collectors.toList());
            cardVO.setTags(tagList);
            cardVO.setData(dataItemList);
            BeanUtils.copyProperties(cardDTO, cardVO);
            return cardVO;
        }).collect(Collectors.toList());
        vo.setDataDate(dto.getDataDate());
        vo.setTipVO(tipVO);
        vo.setCardListDataVO(cardVOList);
        vo.setResultFeedbackMsg(dto.getResultFeedbackMsg());
        vo.setNotActiveStation(dto.getNotActiveStation());
        return vo;
    }


    public static StationAssessmentVO convertAssessmentVO(StationAssessmentDTO dto) {
        StationAssessmentVO vo = new StationAssessmentVO();
        if (Objects.isNull(dto)) {
            vo.setNotActiveStation(STATS_Y);
            return vo;
        }
        vo.setEquipmentUseDetailsCard(convertCard(dto.getEquipmentUseDetailsCard()));
        vo.setStationBaseConditionCard(convertCard(dto.getStationBaseConditionCard()));
        vo.setWarehouseOperationCard(convertCard(dto.getWarehouseOperationCard()));
        vo.setStationTypeCard(convertCard(dto.getStationTypeCard()));
        vo.setKeyStationCard(convertCard(dto.getKeyStationCard()));
        BeanUtils.copyProperties(dto, vo);
        return vo;
    }

    public static AssessmentCardVO convertCard(AssessmentCardDTO dto) {
        if (dto == null ){
            return null;
        }
        AssessmentCardVO cardVO = new AssessmentCardVO();
        BeanUtils.copyProperties(dto, cardVO);
        List<AssessmentCardVO.Item> itemList = Safes.of(dto.getItems()).stream().map(item -> {
            AssessmentCardVO.Item voItem = new AssessmentCardVO.Item();
            BeanUtils.copyProperties(item, voItem);
            List<AssessmentCardVO.Tag> tags = Safes.of(item.getTags()).stream().map(tag -> {
                AssessmentCardVO.Tag tagVO = new AssessmentCardVO.Tag();
                BeanUtils.copyProperties(tag, tagVO);
                return tagVO;
            }).collect(Collectors.toList());
            voItem.setTags(tags);
            List<AssessmentCardVO.ExtraInfo> extraInfoVOlist = Safes.of(item.getExtraInfo()).stream().map(extraInfo -> {
                AssessmentCardVO.ExtraInfo extraVO = new AssessmentCardVO.ExtraInfo();
                BeanUtils.copyProperties(extraInfo, extraVO);
                return extraVO;
            }).collect(Collectors.toList());
            voItem.setExtraInfo(extraInfoVOlist);
            return voItem;
        }).collect(Collectors.toList());
        cardVO.setItems(itemList);
        return cardVO;
    }


    public static XnStationIncentiveCardVO convertXnIncentiveVO(XnStaPracticeIncentiveDTO dto) {
        if (Objects.isNull(dto)) {
            return null;
        }
        XnStationIncentiveCardVO vo = new XnStationIncentiveCardVO();
        BeanUtils.copyProperties(dto, vo);
        return vo;
    }

    public static XnStationIncentiveStatsVO convertXnIncentiveStatsVO(XnStaPracticeIncentiveStatsDetailDTO dto) {
        if (Objects.isNull(dto)) {
            return null;
        }
        XnStationIncentiveStatsVO vo = new XnStationIncentiveStatsVO();
        ActivityStatsDTO cardStats = dto.getActivityCardStats();
        if (Objects.nonNull(cardStats)) {
            ActivityStatsVO activityStatsVO = new ActivityStatsVO();
            BeanUtils.copyProperties(cardStats, activityStatsVO);
            List<ActivityStatsVO.PracticeInspireRangeDO> rangeVOList = Safes.of(cardStats.getInspireRange()).stream().map(range -> {
                ActivityStatsVO.PracticeInspireRangeDO rangeVO = new ActivityStatsVO.PracticeInspireRangeDO();
                BeanUtils.copyProperties(range, rangeVO);
                return rangeVO;
            }).collect(Collectors.toList());
            activityStatsVO.setInspireRange(rangeVOList);
            vo.setActivityCardStats(activityStatsVO);

        }
        List<ActivityConditionVO> flex = Safes.of(dto.getFlexibleConditions()).stream()
                .filter(Objects::nonNull)
                .map(flexCon -> {
                    ActivityConditionVO conditionVO = new ActivityConditionVO();
                    BeanUtils.copyProperties(flexCon, conditionVO);
                    return conditionVO;
                }).collect(Collectors.toList());
        vo.setFlexibleConditions(flex);

        List<ActivityConditionVO> base = Safes.of(dto.getBaseConditions()).stream()
                .filter(Objects::nonNull)
                .map(baseCon -> {
                    ActivityConditionVO conditionVO = new ActivityConditionVO();
                    BeanUtils.copyProperties(baseCon, conditionVO);
                    return conditionVO;
                }).collect(Collectors.toList());
        vo.setBaseConditions(base);

        List<OptCntHistoryVO> historyVOList = Safes.of(dto.getOptCntHistory()).stream()
                .filter(Objects::nonNull)
                .map(optCntDTO -> {
                    OptCntHistoryVO historyVO = new OptCntHistoryVO();
                    BeanUtils.copyProperties(optCntDTO, historyVO);
                    return historyVO;
                }).collect(Collectors.toList());
        vo.setOptCntHistory(historyVOList);
        vo.setNeedShow(dto.getNeedShow());
        return vo;
    }

    public static NewStaPerformSubsidyActivityVO convertNewStaPerformSubsidyVO(NewStaPerformSubsidyActivityDTO dto) {
        if (Objects.isNull(dto)) {
            return null;
        }
        NewStaPerformSubsidyActivityVO resp = new NewStaPerformSubsidyActivityVO();
        resp.setViewCode(dto.getViewCode());
        resp.setNotAllowMsg(dto.getNotAllowMsg());
        resp.setRuleDetailUrl(dto.getRuleDetailUrl());
        resp.setSubsidyCond(dto.getSubsidyCond());
        resp.setPredMonthSubsidy(dto.getPredMonthSubsidy());
        resp.setCumulativeSubsidy(dto.getCumulativeSubsidy());
        resp.setNextLadder(dto.getNextLadder());
        return resp;
    }
    public static NewStaPerformMonthSubsidyVO convertNewStaPerformMonthSubsidyVO(NewStaPerformSubsidyActivityDTO dto) {
        if (Objects.isNull(dto)) {
            return null;
        }
        NewStaPerformMonthSubsidyVO resp = new NewStaPerformMonthSubsidyVO();
        resp.setSubsidyCond(dto.getSubsidyCond());
        resp.setPredMonthSubsidy(dto.getPredMonthSubsidy());
        return resp;
    }



}
