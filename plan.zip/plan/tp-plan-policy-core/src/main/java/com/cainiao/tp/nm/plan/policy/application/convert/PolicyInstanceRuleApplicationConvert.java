package com.cainiao.tp.nm.plan.policy.application.convert;

import com.alibaba.fastjson.JSONObject;
import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.aladdin.utils.Safes;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.tp.nm.plan.api.policy.application.dto.*;
import com.cainiao.tp.nm.plan.api.policy.application.dto.base.ColumnDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiverule.*;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiverule.select.EntitySelectRuleDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiverule.select.SelectRuleDTO;
import com.cainiao.tp.nm.plan.api.policy.common.constants.*;
import com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils;
import com.cainiao.tp.nm.plan.infra.port.utils.ExpressUtils;
import com.cainiao.tp.nm.plan.infra.port.dto.ExpressCodeDTO;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @code date 2025年06月06日 10:34
 * @code desc:
 */
public class PolicyInstanceRuleApplicationConvert {

    public static IncentiveRuleDTO buildIncentiveRuleDTO(PolicyInstanceRuleDTO ruleDTO) {
        if (ruleDTO == null) {
            return null;
        }
        IncentiveRuleDTO incentiveRule = new IncentiveRuleDTO();
        incentiveRule.setIncentivePlanType(ruleDTO.getIncentivePlanType());
        incentiveRule.setPriority(ruleDTO.getPriority());
        incentiveRule.setSelectRule(JSONObject.parseObject(ruleDTO.getLaunchObject(), SelectRuleDTO.class));
        incentiveRule.setContent(JSONObject.parseObject(ruleDTO.getRuleContent(), IncentiveRuleContentDTO.class));
        return incentiveRule;
    }

    public static ExpressOutletsBaseInfoDTO buildExpressOutletsBaseInfo(PolicyInstanceRuleDTO ruleDTO) {
        if (ruleDTO == null) {
            return null;
        }
        if (!PolicyCustomTypeEnum.EXPRESS.getType().equals(ruleDTO.getCustomType())) {
            return null;
        }
        IncentiveRuleDTO incentiveRuleDTO = buildIncentiveRuleDTO(ruleDTO);
        SelectRuleDTO selectRule = incentiveRuleDTO.getSelectRule();
        AssertUtil.notNull(selectRule, "没有圈选规则");
        EntitySelectRuleDTO entitySelectRule = selectRule.getEntitySelectRule();
        AssertUtil.notNull(entitySelectRule, "没有实体网点圈选规则");
        // 判断是否网点
        if (PolicyCustomTypeEnum.EXPRESS.getType().equals(entitySelectRule.getType())) {
            ExpressOutletsBaseInfoDTO expressOutletsBaseInfo = new ExpressOutletsBaseInfoDTO();
            expressOutletsBaseInfo.setOrgName(entitySelectRule.getEntityName());
            expressOutletsBaseInfo.setOrgType(Objects.requireNonNull(ExpressTypeEnum.of(entitySelectRule.getEntityType())).getDesc());
            // 判断是否需要cp
            ExpressCodeDTO unpack = ExpressUtils.unpack(entitySelectRule.getEntityId());
            assert unpack != null;
            expressOutletsBaseInfo.setCpCode(unpack.getCpCode());
            expressOutletsBaseInfo.setOrgCode(unpack.getExpressCode());
            expressOutletsBaseInfo.setOrgCode(entitySelectRule.getEntityId());
            return expressOutletsBaseInfo;
        }
        return null;
    }

    public static Boolean checkOrgCode(PolicyInstanceRuleDTO original, PolicyInstanceRuleDTO income) {
        ExpressOutletsBaseInfoDTO originalInfo = buildExpressOutletsBaseInfo(original);
        ExpressOutletsBaseInfoDTO incomeInfo = buildExpressOutletsBaseInfo(income);
        return Objects.nonNull(originalInfo) && Objects.nonNull(incomeInfo)
                && StringUtils.equals(originalInfo.getOrgCode(), incomeInfo.getOrgCode());
    }

    public static List<IncentiveRuleDetailDTO> buildIncentiveRuleDetail(PolicyInstanceRuleDTO ruleDTO) {
        if (ruleDTO == null) {
            return Collections.emptyList();
        }
        IncentiveRuleDTO incentiveRuleDTO = buildIncentiveRuleDTO(ruleDTO);
        return buildIncentiveRuleDetail(incentiveRuleDTO);
    }

    private static List<IncentiveRuleDetailDTO> buildIncentiveRuleDetail(IncentiveRuleDTO incentiveRuleDTO) {
        if (incentiveRuleDTO == null) {
            return Collections.emptyList();
        }
        IncentiveRuleContentDTO ruleContentDTO = Optional.of(incentiveRuleDTO)
                .map(IncentiveRuleDTO::getContent)
                .orElseThrow(() -> new AladdinBizException("errorCOde", "没有激励规则"));
        List<IncentiveRuleCoefficientContentDTO> coefficientList = ruleContentDTO.getCoefficient();
        List<IncentiveRuleDetailDTO> ruleDetails = Lists.newArrayList();
        // 递归处理激励规则
        Safes.of(coefficientList).forEach(coefficient -> {
            ruleDetails.addAll(recursionIncentiveRuleDetail(coefficient.getFrame(), incentiveRuleDTO));
        });
        return ruleDetails;
    }

    /**
     * 递归处理激励规则
     */
    private static List<IncentiveRuleDetailDTO> recursionIncentiveRuleDetail(IncentiveRuleFrameDTO frameDTO, IncentiveRuleDTO incentiveRuleDTO) {
        if (frameDTO == null) {
            return Collections.emptyList();
        }
        ArrayList<IncentiveRuleDetailDTO> detailDTOList = Lists.newArrayList();
        if (StringUtils.isNotBlank(frameDTO.getFactorCode())) {
            RuleResultDTO resultDTO = frameDTO.getResult().stream().findFirst().orElseThrow(() -> new AladdinBizException("error_code", "没有结果"));
            IncentiveRuleDetailDTO root = new IncentiveRuleDetailDTO();
            root.setIncentiveStationCode(frameDTO.getFactorResult().getFixedVal());
            root.setIncentiveStationName(IncentivePlanStationTypeEnum.getDescBy(frameDTO.getFactorResult().getFixedVal()));
            root.setResultVal(resultDTO.getVal());
            // 周期写死 6
            root.setPeriodValue("6");
            // 没有结果类型
            root.setIncentiveType(incentiveRuleDTO.getIncentivePlanType());
            root.setIncentiveName(Objects.requireNonNull(IncentivePlanTypeEnum.getByType(incentiveRuleDTO.getIncentivePlanType())).getDesc());
            detailDTOList.add(root);
        }
        List<IncentiveRuleFrameDTO> children = frameDTO.getChildren();
        if (CollectionUtils.isEmpty(children)) {
            return detailDTOList;
        }
        children.forEach(child -> {
            detailDTOList.addAll(recursionIncentiveRuleDetail(child, incentiveRuleDTO));
        });
        return detailDTOList;
    }


    public static List<ColumnDTO> buildHistoryRuleColumn(String customType) {
        List<PolicyRuleHistoryTableEnum> tableColumnEnum = PolicyRuleHistoryTableEnum.getTableColumn(customType);
        return tableColumnEnum.stream().map(en -> {
            ColumnDTO columnDTO = new ColumnDTO();
            columnDTO.setTitle(en.getTitle());
            columnDTO.setDataIndex(en.getDataIndex());
            return columnDTO;
        }).collect(Collectors.toList());
    }

    public static List<ColumnDTO> buildRuleColumn(String customType) {
        List<PolicyRuleTableEnum> tableColumnEnum = PolicyRuleTableEnum.getTableColumn(customType);
        return tableColumnEnum.stream().map(en -> {
            ColumnDTO columnDTO = new ColumnDTO();
            columnDTO.setTitle(en.getTitle());
            columnDTO.setDataIndex(en.getDataIndex());
            return columnDTO;
        }).collect(Collectors.toList());
    }

    public static Map<String, String> buildDivisionMap(BaseDivisionInfoDTO divisionInfoDTO) {
        if (divisionInfoDTO == null) {
            return Collections.emptyMap();
        }
        HashMap<String, String> divisionMap = Maps.newHashMap();
        divisionMap.put(divisionInfoDTO.getDivisionId().toString(), divisionInfoDTO.getDivisionName());
        flatDivision(divisionInfoDTO.getChildrenList(), divisionMap);
        return divisionMap;
    }

    public static void flatDivision(List<BaseDivisionInfoDTO> childrenList, HashMap<String, String> divisionMap) {
        if (CollectionUtils.isEmpty(childrenList)) {
            return;
        }
        childrenList.forEach(child -> {
            divisionMap.put(child.getDivisionId().toString(), child.getDivisionName());
            flatDivision(child.getChildrenList(), divisionMap);
        });
    }

    public static List<PolicyRuleDetailDTO> assembleInstanceRuleTree(List<PolicyRuleDetailDTO> dataSource) {
        if (CollectionUtils.isEmpty(dataSource)) {
            return Collections.emptyList();
        }
        List<PolicyRuleDetailDTO> tree = Lists.newArrayList();
        Map<String, List<PolicyRuleDetailDTO>> treeNode = dataSource.stream().collect(Collectors.groupingBy(data -> data.getProvince() + "-" + data.getCity(), Collectors.toList()));
        treeNode.forEach((key, list) -> {
            // 找到城市维度的数据，作为根节点
            List<PolicyRuleDetailDTO> cityNode = list.stream()
                    .filter(rule -> Objects.isNull(rule.getDistrict()))
                    .sorted(Comparator.comparing(PolicyRuleDetailDTO::getEffectTime).reversed())
                    .collect(Collectors.toList());
            if (CollectionUtils.isEmpty(cityNode)) {
                // 此处城市维度下没有 下级区
                tree.addAll(list);
                return;
            }
            // 将城市下对应的区节点数据 set到 城市节点的children
            PolicyRuleDetailDTO lastedCityNode = cityNode.stream().findFirst().orElseThrow(() -> new RuntimeException("没有主省市数据"));
            List<PolicyRuleDetailDTO> districtNode = list.stream().filter(rule -> Objects.nonNull(rule.getDistrict()))
                    .sorted(Comparator.comparing(PolicyRuleDetailDTO::getEffectTime).reversed())
                    .collect(Collectors.toList());
            lastedCityNode.setChildren(districtNode);
            tree.addAll(cityNode);
        });
        return tree;
    }

    /**
     * 标记需要合并的 市、区
     */
    public static List<PolicyRuleDetailDTO> markMergeDivisionInstanceRule(List<PolicyRuleDetailDTO> dataSource, String customType) {
        if (CollectionUtils.isEmpty(dataSource)) {
            return Collections.emptyList();
        }
        if (PolicyCustomTypeEnum.STATION.getType().equals(customType)) {
            return markStationInstanceRule(dataSource);
        } else {
            List<PolicyRuleDetailDTO> data = Lists.newArrayList();
            Map<String, List<PolicyRuleDetailDTO>> orgMap = dataSource.stream().collect(Collectors.groupingBy(PolicyRuleDetailDTO::getOrgCode, Collectors.toList()));
            AssertUtil.notEmpty("没有网点数据", orgMap);
            orgMap.forEach((orgCode, list) -> {
                List<PolicyRuleDetailDTO> orgDetails = list.stream()
                        .sorted(Comparator.comparing(PolicyRuleDetailDTO::getEffectTime).reversed())
                        .collect(Collectors.toList());
                markInstanceRule(orgDetails);
                mergeRuleDetailStartTimeToEndTime(orgDetails);
                data.addAll(orgDetails);
            });
            data.stream().filter(rule -> Objects.isNull(rule.getDistrict())).forEach(rule -> rule.setDistrict("全城"));
            return data;
        }
    }

    public static List<PolicyRuleDetailDTO> markStationInstanceRule(List<PolicyRuleDetailDTO> dataSource) {
        if (CollectionUtils.isEmpty(dataSource)) {
            return Collections.emptyList();
        }
        // 省维度
        Map<String, List<PolicyRuleDetailDTO>> provinceMap = dataSource.stream().collect(Collectors.groupingBy(PolicyRuleDetailDTO::getProvince, Collectors.toList()));
        List<PolicyRuleDetailDTO> markResult = Lists.newArrayList();
        provinceMap.forEach((province, provinceList) -> {
            // 市维度
            List<PolicyRuleDetailDTO> tmpProvince = Lists.newArrayList();
            Map<String, List<PolicyRuleDetailDTO>> cityDivisionMap = provinceList.stream().collect(Collectors.groupingBy(rule -> rule.getProvince() + "-" + rule.getCity(), Collectors.toList()));
            cityDivisionMap.forEach((provinceCity, list) -> {
                ArrayList<PolicyRuleDetailDTO> tmp = Lists.newArrayList();
                // 找到城市维度的数据
                List<PolicyRuleDetailDTO> cityNode = list.stream()
                        .filter(rule -> Objects.isNull(rule.getDistrict()))
                        .sorted(Comparator.comparing(PolicyRuleDetailDTO::getEffectTime).reversed())
                        .collect(Collectors.toList());
                tmp.addAll(cityNode);
                mergeRuleDetailStartTimeToEndTime(cityNode);
                // 城市下对应的区
                List<PolicyRuleDetailDTO> districtNode = list.stream().filter(rule -> Objects.nonNull(rule.getDistrict())).collect(Collectors.toList());
                Map<String, List<PolicyRuleDetailDTO>> districtMap = districtNode.stream().collect(Collectors.groupingBy(rule -> rule.getProvince() + "-" + rule.getCity() + "-" + rule.getDistrict(), Collectors.toList()));
                districtMap.forEach((district, districtList) -> {
                    List<PolicyRuleDetailDTO> districts = districtList.stream()
                            .sorted(Comparator.comparing(PolicyRuleDetailDTO::getEffectTime).reversed())
                            .collect(Collectors.toList());
                    PolicyRuleDetailDTO districtFirstRule = districts.stream().findFirst().orElseThrow(() -> new AladdinBizException("error_code", "根据区县分组后的数据为空"));
                    districtFirstRule.setDistrictRowSpan(districts.size() == 1 ? 0 : districts.size());
                    tmp.addAll(districts);
                    mergeRuleDetailStartTimeToEndTime(districts);
                });
                // 每一次循环代表一个省市，最后需要计算对应的省市需要合并的单元格个数
                PolicyRuleDetailDTO cityFirstRule = tmp.stream().findFirst().orElseThrow(() -> new AladdinBizException("error_code", "根据城市分组后的数据为空"));
                cityFirstRule.setCityRowSpan(tmp.size() == 1 ? 0 : tmp.size());
                tmpProvince.addAll(tmp);
                tmpProvince.stream().filter(rule -> Objects.isNull(rule.getDistrict())).forEach(rule -> rule.setDistrict("全城"));
            });
            PolicyRuleDetailDTO provinceFirstRule = tmpProvince.stream().findFirst().orElseThrow(() -> new AladdinBizException("error_code", "根据省分组后的数据为空"));
            provinceFirstRule.setProvinceRowSpan(tmpProvince.size() == 1 ? 0 : tmpProvince.size());
            markResult.addAll(tmpProvince);
        });
        return markResult;
    }

    private static void markInstanceRule(List<PolicyRuleDetailDTO> dataSource) {
        if (CollectionUtils.isEmpty(dataSource)) {
            return;
        }
        PolicyRuleDetailDTO firstRule = dataSource.stream().findFirst().orElseThrow(() -> new AladdinBizException("error_code", "根据城市分组后的数据为空"));
        // 分组后的rule list 只有一个表示不需要合并，不需要合并 rowSpan默认为 0。多个表示需要合并，则rowSpan默认为集合的size
        int rowSpan = dataSource.size() == 1 ? 0 : dataSource.size();
        firstRule.setCityRowSpan(rowSpan);
    }

    public static void mergeRuleStartTimeToEndTime(List<PolicyInstanceRuleDTO> instanceRuleDTOList) {
        if (CollectionUtils.isEmpty(instanceRuleDTOList)) {
            return;
        }
        if (instanceRuleDTOList.size() == 1) {
            PolicyInstanceRuleDTO policyInstanceRuleDTO = instanceRuleDTOList.stream().findFirst().orElseThrow(() -> new AladdinBizException("error_code", "没有需要合并时间的数据"));
            policyInstanceRuleDTO.setEffectCycle(DateUtils.localDateTimeToYmdStr(policyInstanceRuleDTO.getStartTime()) + "至" + DateUtils.localDateTimeToYmdStr(DateUtils.addOrSubtractDays(policyInstanceRuleDTO.getEndTime(), -1)));
        }
        // 遍历数据源，从第二条开始
        for (int i = 1; i < instanceRuleDTOList.size(); i++) {
            PolicyInstanceRuleDTO current = instanceRuleDTOList.get(i);
            PolicyInstanceRuleDTO previous = instanceRuleDTOList.get(i - 1);
            // 将当前数据的结束时间设置为前一条数据的开始时间-1 (前一条数据的开始时间)
            current.setEffectCycle(DateUtils.localDateTimeToYmdStr(current.getStartTime()) + "至" + DateUtils.localDateTimeToYmdStr(DateUtils.addOrSubtractDays(previous.getStartTime(), -1)));
            if (i == 1) {
                previous.setEffectCycle(DateUtils.localDateTimeToYmdStr(previous.getStartTime()) + "至" + DateUtils.localDateTimeToYmdStr(DateUtils.addOrSubtractDays(previous.getEndTime(), -1)));
            }
        }
    }

    public static void mergeRuleDetailStartTimeToEndTime(List<PolicyRuleDetailDTO> ruleDetailDTOS) {
        if (CollectionUtils.isEmpty(ruleDetailDTOS)) {
            return;
        }
        // 特殊处理第一条
        if (ruleDetailDTOS.size() == 1) {
            PolicyRuleDetailDTO policyRuleDetailDTO = ruleDetailDTOS.stream().findFirst().orElseThrow(() -> new AladdinBizException("error_code", "没有需要合并时间的数据"));
            policyRuleDetailDTO.setEffectCycle(policyRuleDetailDTO.getEffectTime() + "至" + policyRuleDetailDTO.getDeadlineTime());
        }
        // 遍历数据源，从第二条开始
        for (int i = 1; i < ruleDetailDTOS.size(); i++) {
            PolicyRuleDetailDTO current = ruleDetailDTOS.get(i);
            PolicyRuleDetailDTO previous = ruleDetailDTOS.get(i - 1);
            // 第二条 和 第一条 数据的开始生效时间相同 表示通一天生效的
            if (current.getEffectTime().equals(previous.getEffectTime())) {
                continue;
            }
            // 将当前数据的结束时间设置为前一条数据的开始时间-1 (前一条数据的开始时间)
            current.setEffectCycle(current.getEffectTime() + "至" + DateUtils.localDateTimeToYmdStr(DateUtils.addOrSubtractDays(DateUtils.toLocalDateTimeYmdStart(previous.getEffectTime()), -1)));
            if (i == 1) {
                previous.setEffectCycle(previous.getEffectTime() + "至" + previous.getDeadlineTime());
            }
        }
    }

    public static void mergeHistoryRuleDetailStartTimeToEndTime(List<PolicyInstanceRuleHistoryDetailDTO> historyDetailDTOS) {
        if (CollectionUtils.isEmpty(historyDetailDTOS)) {
            return;
        }
        // 特殊处理第一条
        if (historyDetailDTOS.size() == 1) {
            PolicyInstanceRuleHistoryDetailDTO policyRuleDetailDTO = historyDetailDTOS.stream().findFirst().orElseThrow(() -> new AladdinBizException("error_code", "没有需要合并时间的数据"));
            if (Objects.isNull(policyRuleDetailDTO.getEffectTime())) {
                return;
            }
            policyRuleDetailDTO.setEffectCycle(policyRuleDetailDTO.getEffectTime() + "至" + policyRuleDetailDTO.getEndTime());
        }
        // 遍历数据源，从第二条开始
        for (int i = 1; i < historyDetailDTOS.size(); i++) {
            PolicyInstanceRuleHistoryDetailDTO current = historyDetailDTOS.get(i);
            PolicyInstanceRuleHistoryDetailDTO previous = historyDetailDTOS.get(i - 1);
            // 第二条 和 第一条 数据的开始生效时间相同 表示通一天生效的
            if (current.getEffectTime().equals(previous.getEffectTime())) {
                continue;
            }
            // 将当前数据的结束时间设置为前一条数据的开始时间-1 (前一条数据的开始时间)
            if (i ==1){
                previous.setEffectCycle(previous.getEffectTime() + "至" + previous.getEndTime());
            }
            current.setEffectCycle(current.getEffectTime() + "至" + DateUtils.localDateTimeToYmdStr(DateUtils.addOrSubtractDays(DateUtils.toLocalDateTimeYmdStart(previous.getEffectTime()), -1)));
        }
    }


    public static void mergeTime(List<PolicyInstanceRuleHistoryDetailDTO> historyDetailDTOS) {
        if (CollectionUtils.isEmpty(historyDetailDTOS)) {
            return;
        }
        historyDetailDTOS.forEach(dto -> {
            if (Objects.isNull(dto.getEffectTime())) {
                return;
            }
            dto.setEffectCycle(dto.getEffectTime() + "至" + dto.getEndTime());
        });
    }

}
