package com.cainiao.tp.nm.plan.policy.application.component.station;

import com.alibaba.fastjson.JSON;
import com.cainiao.aladdin.log.AladdinMapLog;
import com.cainiao.aladdin.log.BizType;
import com.cainiao.aladdin.log.utils.AladdinLogUtil;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.NewStaPerformSubsidyParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.NewStaPerformSubsidyDataDTO;
import com.cainiao.tp.nm.plan.infra.port.policy.TgManager;
import com.cainiao.tp.nm.plan.policy.application.dto.IncentiveAssessContextDTO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * 站点激励考核数据查询与加工应用组件
 * 调用天工（TG）接口查询站点当月激励考核数据，加工关键指标并组装上下文 DTO
 *
 * @date 2026-03-27
 */
@Slf4j
@Component
public class IncentiveAssessDataComponent {

    private static final DateTimeFormatter MONTH_FORMATTER = DateTimeFormatter.ofPattern("yyyyMM");

    @Resource
    private TgManager tgManager;

    /**
     * 查询并加工站点激励考核数据，组装上下文 DTO
     *
     * @param stationId         站点 ID
     * @param assessMonthOffset 考核月相对于入驻月的偏移量（0~3）
     * @param today             当前日期（用于确定查询月份）
     * @return 激励考核数据上下文，若查询结果为空则返回 null
     */
    public IncentiveAssessContextDTO buildAssessContext(String stationId, int assessMonthOffset, LocalDate today) {
        AladdinMapLog mapLog = AladdinLogUtil.newMapLog("IncentiveAssessDataComponent.buildAssessContext", BizType.DEFAULT);
        mapLog.addParam("stationId", stationId);
        mapLog.addParam("assessMonthOffset", assessMonthOffset);

        List<NewStaPerformSubsidyDataDTO> dataList = null;
        Exception exception = null;
        try {
            String statsMonth = today.format(MONTH_FORMATTER);
            NewStaPerformSubsidyParam subsidyParam = new NewStaPerformSubsidyParam();
            subsidyParam.setStationId(stationId);
//            subsidyParam.setStatsMonth(statsMonth);
            dataList = tgManager.getListData(subsidyParam);
            if (CollectionUtils.isEmpty(dataList)) {
                log.warn("IncentiveAssessDataComponent.buildAssessContext 查询结果为空，stationId={}", stationId);
                return null;
            }
            //检查是否有当月考核数据
            if (dataList.stream().noneMatch(d -> d.getStatsMonth().equals(statsMonth))) {
                log.warn("IncentiveAssessDataComponent.buildAssessContext 查询结果中无当月考核数据，stationId={}", stationId);
                return null;
            }
            return buildContext(stationId, assessMonthOffset, dataList);
        } catch (Exception e) {
            exception = e;
            throw e;
        } finally {
            mapLog.addParam("dataList", dataList != null ? JSON.toJSONString(dataList) : "[]");
            if (exception != null) {
                AladdinLogUtil.log(log, exception, mapLog);
            } else {
                AladdinLogUtil.log(log, mapLog);
            }
        }
    }

    /**
     * 从 TG 数据中提取关键指标，组装上下文 DTO
     *
     * @param stationId         站点 ID
     * @param assessMonthOffset 考核月偏移量
     * @param dataList              TG 返回的激励考核数据
     * @return 激励考核数据上下文 DTO
     */
    private IncentiveAssessContextDTO buildContext(String stationId, int assessMonthOffset,
                                                    List<NewStaPerformSubsidyDataDTO> dataList) {
        //根据考核月取dataList中最大的数据
        NewStaPerformSubsidyDataDTO data = dataList.stream().max((o1, o2) -> o1.getStatsMonth().compareTo(o2.getStatsMonth())).get();
        //检查dataList是否存在isSatisfied=true的记录，检查是否达成首月考核激励
        boolean hasFirstSatisfied = dataList.stream().anyMatch(d -> d.getIsSatisfied() != null && d.getIsSatisfied());
        return IncentiveAssessContextDTO.builder()
                .stationId(stationId)
                .assessMonthOffset(assessMonthOffset)
                .firstOver100ArrDate(data.getFirstOver100ArrDate())
                .isSatisfied(hasFirstSatisfied)
                .cycleNum(data.getCycleNum())
                .isDecorationPass(data.getIsDecorationPass())
                .build();
    }
}
