package com.cainiao.tp.nm.plan.policy.adaptor.service.station;

import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.fastjson.JSONObject;
import com.cainiao.aladdin.log.AladdinCommLog;
import com.cainiao.aladdin.log.BizType;
import com.cainiao.aladdin.log.utils.AladdinLogUtil;
import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.aladdin.reslut.Result;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.station.StationElementButtonQueryParam;
import com.cainiao.tp.nm.plan.api.policy.application.service.station.PGStationElementButtonService;
import com.cainiao.tp.nm.plan.policy.common.util.AssertUtil;
import com.cainiao.tp.pangu.basic.client.enums.TpsPgButtonTypeEnum;
import com.cainiao.tps.pangu.management.common.model.dto.element.TpsPgElementButtonDTO;
import com.cainiao.tps.pangu.management.common.model.request.TpgPgElementButtonFetchReq;
import com.cainiao.tps.pangu.management.common.model.request.TpsPgElementButtonReq;
import com.cainiao.tps.pangu.management.common.model.response.TpsPgElementButtonResp;
import com.cainiao.tps.pangu.management.spi.service.element.ElementButtonSpiService;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * @code date 2025年08月04日 14:52
 * @code desc:溪鸟app端站点详情页的激励按钮
 */
@Slf4j
@HSFProvider(serviceInterface = ElementButtonSpiService.class, serviceVersion = "1.0.0_xn_sta_inc")
public class XNPGStationElementButtonSpiServiceImpl implements ElementButtonSpiService {

    public static final String SOURCE = "XN";
    @Resource
    private PGStationElementButtonService pgStationElementButtonService;

    @Override
    public Result<List<TpsPgElementButtonDTO>> pullButtonList(TpsPgElementButtonReq tpsPgElementButtonReq, AbstractOperation abstractOperation) {
        return null;
    }

    @Override
    public Result<TpsPgElementButtonResp> sendRequest(TpsPgElementButtonReq tpsPgElementButtonReq, AbstractOperation abstractOperation) {
        return null;
    }

    @Override
    public Result<List<TpsPgElementButtonDTO>> fetchButtonList(TpgPgElementButtonFetchReq tpgPgElementButtonFetchReq, AbstractOperation abstractOperation) {
        AladdinCommLog aladdinCommLog = AladdinLogUtil.newCommLog(BizType.DEFAULT, abstractOperation);
        Map<String, Object> logContext = Maps.newHashMap();
        aladdinCommLog.setParams(JSONObject.toJSONString(tpgPgElementButtonFetchReq));
        aladdinCommLog.setContext(logContext);
        log.info("XNPGStationElementButtonSpiServiceImpl.fetchButtonList={}",JSONObject.toJSONString(tpgPgElementButtonFetchReq));
        try {
            StationElementButtonQueryParam param = new StationElementButtonQueryParam();
            param.setElementId(tpgPgElementButtonFetchReq.getElementId());
            param.setStationId(tpgPgElementButtonFetchReq.getOutBizId());
            param.setEmployeeId(abstractOperation.getOperatorId());
            param.setSource(SOURCE);
            String buttonUrl = pgStationElementButtonService.getButtonUrl(param, abstractOperation);
            if (buttonUrl == null) {
                return Result.create(Lists.newArrayList());
            }
            TpsPgElementButtonDTO button = new TpsPgElementButtonDTO();
            button.setName("建站激励");
            button.setKey("stationIncentive");
            button.setType(TpsPgButtonTypeEnum.JUMP.getValue());
            button.setLinkUrl(buttonUrl);
            button.setOrder(12);
            log.info("XNPGStationElementButtonSpiServiceImpl.fetchButtonList.button={}",JSONObject.toJSONString(button));
            return Result.create(Lists.newArrayList(button));
        } catch (Throwable e) {
            AladdinLogUtil.log(log, e, aladdinCommLog);
            return Result.create(Lists.newArrayList());
        }
    }

}
