package com.cainiao.tp.nm.plan.policy.common.util;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.read.metadata.ReadSheet;
import com.alibaba.excel.support.ExcelTypeEnum;
import com.alibaba.fastjson.JSON;
import com.cainiao.tp.nm.plan.policy.common.util.dto.ExcelDataDTO;
import com.cainiao.tp.nm.plan.policy.common.util.dto.ExcelHeadAndDataListener;
import com.cainiao.tp.nm.plan.policy.common.util.dto.ExcelListener;
import com.google.common.collect.Lists;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

/**
 * @description: excel导出工具
 * @create: 2023-12-14 15:14
 **/

public class ExcelUtil {


    /**
     * 导出 Excel : 单个sheet 保存在内存中
     *
     * @param list      list
     * @param sheetName sheet名称
     * @param clazz     类
     * @param <T>       对象任意数据
     */
    public static <T> ByteArrayOutputStream writeExcelInBytes(List<T> list, String sheetName, Class<T> clazz) {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        EasyExcel.write(outputStream, clazz).excelType(ExcelTypeEnum.XLSX).build().write(list, EasyExcel.write().sheet(1, sheetName).build()).finish();
        return outputStream;
    }

    /**
     * 导出 Excel : 单个sheet 保存在内存中
     *
     * @param dataList  list
     * @param sheetName sheet名称
     * @param headList  类
     */
    public static ByteArrayOutputStream writeExcelInBytes(List<List<String>> dataList, String sheetName, List<List<String>> headList) {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        EasyExcel.write(outputStream).needHead(true).head(headList).excelType(ExcelTypeEnum.XLSX).build().write(dataList, EasyExcel.write().sheet(1, sheetName).build()).finish();
        return outputStream;
    }


    /**
     * 读
     *
     * @param inputStream 读完以后要关闭
     * @param clazz       类
     * @param <T>         类
     * @return list
     */
    public static <T> List<T> readExcel(InputStream inputStream, Class<T> clazz) {
        ReadSheet readSheet = new ReadSheet(0);
        ExcelListener<T> excelListener = new ExcelListener<>();
        EasyExcel.read(inputStream).charset(StandardCharsets.UTF_8).registerReadListener(excelListener).excelType(ExcelTypeEnum.XLSX).head(clazz).build().read(readSheet).finish();
        return excelListener.getDataList();
    }

    /**
     * 读
     *
     * @param inputStream 读完以后要关闭
     * @param headList    头信息
     * @param <T>         类
     * @return list
     */
    public static <T> List<T> readExcel(InputStream inputStream, List<List<String>> headList) {
        ReadSheet readSheet = new ReadSheet(0);
        ExcelListener<T> excelListener = new ExcelListener<>();
        EasyExcel.read(inputStream).charset(StandardCharsets.UTF_8).registerReadListener(excelListener).excelType(ExcelTypeEnum.XLSX).head(headList).build().read(readSheet).finish();
        return excelListener.getDataList();
    }


    /**
     * 读取获取，获取头信息和数据
     * @param inputStream 流
     * @return return
     */
    public static ExcelDataDTO readHeadAndDataExcel(InputStream inputStream) {
        ReadSheet readSheet = new ReadSheet(0);
        ExcelHeadAndDataListener excelListener = new ExcelHeadAndDataListener();
        EasyExcel.read(inputStream).charset(StandardCharsets.UTF_8).headRowNumber(0).registerReadListener(excelListener).excelType(ExcelTypeEnum.XLSX).build().read(readSheet).finish();
       return ExcelDataDTO.builder().dataList(excelListener.getDataList()).headerList(excelListener.getHeaderList()).build();
    }


    /**
     * 读取数据
     *
     * @param inputStream 读完以后要关闭
     * @return list
     */
    public static List<LinkedHashMap<Integer, String>> readExcel(InputStream inputStream) {
        ReadSheet readSheet = new ReadSheet(0);
        ExcelListener<LinkedHashMap<Integer, String>> excelListener = new ExcelListener<>();
        EasyExcel.read(inputStream).charset(StandardCharsets.UTF_8).registerReadListener(excelListener).excelType(ExcelTypeEnum.XLSX).build().read(readSheet).finish();
        return excelListener.getDataList();
    }


    //todo 测试先放着
    public static void main(String[] args) throws FileNotFoundException {
        String filePath = "/users/maojizhang/test.xlsx";
        try (FileInputStream fis = new FileInputStream(filePath)) {
            List<List<String>> dataList = new ArrayList<>();
            dataList.add(Lists.newArrayList("1"));
            ExcelDataDTO excelDataDTO = readHeadAndDataExcel(fis);
            System.out.println("111"+JSON.toJSON(excelDataDTO));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}
