package com.cainiao.tp.nm.plan.policy.application.extension.definition;

import com.alibaba.fastjson.JSONObject;
import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.aladdin.utils.Safes;
import com.cainiao.tp.nm.plan.api.policy.application.dto.*;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiverule.*;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiverule.select.AreaSelectRuleDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiverule.select.EntitySelectRuleDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiverule.select.SelectRuleDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiverule.select.TagSelectRuleDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyInstanceDetailQueryParam;
import com.cainiao.tp.nm.plan.api.policy.common.constants.ExpressTypeEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyCustomTypeEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyInstanceApprovalStatusEnum;
import com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils;
import com.cainiao.tp.nm.plan.infra.port.policy.DivisionManager;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyInstanceQueryManager;
import com.cainiao.tp.nm.plan.policy.common.util.AssertUtil;
import com.cainiao.tp.nm.plan.infra.port.utils.ExpressUtils;
import com.cainiao.tp.nm.plan.infra.port.dto.ExpressCodeDTO;
import com.google.common.collect.Lists;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

import static com.cainiao.tp.nm.plan.policy.application.convert.PolicyInstanceRuleApplicationConvert.*;

public abstract class AbstractPolicyDashBoardView implements PolicyDashBoardView<PolicyTemplateDTO, PolicyInstanceRuleDTO> {

    @Resource
    DivisionManager divisionManager;
    @Resource
    PolicyInstanceQueryManager instanceQueryManager;

    /**
     * 递归最大层级为10层
     */
    private final static int MAX_LEVEL=10;

    @Override
    public List<ViewHeadDTO> getHeader(PolicyTemplateDTO policyTemplateDTO) {
        String exportTempCode = getTempCode(policyTemplateDTO);
        TpExportHeadHolder instance = TpExportHeadHolder.getINSTANCE();
        List<ExcelHead> head = instance.getHead(exportTempCode);
        AssertUtil.notEmpty(head,"模版未配置，请联系管理员，exportTempCode="+exportTempCode);
        return head.stream().map(this::convert).collect(Collectors.toList());
    }

    /**
     * 获取模版code
     * @param policyTemplateDTO 列表
     * @return return
     */
    protected abstract String getTempCode(PolicyTemplateDTO policyTemplateDTO);

    @Override
    public List<JSONObject> getDataSource(List<PolicyInstanceRuleDTO> ruleDTOList) {
        if(CollectionUtils.isEmpty(ruleDTOList)){
            return Lists.newArrayList();
        }
        List<PolicyRuleRecordDTO> resultList = Safes.of(ruleDTOList).stream().map(ruleDTO -> {
            PolicyRuleRecordDTO detailDTO = new PolicyRuleRecordDTO();
            BeanUtils.copyProperties(ruleDTO, detailDTO);

            IncentiveRuleDTO incentiveRuleDTO = buildIncentiveRuleDTO(ruleDTO);
            //加载圈选对象
            ScaleObjectDTO scaleObjectDTO = loadSelectRule(incentiveRuleDTO);
            detailDTO.setScaleObjectDTO(scaleObjectDTO);
            detailDTO.setProvince(scaleObjectDTO.getProvince());
            detailDTO.setCity(scaleObjectDTO.getCity());
            detailDTO.setDistrict(scaleObjectDTO.getDistrict());

            // 加载激励规则
            Map<String, String> incentiveFactorParamMap = loadIncentiveFactorParam(ruleDTO);
            detailDTO.setIncentiveRuleMap(incentiveFactorParamMap);

            //修改时间
            detailDTO.setEffectTime(DateUtils.localDateTimeToYmdStr(ruleDTO.getStartTime()));
            detailDTO.setDeadlineTime(DateUtils.localDateTimeToYmdStr(DateUtils.addOrSubtractDays(ruleDTO.getEndTime(), -1)));
            detailDTO.setReportTime(DateUtils.localDateTimeToYmdhmsStr(ruleDTO.getGmtCreate()));
            detailDTO.setEndTime(DateUtils.localDateTimeToYmdStr(DateUtils.addOrSubtractDays(ruleDTO.getEndTime(), -1)));
            detailDTO.setPolicyInstanceId(ruleDTO.getInstanceId());
            detailDTO.setApprovalStatus(ruleDTO.getApprovalStatus());
            detailDTO.setApprovalStatusDesc(PolicyInstanceApprovalStatusEnum.getDescByCode(ruleDTO.getApprovalStatus()));
            return detailDTO;
        }).collect(Collectors.toList());
        setInstanceFeature(resultList);
        resultList= postProcess(resultList);
        if(CollectionUtils.isEmpty(resultList)){
            return Lists.newArrayList();
        }
      return resultList.stream().map(this::toJsonObject).collect(Collectors.toList());
    }


    private void setInstanceFeature(List<PolicyRuleRecordDTO> resultList) {
        if(CollectionUtils.isEmpty(resultList)){
            return;
        }
        Set<Long> idList = resultList.stream().map(PolicyRuleRecordDTO::getPolicyInstanceId).collect(Collectors.toSet());
        PolicyInstanceDetailQueryParam param = new PolicyInstanceDetailQueryParam();
        param.setIdList(Lists.newArrayList(idList));
        param.setPageSize(idList.size() + 1);
        List<PolicyInstanceDTO> policyInstanceDTOList = instanceQueryManager.queryPolicyInstanceByParam(param);
        Map<Long, PolicyInstanceDTO> collectMap = policyInstanceDTOList.stream().collect(Collectors.toMap(PolicyInstanceDTO::getId, dto -> dto, (v1, v2) -> v1));

        resultList.forEach(dto -> {
            PolicyInstanceDTO policyInstanceDTO = collectMap.get(dto.getPolicyInstanceId());
            Map<String, String> featureMap = policyInstanceDTO.getFeatureMap();
            if (MapUtils.isNotEmpty(featureMap)) {
                dto.getFeature().putAll(featureMap);
            }
        });
//        detailDTO.setSubmitter(featureMap.getOrDefault(PolicyInstanceFeature.SUBMISSION_USER_NAME.getKey(), ""));
//        detailDTO.setReason(featureMap.getOrDefault(PolicyFeatureConstants.CANCEL_REASON, ""));
    }

    protected JSONObject toJsonObject(PolicyRuleRecordDTO detailDTO) {
      return JSONObject.parseObject(JSONObject.toJSONString(detailDTO));
    }

    protected List<PolicyRuleRecordDTO> postProcess(List<PolicyRuleRecordDTO> resultList) {
        if(CollectionUtils.isEmpty(resultList)){
            return resultList;
        }

        //复杂的逻辑，不要在这里累加
        PolicyRuleRecordDTO policyRuleRecordDTO = resultList.get(0);
        String customType = policyRuleRecordDTO.getCustomType();
        if (PolicyCustomTypeEnum.EXPRESS.getType().equals(customType)){
            resultList.forEach(rule->{
                ScaleObjectDTO scaleObjectDTO = rule.getScaleObjectDTO();
                String entityId = scaleObjectDTO.getEntityId();
                if(StringUtils.isBlank(entityId)){
                    return;
                }
                String entityType = rule.getScaleObjectDTO().getEntityType();
                ExpressTypeEnum expressTypeEnum = ExpressTypeEnum.of(entityType);
                if(expressTypeEnum !=null){
                    rule.getScaleObjectDTO().setEntityTypeName(expressTypeEnum.getDesc());
                }
                ExpressCodeDTO unpack = ExpressUtils.unpack(rule.getScaleObjectDTO().getEntityId());
                if (null != unpack) {
                    rule.getFeature().put("express_cp_code", unpack.getCpCode());
                }
            });
        }

       return resultList;
    }

//////////////////////-------------------------------///////////////////////////////////////

protected ViewHeadDTO convert(ExcelHead head){
    ViewHeadDTO viewHeadDTO = new ViewHeadDTO();
    viewHeadDTO.setIndex(head.getIndex());
    viewHeadDTO.setName(head.getHeadName());
    viewHeadDTO.setKey(head.getFieldKey());
    String obtainValueKey = head.getObtainValueKey();
    viewHeadDTO.setObtainValueKey(obtainValueKey);
    if(StringUtils.isBlank(obtainValueKey)){
        viewHeadDTO.setObtainValueKey(head.getFieldKey());
    }
    viewHeadDTO.setQlExpression(head.getQlExpression());
    viewHeadDTO.setRequired(head.getRequired());
    Boolean show = head.getShow();
    if(null==show){
        show = true;
    }
    viewHeadDTO.setShow(show);
    viewHeadDTO.setDefaultValue(head.getDefaultValue());
    return viewHeadDTO;
}

    private Map<String, String> loadIncentiveFactorParam(PolicyInstanceRuleDTO ruleDTO) {
        if (ruleDTO == null) {
            return Collections.emptyMap();
        }
        List<IncentiveFactorDTO> incentiveFactorDTOList = buildIncentiveRuleDetail(ruleDTO);
        if(CollectionUtils.isEmpty(incentiveFactorDTOList)){
            return Collections.emptyMap();
        }

       return incentiveFactorDTOList.stream().collect(Collectors.toMap(IncentiveFactorDTO::getFactorCode, IncentiveFactorDTO::getValue,(v1,v2)->v1));
    }


    public static List<IncentiveFactorDTO> buildIncentiveRuleDetail(PolicyInstanceRuleDTO ruleDTO) {
        if (ruleDTO == null) {
            return Collections.emptyList();
        }
        IncentiveRuleDTO incentiveRuleDTO = buildIncentiveRuleDTO(ruleDTO);
        return buildIncentiveRuleDetail(incentiveRuleDTO);
    }

    private static List<IncentiveFactorDTO> buildIncentiveRuleDetail(IncentiveRuleDTO incentiveRuleDTO) {
        if (incentiveRuleDTO == null) {
            return Collections.emptyList();
        }
        IncentiveRuleContentDTO content = incentiveRuleDTO.getContent();
        if (null == content) {
            return Collections.emptyList();
        }
        List<IncentiveRuleCoefficientContentDTO> coefficient = content.getCoefficient();
        //金额暂时不解析，后续有需要在解析
        //        IncentiveRuleFrameDTO price = content.getPrice();
        if(CollectionUtils.isEmpty(coefficient)){
            return Collections.emptyList();
        }
        List<IncentiveFactorDTO> ruleDetails = new ArrayList<>();

        coefficient.forEach(dto->{
            IncentiveRuleFrameDTO frame = dto.getFrame();
            ruleDetails.addAll(recursionIncentiveRuleDetail(frame, 1));
        });

        return ruleDetails;
    }


    /**
     * 递归处理激励规则
     * @param frameDTO return
     * @param maxLevel 递归的最大层级
     * @return return
     */
    private static List<IncentiveFactorDTO> recursionIncentiveRuleDetail(IncentiveRuleFrameDTO frameDTO,Integer maxLevel) {
        if (frameDTO == null) {
            return Collections.emptyList();
        }
        if(MAX_LEVEL<=maxLevel){
            throw new AladdinBizException("error_code", "激励层级解析异常，请联系管理员检查数据");
        }

        List<RuleResultDTO> result = frameDTO.getResult();
        List<IncentiveRuleFrameDTO> children = frameDTO.getChildren();

        if(CollectionUtils.isEmpty(result)&&CollectionUtils.isEmpty(children)){
            return Collections.emptyList();
        }

        List<IncentiveFactorDTO>  factortDtoList=new ArrayList<>();
        if(CollectionUtils.isNotEmpty(result)){
            result.forEach(dto->{
                IncentiveFactorDTO incentiveFactorDTO=new IncentiveFactorDTO();
                incentiveFactorDTO.setFactorCode(dto.getResultFillCode());
                incentiveFactorDTO.setValue(dto.getVal());
                incentiveFactorDTO.setUnit(dto.getUnit());
                factortDtoList.add(incentiveFactorDTO);
            });
        }


        if (CollectionUtils.isEmpty(children)) {
            return factortDtoList;
        }
        maxLevel=maxLevel+1;
        final  Integer finalMaxLevel = maxLevel;
        children.forEach(child -> factortDtoList.addAll(recursionIncentiveRuleDetail(child, finalMaxLevel)));
        return factortDtoList;
    }
//////////////////////-------------------------------///////////////////////////////////////

    /**
     * 加载圈选规则
     *
     * @param incentiveRuleDTO roleDTO
     */
    private ScaleObjectDTO loadSelectRule(IncentiveRuleDTO incentiveRuleDTO) {
        ScaleObjectDTO scaleObjectDTO = new ScaleObjectDTO();
        SelectRuleDTO selectRule = incentiveRuleDTO.getSelectRule();
        if (null == selectRule) {
            return scaleObjectDTO;
        }
        Long tempId = incentiveRuleDTO.getTempId();
        //加载标签数据
        loadTag(selectRule.getTagSelectRule(), scaleObjectDTO, tempId);

        //加载城市
        AreaSelectRuleDTO areaSelectRule = selectRule.getAreaSelectRule();
        loadCity(areaSelectRule, scaleObjectDTO);

        //加载主体
        EntitySelectRuleDTO entitySelectRule = selectRule.getEntitySelectRule();
        loadEntity(entitySelectRule, scaleObjectDTO);
        return scaleObjectDTO;
    }

    private void loadEntity(EntitySelectRuleDTO entitySelectRule, ScaleObjectDTO scaleObjectDTO) {
        if (null == entitySelectRule || StringUtils.isBlank(entitySelectRule.getEntityId())) {
            return;
        }
        scaleObjectDTO.setEntityId(entitySelectRule.getEntityId());
        scaleObjectDTO.setEntityType(entitySelectRule.getEntityType());
        scaleObjectDTO.setEntityName(entitySelectRule.getEntityName());
    }

    private void loadCity(AreaSelectRuleDTO areaSelectRule, ScaleObjectDTO scaleObjectDTO) {
        if (areaSelectRule == null) {
            scaleObjectDTO.setCity("-");
            scaleObjectDTO.setProvince("-");
            scaleObjectDTO.setDistrict("-");
            return;
        }
        String provinceCode = areaSelectRule.getProvinceCode();
        String cityCode = areaSelectRule.getCityCode();
        String districtCode = areaSelectRule.getDistrictCode();
        // 构建省市区
        Long provCode = StringUtils.isBlank(provinceCode) ? null : Long.valueOf(provinceCode);
        Optional<BaseDivisionInfoDTO> provinceByCode = divisionManager.getProvinceByCode(provCode);
        BaseDivisionInfoDTO baseDivisionInfoDTO = provinceByCode.orElse(null);
        Map<String, String> divisionMap = buildDivisionMap(baseDivisionInfoDTO);

        scaleObjectDTO.setProvince(divisionMap.get(provinceCode));
        scaleObjectDTO.setProvinceCode(provinceCode);
        scaleObjectDTO.setCity(divisionMap.get(cityCode));
        scaleObjectDTO.setCityCode(cityCode);
        scaleObjectDTO.setDistrict(divisionMap.get(districtCode));
        scaleObjectDTO.setDistrictCode(districtCode);
    }


    private void loadTag(TagSelectRuleDTO tagSelectRule, ScaleObjectDTO scaleObjectDTO, Long tempId) {
        if (null == tagSelectRule || CollectionUtils.isEmpty(tagSelectRule.getTagCodeList())) {
            return;
        }
        List<String> tagCodeList = tagSelectRule.getTagCodeList();
        scaleObjectDTO.setTagList(tagCodeList);
        StringJoiner stringJoiner = new StringJoiner(",");
        tagCodeList.forEach(tag -> {
            CircleTagDTO tagDTO = PolicyCircleTagsHolder.getINSTANCE().ofCode(tag, tempId + "");
            if (null != tagDTO) {
                stringJoiner.add(tagDTO.getName());
            } else {
                stringJoiner.add(tag);
            }
        });
        scaleObjectDTO.setTag(stringJoiner.toString());
    }
}
