package com.cainiao.tp.nm.plan.policy.common.util.dto;

import lombok.Builder;
import lombok.Data;

import java.util.LinkedHashMap;
import java.util.List;

@Data
@Builder
public class ExcelDataDTO {

    /**
     * 表头
     */
    private List<LinkedHashMap<Integer, String>> headerList;

    /**
     * 数据
     */
    private List<LinkedHashMap<Integer, String>> dataList;

}
