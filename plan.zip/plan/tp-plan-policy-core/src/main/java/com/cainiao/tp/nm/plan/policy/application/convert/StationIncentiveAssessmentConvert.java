package com.cainiao.tp.nm.plan.policy.application.convert;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.aladdin.utils.DateUtil;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.tp.nm.plan.api.policy.application.annotation.AssessmentMetric;
import com.cainiao.tp.nm.plan.api.policy.application.dto.AssessmentMetricGroupDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.StationAssessmentConfigHolder;
import com.cainiao.tp.nm.plan.api.policy.application.dto.StationDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.NewStaPerformSubsidyConfigDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.NewStaPerformSubsidyActivityDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.NewStaPerformSubsidyDataDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.StationIncentiveBillDetailDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.heavy.AssessmentCardDTO;
import com.cainiao.tp.nm.plan.api.policy.common.constants.NewStaPerformSubsidyViewEnum;
import com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils;
import com.cainiao.tp.nm.plan.policy.application.dto.NewStaPerformSubsidyViewDTO;
import com.cainiao.tp.nm.plan.policy.common.util.QlUtils;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang.StringUtils;

import java.lang.reflect.Field;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.cainiao.tp.nm.plan.api.policy.common.constants.IncentivePageConstants.EXTRA_NORMAL;
import static com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils.*;
import static com.cainiao.tp.nm.plan.policy.common.util.ReflectUtils.*;

/**
 * @code date 2025年08月05日 16:27
 * @code desc:null
 */
public class StationIncentiveAssessmentConvert {

    private static final Map<String, List<Field>> assessmentFieldCache = new ConcurrentHashMap<>();

    public static NewStaPerformSubsidyActivityDTO buildNewStaPerformAssessment(List<NewStaPerformSubsidyDataDTO> subsidyData
            , StationDTO stationDTO, NewStaPerformSubsidyConfigDTO subsidyConfig) {
        NewStaPerformSubsidyActivityDTO activityDTO = new NewStaPerformSubsidyActivityDTO();
        activityDTO.setRuleDetailUrl(getNewStaPerformRuleDetailUrl(stationDTO, subsidyConfig));
        // 1.决策视图
        NewStaPerformSubsidyViewDTO viewDTO = NewStaPerformSubsidyConvert.judgeView(stationDTO, subsidyData, subsidyConfig);
        activityDTO.setViewCode(viewDTO.getViewCode());
        activityDTO.setNotAllowMsg(viewDTO.getNotAllowMsg());

        if (NewStaPerformSubsidyViewEnum.NOT_ALLOW_PARTICIPATE.getCode().equals(viewDTO.getViewCode())) {
            return activityDTO;
        }

        // 默认先取本月
        NewStaPerformSubsidyDataDTO newStaPerformSubsidyDataDTO = new NewStaPerformSubsidyDataDTO();
        if(CollectionUtils.isNotEmpty(subsidyData)){
            String currentMonth = DateUtils.toDateStr(LocalDateTime.now(), "yyyyMM");
            Optional<NewStaPerformSubsidyDataDTO> currentMonthFirst = subsidyData.stream().filter(sd -> currentMonth.equals(sd.getStatsMonth())).findFirst();
            NewStaPerformSubsidyDataDTO lastlyMonth = subsidyData.stream().sorted(Comparator.comparing(NewStaPerformSubsidyDataDTO::getStatsMonth).reversed()).findFirst().get();
            newStaPerformSubsidyDataDTO = currentMonthFirst.isPresent() ? currentMonthFirst.get() : lastlyMonth;
        }

        if(NewStaPerformSubsidyViewEnum.HAS_CUMULA_SUBSIDY.getCode().equals(viewDTO.getViewCode())){
            // 2. 获取累计补贴信息
            activityDTO.setCumulativeSubsidy(NewStaPerformSubsidyConvert.buildCumulativeSubsidy(subsidyData, subsidyConfig));
        }

        // 3. 获取下一个梯度信息
        activityDTO.setNextLadder(NewStaPerformSubsidyConvert.buildNextLadder(newStaPerformSubsidyDataDTO, subsidyConfig));

        // 4. 获取预计补贴和领取条件
        NewStaPerformSubsidyActivityDTO predSubsidyAndCond = buildOnlyMonthNewStaPerformAssessment(newStaPerformSubsidyDataDTO, subsidyConfig.getNewStaPerformSubsidyPriceQlExpress());

        Date fy26Q4Date = DateUtil.getStr2SDate(subsidyConfig.getFy26Q4StartDate());
        boolean isEntryFy26Q4 = stationDTO.getGmtCreate().after(fy26Q4Date);
        //5. FY26Q4之前达标条件删除【其它达标条件】
        if(!isEntryFy26Q4){
            predSubsidyAndCond.removeSubsidyCond("noneRiskStaCondition");
        }
        activityDTO.setSubsidyCond(predSubsidyAndCond.getSubsidyCond());
        activityDTO.setPredMonthSubsidy(predSubsidyAndCond.getPredMonthSubsidy());
        return activityDTO;
    }

    public static NewStaPerformSubsidyActivityDTO buildOnlyMonthNewStaPerformAssessment(NewStaPerformSubsidyDataDTO newStaPerformSubsidyDataDTO, String qlExpress) {
        NewStaPerformSubsidyActivityDTO activityDTO = new NewStaPerformSubsidyActivityDTO();

        // 1. 获取预计补贴和领取条件
        List<AssessmentCardDTO> assessmentCardDTOS = buildNewStaPerformAssessment(newStaPerformSubsidyDataDTO);
        Map<String, AssessmentCardDTO> cardMap = assessmentCardDTOS.stream()
                .collect(Collectors.toMap(AssessmentCardDTO::getCode, Function.identity(), (v1, v2) -> v1));
        activityDTO.setSubsidyCond(cardMap.get("subsidyCond"));
        activityDTO.setPredMonthSubsidy(cardMap.get("predSubsidy"));

        // 2. 特殊处理 如果不达标，结算没有预计补贴 需要自己计算
        assertPreMonthSubsidy(activityDTO.getPredMonthSubsidy(), newStaPerformSubsidyDataDTO, qlExpress);

        // 3. 特殊处理，只有第3-6期，删除「完成装修认证」
        String cycleNum = newStaPerformSubsidyDataDTO.getCycleNum();
        if(StringUtils.isBlank(cycleNum) || Integer.parseInt(cycleNum) < 3){
            activityDTO.removeSubsidyCond("newStaDecorationAuth");
        }
        return activityDTO;
    }

    public static List<AssessmentCardDTO> buildNewStaPerformAssessment(NewStaPerformSubsidyDataDTO subsidyData) {
        Map<String, Object> contextMap = JSONObject.parseObject(JSONObject.toJSONString(subsidyData), new TypeReference<Map<String, Object>>() {});
        StationAssessmentConfigHolder instance = StationAssessmentConfigHolder.getINSTANCE();
        List<AssessmentMetricGroupDTO> metricGroupList = instance.getMetricGroupList("newStaPerformSubsidy");
        AssertUtil.isTrue(CollectionUtils.isNotEmpty(metricGroupList), "新建站实操激励模版配置为空");
        return assembleMetrics(metricGroupList, contextMap);
    }

    private static void assertPreMonthSubsidy(AssessmentCardDTO predMonthSubsidy, NewStaPerformSubsidyDataDTO subsidyData, String qlExpress){
        if(null == predMonthSubsidy || CollectionUtils.isEmpty(predMonthSubsidy.getItems())){
            return;
        }

        for(AssessmentCardDTO.Item item : predMonthSubsidy.getItems()){
            if("predMonthSubsidy".equals(item.getCode())){
                String yyyyMM = DateUtils.toDateStr(LocalDateTime.now(), "yyyyMM");
                String statsMonth = subsidyData.getStatsMonth();
                item.setTitle((StringUtils.isBlank(statsMonth) || yyyyMM.equals(statsMonth) ? "本月" : (statsMonth.substring(4) + "月")) + item.getTitle());
                double v = NewStaPerformSubsidyConvert.calculPrice(subsidyData, qlExpress);
                item.setValue(String.valueOf((int) v));
            }
        }
    }


    public static List<AssessmentCardDTO> buildAssessment(StationIncentiveBillDetailDTO billDetailDTO, String quarter) {
        List<Field> assessmentField = getValidateField(billDetailDTO.getStationId(), billDetailDTO.getCycleNum(), billDetailDTO);
        Map<String, Field> flatFieldMap = flatFieldMap(assessmentField);
        Map<String, Object> contextMap = buildQlContextMap(flatFieldMap, billDetailDTO);

        StationAssessmentConfigHolder instance = StationAssessmentConfigHolder.getINSTANCE();
        List<AssessmentMetricGroupDTO> metricGroupList = instance.getMetricGroupList(quarter);
        AssertUtil.notNull(metricGroupList, "站点考核指标配置为空");
        contextMap.put("cycleNum",billDetailDTO.getCycleNum());
        contextMap.put("dataRange",getDataRange(billDetailDTO));
        contextMap.put("firstOverDate",billDetailDTO.getFirstOver100ArrDate());
        return assembleMetrics(metricGroupList, contextMap);
    }

    private static List<Field> getValidateField(String stationId, String cycleNum, StationIncentiveBillDetailDTO detail) {
        return assessmentFieldCache.computeIfAbsent(stationId + "-" + cycleNum, func -> getFieldList(detail, AssessmentMetric.class));
    }

    private static Map<String, Object> buildQlContextMap(Map<String, Field> flatFieldMap, StationIncentiveBillDetailDTO detail) {
        if (flatFieldMap == null) {
            return Maps.newHashMap();
        }
        HashMap<String, Object> contextMap = Maps.newHashMap();
        flatFieldMap.forEach((k, v) -> {
            contextMap.put(k, getFieldValue(detail, v));
        });
        return contextMap;
    }

    public static List<AssessmentCardDTO> assembleMetrics(List<AssessmentMetricGroupDTO> metricGroupDTOList, Map<String, Object> contextMap) {
        if (CollectionUtils.isEmpty(metricGroupDTOList)) {
            return Lists.newArrayList();
        }
        return metricGroupDTOList.stream().map(group -> {
            AssessmentCardDTO assessmentCardDTO = new AssessmentCardDTO();
            List<AssessmentCardDTO.Item> metricsList = group.getMetricItemList().stream().map(item -> {
                if (StringUtils.isNotBlank(item.getShowCycleNum()) && !item.getShowCycleNum().equals(contextMap.getOrDefault("cycleNum",null))) {
                    return null;
                }
                Boolean qualified = getQualified(item.getQualifiedQl(), contextMap);
                String value = getValue(item.getValueQl(), contextMap, item.getValueField());
                AssessmentCardDTO.Item metric = new AssessmentCardDTO.Item();
                metric.setCode(item.getCode());
                metric.setTitle(item.getTitle());
                if (StringUtils.isNotBlank(item.getQualifiedDate() )&& contextMap.get("firstOverDate") != null) {
                    String qualifiedDate = DateUtils.localDateToStr(DateUtils.strToLocalDate(contextMap.get("firstOverDate").toString(), CHECK_DATE_PATTERN), DS_DATE_PATTERN);
                    metric.setQualifiedDate(String.format(item.getQualifiedDate(), qualifiedDate));
                }
                metric.setTip(item.getTip());
                metric.setValue(value);
                metric.setUnit(item.getUnit());
                metric.setIsQualified(qualified);
                if (StringUtils.isNotBlank(item.getTarget())) {
                    metric.setExtraInfo(Lists.newArrayList(buildExtraInfoItem(EXTRA_NORMAL, item.getTarget())));
                }
                if (Objects.nonNull(qualified)) {
                    metric.setTags(Lists.newArrayList(AssessmentCardDTO.Tag.getTag(qualified)));
                }
                return metric;
            }).collect(Collectors.toList());
            metricsList = metricsList.stream().filter(Objects::nonNull).collect(Collectors.toList());
            boolean allQualified = metricsList.stream().filter(metric -> Objects.nonNull(metric.getIsQualified())).allMatch(AssessmentCardDTO.Item::getIsQualified);
            assessmentCardDTO.setTitle(group.getTitle());
            assessmentCardDTO.setCode(group.getCode());
            assessmentCardDTO.setDataDate((String) contextMap.getOrDefault("dataRange",""));
            assessmentCardDTO.setItems(metricsList);
            // 设备设备不展示是否达标
            if (!"equipmentUse".equals(group.getCode())) {
                assessmentCardDTO.setIsMeet(allQualified);
            }
            return assessmentCardDTO;
        }).collect(Collectors.toList());
    }

    private static AssessmentCardDTO.ExtraInfo buildExtraInfoItem(String status, String content) {
        AssessmentCardDTO.ExtraInfo extraInfo = new AssessmentCardDTO.ExtraInfo();
        extraInfo.setStatus(status);
        extraInfo.setContent(content);
        return extraInfo;
    }

    private static String getValue(String ql, Map<String, Object> contextMap, List<String> fieldList) {
        if (StringUtils.isBlank(ql)) {
            if (MapUtils.isNotEmpty(contextMap) && CollectionUtils.isNotEmpty(fieldList)) {
                String field = fieldList.stream().findFirst().orElseThrow(() -> new AladdinBizException("error", "指标值字段配置异常"));
                Object res = contextMap.get(field);
                return res != null ? res.toString() : "-";
            } else {
                throw new AladdinBizException("error", "指标指定字段配置错误");
            }
        }
        Object res = QlUtils.executeQlScript(ql, contextMap);
        return res != null ? res.toString() : null;
    }

    private static Boolean getQualified(String ql, Map<String, Object> contextMap) {
        if (StringUtils.isBlank(ql)) {
            return null;
        }
        Object res = QlUtils.executeQlScript(ql, contextMap);
        return parseBoolean(res);
    }

    private static Boolean parseBoolean(Object value) {
        if (value instanceof Boolean) {
            return (Boolean) value;
        } else {
            throw new AladdinBizException("error", "指标达标ql配置,结果必须为Boolean");
        }
    }

    private static String getDataRange(StationIncentiveBillDetailDTO detail) {
        // 考核范围时间
        String[] cycleRange = detail.getCycleRange().split("~");
        LocalDate checkStartDate = DateUtils.strToLocalDate(cycleRange[0], CHECK_DATE_PATTERN);
        LocalDate checkEndDate = DateUtils.strToLocalDate(cycleRange[1] + " 235959", CHECK_DATE_TIME_PATTERN);
        // 数据范围
        LocalDate dsDate = DateUtils.strToLocalDate(detail.getDs(), DS_DATE_PATTERN);
        LocalDate endRange = checkEndDate.isBefore(LocalDate.now()) ? checkEndDate : dsDate;
        return String.format("%s~%s", DateUtils.localDateToStr(checkStartDate, DATA_DATE_DAY_PATTERN), DateUtils.localDateToStr(endRange, DATA_DATE_DAY_PATTERN));
    }

    private static String getNewStaPerformRuleDetailUrl(StationDTO stationDTO, NewStaPerformSubsidyConfigDTO subsidyConfig){
        if(null == stationDTO){
            return null;
        }
        Date fy27Q1Date = DateUtil.getStr2SDate(subsidyConfig.getFy27Q1StartDate());
        Date fy26Q4Date = DateUtil.getStr2SDate(subsidyConfig.getFy26Q4StartDate());
        boolean isEntryFy26Q4 = stationDTO.getGmtCreate().after(fy26Q4Date) && stationDTO.getGmtCreate().before(fy27Q1Date);
        boolean isEntryFy27Q1 = stationDTO.getGmtCreate().after(fy27Q1Date);
        String cityCode = stationDTO.getCityCode();
        //FY26Q4
        if(isEntryFy27Q1) {
            if(CollectionUtils.isNotEmpty(subsidyConfig.getRuleDetailTop20CityCodeList()) && subsidyConfig.getRuleDetailTop20CityCodeList().contains(cityCode)){
                return subsidyConfig.getRuleDetailFy27Q1Top20Url();
            }else{
                return subsidyConfig.getRuleDetailFy27Q1Url();
            }
        }else if (isEntryFy26Q4) {
            if(CollectionUtils.isNotEmpty(subsidyConfig.getRuleDetailTop20CityCodeList()) && subsidyConfig.getRuleDetailTop20CityCodeList().contains(cityCode)){
                return subsidyConfig.getRuleDetailFy26Q4Top20Url();
            }else if (CollectionUtils.isNotEmpty(subsidyConfig.getRuleDetailTop100CityCodeList()) && subsidyConfig.getRuleDetailTop100CityCodeList().contains(cityCode)){
                return subsidyConfig.getRuleDetailFy26Q4Top100Url();
            }else {
                return "";
            }
        } else {
            if(CollectionUtils.isNotEmpty(subsidyConfig.getRuleDetailTop20CityCodeList()) && subsidyConfig.getRuleDetailTop20CityCodeList().contains(cityCode)){
                return subsidyConfig.getRuleDetailTop20Url();
            }else{
                return subsidyConfig.getRuleDetailUrl();
            }
        }
    }
}
