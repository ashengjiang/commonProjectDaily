package com.cainiao.tp.nm.plan.policy.application.component.imports;

import com.cainiao.tp.nm.plan.policy.application.component.imports.dto.ImportResultDTO;

public interface ImportManager {

    /**
     * 返回的结果是ossKey
     *
     * @param fileKey ossKey
     * @param  templeCode 模板code
     * @return return
     */
    ImportResultDTO executeImportByOss(String fileKey,String templeCode);

}
