package com.cainiao.tp.nm.plan.policy.application.service.dashboard;

import com.alibaba.fastjson.JSON;
import com.cainiao.aladdin.lock.Lock;
import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.aladdin.utils.Safes;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.aladdin.validate.utils.ValidateUtil;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.base.BaseDashboardCommonRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.PolicyInstanceQueryRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.PolicyInstanceRuleHistoryQueryRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.PolicyTemplateDashboardQueryRequest;
import com.cainiao.tp.nm.plan.api.policy.application.dto.*;
import com.cainiao.tp.nm.plan.api.policy.application.dto.base.BaseTableDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.base.ColumnDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyInstanceDetailQueryParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyInstanceRuleQueryParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.ScaleStationBaseExportParam;
import com.cainiao.tp.nm.plan.api.policy.application.service.dashboard.PolicyDashboardAppService;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyTairLockManager;
import com.cainiao.tp.nm.plan.api.policy.common.constants.DashBoardViewTypeEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyBizTypeEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyCustomTypeEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyInstanceApprovalStatusEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyInstanceStatusEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyStatisticsConstants;
import com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyInstanceQueryManager;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyInstanceRuleQueryManager;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyTemplateQueryManager;
import com.cainiao.tp.nm.plan.policy.adaptor.component.rights.RightsControlContext;
import com.cainiao.tp.nm.plan.policy.adaptor.component.rights.RightsControlUtils;
import com.cainiao.tp.nm.plan.policy.application.component.ExportAndImportComponentFactory;
import com.cainiao.tp.nm.plan.policy.application.extension.factory.PolicyDashboardTransformEngine;
import com.cainiao.tp.nm.plan.policy.common.util.ExcelDataUtil;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import static com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyCommonConstants.SPLICING;
import static com.cainiao.tp.nm.plan.policy.application.convert.PolicyInstanceRuleApplicationConvert.checkOrgCode;

/**
 * @code date 2025年06月03日 14:31
 * @code desc:政策看板查询 appService
 */
@Slf4j
@Component
public class PolicyDashboardAppServiceImpl implements PolicyDashboardAppService {

    @Resource
    private PolicyInstanceQueryManager instanceQueryManager;
    @Resource
    private PolicyInstanceRuleQueryManager instanceRuleReadQueryManger;
    @Resource
    private PolicyTemplateQueryManager policyTemplateQueryManager;
    @Resource
    private PolicyDashboardTransformEngine transformEngine;
    @Resource
    private ExportAndImportComponentFactory factory;
    @Resource
    PolicyTairLockManager policyTairLockManager;


    private final static String LOCK_KEY = "policy:dashboard:export:";
    private final static int EXPIRE_TIME = 60 *10;
    /**
     * 查询政策实例详情
     *
     * @param request 查询请求
     * @return 政策实例详情
     */
    @Override
    public List<PolicyTemplateDetailDTO> queryPolicyInstanceDetail(PolicyTemplateDashboardQueryRequest request, AbstractOperation operation) {
        AssertUtil.notNull(request, "request is null");
        AssertUtil.notNull(request.getPolicyType(), "policyType is null");

        List<PolicyTemplateDTO> templateDTOList = policyTemplateQueryManager.queryPolicyTemplate(request.getPolicyType());
        List<PolicyTemplateDetailDTO> result = Safes.of(templateDTOList).stream()
                .sorted(Comparator.comparing(PolicyTemplateDTO::getGmtCreate).reversed())
                .map(template -> {
                    PolicyTemplateDetailDTO detailDTO = new PolicyTemplateDetailDTO();
                    detailDTO.setId(template.getId());
                    detailDTO.setCustomerType(template.getCustomType());
                    detailDTO.setLabel(template.getTemplateName());
                    detailDTO.setValue(template.getId().toString());
                    detailDTO.setName(template.getTemplateName());
                    detailDTO.setCustomerTypeName(PolicyCustomTypeEnum.getDescBy(template.getCustomType()));
                    detailDTO.setStartDate(DateUtils.localDateTimeToYmdStr(template.getStartTime()));
                    detailDTO.setEndDate(DateUtils.localDateTimeToYmdStr(DateUtils.addOrSubtractDays(template.getEndTime(),-1)));
                    return detailDTO;
                }).collect(Collectors.toList());
        // 如果id不为空则将id对应的数据放在最前面
        if (request.getTemplateId() != null) {
            Map<Boolean, List<PolicyTemplateDetailDTO>> map = result.stream().collect(Collectors.partitioningBy(dto -> dto.getId().equals(request.getTemplateId())));
            if (MapUtils.isEmpty(map)) {
                return result;
            }
            result = Lists.newArrayList();
            result.addAll(map.get(true));
            result.addAll(map.get(false));
        }
        return result;
    }

    /**
     * 查询政策实例统计
     *
     * @param request 查询请求
     * @return 政策实例统计
     */
    @Override
    public List<PolicyInstanceStatisticsDTO> queryPolicyInstanceStatistics(PolicyInstanceQueryRequest request, AbstractOperation operation) {
        AssertUtil.notNull(request, "request is null");
        if(Objects.isNull(request.getPolicyTemplateId())) {
            return Collections.emptyList();
        }
        ValidateUtil.validateAndThrow(request);
        // 权限校验
        rightCheck(request);
        PolicyTemplateDTO templateDTO = policyTemplateQueryManager.queryPolicyTemplateById(request.getPolicyTemplateId());
        AssertUtil.notNull(templateDTO, "根据模版id无法查询到对应政策模版：policyTemplateId=" + request.getPolicyTemplateId());
        assembleTemplateRequest(templateDTO, request);
        List<PolicyInstanceStatisticsDTO> result = new ArrayList<>();
//        PolicyInstanceRuleQueryParam effectParam = buildQueryEffectInstanceRuleParam(request);
//        Long countEffect = instanceRuleReadQueryManger.countPolicyInstanceRuleByParam(effectParam);
//        result.add(PolicyInstanceStatisticsDTO.builder()
//                .title(PolicyStatisticsConstants.ALREADY_EFFECT)
//                .value(String.valueOf(countEffect))
//                .build());
        PolicyInstanceDetailQueryParam approvingParam = buildQueryApprovingInstanceParam(request, operation);
        Long countApproving = instanceQueryManager.countPolicyInstanceByParam(approvingParam);
        result.add(PolicyInstanceStatisticsDTO.builder()
                .title(PolicyStatisticsConstants.REPORT_UNDER_APPROVAL)
                .value(String.valueOf(countApproving))
                .url(PolicyStatisticsConstants.getPanGuApprovalPage())
                .build());
        return result;
    }


    /**
     * 查询政策实例项详情
     *
     * @param request 查询请求
     * @return 政策实例项详情
     */
    @Override
    public BaseTableDTO queryApprovedPolicyInstanceRule(PolicyInstanceQueryRequest request, AbstractOperation operation) {
        AssertUtil.notNull(request, "request is null");
        if(Objects.isNull(request.getPolicyTemplateId())) {
            return null;
        }
        ValidateUtil.validateAndThrow(request);
        // 权限校验
        rightCheck(request);
        // 过滤条件城市权限check
        RightsControlContext rightsControlContext = RightsControlUtils.get();
        request.validateFilterParam(rightsControlContext.isHasCnRights());

        PolicyTemplateDTO templateDTO = policyTemplateQueryManager.queryPolicyTemplateById(request.getPolicyTemplateId());
        AssertUtil.notNull(templateDTO, "根据模版id无法查询到对应政策模版：policyTemplateId=" + request.getPolicyTemplateId());
        assembleTemplateRequest(templateDTO, request);
        PolicyInstanceRuleQueryParam queryParam = buildInstanceRuleQueryParam(request);
        List<PolicyInstanceRuleDTO> ruleDTOList = instanceRuleReadQueryManger.queryPolicyInstanceRuleByParam(queryParam);
        String transformType = request.getPolicyType() + SPLICING + DashBoardViewTypeEnum.MAIN_TABLE.getViewType();
        return transformEngine.transformMainTableView(ruleDTOList, transformType,templateDTO);

    }

    /**
     * 查询政策实例项历史
     *
     * @param request 查询请求
     * @return 政策实例项历史
     */
    @Override
    public BaseTableDTO queryPolicyInstanceInstanceRuleReportHistory(PolicyInstanceRuleHistoryQueryRequest request, AbstractOperation operation) {
        AssertUtil.notNull(request, "request is null");
        AssertUtil.notNull(request.getPolicyRuleInstanceId(), "policyRuleInstanceId is null");
        ValidateUtil.validateAndThrow(request);
        // 权限校验
        PolicyInstanceRuleDTO policyInstanceRuleDTO = instanceRuleReadQueryManger.queryPolicyInstanceRuleById(request.getPolicyRuleInstanceId());
        AssertUtil.notNull(policyInstanceRuleDTO, "政策规则实例不存在");
        rightCheck(request, policyInstanceRuleDTO.getCityCode());
        PolicyTemplateDTO templateDTO = policyTemplateQueryManager.queryPolicyTemplateById(policyInstanceRuleDTO.getTemplateId());
        PolicyInstanceRuleQueryParam queryParam = buildQueryHistoryInstanceRuleParam(policyInstanceRuleDTO);
        List<PolicyInstanceRuleDTO> ruleDTOList = instanceRuleReadQueryManger.queryPolicyInstanceRuleByParam(queryParam);

        ruleDTOList = filterNotMatchRule(ruleDTOList, policyInstanceRuleDTO);
        String transformType = policyInstanceRuleDTO.getBizType() + SPLICING + DashBoardViewTypeEnum.HISTORY_TABLE.getViewType();
        return transformEngine.transformHistoryTableView(ruleDTOList, transformType,templateDTO);
    }


    @Override
    public String export(PolicyInstanceQueryRequest request, AbstractOperation operation) {
        AssertUtil.notNull(request.getPolicyTemplateId(), "没有对应的政策规则数据需要导出");
        ValidateUtil.validateAndThrow(request);
        Lock lock = getLock(operation.getOperatorId(),null);
        boolean tryLock = policyTairLockManager.tryLock(lock);
        com.cainiao.tp.nm.plan.policy.common.util.AssertUtil.isTrue(tryLock, "正在导出中，请稍等");
        try {
            Lock frequency = getLock(operation.getOperatorId() + "frequency", 2 * 60);
            boolean b = policyTairLockManager.tryLock(frequency);
            com.cainiao.tp.nm.plan.policy.common.util.AssertUtil.isTrue(b, "导出频次过快，请2分钟以后在试");
            // 权限校验
            rightCheck(request);

            PolicyTemplateDTO templateDTO = policyTemplateQueryManager.queryPolicyTemplateById(request.getPolicyTemplateId());
            AssertUtil.notNull(templateDTO, "根据模版id无法查询到对应政策模版：policyTemplateId=" + request.getPolicyTemplateId());
            assembleTemplateRequest(templateDTO, request);
            PolicyInstanceRuleQueryParam queryParam = buildInstanceRuleQueryParam(request);
            queryParam.setPageIndex(1);
            queryParam.setPageSize(5000);
            List<PolicyInstanceRuleDTO> ruleDTOList = instanceRuleReadQueryManger.queryPolicyInstanceRuleByParam(queryParam);
            String transformType = request.getPolicyType() + SPLICING + DashBoardViewTypeEnum.MAIN_TABLE.getViewType();
            BaseTableDTO baseTableDTO = transformEngine.transformMainTableView(ruleDTOList, transformType, templateDTO);

            DefaultExportDTO dto=new DefaultExportDTO();
            dto.setDataSource(ExcelDataUtil.toExcelData(baseTableDTO.getDataSource()));
            dto.setExcelHeads(toExcelHead(baseTableDTO.getColumns()));
            ExportResultDTO exportResultDTO=factory.executeDefaultExport(dto);
            log.info("PolicyDashboardAppServiceImpl export request:{},userName={},userId={}", JSON.toJSON(request), operation.getOperatorNick(), operation.getOperatorId());
            return exportResultDTO.getDownLoadUrl();
        } finally {
            lock.setLocked(true);
            policyTairLockManager.release(lock);
        }
    }

    private List<ExcelHead> toExcelHead(List<ColumnDTO> columnDTOList){
        if(CollectionUtils.isEmpty(columnDTOList)){
            return Lists.newArrayList();
        }
        List<ExcelHead> resultList = Lists.newArrayList();
        for (int i = 0; i < columnDTOList.size(); i++) {
            ExcelHead excelHead=new ExcelHead();
            excelHead.setIndex(i);
            excelHead.setFieldKey(columnDTOList.get(i).getDataIndex());
            excelHead.setHeadName(columnDTOList.get(i).getTitle());
            excelHead.setHeadDesc(columnDTOList.get(i).getTitle());
            resultList.add(excelHead);
        }
        return resultList;
    }
    private Lock getLock(String key,Integer expireTime){
        Lock lock = new Lock(LOCK_KEY + key);
        if(expireTime !=null){
            lock.setExpire(expireTime);
        }else{
            lock.setExpire(EXPIRE_TIME);
        }
        return lock;
    }
    /**
     * 获取导出的模版code
     *
     * @return return
     */
    private String getTempCode(PolicyTemplateDTO policyTemplateDTO) {
        String customType = policyTemplateDTO.getCustomType();
        String bizType = policyTemplateDTO.getBizType();
        if (PolicyBizTypeEnum.SCALE.getType().equals(bizType) && PolicyCustomTypeEnum.STATION.getType().equals(customType)) {
            return "ScaleStationExport";
        }
        if (PolicyBizTypeEnum.SCALE.getType().equals(bizType) && PolicyCustomTypeEnum.EXPRESS.getType().equals(customType)) {
            return "ScaleExpressExport";
        }
        //todo 异常统一处理
        throw new RuntimeException("未配置导出模版，请联系管理员配置");
    }

     private ScaleStationBaseExportParam buildScalePolicyExportParam(PolicyInstanceQueryRequest request, AbstractOperation operation){
         ScaleStationBaseExportParam param=new ScaleStationBaseExportParam();
         param.setRequest(request);
         param.setOperation(operation);
         return param;
    }

    private PolicyInstanceRuleQueryParam buildQueryHistoryInstanceRuleParam(PolicyInstanceRuleDTO policyInstanceRuleDTO) {
        PolicyInstanceRuleQueryParam queryParam = new PolicyInstanceRuleQueryParam();
        queryParam.setProvinceCode(policyInstanceRuleDTO.getProvinceCode());
        queryParam.setCityCode(policyInstanceRuleDTO.getCityCode());
        queryParam.setDistrictCode(policyInstanceRuleDTO.getDistrictCode());
        queryParam.setBizType(policyInstanceRuleDTO.getBizType());
        queryParam.setCustomType(policyInstanceRuleDTO.getCustomType());
        queryParam.setTemplateId(policyInstanceRuleDTO.getTemplateId());
        return queryParam;
    }

    private void rightCheck(BaseDashboardCommonRequest request,String cityCode) {
        RightsControlContext rightsControlContext = RightsControlUtils.get();
//        // 验证角色权限
//        String permissionDeniedPrompt = policyConfigManager.getPermissionDeniedPrompt();
//        AssertUtil.isTrue(rightsControlContext.isHasRoleRights(),permissionDeniedPrompt);
        // 验证地区权限
        boolean hasCnRights = rightsControlContext.isHasCnRights();
        if(hasCnRights){
            return;
        }
        Set<Long> cityCodeList = rightsControlContext.getCityCodeList();
        AssertUtil.notEmpty("无城市权限",cityCodeList);
        List<String> codeList = Safes.of(rightsControlContext.getCityCodeList()).stream().map(String::valueOf).collect(Collectors.toList());
        if(StringUtils.isNotBlank(cityCode)){
            AssertUtil.isTrue(codeList.contains(cityCode), "无城市权限");
        }
        request.setCityCodeList(codeList);
    }

    private void rightCheck(BaseDashboardCommonRequest request) {
        rightCheck(request,null);
    }
    private static PolicyInstanceDetailQueryParam buildQueryApprovingInstanceParam(PolicyInstanceQueryRequest request, AbstractOperation operation) {
        PolicyInstanceDetailQueryParam queryParam = new PolicyInstanceDetailQueryParam();
        queryParam.setBizStatus(PolicyInstanceApprovalStatusEnum.APPROVALING.getCode());
        queryParam.setTemplateId(request.getPolicyTemplateId());
        queryParam.setCustomType(request.getCustomType());
        queryParam.setBizType(request.getPolicyType());
        queryParam.setStatus(PolicyInstanceStatusEnum.WAITING_EFFECT.getCode());
        queryParam.setCityCodeList(request.getCityCodeList());
        queryParam.setSubmitter(operation.getOperatorNick());
        return queryParam;
    }

    private static PolicyInstanceRuleQueryParam buildQueryEffectInstanceRuleParam(PolicyInstanceQueryRequest request) {
        PolicyInstanceRuleQueryParam queryParam = new PolicyInstanceRuleQueryParam();
        queryParam.setTemplateId(request.getPolicyTemplateId());
        queryParam.setCustomType(request.getCustomType());
        queryParam.setBizType(request.getPolicyType());
        queryParam.setStatus(PolicyInstanceStatusEnum.EFFECT.getCode());
        queryParam.setCityCodeList(request.getCityCodeList());
        return queryParam;
    }
    private void assembleTemplateRequest(PolicyTemplateDTO templateDTO, BaseDashboardCommonRequest request) {
        // set 查询必要参数
        request.setPolicyTemplateId(templateDTO.getId());
        request.setPolicyType(templateDTO.getBizType());
        request.setCustomType(templateDTO.getCustomType());
    }

    private PolicyInstanceRuleQueryParam buildInstanceRuleQueryParam(PolicyInstanceQueryRequest request) {
        PolicyInstanceRuleQueryParam queryParam = new PolicyInstanceRuleQueryParam();
        queryParam.setTemplateId(request.getPolicyTemplateId());
        queryParam.setCustomType(request.getCustomType());
        queryParam.setBizType(request.getPolicyType());
        queryParam.setApprovalStatus(PolicyInstanceApprovalStatusEnum.PASS.getCode());
        queryParam.setCityCodeList(request.getCityCodeList());
        queryParam.setProvinceCode(request.getProvinceCode());
        queryParam.setExpressId(request.getExpressId());
        return queryParam;
    }

    private List<PolicyInstanceRuleDTO> filterNotMatchRule(List<PolicyInstanceRuleDTO> ruleDTOList, PolicyInstanceRuleDTO mainRuleDTO) {
        if (CollectionUtils.isEmpty(ruleDTOList)) {
            return ruleDTOList;
        }
        return Safes.of(ruleDTOList).stream().filter(ruleDTO -> {
            if (PolicyCustomTypeEnum.STATION.getType().equals(mainRuleDTO.getCustomType())) {
                return Objects.equals(mainRuleDTO.getDistrictCode(), ruleDTO.getDistrictCode());
            }
            if (PolicyCustomTypeEnum.EXPRESS.getType().equals(mainRuleDTO.getCustomType())) {
                return checkOrgCode(mainRuleDTO, ruleDTO);
            }
            return false;
        }).collect(Collectors.toList());
    }
}
