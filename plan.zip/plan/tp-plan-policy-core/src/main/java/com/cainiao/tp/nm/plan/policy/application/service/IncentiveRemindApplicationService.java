package com.cainiao.tp.nm.plan.policy.application.service;

import com.cainiao.aladdin.log.AladdinMapLog;
import com.cainiao.aladdin.log.BizType;
import com.cainiao.aladdin.log.utils.AladdinLogUtil;
import com.cainiao.tp.nm.plan.api.policy.application.dto.IncentiveRemindRuleDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.IncentiveRemindHolder;
import com.cainiao.tp.nm.plan.infra.port.policy.IncentiveRemindRulePort;
import com.cainiao.tp.nm.plan.infra.port.policy.IncentiveRemindTairPort;
import com.cainiao.tp.nm.plan.infra.port.policy.TpPushStationMessageManager;
import com.cainiao.tp.nm.plan.policy.application.component.station.IncentiveAssessDataComponent;
import com.cainiao.tp.nm.plan.policy.application.dto.IncentiveAssessContextDTO;
import com.cainiao.tp.nm.plan.policy.domain.service.IncentiveRemindRuleMatchDomainService;
import com.cainiao.tp.nm.plan.policy.domain.service.IncentiveRemindTriggerDomainService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * 站点实操激励提醒应用服务
 * 编排完整业务流程：推送时间判断 → 数据查询加工 → 规则匹配 → 防重发 → 通知发送
 *
 * @date 2026-03-27
 */
@Slf4j
@Service
public class IncentiveRemindApplicationService {

    /**
     * 装修报备页面跳转类型
     */
    private static final String JUMP_TYPE_DECORATION_REPORT = "DECORATION_REPORT";

    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd");

    private static final DateTimeFormatter DATE_MONTH_FORMATTER = DateTimeFormatter.ofPattern("yyyyMM");

    private static final String CYCLE3_DECOR_FAIL = "CYCLE3_DECOR_FAIL";

    @Resource
    private IncentiveRemindTriggerDomainService incentiveRemindTriggerDomainService;

    @Resource
    private IncentiveRemindRuleMatchDomainService incentiveRemindRuleMatchDomainService;

    @Resource
    private IncentiveAssessDataComponent incentiveAssessDataComponent;

    @Resource
    private IncentiveRemindRulePort incentiveRemindRulePort;

    @Resource
    private IncentiveRemindTairPort incentiveRemindTairPort;

    @Resource
    private TpPushStationMessageManager tpPushStationMessageManager;

    /**
     * 处理单个站点的实操激励提醒逻辑
     * 流程：推送时间判断 → 查询加工激励数据 → 规则匹配 → 防重发检查 → 发送通知 → 写入防重发标记
     *
     * @param stationId 站点 ID
     * @param joinDate  站点入驻日期（由 Job 层从 OpenSearch 查询时一并获取）
     */
    public void processIncentiveRemind(String stationId, LocalDate joinDate) {
        LocalDate today = LocalDate.now();
        AladdinMapLog mapLog = AladdinLogUtil.newMapLog("IncentiveRemindApplicationService.processIncentiveRemind", BizType.DEFAULT);
        mapLog.addParam("stationId", stationId);
        mapLog.addParam("joinDate", joinDate.toString());
        mapLog.addParam("today", today.toString());

        Exception exception = null;
        try {
            // 步骤1：获取 Diamond 通知规则列表
            List<IncentiveRemindRuleDTO> ruleList = incentiveRemindRulePort.getRuleList();
            if (CollectionUtils.isEmpty(ruleList)) {
                log.warn("IncentiveRemindApplicationService 规则列表为空，跳过站点，stationId={}", stationId);
                return;
            }

            // 步骤2：计算考核月偏移量，查询并加工站点激励考核数据
            int assessMonthOffset = incentiveRemindTriggerDomainService.calcAssessMonthOffset(joinDate, today);
            //超过最大考核月就没有必要考核了
            if(assessMonthOffset == -1){
                return;
            }
            IncentiveAssessContextDTO context = incentiveAssessDataComponent.buildAssessContext(
                    stationId, assessMonthOffset, today);
            if (context == null) {
                log.warn("IncentiveRemindApplicationService 激励数据为空，跳过站点，stationId={}", stationId);
                return;
            }
            //首月激励并且未装修则必须要通知
            boolean isFirstIncentiveAndNoDeco = context.getIsSatisfied() && !context.getIsDecorationPass();

            // 步骤3：判断当日是否为推送触发日
            boolean isTriggerDay = incentiveRemindTriggerDomainService.isTriggerDay(joinDate, today);
            if (!isTriggerDay && !isFirstIncentiveAndNoDeco) {
                log.info("IncentiveRemindApplicationService 当日非推送触发日，跳过站点，stationId={}", stationId);
                return;
            }

            // 步骤4：QL 规则匹配
            IncentiveRemindRuleDTO matchedRule = incentiveRemindRuleMatchDomainService.matchRule(ruleList, context);
            if (matchedRule == null) {
                log.info("IncentiveRemindApplicationService 无规则匹配，不发送通知，stationId={}", stationId);
                return;
            }

            // 步骤5：防重发检查，装修通知单考核周期只需要提醒一次
            String triggerCycle = CYCLE3_DECOR_FAIL.equals(matchedRule.getRuleCode())? today.format(DATE_MONTH_FORMATTER):today.format(DATE_FORMATTER);
            boolean alreadySent = incentiveRemindTairPort.isAlreadySent(stationId, matchedRule.getRuleCode(), triggerCycle);
            if (alreadySent) {
                log.info("IncentiveRemindApplicationService 通知已发送，跳过，stationId={}, ruleName={}",
                        stationId, matchedRule.getRuleName());
                return;
            }

            if(!IncentiveRemindHolder.getINSTANCE().isIncentiveRemindGrayHit(stationId)){
                log.info("IncentiveRemindApplicationService 灰度未命中，不发送通知，stationId={}, ruleName={}",
                        stationId, matchedRule.getRuleName());
                return;
            }

            // 步骤6：发送通知
            String jumpUrl = resolveJumpUrl(matchedRule.getJumpType());
            tpPushStationMessageManager.sendIncentiveRemindPopup(
                    Long.valueOf(stationId), matchedRule.getNotifyContent(), jumpUrl, matchedRule.getNoticeSchemeCode());

            // 步骤7：写入防重发标记
            incentiveRemindTairPort.markAsSent(stationId, matchedRule.getRuleCode(), triggerCycle);

            mapLog.addParam("matchedRule", matchedRule.getRuleName());
            mapLog.addParam("result", "sent");
        } catch (Exception e) {
            exception = e;
            throw e;
        } finally {
            if (exception != null) {
                AladdinLogUtil.log(log, exception, mapLog);
            } else {
                AladdinLogUtil.log(log, mapLog);
            }
        }
    }

    /**
     * 根据跳转类型解析跳转 URL
     * URL 配置从 TpNmCommonConfigHolder 中获取
     *
     * @param jumpType 跳转类型
     * @return 跳转 URL
     */
    private String resolveJumpUrl(String jumpType) {
        if (JUMP_TYPE_DECORATION_REPORT.equals(jumpType)) {
            return IncentiveRemindHolder.getINSTANCE().getDecorationReportUrl();
        }
        return IncentiveRemindHolder.getINSTANCE().getActivityDetailUrl();
    }
}
