package com.cainiao.tp.nm.plan.policy.application.service;

import com.alibaba.fastjson.JSON;
import com.cainiao.aladdin.lock.Lock;
import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.PolicyInstanceExportTemplateVO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.*;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiverule.IncentiveRuleFillDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.CheckExportParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyExportTemplateParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyInstanceBatchSubmitParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyInstanceCreateParam;
import com.cainiao.tp.nm.plan.api.policy.application.service.PolicyInstanceAppService;
import com.cainiao.tp.nm.plan.api.policy.application.service.PolicySubmissionAppService;
import com.cainiao.tp.nm.plan.api.policy.common.constants.*;
import com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils;
import com.cainiao.tp.nm.plan.infra.port.policy.CacheManager;
import com.cainiao.tp.nm.plan.infra.port.policy.EmployeeRightsLoadManager;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyTairLockManager;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyTemplateQueryManager;
import com.cainiao.tp.nm.plan.policy.application.component.ExportAndImportComponentFactory;
import com.cainiao.tp.nm.plan.policy.application.component.policy.submission.PolicySubmissionComponent;
import com.cainiao.tp.nm.plan.policy.application.component.policy.submission.context.CheckExportContext;
import com.cainiao.tp.nm.plan.policy.application.component.policy.submission.context.ExportTemplateContext;
import com.cainiao.tp.nm.plan.policy.application.component.policy.submission.impl.AbstractScalePolicySubmissionComponent;
import com.cainiao.tp.nm.plan.policy.common.util.AssertUtil;
import com.cainiao.tp.nm.plan.policy.domain.model.PolicyTemplate;
import com.cainiao.tp.nm.plan.policy.domain.repository.PolicyTemplateRepository;
import com.cainiao.tps.control.org.client.constant.newDept.TpsOrgNewDeptLevelEnum;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@Slf4j
public class PolicySubmissionAppServiceImpl implements PolicySubmissionAppService {

    @Resource
    PolicyTemplateQueryManager policyTemplateQueryManager;
    @Resource
    ExportAndImportComponentFactory executeExportFactory;
    @Autowired(required = false)
    List<PolicySubmissionComponent> policySubmissionComponentList;
    @Resource
    CacheManager cacheManager;
    @Resource
    PolicyInstanceAppService policyInstanceAppService;
    @Resource
    PolicyTairLockManager policyTairLockManager;
    @Resource
    EmployeeRightsLoadManager employeeRightsLoadManager;
    @Resource
    PolicyTemplateRepository repository;

    private final static String REGEX = "^\\d{4}-\\d{2}-\\d{2}$";
    private final static String SUBMISSION_LOCK_PREFIX = "submission:lock:key:";
    private final static Integer EXPIRE = 60 * 10;


    public RightOperateCodeDTO getRightOperateCode(AbstractOperation operation) {
        String highestLevelCode = employeeRightsLoadManager.getEmployeeHighestLevelCode(operation.getLongOperatorId());
        RightOperateCodeDTO recordVO = new RightOperateCodeDTO();
        fillOperateList(recordVO, highestLevelCode);
        return recordVO;
    }

    public static void fillOperateList(RightOperateCodeDTO recordVO, String highestLevelCode) {
        List<String> operateCodeList = new ArrayList<>();
        recordVO.setOperateCodeList(operateCodeList);
        if (TpsOrgNewDeptLevelEnum.RG_LEVEL.getCode().equals(highestLevelCode)) {
            operateCodeList.add(PolicyTemplateOperateEnum.REPORT.getCode());
        }

        if (TpsOrgNewDeptLevelEnum.CN_LEVEL.getCode().equals(highestLevelCode)) {
            operateCodeList.add(PolicyTemplateOperateEnum.CREATE_TEMPLATE.getCode());
        }
    }

    @Override
    public PolicyInstanceExportTemplateVO exportTemplate(PolicyExportTemplateParam param, AbstractOperation operation) {
        Lock lock = getLock(operation.getOperatorId());
        boolean tryLock = policyTairLockManager.tryLock(lock);
        AssertUtil.isTrue(tryLock, "处理中，请等待处理完成");
        try {
            PolicyTemplateDTO policyTemplateDTO = getPolicyTemplateAndCheck(param.getTemplateId());
            String tempCode = getTempCode(policyTemplateDTO);
            PolicySubmissionComponent component = getComponent(tempCode);
            ExportTemplateContext exportTemplateContext = new ExportTemplateContext();
            exportTemplateContext.setParam(param);
            exportTemplateContext.setPolicyTemplateDTO(policyTemplateDTO);
            return component.exportTemplate(exportTemplateContext, operation);
        } catch (Exception e) {
            log.error("exportTemplate error,param={},userid={}", JSON.toJSON(param), operation.getOperatorId(), e);
            throw e;
        } finally {
            lock.setLocked(true);
            policyTairLockManager.release(lock);
        }
    }

    private Lock getLock(String key) {
        Lock lock = new Lock(SUBMISSION_LOCK_PREFIX + key);
        lock.setExpire(EXPIRE);
        return lock;
    }

    @Override
    public PolicySubmissionCheckResultDTO polling(String jobId, AbstractOperation operation) {
        CheckExportResultCacheDTO result = cacheManager.get(AbstractScalePolicySubmissionComponent.CACHE_JOB_RESULT_PREFIX + jobId, CheckExportResultCacheDTO.class);
        if (null == result) {
            return AbstractScalePolicySubmissionComponent.buildPolicySubmissionCheckResultDTO(jobId);
        }
        PolicySubmissionCheckResultDTO resultDTO = new PolicySubmissionCheckResultDTO();
        resultDTO.setStatus(result.getStatus());
        resultDTO.setDownloadUrl(result.getDownloadUrl());
        resultDTO.setTotalCount(result.getTotalCount());
        resultDTO.setSuccessCount(result.getSuccessCount());
        resultDTO.setFailCount(result.getFailCount());
        resultDTO.setJobId(result.getJobId());
        resultDTO.setReason(result.getReason());
        resultDTO.setErrorDownloadUrl(result.getErrorDownloadUrl());
        resultDTO.setProgress(100);
        log.info("submission polling result={}", JSON.toJSON(resultDTO));
        return resultDTO;
    }

    @Override
    public PolicySubmissionCheckResultDTO checkExport(CheckExportParam param, AbstractOperation operation) {
        preCheck(param);
        Lock key = getLock(operation.getOperatorId() + "checkExport");
        boolean lock = policyTairLockManager.tryLock(key);
        AssertUtil.isTrue(lock, "处理中，请等待处理完成");
        try {
            PolicyTemplateDTO policyTemplateDTO = getPolicyTemplateAndCheck(param.getTemplateId());
            preExportParamCheck(policyTemplateDTO, param);
            String tempCode = getTempCode(policyTemplateDTO);
            PolicySubmissionComponent component = getComponent(tempCode);
            //放入缓存中
            CheckExportContext context = new CheckExportContext();
            context.setTemplateId(param.getTemplateId());
            context.setParam(param);
            context.setPolicyTemplateDTO(policyTemplateDTO);
            context.setJobId(UUID.randomUUID().toString());
            return component.checkExport(context, operation);
        } finally {
            key.setLocked(true);
            policyTairLockManager.release(key);
        }
    }


    private void preCheck(CheckExportParam param) {
        AssertUtil.notBlank(param.getBizType(), "政策类型不能为空");
        AssertUtil.notNull(param.getTemplateId(), "政策ID不能为空");
        AssertUtil.notNull(param.getKey(), "文件key不能为空");
        AssertUtil.notNull(param.getEffectType(), "生效类型不能为空");
        if (PolicySubmissionEffectType.SPECIFIED_TIME_EFFECT.getType().equals(param.getEffectType())) {
            AssertUtil.notBlank(param.getEffectStartTime(), "生效时间不能为空");
            AssertUtil.isTrue(param.getEffectStartTime().matches(REGEX), "生效时间格式不正确,YYYY-MM-DD");
        }
    }


    @Override
    public boolean batchSubmit(PolicyInstanceBatchSubmitParam param, AbstractOperation operation) {
        String jobId = param.getJobId();
        Lock key = getLock(jobId);
        boolean lock = policyTairLockManager.tryLock(key);
        AssertUtil.isTrue(lock, "处理中，请等待处理完成");
        try {
            CheckExportResultCacheDTO resultCacheDTO = cacheManager.get(AbstractScalePolicySubmissionComponent.CACHE_JOB_RESULT_PREFIX + jobId, CheckExportResultCacheDTO.class);
            Integer submissionFlag = resultCacheDTO.getSubmissionFlag();
            AssertUtil.isTrue(submissionFlag == null, "任务已经处理，请勿重复提交");
            AssertUtil.notNull(resultCacheDTO, "任务不存在,无法提交，请先导入表格数据");
            AssertUtil.isTrue(ExportStatusEnum.SUCCEEDED.getStatus().equals(resultCacheDTO.getStatus()), "任务处理失败，请重新导入表格数据");
            AssertUtil.isTrue(resultCacheDTO.getFailCount() <= 0, "导入的表格数据存在失败的数据，请先处理完成以后在重新导入处理");
            List<PolicyInstanceCreateParam> resultList = resultCacheDTO.getResultList();
            AssertUtil.notEmpty(resultList, "导入的表格数据不存在，请重新重新上传数据");
            PolicyInstanceCreateParam cacheParam = resultList.get(0);
            PolicyInstanceCreateParam createParam = new PolicyInstanceCreateParam();
            createParam.setTemplateId(cacheParam.getTemplateId());
            createParam.setIncentivePlanType(cacheParam.getIncentivePlanType());
            createParam.setStartTime(cacheParam.getStartTime());
            createParam.setOperatorId(cacheParam.getOperatorId());
            createParam.setFeatureMap(cacheParam.getFeatureMap());
            List<IncentiveRuleFillDTO> collect = resultList.stream().map(p -> p.getFillList().get(0)).collect(Collectors.toList());
            createParam.setFillList(collect);
            policyInstanceAppService.create(createParam, operation);


            //防止重复提交啊
            resultCacheDTO.setSubmissionFlag(1);
            cacheManager.set(AbstractScalePolicySubmissionComponent.CACHE_JOB_RESULT_PREFIX + jobId, resultCacheDTO, EXPIRE);
            return true;
        } catch (Exception e) {
            log.error("batchSubmit error,param={},opid={}", JSON.toJSON(param), operation.getOperatorId(), e);
            throw new RuntimeException(e);
        } finally {
            key.setLocked(true);
            policyTairLockManager.release(key);
        }
    }

    private void preExportParamCheck(PolicyTemplateDTO policyTemplateDTO, CheckExportParam param) {
        LocalDateTime startTime = policyTemplateDTO.getStartTime();
        LocalDateTime endTime = policyTemplateDTO.getEndTime();
        Integer effectType = param.getEffectType();
        if (PolicySubmissionEffectType.APPROVED_EFFECT.getType().equals(effectType)) {
            AssertUtil.isTrue(LocalDateTime.now().isAfter(startTime), "模版规则未开始，无法选择审批后生效");
        }

        if (PolicySubmissionEffectType.SPECIFIED_TIME_EFFECT.getType().equals(effectType)) {
            String effectStartTime = param.getEffectStartTime();
            LocalDateTime localDateTimeYmdStart = DateUtils.toLocalDateTimeYmdStart(effectStartTime);
            AssertUtil.isTrue(localDateTimeYmdStart.equals(startTime) || localDateTimeYmdStart.isAfter(startTime), "请修改生效时间在政策生效之后");
            AssertUtil.isTrue(localDateTimeYmdStart.isBefore(endTime) || localDateTimeYmdStart.equals(endTime), "生效时间不能超过政策结束时间");
        }
    }


    private PolicyTemplateDTO getPolicyTemplateAndCheck(Long templateId) {
        AssertUtil.notNull(templateId, "政策模版ID不能为空");
        PolicyTemplate policyTemplate = repository.get(templateId);
        AssertUtil.notNull(policyTemplate, "政策规则不存在，无法操作相关提报");
        PolicyTemplateDTO policyTemplateDTO = JSON.parseObject(JSON.toJSONString(policyTemplate), PolicyTemplateDTO.class);
        Byte status = policyTemplateDTO.getStatus();
        AssertUtil.isTrue(PolicyTemplateStatusEnum.EFFECT.getCode().equals(status), "政策规则未生效，无法操作相关提报");
        LocalDateTime endTime = policyTemplateDTO.getEndTime();
        AssertUtil.isTrue(LocalDateTime.now().isBefore(endTime), "政策规则已经结束,无法操作相关提报");
        return policyTemplateDTO;
    }

    /**
     * 获取导出的模版code
     *
     * @return return
     */
    private String getTempCode(PolicyTemplateDTO policyTemplateDTO) {
        Long id = policyTemplateDTO.getId();
        PolicyViewRefTempDTO policyViewRefTempDTO = PolicyViewConfigHolder.getINSTANCE().getConfigMap().get(id + "");
        if(null!=policyViewRefTempDTO){
            return PolicySubmissionComponent.DEFAULT_CODE;
        }

        String customType = policyTemplateDTO.getCustomType();
        String bizType = policyTemplateDTO.getBizType();
        if (PolicyBizTypeEnum.SCALE.getType().equals(bizType) && PolicyCustomTypeEnum.STATION.getType().equals(customType)) {
            return "scaleStationSubmission";
        }
        if (PolicyBizTypeEnum.SCALE.getType().equals(bizType) && PolicyCustomTypeEnum.EXPRESS.getType().equals(customType)) {
            return "ScaleExpressSubmission";
        }
        //todo 异常统一处理
        throw new RuntimeException("未配置导出模版，请联系管理员");
    }


    public PolicySubmissionComponent getComponent(String operateCode) {
        PolicySubmissionComponent policySubmissionComponent = policySubmissionComponentList.stream().filter(component -> operateCode.equals(component.getOperateCode())).findFirst().orElse(null);
        AssertUtil.notNull(policySubmissionComponent, operateCode + "，未配置处理器");
        return policySubmissionComponent;
    }

}
