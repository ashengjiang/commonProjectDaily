package com.cainiao.tp.nm.plan.policy.adaptor.convert;

import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.launchplan.AreaRuleLaunchVO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.launchplan.AreaRuleLaunchDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.launchplan.RuleLaunchDTO;

/**
 * @Date 2025/6/11 18:32
 */
public class RuleLaunchAdaptorConvert {

    /**
     * vo转dto
     * @param areaRuleLaunch 区域规则投放
     * @return 投放方案
     */
    public static RuleLaunchDTO voToDto(AreaRuleLaunchVO areaRuleLaunch) {
        if (areaRuleLaunch == null) {
            return null;
        }
        RuleLaunchDTO ruleLaunch = new RuleLaunchDTO();
        AreaRuleLaunchDTO areaRuleLaunchDTO = new AreaRuleLaunchDTO();
        if (Boolean.TRUE.equals(areaRuleLaunch.getNational())){
            ruleLaunch.setAreaRuleLaunch(areaRuleLaunchDTO);
            areaRuleLaunchDTO.setNational(true);
            return ruleLaunch;
        }
        areaRuleLaunchDTO.setProvinceCodeList(areaRuleLaunch.getProvinceCodeList());
        areaRuleLaunchDTO.setCityCodeList(areaRuleLaunch.getCityCodeList());
        areaRuleLaunchDTO.setDistrictCodeList(areaRuleLaunch.getDistrictCodeList());
        ruleLaunch.setAreaRuleLaunch(areaRuleLaunchDTO);
        return ruleLaunch;
    }
}
