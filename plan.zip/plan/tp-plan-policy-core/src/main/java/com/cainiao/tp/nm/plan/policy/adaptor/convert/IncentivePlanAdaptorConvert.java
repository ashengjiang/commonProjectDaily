package com.cainiao.tp.nm.plan.policy.adaptor.convert;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.IncentiveExpenseItemQueryRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.PolicyTemplateCreateRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.PolicyTemplateIncentiveQueryRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.incentiveplan.BasicIncentiveContentVO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.incentiveplan.FlexibleIncentiveContentVO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.incentiveplan.IncentiveExpenseItemVO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.incentiveplan.IncentivePlanVO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.PolicyIncentiveExpenseItemDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.IncentivePlanCoefficientContentDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.IncentivePlanContentDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.IncentivePlanDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.IncentivePlanFactorResultDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.IncentivePlanResultDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.limit.IncentiveResultLimitDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.IncentiveExpenseItemQueryParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.IncentivePlanQueryParam;
import com.cainiao.tp.nm.plan.api.policy.common.constants.IncentivePlanStationTypeEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.IncentivePlanTypeEnum;
import com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * @Date 2025/6/6 11:11
 * @code desc: 激励方案适配器转换
 */
public class IncentivePlanAdaptorConvert {

    public static List<IncentiveExpenseItemVO> dtoToExpenseItemVo(List<PolicyIncentiveExpenseItemDTO> incentivePlanDTOList) {
        if (CollectionUtils.isEmpty(incentivePlanDTOList)) {
            return new ArrayList<>();
        }
        return incentivePlanDTOList.stream().map(IncentivePlanAdaptorConvert::dtoToExpenseItemVo).filter(Objects::nonNull).collect(Collectors.toList());
    }

    public static IncentiveExpenseItemVO dtoToExpenseItemVo(PolicyIncentiveExpenseItemDTO expenseItemDTO) {
        if (expenseItemDTO == null) {
            return null;
        }
        IncentiveExpenseItemVO incentiveExpenseItemVO = new IncentiveExpenseItemVO();
        incentiveExpenseItemVO.setExpenseItemCode(expenseItemDTO.getExpenseItemCode());
        incentiveExpenseItemVO.setExpenseItemName(expenseItemDTO.getExpenseItemName());
        return incentiveExpenseItemVO;
    }

    public static IncentiveExpenseItemQueryParam convertQueryParam(IncentiveExpenseItemQueryRequest queryRequest) {
        if (queryRequest == null) {
            return null;
        }
        IncentiveExpenseItemQueryParam param = new IncentiveExpenseItemQueryParam();
        param.setBizType(queryRequest.getBizType());
        param.setCustomType(queryRequest.getCustomType());
        param.setIncentivePlanType(queryRequest.getIncentivePlanType());
        if (StringUtils.isNotBlank(queryRequest.getStartTimeStr())) {
            LocalDateTime startTime = DateUtils.toLocalDateTimeYmdStart(queryRequest.getStartTimeStr());
            param.setStartTime(startTime);
        }
        if (StringUtils.isNotBlank(queryRequest.getEndTimeStr())) {
            LocalDateTime endTime = DateUtils.toLocalDateTimeYmdEnd(queryRequest.getEndTimeStr());
            param.setEndTime(endTime);
        }
        return param;
    }

    public static IncentivePlanQueryParam convertQueryParam(PolicyTemplateIncentiveQueryRequest queryRequest) {
        IncentivePlanQueryParam param = new IncentivePlanQueryParam();
        param.setBizType(queryRequest.getBizType());
        param.setCustomType(queryRequest.getCustomType());
        param.setOutIncentiveTypeList(Collections.singletonList(queryRequest.getExpenseItemCode()));
        if (StringUtils.isNotBlank(queryRequest.getStartTimeStr())) {
            LocalDateTime startTime = DateUtils.toLocalDateTimeYmdStart(queryRequest.getStartTimeStr());
            param.setStartTime(startTime);
        }
        if (StringUtils.isNotBlank(queryRequest.getEndTimeStr())) {
            LocalDateTime endTime = DateUtils.toLocalDateTimeYmdEnd(queryRequest.getEndTimeStr());
            param.setEndTime(endTime);
        }
        return param;
    }

    public static List<IncentivePlanVO> dtoToVo(List<IncentivePlanDTO> incentivePlanDTOList) {
        if (CollectionUtils.isEmpty(incentivePlanDTOList)) {
            return new ArrayList<>();
        }
        return incentivePlanDTOList.stream().map(IncentivePlanAdaptorConvert::dtoToVo).collect(Collectors.toList());
    }

    public static IncentivePlanVO dtoToVo(IncentivePlanDTO incentivePlanDTO) {
        if (incentivePlanDTO == null) {
            return null;
        }
        IncentivePlanVO incentivePlanVO = new IncentivePlanVO();
        incentivePlanVO.setPlanName(incentivePlanDTO.getPlanName());
        incentivePlanVO.setIncentivePlanType(incentivePlanDTO.getIncentivePlanType());
        incentivePlanVO.setIncentivePlanCode(incentivePlanDTO.getIncentivePlanCode());
        String incentivePlanType = incentivePlanDTO.getIncentivePlanType();
        IncentivePlanTypeEnum incentivePlanTypeEnum = IncentivePlanTypeEnum.getByType(incentivePlanType);
        if (incentivePlanTypeEnum == null) {
            return incentivePlanVO;
        }
        incentivePlanVO.setPlanTitle(incentivePlanTypeEnum.getDesc());
        switch (incentivePlanTypeEnum) {
            case BASIC:
                BasicIncentiveContentVO basicIncentiveContent = getBasicIncentiveContent(incentivePlanDTO.getContent());
                incentivePlanVO.setBasicIncentiveContent(basicIncentiveContent);
                break;
            case FLEXIBLE:
                List<FlexibleIncentiveContentVO> flexibleIncentiveContent = getFlexibleIncentiveContent(incentivePlanDTO.getContent());
                incentivePlanVO.setFlexibleIncentiveContent(flexibleIncentiveContent);
                break;
            default:
                break;
        }
        return incentivePlanVO;
    }

    private static BasicIncentiveContentVO getBasicIncentiveContent(IncentivePlanContentDTO content) {
        BasicIncentiveContentVO basicIncentiveContent = new BasicIncentiveContentVO();
        List<String> valueList = new ArrayList<>();
        if (content == null || CollectionUtils.isEmpty(content.getCoefficient())) {
            return basicIncentiveContent;
        }
        List<IncentivePlanCoefficientContentDTO> coefficient = content.getCoefficient();
        if (CollectionUtils.isEmpty(coefficient) || coefficient.get(0) == null) {
            return basicIncentiveContent;
        }
        IncentivePlanCoefficientContentDTO coefficientContentDTO = coefficient.get(0);
        if (coefficientContentDTO.getFrame() == null || CollectionUtils.isEmpty(coefficientContentDTO.getFrame().getResult())) {
            return basicIncentiveContent;
        }
        List<IncentivePlanResultDTO> result = coefficientContentDTO.getFrame().getResult();
        if (result.get(0) == null || StringUtils.isBlank(result.get(0).getVal())) {
            return basicIncentiveContent;
        }
        String val = result.get(0).getVal();
        valueList.add(val);
        basicIncentiveContent.setValueList(valueList);
        return basicIncentiveContent;
    }

    private static List<FlexibleIncentiveContentVO> getFlexibleIncentiveContent(IncentivePlanContentDTO content) {
        if (content == null || CollectionUtils.isEmpty(content.getCoefficient())) {
            return new ArrayList<>();
        }
        List<IncentivePlanCoefficientContentDTO> coefficient = content.getCoefficient();
        if (CollectionUtils.isEmpty(coefficient) || coefficient.get(0) == null) {
            return new ArrayList<>();
        }
        IncentivePlanCoefficientContentDTO coefficientContentDTO = coefficient.get(0);
        if (coefficientContentDTO.getFrame() == null || CollectionUtils.isEmpty(coefficientContentDTO.getFrame().getChildren())) {
            return new ArrayList<>();
        }
        return coefficientContentDTO.getFrame().getChildren()
            .stream()
            .filter(flexibleIncentiveContentDTO -> flexibleIncentiveContentDTO.getFactorResult() != null)
            .map(flexibleIncentiveContentDTO -> {
                FlexibleIncentiveContentVO flexibleIncentiveContent = new FlexibleIncentiveContentVO();
                IncentivePlanFactorResultDTO factorResult = flexibleIncentiveContentDTO.getFactorResult();
                String stationTypeName = IncentivePlanStationTypeEnum.getDescBy(factorResult.getFixedVal());
                if (StringUtils.isBlank(stationTypeName)) {
                    return null;
                }
                flexibleIncentiveContent.setStationTypeName(stationTypeName);
                if (flexibleIncentiveContentDTO.getResult() == null || CollectionUtils.isEmpty(flexibleIncentiveContentDTO.getResult())) {
                    return flexibleIncentiveContent;
                }
                IncentivePlanResultDTO incentivePlanResultDTO = flexibleIncentiveContentDTO.getResult().get(0);
                if (incentivePlanResultDTO == null || incentivePlanResultDTO.getResultLimit() == null) {
                    return flexibleIncentiveContent;
                }
                IncentiveResultLimitDTO resultLimit = incentivePlanResultDTO.getResultLimit();
                if (resultLimit.getOptionLimit() == null) {
                    return flexibleIncentiveContent;
                }
                flexibleIncentiveContent.setValueList(resultLimit.getOptionLimit().getOptionList());
                return flexibleIncentiveContent;
            })
            .filter(Objects::nonNull)
            .collect(Collectors.toList());
    }

    /**
     * 消除激励方案内容
     *
     * @param incentivePlanList 激励方案
     * @return 激励方案
     */
    public static List<IncentivePlanDTO> eliminateContent(List<IncentivePlanDTO> incentivePlanList) {
        if (CollectionUtils.isEmpty(incentivePlanList)) {
            return new ArrayList<>();
        }
        return incentivePlanList.stream().filter(Objects::nonNull).map(incentivePlan -> {
            incentivePlan.setContent(null);
            return incentivePlan;
        }).collect(Collectors.toList());

    }

    public static IncentivePlanQueryParam convertQueryParamByPolicyTemplate(PolicyTemplateCreateRequest request) {
        IncentivePlanQueryParam incentivePlanQueryParam = new IncentivePlanQueryParam();
        incentivePlanQueryParam.setCustomType(request.getCustomType());
        incentivePlanQueryParam.setBizType(request.getBizType());
        incentivePlanQueryParam.setOutIncentiveTypeList(request.getIncentivePlanTypeList());
        if (StringUtils.isNotBlank(request.getStartTimeStr())) {
            LocalDateTime startTime = DateUtils.toLocalDateTimeYmdStart(request.getStartTimeStr());
            incentivePlanQueryParam.setStartTime(startTime);
        }
        if (StringUtils.isNotBlank(request.getEndTimeStr())) {
            LocalDateTime startTime = DateUtils.toLocalDateTimeYmdEnd(request.getEndTimeStr());
            incentivePlanQueryParam.setEndTime(startTime);
        }
        return incentivePlanQueryParam;
    }
}
