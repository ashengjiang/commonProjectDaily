package com.cainiao.tp.nm.plan.policy.domain.component;

import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyInstanceCreateParam;
import com.cainiao.tp.nm.plan.api.policy.common.constants.DefaultSelectRulePriorityEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyInstanceStatusEnum;
import com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils;
import com.cainiao.tp.nm.plan.policy.domain.model.PolicyInstance;
import com.cainiao.tp.nm.plan.policy.domain.model.PolicyTemplate;
import com.cainiao.tp.nm.plan.policy.domain.model.valobj.incentiveplan.IncentivePlan;
import com.cainiao.tp.nm.plan.policy.domain.model.valobj.incentiverule.IncentiveRule;
import com.cainiao.tp.nm.plan.policy.domain.model.valobj.incentiverule.IncentiveRuleContent;
import com.cainiao.tp.nm.plan.policy.domain.model.valobj.incentiverule.select.AreaSelectRule;
import com.cainiao.tp.nm.plan.policy.domain.model.valobj.incentiverule.select.EntitySelectRule;
import com.cainiao.tp.nm.plan.policy.domain.model.valobj.incentiverule.select.SelectRule;
import com.cainiao.tp.nm.plan.policy.domain.model.valobj.incentiverule.select.TagSelectRule;
import com.cainiao.tp.nm.plan.policy.domain.repository.PolicyInstanceRepository;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @date: 2022-03-16
 * desc: 政策扩展点
 */
@Slf4j
@Component
public abstract class AbstractPolicyInstanceDefinition implements PolicyInstanceDefinition {

    @Resource
    protected PolicyInstanceRepository policyInstanceRepository;

    @Override
    public void validCreate(PolicyTemplate policyTemplate, PolicyInstanceCreateParam param) {
        AssertUtil.isTrue(null != policyTemplate, "模版不存在");
        param.validate();
        // 时间校验
        LocalDateTime startTime = StringUtils.isNotBlank(param.getStartTime())
                ? DateUtils.toLocalDateTimeYmdStart(param.getStartTime()) : null;
        LocalDateTime now = LocalDateTime.now();

        if(null != startTime){
            AssertUtil.isTrue(startTime.compareTo(policyTemplate.getEndTime())<0
                    && startTime.compareTo(policyTemplate.getStartTime())>=0 , "开始时间不在政策周期内");
        }
        AssertUtil.isTrue(now.compareTo(policyTemplate.getEndTime())<0 , "政策周期已结束");

        // 规则实例和模版的校验
        Optional<IncentivePlan> first = policyTemplate.getIncentivePlanList().stream()
                .filter(plan -> plan.getIncentivePlanType().equals(param.getIncentivePlanType())).findFirst();
        AssertUtil.isTrue(first.isPresent(), "激励类型不存在");
        IncentivePlan incentivePlan = first.get();

        List<IncentiveRule> ruleList = param.getFillList().stream()
                .map(fill -> IncentiveRule.create(incentivePlan, fill)).collect(Collectors.toList());

        // 校验历史激励规则
        List<PolicyInstance> historyPolicyInstanceList = policyInstanceRepository.listByTemplate(param.getTemplateId(), param.getIncentivePlanType());
        Map<String, IncentiveRuleContent> ruleMap = ruleList.stream().collect(Collectors.toMap(rule -> rule.getSelectRule().selectId(), rule -> rule.getContent(), (u1, u2) -> u1));
        if(CollectionUtils.isNotEmpty(historyPolicyInstanceList)){
            historyPolicyInstanceList.stream().sorted(Comparator.comparing(PolicyInstance::getId).reversed()).forEach(his -> {
                Map<String, IncentiveRuleContent> hisRuleMap = his.getIncentiveRuleList().stream()
                        .collect(Collectors.toMap(rule -> rule.getSelectRule().selectId(), rule -> rule.getContent(), (u1, u2) -> u1));
                ruleMap.forEach((k,v)->{
                    if(null != hisRuleMap.get(k)){
                        AssertUtil.isTrue(PolicyInstanceStatusEnum.EFFECT.getCode().equals(his.getStatus()), "有相同的政策实例在审批中");
                        if(null == startTime){
                            AssertUtil.isTrue(now.compareTo(his.getStartTime()) > 0, "存在未开始的政策实例");
                        }else{
                            AssertUtil.isTrue(startTime.compareTo(his.getStartTime()) > 0, "存在开始时间之后的政策实例");
                        }
                    }
                });
            });
        }
    }

    @Override
    public void decisionPriority(PolicyTemplate template, PolicyInstance policyInstance) {
        for(IncentiveRule incentiveRule : policyInstance.getIncentiveRuleList()){
            SelectRule selectRule = incentiveRule.getSelectRule();
            EntitySelectRule entitySelectRule = selectRule.getEntitySelectRule();
            Long priority = 0L;
            // 名单圈选 > 区域圈选 > 标签圈选 > 版本
            if(null != entitySelectRule){
                // 1. 名单圈选，优先级最高
                priority += DefaultSelectRulePriorityEnum.ENTITY.getCoefficient()
                        * DefaultSelectRulePriorityEnum.ENTITY.getParagraph();
            }else{
                // 2. 区域圈选优先级
                AreaSelectRule areaSelectRule = selectRule.getAreaSelectRule();
                DefaultSelectRulePriorityEnum area = DefaultSelectRulePriorityEnum.AREA_NATIONAL;
                if(null != areaSelectRule){
                    if(null != areaSelectRule.getDistrictCode()){
                        area=DefaultSelectRulePriorityEnum.AREA_DISTRICT;
                    }else if(null != areaSelectRule.getCityCode()){
                        area=DefaultSelectRulePriorityEnum.AREA_CITY;
                    }else if(null != areaSelectRule.getProvinceCode()){
                        area=DefaultSelectRulePriorityEnum.AREA_PROV;
                    }
                }
                priority += area.getCoefficient() * area.getParagraph();

                // 3. 标签圈选优先级
                TagSelectRule tagSelectRule = selectRule.getTagSelectRule();
            }

            // 4.版本优先级
            LocalDateTime startTime = null != policyInstance.getStartTime()
                    ? policyInstance.getStartTime() : LocalDateTime.now();
            Integer version = Integer.parseInt(DateUtils.toDateStr(startTime, "yyMMdd"));
            priority += version * DefaultSelectRulePriorityEnum.VERSION.getParagraph();

            incentiveRule.setPriority(priority);
        }
    }
}
