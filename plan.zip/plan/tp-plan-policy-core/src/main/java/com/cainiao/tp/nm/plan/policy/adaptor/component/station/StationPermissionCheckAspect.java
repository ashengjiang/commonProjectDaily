package com.cainiao.tp.nm.plan.policy.adaptor.component.station;

import com.cainiao.aladdin.env.SystemEnvUtil;
import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.sutee.commons.base.result.CnResult;
import com.cainiao.sutee.commons.restful.enums.RestResultCodeEnum;
import com.cainiao.sutee.commons.restful.result.CnRestResult;
import com.cainiao.tp.nm.plan.infra.port.dto.context.StationPermissionContext;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.base.BaseStationPermissionRequest;
import com.cainiao.tp.nm.plan.api.policy.common.constants.RequestSourceEnum;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyConfigManager;
import com.cainiao.tp.nm.plan.infra.port.policy.StationPermissionCheckManager;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Objects;

import static com.cainiao.tp.nm.plan.api.policy.common.constants.RequestConstants.CN_REST_RESULT;
import static com.cainiao.tp.nm.plan.api.policy.common.constants.RequestConstants.CN_RESULT;

/**
 * @code date 2025年07月31日 10:25
 * @code desc:站点权限检测切面
 */
@Order
@Slf4j
@Aspect
@Component
public class StationPermissionCheckAspect {

    @Resource
    private StationPermissionCheckManager stationPermissionCheckManager;
    @Resource
    private PolicyConfigManager policyConfigManager;

    @Pointcut("execution(* com.cainiao.tp.nm.plan.policy.adaptor.rest..*.*(..)) " +
            "|| execution(* com.cainiao.tp.nm.plan.policy.adaptor.mtop..*.*(..)) " +
            "&& @annotation(com.cainiao.tp.nm.plan.policy.adaptor.component.station.StationPermissionCheck)" +
            "&& execution(public com.cainiao.sutee.commons.base.result.Result+ *(..))")
    public void stationPermissionCheckPointcut() {
    }


    @Around("stationPermissionCheckPointcut()")
    public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();
        Class<?> returnType = signature.getReturnType();
        Object[] args = joinPoint.getArgs();
        StationPermissionCheck stationPermissionCheck = method.getAnnotation(StationPermissionCheck.class);
        log.info("StationRightCheckAspect.method={},returnType={},args={}", method.getName(), returnType.getName(),args);
        if (Objects.isNull(stationPermissionCheck)) {
            return joinPoint.proceed();
        }
        try {
            StationPermissionContext context = assembleContext(args);
            RequestSourceEnum.validateSource(context.getSource());
            context = stationPermissionCheckManager.checkPermission(context);
            checkContextAndAssembleStationId(context,args);
            StationPermissionUtils.setContent(context);
            log.info("StationRightCheckAspect.context={}", context);
            return joinPoint.proceed();
        } catch (Exception e) {
            log.warn("StationPermissionCheckAspect.error."+method+".查询失败", e);
            return buildFailedResult(returnType.getSimpleName(), getErrMsg(e));
        } finally {
            StationPermissionUtils.remove();
        }
    }

    private StationPermissionContext assembleContext(Object[] args) {
        AssertUtil.notNull(args, "请求参数不能为空");
        BaseStationPermissionRequest basePermissionRequest = (BaseStationPermissionRequest) Arrays.stream(args).findFirst().orElseThrow(() -> new AladdinBizException("error", "请求参数不能为空"));
        StationPermissionContext context = new StationPermissionContext();
        context.setStationId(basePermissionRequest.getStationId());
        context.setSource(basePermissionRequest.getSource());
        return context;
    }

    private Object buildFailedResult(String returnTypeName, String errMsg) {
        if (CN_RESULT.equals(returnTypeName)) {
            return CnResult.fail(CnResult.SYSTEM_ERROR.getCode(), errMsg);
        } else if (CN_REST_RESULT.equals(returnTypeName)) {
            return CnRestResult.fail(RestResultCodeEnum.SYSTEM_ERROR, errMsg);
        }
        throw new AladdinBizException("request.error", "请求返回类型不支持");
    }

    private String getErrMsg(Exception e) {
        if (!(e instanceof AladdinBizException)) {
            return "站点激励数据查询失败,请稍后重试";
        } else {
            return e.getMessage();
        }
    }

    private void checkContextAndAssembleStationId(StationPermissionContext context,Object[] args) {
        AssertUtil.notNull(context, "context不能为空，请先登录");
        AssertUtil.notNull(context.getStationId(), "站点ID不能为空");
        AssertUtil.notNull(context.getSource(), "请求来源不能为空");
        AssertUtil.notNull(context.getEmployeeId(), "员工ID不能为空");
        mockStationId(context);
        // 这里setStationId 是为了兼容下驿站掌柜端mtop调用，低码页面无法传递stationId
        BaseStationPermissionRequest basePermissionRequest = (BaseStationPermissionRequest) Arrays.stream(args).findFirst().orElseThrow(() -> new AladdinBizException("error", "请求参数不能为空"));
        basePermissionRequest.setStationId(context.getStationId());
    }

    private void mockStationId(StationPermissionContext context) {
        if (SystemEnvUtil.isOnline()){
            return;
        }
        String mockStationId = policyConfigManager.getMockStaMapping(context.getStationId());
        if (Objects.nonNull(mockStationId)) {
            log.info("StationPermissionCheckAspect.mockStationId,stationId={},mockStationId={}", context.getStationId(), mockStationId);
            context.setStationId(mockStationId);
        }
    }

}
