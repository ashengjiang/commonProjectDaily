package com.cainiao.tp.nm.plan.policy.domain.service;

import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyTemplateCreateParam;
import com.cainiao.tp.nm.plan.policy.domain.model.PolicyTemplate;

/**
 * @code date 2025年3月10日
 * @code desc: 政策模版领域服务
 */
public interface PolicyTemplateDomainService {

    /**
     * 创建政策模版
     */
    PolicyTemplate createTemplate(PolicyTemplateCreateParam param);
}
