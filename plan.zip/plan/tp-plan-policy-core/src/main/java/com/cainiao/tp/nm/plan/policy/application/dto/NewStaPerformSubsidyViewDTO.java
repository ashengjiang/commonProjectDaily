package com.cainiao.tp.nm.plan.policy.application.dto;

import com.cainiao.aladdin.domain.BaseBean;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @code date 2025年06月03日 15:19
 * @code desc:新站实操激励视图
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class NewStaPerformSubsidyViewDTO extends BaseBean {

    /**
     * 视图code
     */
    private String viewCode;

    /**
     * 不满足条件的msg
     */
    private String notAllowMsg;
}
