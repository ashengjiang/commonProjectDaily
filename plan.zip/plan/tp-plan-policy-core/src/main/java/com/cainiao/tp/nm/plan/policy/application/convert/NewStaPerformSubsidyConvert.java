package com.cainiao.tp.nm.plan.policy.application.convert;

import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.aladdin.utils.DateUtil;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.tp.nm.plan.api.policy.application.dto.StationDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.NewStaPerformSubsidyConfigDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.PolicyIncentiveExpenseItemDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.PolicyIncentivePlanConfigDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.NewStaPerformCumulativeSubsidyDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.NewStaPerformCumulativeSubsidyItemDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.NewStaPerformNextLadderDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.NewStaPerformSubsidyDataDTO;
import com.cainiao.tp.nm.plan.api.policy.common.constants.NewStaPerformSubsidyViewEnum;
import com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils;
import com.cainiao.tp.nm.plan.policy.application.dto.NewStaPerformSubsidyViewDTO;
import com.cainiao.tp.nm.plan.policy.common.util.QlUtils;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;

/**
 * @code date 2025年08月05日 16:27
 * @code desc:null
 */
public class NewStaPerformSubsidyConvert {

    /**
     * 计算累计补贴信息
     * @param subsidyData 所有月的补贴信息
     * @return
     */
    public static NewStaPerformCumulativeSubsidyDTO buildCumulativeSubsidy(List<NewStaPerformSubsidyDataDTO> subsidyData, NewStaPerformSubsidyConfigDTO subsidyConfig) {
        NewStaPerformCumulativeSubsidyDTO res = new NewStaPerformCumulativeSubsidyDTO();
        List<NewStaPerformCumulativeSubsidyItemDTO> subsidyDTOS = Lists.newArrayList();
        res.setItem(subsidyDTOS);
        res.setTitle("累计已补贴");
        res.setTip(subsidyConfig.getCumulativeSubsidyTip());
        res.setUnit("元");
        res.setDetailUrl(subsidyConfig.getSubsidyDetailUrl());
        if(CollectionUtils.isEmpty(subsidyData)){
            return res;
        }

        String yyyyMM = DateUtils.toDateStr(LocalDateTime.now(), "yyyyMM");
        subsidyData.stream().filter(sd -> StringUtils.isNotBlank(sd.getCheckStartMonth())
                && sd.getStatsMonth().compareTo(sd.getCheckStartMonth()) >= 0)
                .sorted(Comparator.comparing(NewStaPerformSubsidyDataDTO::getStatsMonth)).forEach(dataDTO -> {
            NewStaPerformCumulativeSubsidyItemDTO dto = new NewStaPerformCumulativeSubsidyItemDTO();
            dto.setMonth(dataDTO.getStatsMonth());
            dto.setValue(String.valueOf(dataDTO.getSubsidyAmountYuan()));
            dto.setDispatchStatus(dataDTO.getDispatchStatus());
            dto.setIsQualified(Boolean.TRUE.equals(dataDTO.getIsSatisfied()));
            dto.setCycleNum(dataDTO.getCycleNum());
            dto.setIsStarted(true);
            if(!dto.getIsQualified()){
                dto.setSubsidyDesc("未达标");
            }else if("has_chargeoff".equals(dataDTO.getDispatchStatus())){
                dto.setSubsidyDesc("已到账");
            }else if(dataDTO.getStatsMonth().compareTo(yyyyMM) >= 0){
                dto.setSubsidyDesc("预估收益");
            }else{
                dto.setSubsidyDesc("待到账");
            }
            subsidyDTOS.add(dto);
        });

        if(CollectionUtils.isNotEmpty(subsidyDTOS)){
            NewStaPerformCumulativeSubsidyItemDTO subsidyItemDTO = subsidyDTOS.get(subsidyDTOS.size() - 1);
            Date subsidyMonth = DateUtil.getStrToDate("yyyyMM", subsidyItemDTO.getMonth());
            if(StringUtils.isNotBlank(subsidyItemDTO.getCycleNum()) && Integer.valueOf(subsidyItemDTO.getCycleNum()) < 6){
                Integer maxCycleNum = Integer.valueOf(subsidyItemDTO.getCycleNum());
                int subCycleNum = 6 - maxCycleNum;
                for(int x=1; x <= subCycleNum; x++){
                    NewStaPerformCumulativeSubsidyItemDTO dto = new NewStaPerformCumulativeSubsidyItemDTO();
                    dto.setMonth(DateUtil.getDate2Str("yyyyMM", org.apache.commons.lang3.time.DateUtils.addMonths(subsidyMonth, x)));
                    dto.setCycleNum(String.valueOf(x + maxCycleNum));
                    dto.setIsStarted(false);
                    dto.setSubsidyDesc("未开始");
                    subsidyDTOS.add(dto);
                }
            }
        }

        return res;
    }

    public static NewStaPerformNextLadderDTO buildNextLadder(NewStaPerformSubsidyDataDTO subsidyData, NewStaPerformSubsidyConfigDTO subsidyConfig){
        String qlExpress = subsidyConfig.getNewStaPerformSubsidyPriceQlExpress();
        List<Double> ladderList = subsidyConfig.getNewStaPerformSubsidyPriceLadderList();
        Double coefficient = (null != subsidyData.getCoefficient() ? subsidyData.getCoefficient() : 1);
        Double statsMonthAvgVaildArrCnt = (null != subsidyData.getStatsMonthAvgVaildArrCnt() ? subsidyData.getStatsMonthAvgVaildArrCnt() : 0);

        NewStaPerformNextLadderDTO nextLadder = new NewStaPerformNextLadderDTO();

        Optional<Double> first = ladderList.stream().filter(ladder -> statsMonthAvgVaildArrCnt < ladder).sorted().findFirst();
        nextLadder.setIsTop(!first.isPresent());
        if(first.isPresent()){
            nextLadder.setNextOrder(first.get().intValue());
            nextLadder.setNextSubOrder((int)Math.ceil(first.get()- statsMonthAvgVaildArrCnt));
            Map<String, Object> contextMap = Maps.newHashMap();
            contextMap.put("coefficient", coefficient);
            contextMap.put("statsMonthAvgVaildArrCnt", first.get());
            Object res = QlUtils.executeQlScript(qlExpress, contextMap);
            nextLadder.setNextSubsidy(Double.valueOf(res.toString()));
        }
        return nextLadder;
    }

    public static NewStaPerformSubsidyViewDTO judgeView(StationDTO stationDTO, List<NewStaPerformSubsidyDataDTO> subsidyData, NewStaPerformSubsidyConfigDTO subsidyConfig) {
        AssertUtil.notNull(stationDTO, "站点不存在");
        NewStaPerformSubsidyViewDTO viewDTO = new NewStaPerformSubsidyViewDTO();
        // 基础条件验证
        boolean judgeBasicCond = judgeBasicCond(stationDTO, subsidyConfig);
        if(!judgeBasicCond){
            viewDTO.setViewCode(NewStaPerformSubsidyViewEnum.NOT_ALLOW_PARTICIPATE.getCode());
            viewDTO.setNotAllowMsg("抱歉，不符合新入驻站点条件，无法参与活动");
            return viewDTO;
        }
        Date fy27Q1Date = DateUtil.getStr2SDate(subsidyConfig.getFy27Q1StartDate());
        Date fy26Q4Date = DateUtil.getStr2SDate(subsidyConfig.getFy26Q4StartDate());
        boolean isEntryFy26Q4 = stationDTO.getGmtCreate().after(fy26Q4Date) && stationDTO.getGmtCreate().before(fy27Q1Date);
        boolean isAfterFy26Q4 = stationDTO.getGmtCreate().after(fy26Q4Date);
        boolean isTop100City = CollectionUtils.isNotEmpty(subsidyConfig.getRuleDetailTop100CityCodeList())
                && subsidyConfig.getRuleDetailTop100CityCodeList().contains(stationDTO.getCityCode());
        //FY26Q4 非top100城市没有激励
        if (isEntryFy26Q4 && !isTop100City) {
            viewDTO.setViewCode(NewStaPerformSubsidyViewEnum.NOT_ALLOW_PARTICIPATE.getCode());
            viewDTO.setNotAllowMsg("抱歉，您无法参与入库单量激励活动");
            return viewDTO;
        }
        // 建站条件验证
        boolean judgeBuildStaCond = judgeBuildStaCond(stationDTO);
        //FY26Q4+top100城市取消线索转化条件限制
        if (!isAfterFy26Q4 && !judgeBuildStaCond) {
            viewDTO.setViewCode(NewStaPerformSubsidyViewEnum.NOT_ALLOW_PARTICIPATE.getCode());
            viewDTO.setNotAllowMsg("抱歉，您无法参与入库单量激励活动");
            return viewDTO;
        }

        // 结算数据判断
        LocalDateTime now = LocalDateTime.now();
        Date gmtCreate = stationDTO.getGmtCreate();
        LocalDateTime enterEndDate = gmtCreate.toInstant().atZone(ZoneId.systemDefault())
                .toLocalDate().withDayOfMonth(1).plusMonths(4).atStartOfDay();
        if(CollectionUtils.isEmpty(subsidyData)){
            if(now.isBefore(enterEndDate)){
                viewDTO.setViewCode(NewStaPerformSubsidyViewEnum.NOT_CUMULA_SUBSIDY.getCode());
                return viewDTO;
            }else{
                viewDTO.setViewCode(NewStaPerformSubsidyViewEnum.NOT_ALLOW_PARTICIPATE.getCode());
                viewDTO.setNotAllowMsg("抱歉，因您在入驻后3个自然月内首月实操考核未达标，已无法继续参与活动。 ");
                return viewDTO;
            }
        }

        // 风控条件验证
        NewStaPerformSubsidyDataDTO latestSubsidyDetail = subsidyData.stream()
                .sorted(Comparator.comparing(NewStaPerformSubsidyDataDTO::getStatsMonth).reversed()).findFirst().get();
        if(!isAfterFy26Q4 && (Boolean.TRUE.equals(latestSubsidyDetail.getIsRisk()) || Boolean.TRUE.equals(latestSubsidyDetail.getIsBlackStation()))){
            viewDTO.setViewCode(NewStaPerformSubsidyViewEnum.NOT_ALLOW_PARTICIPATE.getCode());
            viewDTO.setNotAllowMsg("抱歉，您的站点不在本次活动参与范围内");
            return viewDTO;
        }

        // 累计补贴条件验证
        int beforeAccumulatedSubsidy = getBeforeAccumulatedSubsidy(subsidyData);
        if(beforeAccumulatedSubsidy <=0 && now.isAfter(enterEndDate)){
            viewDTO.setViewCode(NewStaPerformSubsidyViewEnum.NOT_ALLOW_PARTICIPATE.getCode());
            viewDTO.setNotAllowMsg("抱歉，因您在入驻后3个自然月内首月实操考核未达标，已无法继续参与活动。 ");
            return viewDTO;
        }


        String yyyyMM = DateUtils.toDateStr(now, "yyyyMM");
        boolean entryCheck =StringUtils.isNotBlank(latestSubsidyDetail.getCheckStartMonth()) && latestSubsidyDetail.getCheckStartMonth().compareTo(yyyyMM) < 0;
        if(now.isBefore(enterEndDate) && beforeAccumulatedSubsidy <=0 && !entryCheck){
            viewDTO.setViewCode(NewStaPerformSubsidyViewEnum.NOT_CUMULA_SUBSIDY.getCode());
        }else if(beforeAccumulatedSubsidy > 0 || entryCheck){
            viewDTO.setViewCode(NewStaPerformSubsidyViewEnum.HAS_CUMULA_SUBSIDY.getCode());
        }else{
            throw new AladdinBizException("数据不符合预期", "抱歉，开了个小差，请稍后重新再试~");
        }

        return viewDTO;
    }


    public static boolean judgeBasicCond(StationDTO stationDTO, NewStaPerformSubsidyConfigDTO subsidyConfig) {
        AssertUtil.notNull(stationDTO, "站点不存在");
        Map<String, String> featureMap = stationDTO.getFeatureMap();

        // 判断入驻时间
        Date gmtCreate = stationDTO.getGmtCreate();
        Date beginDate = DateUtil.getStr2SDate(subsidyConfig.getStartDate());
        Date endDate = DateUtil.getStr2SDate(subsidyConfig.getEndDate());
        boolean isEnter = gmtCreate.after(beginDate) && gmtCreate.before(endDate);
        // 判断站点类型：社区驿站专业点
        boolean isProfessionalStation = "professional_station".equals(featureMap.get("station_type"));
        //判断是否主体变更站点
        boolean isTransferStation = StringUtils.isNotBlank(featureMap.get("transfer_station_id"));
        //判断是否溪鸟转化站点
        boolean isCountrySideTransfer = "y".equals(featureMap.get("isCountrySideTransfer"));
        //判断生命周期是否为退出期
        boolean isStationQuit = StringUtils.isNotBlank(featureMap.get("station_quit_tag"));

        return isEnter && isProfessionalStation && !isTransferStation && !isCountrySideTransfer && !isStationQuit;
    }

    public static boolean judgeBuildStaCond(StationDTO stationDTO) {
        AssertUtil.notNull(stationDTO, "站点不存在");
        Map<String, String> featureMap = stationDTO.getFeatureMap();

        // 判断是否空白热点建站
        boolean isBlankAoiId = StringUtils.isNotBlank(featureMap.get("blank_aoi_id"));
        // 判断代收点转化建站（优质热点 + 渠道经理复审：是）
        boolean isCollectionPointTransfer = "y".equals(featureMap.get("cp_is_collection_point_transfer"));
        // 判断翻站码建站
        boolean transferCollectPointId = StringUtils.isNotBlank(featureMap.get("transfer_collect_point_id"));

        return isBlankAoiId || isCollectionPointTransfer || transferCollectPointId;
    }

    /**
     * 获取上个月及之前所有月的累计补贴金额
     * @param subsidyData
     */
    private static int getBeforeAccumulatedSubsidy(List<NewStaPerformSubsidyDataDTO> subsidyData){
        int accumulatedSubsidy = 0;
        String yyyyMM = DateUtils.toDateStr(LocalDateTime.now(), "yyyyMM");
        if(CollectionUtils.isEmpty(subsidyData)){
            return accumulatedSubsidy;
        }

        for(NewStaPerformSubsidyDataDTO subsidy : subsidyData){
            if(StringUtils.isNotBlank(subsidy.getStatsMonth()) && subsidy.getStatsMonth().compareTo(yyyyMM) < 0){
                accumulatedSubsidy += subsidy.getSubsidyAmount();
            }
        }

        return accumulatedSubsidy;
    }

    public static double calculPrice(NewStaPerformSubsidyDataDTO subsidyData, String qlExpress){
        int subsidyAmount = subsidyData.getSubsidyAmount();
        int subsidyAmountYuan = subsidyData.getSubsidyAmountYuan();
        if(subsidyAmount > 0){
            return subsidyAmountYuan;
        }

        Double coefficient = subsidyData.getCoefficient();
        Double statsMonthAvgVaildArrCnt = subsidyData.getStatsMonthAvgVaildArrCnt();
        if(null == coefficient || null == statsMonthAvgVaildArrCnt){
            return subsidyAmountYuan;
        }

        Map<String, Object> contextMap = Maps.newHashMap();
        contextMap.put("coefficient", coefficient);
        contextMap.put("statsMonthAvgVaildArrCnt", statsMonthAvgVaildArrCnt);
        Object res = QlUtils.executeQlScript(qlExpress, contextMap);
        return Double.valueOf(res.toString());
    }
}
