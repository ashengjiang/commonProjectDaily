package com.cainiao.tp.nm.plan.policy.domain.service.impl;

import com.alibaba.fastjson.JSON;
import com.cainiao.tp.nm.plan.api.policy.application.dto.IncentiveRemindRuleDTO;
import com.cainiao.tp.nm.plan.policy.application.dto.IncentiveAssessContextDTO;
import com.cainiao.tp.nm.plan.policy.domain.service.IncentiveRemindRuleMatchDomainService;
import com.ql.util.express.DefaultContext;
import com.ql.util.express.ExpressRunner;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * 站点实操激励提醒 QL 规则匹配领域服务实现
 * 使用 QLExpress 表达式引擎按顺序匹配规则，短路返回第一条满足条件的规则
 *
 * @date 2026-03-27
 */
@Slf4j
@Component
public class IncentiveRemindRuleMatchDomainServiceImpl implements IncentiveRemindRuleMatchDomainService {

    /**
     * QLExpress 表达式执行器，线程安全，可复用
     */
    private static final ExpressRunner EXPRESS_RUNNER = new ExpressRunner();

    @Override
    public IncentiveRemindRuleDTO matchRule(List<IncentiveRemindRuleDTO> ruleList, IncentiveAssessContextDTO context) {
        if (CollectionUtils.isEmpty(ruleList) || context == null) {
            return null;
        }

        for (IncentiveRemindRuleDTO rule : ruleList) {
            if (evaluateRule(rule, context)) {
                log.info("IncentiveRemindRuleMatchDomainService 规则匹配成功，stationId={}, ruleName={}",
                        context.getStationId(), rule.getRuleName());
                return rule;
            }
        }

        log.info("IncentiveRemindRuleMatchDomainService 无规则匹配，stationId={}, context={}",
                context.getStationId(), JSON.toJSONString(context));
        return null;
    }

    /**
     * 执行单条 QL 规则表达式，判断当前站点上下文是否满足规则条件
     *
     * @param rule    通知规则
     * @param context 站点激励考核数据上下文
     * @return true=满足规则条件
     */
    private boolean evaluateRule(IncentiveRemindRuleDTO rule, IncentiveAssessContextDTO context) {
        try {
            // 将上下文字段注入 QL 表达式执行环境
            DefaultContext<String, Object> qlContext = new DefaultContext<>();
            qlContext.put("firstOver100ArrDate", context.getFirstOver100ArrDate());
            qlContext.put("isSatisfied", context.getIsSatisfied());
            qlContext.put("assessMonthOffset", context.getAssessMonthOffset());
            qlContext.put("cycleNum", context.getCycleNum());
            qlContext.put("isDecorationPass", context.getIsDecorationPass());

            Object result = EXPRESS_RUNNER.execute(rule.getRuleExpression(), qlContext, null, true, false);
            return Boolean.TRUE.equals(result);
        } catch (Exception e) {
            log.error("IncentiveRemindRuleMatchDomainService QL 表达式执行异常，ruleName={}, expression={}, stationId={}, error={}",
                    rule.getRuleName(), rule.getRuleExpression(), context.getStationId(), e.getMessage(), e);
            return false;
        }
    }
}
