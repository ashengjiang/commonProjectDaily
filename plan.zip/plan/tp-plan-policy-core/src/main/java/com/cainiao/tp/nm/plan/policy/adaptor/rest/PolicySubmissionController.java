package com.cainiao.tp.nm.plan.policy.adaptor.rest;

import com.cainiao.sutee.commons.restful.result.CnRestResult;
import com.cainiao.tp.boot.annotation.TpController;
import com.cainiao.tp.boot.annotation.access.TpBucAccess;
import com.cainiao.tp.boot.annotation.access.TpMoziAccess;
import com.cainiao.tp.boot.utils.TpWebUtil;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.PolicyFileUploadRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.SubmissionPollingRequest;
import com.cainiao.tp.nm.plan.api.policy.application.dto.RightOperateCodeDTO;
import com.cainiao.tp.nm.plan.policy.adaptor.component.rights.RightsControl;
import com.cainiao.tp.nm.plan.policy.adaptor.component.rights.RightsControlContext;
import com.cainiao.tp.nm.plan.policy.adaptor.component.rights.RightsControlUtils;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.PolicyInstanceExportTemplateVO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.OssAuthDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicySubmissionCheckResultDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.CheckExportParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyExportTemplateParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyInstanceBatchSubmitParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyInstanceEffectParam;
import com.cainiao.tp.nm.plan.infra.port.policy.FileStoryManager;
import com.cainiao.tp.nm.plan.api.policy.application.service.PolicyInstanceAppService;
import com.cainiao.tp.nm.plan.api.policy.application.service.PolicySubmissionAppService;
import com.cainiao.tp.nm.plan.policy.common.util.AssertUtil;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;
import java.util.UUID;

/**
 * 政策实例提报 */
@TpBucAccess
@TpController
@TpMoziAccess
@RequestMapping(value = {"/policy/submission"})
public class PolicySubmissionController {

    @Resource
    PolicyInstanceAppService policyInstanceAppService;
    @Resource
    FileStoryManager fileStoryManager;
    @Resource
    PolicySubmissionAppService policySubmissionAppService;

    private final static String DEFAULT_DIR = "policySubmission";

    @GetMapping("/getRightOperateCode")
    @RightsControl(roleCodeArray = {"scale_policy_admin"})
    public CnRestResult<RightOperateCodeDTO> getRightOperateCode() {
        return CnRestResult.succeed(policySubmissionAppService.getRightOperateCode(TpWebUtil.getWebOperation()));
    }


    /**
     * 获取上传的权限
     *
     * @param request request
     * @return return
     */
    @GetMapping("/fileUploadAccess")
    public CnRestResult<OssAuthDTO> fileUploadAccess(PolicyFileUploadRequest request) {
        String fileName = request.getFileName();
        return CnRestResult.succeed(fileStoryManager.getUploadOssTokenConfig(fileName, DEFAULT_DIR));
    }

    /**
     * 模版导出
     *
     * @param param req
     * @return return
     */
    @GetMapping("/exportTemplate")
    @RightsControl(roleCodeArray = {"scale_policy_admin"})
    public CnRestResult<String> exportTemplate(PolicyExportTemplateParam param) {
        AssertUtil.notBlank(param.getBizType(), "bizType is not null");
        AssertUtil.notNull(param.getTemplateId(), "templateId is not null");
        RightsControlContext rightsControlContext = RightsControlUtils.get();
        param.setHasCnRights(rightsControlContext.isHasCnRights());
        param.setCityCodeList(rightsControlContext.getCityCodeList());
        PolicyInstanceExportTemplateVO result = policySubmissionAppService.exportTemplate(param, TpWebUtil.getWebOperation());
        return CnRestResult.succeed(result.getDownLoadUrl());
    }


    /**
     * 轮询查询任务处理结果
     *
     * @param request 任务ID
     * @return return
     */
    @PostMapping("/polling")
    @RightsControl(roleCodeArray = {"scale_policy_admin"})
    public CnRestResult<PolicySubmissionCheckResultDTO> polling(@RequestBody SubmissionPollingRequest request) {
        return CnRestResult.succeed(policySubmissionAppService.polling(request.getJobId(), TpWebUtil.getWebOperation()));
    }


    /**
     * 前置check
     *
     * @param param 任务ID
     * @return return
     */
    @PostMapping("/checkExport")
    @RightsControl(roleCodeArray = {"scale_policy_admin"})
    public CnRestResult<PolicySubmissionCheckResultDTO> checkExport(@RequestBody CheckExportParam param) {
        AssertUtil.notBlank(param.getBizType(), "请输入业务类型");
        AssertUtil.notNull(param.getTemplateId(), "请输入模版ID");
        AssertUtil.notNull(param.getEffectType(), "请输入生效时间");
        AssertUtil.notNull(param.getKey(), "请传入文件key");
        PolicySubmissionCheckResultDTO policySubmissionCheckResultDTO = new PolicySubmissionCheckResultDTO();
        policySubmissionCheckResultDTO.setJobId(UUID.randomUUID().toString());
        param.setHasCnRights(RightsControlUtils.get().isHasCnRights());
        param.setCityCodeList(RightsControlUtils.get().getCityCodeList());
        PolicySubmissionCheckResultDTO resultDTO = policySubmissionAppService.checkExport(param, TpWebUtil.getWebOperation());
        return CnRestResult.succeed(resultDTO);
    }


    /**
     * 前置check
     *
     * @param param 任务ID
     * @return return
     */
    @PostMapping("/batchSubmit")
    @RightsControl(roleCodeArray = {"scale_policy_admin"})
    public CnRestResult<Boolean> batchSubmit(@RequestBody PolicyInstanceBatchSubmitParam param) {
        AssertUtil.notBlank(param.getJobId(), "请传入任务ID");
        boolean result = policySubmissionAppService.batchSubmit(param, TpWebUtil.getWebOperation());
        return CnRestResult.succeed(result);
    }


    /**
     * 前置check
     *
     * @param param 任务ID
     * @return return
     */
    @PostMapping("/submit")
    @RightsControl(roleCodeArray = {"scale_policy_admin"})
    public CnRestResult<Boolean> submit(@RequestBody PolicyInstanceEffectParam param) {
        policyInstanceAppService.effect(param, TpWebUtil.getWebOperation());
        return CnRestResult.succeed(true);
    }

}
