package com.cainiao.tp.nm.plan.policy.domain.repository;

import com.cainiao.sutee.commons.base.model.Page;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyTemplateDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyTemplateQueryParam;
import com.cainiao.tp.nm.plan.policy.domain.model.PolicyTemplate;

import java.util.List;

/**
 * @code date 2025年3月10日
 * @code desc: 政策模版仓储
 */
public interface PolicyTemplateRepository {

    PolicyTemplate get(Long templateId);

    List<PolicyTemplate> get(String bizType, String customType);

    Long create(PolicyTemplate policyTemplate);

    void delete(PolicyTemplate policyTemplate);

    Page<PolicyTemplate> selectPage(PolicyTemplateQueryParam queryParam);

    List<PolicyTemplateDTO> selectAll(PolicyTemplateQueryParam queryParam);
}
