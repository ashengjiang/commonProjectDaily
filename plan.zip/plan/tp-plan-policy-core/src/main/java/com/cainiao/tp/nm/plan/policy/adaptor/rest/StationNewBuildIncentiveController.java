package com.cainiao.tp.nm.plan.policy.adaptor.rest;

import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.sutee.commons.restful.result.CnRestResult;
import com.cainiao.tp.boot.annotation.TpController;
import com.cainiao.tp.boot.annotation.access.TpBucAccess;
import com.cainiao.tp.boot.annotation.access.TpMoziAccess;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.StationIncentiveRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.XnStationIncentiveRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.station.heavy.StationAssessmentVO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.station.heavy.StationIncentiveVO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.station.light.XnStationIncentiveCardVO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.station.light.XnStationIncentiveStatsVO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.station.StationIncentiveQueryParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.station.XnStaIncentiveQueryParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.heavy.StationAssessmentDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.heavy.StationIncentiveDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.light.XnStaPracticeIncentiveDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.light.XnStaPracticeIncentiveStatsDetailDTO;
import com.cainiao.tp.nm.plan.api.policy.application.service.station.StationIncentiveAppService;
import com.cainiao.tp.nm.plan.api.policy.application.service.station.XnStaIncentiveAppService;
import com.cainiao.tp.nm.plan.policy.adaptor.component.station.StationPermissionCheck;
import com.cainiao.tp.nm.plan.policy.adaptor.convert.StationIncentiveConvert;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;

/**
 * @code date 2025年08月01日 11:47
 * @code desc:null
 */
@Slf4j
@TpBucAccess
@TpController
@TpMoziAccess
@RequestMapping("/station/incentive")
public class StationNewBuildIncentiveController {

    @Resource
    private StationIncentiveAppService incentiveAppService;
    @Resource
    private XnStaIncentiveAppService xnStaIncentiveAppService;

    @GetMapping("/queryBillDetail")
    @StationPermissionCheck
    public CnRestResult<StationIncentiveVO> queryStationNewBuildBillDetail(StationIncentiveRequest request) {
        AssertUtil.notNull(request,"请求参数不能为空");
        AssertUtil.notNull(request.getStationId(), "站点ID不能为空");
        AssertUtil.notNull(request.getQuarter(), "查询财年不能为空");
        StationIncentiveQueryParam queryParam = buildIncentiveQueryParam(request);
        StationIncentiveDTO incentiveDTO = incentiveAppService.queryStationIncentive(queryParam);
        return CnRestResult.succeed(StationIncentiveConvert.stationIncentiveVO(incentiveDTO));
    }


    @GetMapping("/queryAssessmentDetail")
    @StationPermissionCheck
    public CnRestResult<StationAssessmentVO> queryStationIncentiveAssessment(StationIncentiveRequest request) {
        AssertUtil.notNull(request,"请求参数不能为空");
        AssertUtil.notNull(request.getStationId(), "站点ID不能为空");
        AssertUtil.notNull(request.getQuarter(), "查询财年不能为空");
        AssertUtil.notNull(request.getPeriod(), "查询账单不能为空");
        StationIncentiveQueryParam queryParam = buildIncentiveQueryParam(request);
        StationAssessmentDTO assessmentDTO = incentiveAppService.queryStationAssessment(queryParam);
        return CnRestResult.succeed(StationIncentiveConvert.convertAssessmentVO(assessmentDTO));
    }

    @GetMapping("/queryXnStaIncentiveBaseInfo")
    @StationPermissionCheck
    public CnRestResult<XnStationIncentiveCardVO> queryXnStaIncentiveBaseInfo(XnStationIncentiveRequest request) {
        AssertUtil.notNull(request,"请求参数不能为空");
        AssertUtil.notNull(request.getStationId(), "站点ID不能为空");
        AssertUtil.notNull(request.getStatsMonth(), "查询统计月份不能为空");
        request.setStatsMonth(request.getStatsMonth().replace("-", ""));
        XnStaIncentiveQueryParam queryParam = buildXnIncentiveQueryParam(request);
        XnStaPracticeIncentiveDTO baseDTO = xnStaIncentiveAppService.queryStaPracticeIncentiveBaseInfo(queryParam);
        return CnRestResult.succeed(StationIncentiveConvert.convertXnIncentiveVO(baseDTO));
    }

    @GetMapping("/queryXnStaIncentiveStatsDetail")
    @StationPermissionCheck
    public CnRestResult<XnStationIncentiveStatsVO> queryXnStaIncentiveStatsDetail(XnStationIncentiveRequest request) {
        AssertUtil.notNull(request,"请求参数不能为空");
        AssertUtil.notNull(request.getStationId(), "站点ID不能为空");
        AssertUtil.notNull(request.getStatsMonth(), "查询统计月份不能为空");
        request.setStatsMonth(request.getStatsMonth().replace("-", ""));
        XnStaIncentiveQueryParam queryParam = buildXnIncentiveQueryParam(request);
        XnStaPracticeIncentiveStatsDetailDTO statsDetailDTO = xnStaIncentiveAppService.queryStaPracticeIncentiveStatsDetail(queryParam);
        return CnRestResult.succeed(StationIncentiveConvert.convertXnIncentiveStatsVO(statsDetailDTO));
    }

    private StationIncentiveQueryParam buildIncentiveQueryParam(StationIncentiveRequest request) {
        StationIncentiveQueryParam queryParam = new StationIncentiveQueryParam();
        queryParam.setStationId(request.getStationId());
        queryParam.setQuarter(request.getQuarter());
        queryParam.setPeriod(request.getPeriod());
        queryParam.setSource(request.getSource());
        return queryParam;
    }

    private XnStaIncentiveQueryParam buildXnIncentiveQueryParam(XnStationIncentiveRequest request) {
        XnStaIncentiveQueryParam queryParam = new XnStaIncentiveQueryParam();
        queryParam.setStatsMonth(request.getStatsMonth());
        queryParam.setStationId(request.getStationId());
        return queryParam;
    }

}
