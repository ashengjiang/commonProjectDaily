package com.cainiao.tp.nm.plan.policy.application.component;

import com.cainiao.tp.nm.plan.policy.application.component.export.ExportComponent;
import com.cainiao.tp.nm.plan.policy.application.component.export.impl.DefaultExportComponentImpl;
import com.cainiao.tp.nm.plan.policy.application.component.imports.ImportManager;
import com.cainiao.tp.nm.plan.policy.application.component.imports.dto.ImportResultDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.ExcelData;
import com.cainiao.tp.nm.plan.api.policy.application.dto.ExportResultDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.DefaultExportDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

@Component
public class ExportAndImportComponentFactory {

    @Autowired(required = false)
    private List<ExportComponent> exportComponentsList;

    @Resource
    private ImportManager importManager;


    /**
     * 导入
     *
     * @param fileKey  文件key
     * @param code code
     * @return return
     */
    public ImportResultDTO executeImportComponent(String fileKey, String code) {
       return importManager.executeImportByOss(fileKey, code);
    }


    /**
     * 导出
     *
     * @param req  req
     * @param code code
     * @return return
     */
    public ExportResultDTO executeExport(Object req, String code) {
        return getExportComponent(code).executeExport(req);
    }

    /**
     * 导出
     *
     * @param dataSource     req
     * @param exportTempCode 模版code
     * @return return
     */
    public ExportResultDTO executeDefaultExport(List<List<ExcelData>> dataSource, String exportTempCode) {
        DefaultExportDTO req = new DefaultExportDTO();
        req.setDataSource(dataSource);
        req.setExportTempCode(exportTempCode);
        return getExportComponent(DefaultExportComponentImpl.CODE).executeExport(req);
    }

    /**
     * 导出
     *
     * @param req req
     * @return return
     */
    public ExportResultDTO executeDefaultExport(DefaultExportDTO req) {
        return getExportComponent(DefaultExportComponentImpl.CODE).executeExport(req);
    }


    private ExportComponent getExportComponent(String code) {
        ExportComponent exportComponent = exportComponentsList.stream().filter(component -> component.getCode().equals(code)).findFirst().orElse(null);
        if (null == exportComponent) {
            throw new RuntimeException("未找到对应的导出组件");
        } else {
            return exportComponent;
        }
    }

}
