package com.cainiao.tp.nm.plan.policy.adaptor.convert;

import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.tp.boot.utils.TpWebUtil;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.LaunchPlanCreateRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.PolicyTemplateCreateRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.PolicyTemplateDeleteRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.IncentiveContentRecordVO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.PolicyRuleRecordVO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.PolicyTemplateRecordVO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.SelectContentVO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.incentiveplan.IncentiveExpenseItemVO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyTemplateDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.*;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.limit.IncentiveResultLimitDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.limit.OptionLimitDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.launchplan.LaunchPlanDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.launchplan.ListItemLaunchDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.launchplan.ListLaunchDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyTemplateCreateParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyTemplateDeleteParam;
import com.cainiao.tp.nm.plan.api.policy.common.constants.*;
import com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils;
import com.cainiao.tps.control.org.client.constant.newDept.TpsOrgNewDeptLevelEnum;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @Date 2025/6/3 13:31
 * @code desc: 政策模板转换
 */
@Component
public class PolicyTemplateAdaptorConvert {

    /**
     * 政策模板创建参数
     * @param createRequest 政策模板创建参数
     * @param incentivePlanDTOList 激励方案
     * @return
     */
    public static PolicyTemplateCreateParam convertCreateParam(PolicyTemplateCreateRequest createRequest,List<IncentivePlanDTO> incentivePlanDTOList){
        if (createRequest == null) {
            return null;
        }
        AssertUtil.isTrue(CollectionUtils.isNotEmpty(incentivePlanDTOList), "基础激励方案费用项code数量不足");
        boolean hasBasic = incentivePlanDTOList.stream().anyMatch(incentivePlan -> IncentivePlanTypeEnum.BASIC.getType().equals(incentivePlan.getIncentivePlanType()));
        AssertUtil.isTrue(hasBasic, "缺少基础激励方案费用项code");
        boolean hasFlexible = incentivePlanDTOList.stream().anyMatch(incentivePlan -> IncentivePlanTypeEnum.FLEXIBLE.getType().equals(incentivePlan.getIncentivePlanType()));
        AssertUtil.isTrue(hasFlexible, "缺少灵活激励方案费用项code");
        AbstractOperation operation = TpWebUtil.getWebOperation();
        PolicyTemplateCreateParam createParam = new PolicyTemplateCreateParam();
        BeanUtils.copyProperties(createRequest, createParam);
        createParam.setStartTimeStr(createRequest.getStartTimeStr());
        createParam.setEndTimeStr(createRequest.getEndTimeStr());
        // 激励方案
        LaunchPlanCreateRequest launchPlanCreateRequest = createRequest.getLaunchPlan();
        createParam.setIncentivePlanList(incentivePlanDTOList);
        // 投放方案
        LaunchPlanDTO launchPlanDTO = LaunchPlanAdaptorConvert.createRequestToDto(launchPlanCreateRequest, createParam.getCustomType());
        createParam.setLaunchPlan(launchPlanDTO);

        createParam.setOperatorId(Long.valueOf(operation.getOperatorId()));
        return createParam;
    }

    public static List<PolicyTemplateRecordVO> convertVO(List<PolicyTemplateDTO> policyTemplateDTOList) {
        if (CollectionUtils.isEmpty(policyTemplateDTOList)) {
            return new ArrayList<>();
        }
        return policyTemplateDTOList.stream()
            .map(PolicyTemplateAdaptorConvert::convertVO)
            .filter(Objects::nonNull)
            .collect(Collectors.toList());
    }

    public static PolicyTemplateRecordVO convertVO(PolicyTemplateDTO policyTemplateDTO) {
        if (policyTemplateDTO == null) {
            return null;
        }
        PolicyTemplateRecordVO policyTemplateRecordVO = new PolicyTemplateRecordVO();
        policyTemplateRecordVO.setId(policyTemplateDTO.getId());
        policyTemplateRecordVO.setTemplateName(policyTemplateDTO.getTemplateName());
        // 客户类型
        policyTemplateRecordVO.setCustomType(policyTemplateDTO.getCustomType());
        policyTemplateRecordVO.setCustomTypeDesc(PolicyCustomTypeEnum.getDescBy(policyTemplateDTO.getCustomType()));
        // 业务类型
        policyTemplateRecordVO.setBizType(policyTemplateDTO.getBizType());
        policyTemplateRecordVO.setBizTypeDesc(PolicyBizTypeEnum.getDescBy(policyTemplateDTO.getBizType()));
        policyTemplateRecordVO.setGmtCreateStr(DateUtils.localDateTimeToYmdhmsStr(policyTemplateDTO.getGmtCreate()));
        // 周期
        String startTimeStr = policyTemplateDTO.getStartTimeStr();
        String endTimeStr = policyTemplateDTO.getEndTimeStr();
        LocalDateTime startTime = DateUtils.toLocalDateTimeYmdStart(startTimeStr);
        LocalDateTime endTime = DateUtils.toLocalDateTimeYmdEnd(endTimeStr);
        policyTemplateRecordVO.setPeriod(DateUtils.periodFormat(startTime, endTime));
        // 状态
        PolicyTemplateDurationStatusEnum durationStatusEnum = PolicyTemplateDurationStatusEnum.getByRangeTime(policyTemplateDTO.getStartTime(), policyTemplateDTO.getEndTime());
        if (durationStatusEnum != null) {
            policyTemplateRecordVO.setDurationStatusStr(durationStatusEnum.getDesc());
            policyTemplateRecordVO.setDurationStatus(durationStatusEnum.getCode());
        }
        // 政策规则
        fillPolicyRule(policyTemplateRecordVO, policyTemplateDTO);
        // 费用项
        fillExpenseItem(policyTemplateRecordVO, policyTemplateDTO);
        // 圈选内容
        fillSelectContent(policyTemplateRecordVO, policyTemplateDTO);
        return policyTemplateRecordVO;
    }

    /**
     * 填充圈选内容
     * @param policyTemplateRecordVO 政策模板vo
     * @param policyTemplateDTO 政策模板dto
     */
    private static void fillSelectContent(PolicyTemplateRecordVO policyTemplateRecordVO, PolicyTemplateDTO policyTemplateDTO){
        SelectContentVO selectContentVO = new SelectContentVO();
        String selectContent = StringUtils.EMPTY;
        LaunchPlanDTO launchPlan = policyTemplateDTO.getLaunchPlan();
        LaunchPlanTypeEnum planTypeEnum = LaunchPlanTypeEnum.getByType(launchPlan.getLaunchType());
        if (planTypeEnum == null) {
            return;
        }
        selectContentVO.setLaunchType(planTypeEnum.getType());
        switch (planTypeEnum){
            case RULE:
                boolean national = launchPlan.getRuleLaunch().getAreaRuleLaunch().isNational();
                selectContent = national ? "全国" : selectContent;
                selectContentVO.setLaunchArea(selectContent);
                break;
            case LIST:
                String tagCodePrefix = "签约协议code：";
                ListLaunchDTO listLaunch = launchPlan.getListLaunch();
                List<String> protocolCodeList = listLaunch.getItemLaunch().stream().map(ListItemLaunchDTO::getAttrValue).collect(Collectors.toList());
                selectContentVO.setTagCodePrefix(tagCodePrefix);
                selectContentVO.setProtocolCodeList(protocolCodeList);
                break;
            default:
                break;
        }
        policyTemplateRecordVO.setSelectContentVO(selectContentVO);
    }
    private static void fillPolicyRule(PolicyTemplateRecordVO policyTemplateRecordVO, PolicyTemplateDTO policyTemplateDTO) {
        // 激励方案
        List<IncentivePlanDTO> incentivePlanList = policyTemplateDTO.getIncentivePlanList();
        // 线上化跳过
        if (breakPolicyRuleList(incentivePlanList, policyTemplateDTO)) {
            return;
        }
        List<PolicyRuleRecordVO> policyRuleList = incentivePlanList.stream().map(incentivePlan -> {
            PolicyRuleRecordVO policyRuleRecordVO = new PolicyRuleRecordVO();
            policyRuleRecordVO.setPlanTitle(IncentivePlanTypeEnum.getDescByType(incentivePlan.getIncentivePlanType()));
            policyRuleRecordVO.setPlanName(incentivePlan.getPlanName());
            policyRuleRecordVO.setIncentivePlanCode(incentivePlan.getIncentivePlanCode());
            policyRuleRecordVO.setIncentivePlanType(incentivePlan.getIncentivePlanType());
            IncentivePlanContentDTO content = incentivePlan.getContent();
            List<IncentiveContentRecordVO> contentRecordList = convertIncentivePlanContentList(content, incentivePlan.getIncentivePlanType());
            policyRuleRecordVO.setContentRecordList(contentRecordList);
            return policyRuleRecordVO;
        }).collect(Collectors.toList());
        policyTemplateRecordVO.setPolicyRuleList(policyRuleList);
    }

    /**
     * 填充激励费用项
     * @param policyTemplateRecordVO 政策模板vo
     * @param policyTemplateDTO 政策模板dto
     */
    private static void fillExpenseItem(PolicyTemplateRecordVO policyTemplateRecordVO, PolicyTemplateDTO policyTemplateDTO) {
        // 激励方案
        List<IncentivePlanDTO> incentivePlanList = policyTemplateDTO.getIncentivePlanList();
        List<IncentiveExpenseItemVO> expenseItemVOList = incentivePlanList.stream().map(incentivePlan -> {
            IncentiveExpenseItemVO policyRuleRecordVO = new IncentiveExpenseItemVO();
            policyRuleRecordVO.setExpenseItemName(incentivePlan.getPlanName());
            policyRuleRecordVO.setExpenseItemCode(incentivePlan.getIncentivePlanCode());
            return policyRuleRecordVO;
        }).collect(Collectors.toList());
        policyTemplateRecordVO.setIncentiveExpenseItemList(expenseItemVOList);
    }

    /**
     * 是否需要跳过激励规则编排
     * @param incentivePlanList 激励方案
     * @param profile 政策模板
     * @return 是否需要跳过
     */
    private static boolean breakPolicyRuleList(List<IncentivePlanDTO> incentivePlanList, PolicyTemplateDTO profile) {
        return CollectionUtils.isEmpty(incentivePlanList) || PolicyBizTypeEnum.DIGITIZATION.getType().equals(profile.getBizType());
    }
    /**
     * 政策规则
     * @param incentivePlanContent 激励方案内容
     * @param incentivePlanType 激励方案类型
     * @return 激励方案内容
     */
    private static List<IncentiveContentRecordVO> convertIncentivePlanContentList(IncentivePlanContentDTO incentivePlanContent,String incentivePlanType) {
        if (incentivePlanContent == null) {
            return new ArrayList<>();
        }

        if (IncentivePlanTypeEnum.BASIC.getType().equals(incentivePlanType)){
            // 基础激励
            return convertBasicIncentivePlanContent(incentivePlanContent);
        }
        // 灵活激励
        return convertFlexibleIncentivePlanContent(incentivePlanContent);
    }

    /**
     * 灵活激励
     *
     * @param incentivePlanContent 激励方案内容
     * @return contentRecordList 激励方案内容
     */
    private static List<IncentiveContentRecordVO> convertFlexibleIncentivePlanContent(IncentivePlanContentDTO incentivePlanContent) {
        if (incentivePlanContent == null || CollectionUtils.isEmpty(incentivePlanContent.getCoefficient())) {
            return new ArrayList<>();
        }
        IncentivePlanCoefficientContentDTO contentDTO = incentivePlanContent.getCoefficient().get(0);
        if (contentDTO == null || contentDTO.getFrame() == null || CollectionUtils.isEmpty(contentDTO.getFrame().getChildren())) {
            return new ArrayList<>();
        }
        List<IncentivePlanFrameDTO> children = contentDTO.getFrame().getChildren();
        return children.stream()
            .filter(Objects::nonNull)
            .filter(incentivePlanFrameDTO -> incentivePlanFrameDTO.getFactorResult() != null && incentivePlanFrameDTO.getResult() != null)
            .filter(incentivePlanFrameDTO -> CollectionUtils.isNotEmpty(incentivePlanFrameDTO.getResult())
                && incentivePlanFrameDTO.getResult().get(0) != null)
            .map(incentivePlanFrameDTO -> {
                IncentivePlanFactorResultDTO factorResult = incentivePlanFrameDTO.getFactorResult();
                String stationDesc = IncentivePlanStationTypeEnum.getDescBy(factorResult.getFixedVal());
                IncentivePlanResultDTO incentivePlanResultDTO = incentivePlanFrameDTO.getResult().get(0);
                if (incentivePlanResultDTO == null || incentivePlanResultDTO.getResultLimit() == null) {
                    return null;
                }
                OptionLimitDTO optionLimit = incentivePlanResultDTO.getResultLimit().getOptionLimit();
                if (optionLimit == null || CollectionUtils.isEmpty(optionLimit.getOptionList())) {
                    return null;
                }
                IncentiveContentRecordVO incentiveContentRecordVO = new IncentiveContentRecordVO();
                incentiveContentRecordVO.setIncentiveContent(buildIncentiveContent(stationDesc, optionLimit.getOptionList()));
                incentiveContentRecordVO.setIncentivePeriod("激励周期: 6");
                return incentiveContentRecordVO;
            }).filter(Objects::nonNull).collect(Collectors.toList());
    }


    /**
     * 构建激励内容
     * @param stationDesc 站点描述
     * @param incentiveValueOptionList 激励值选项列表
     * @return incentiveContent 激励内容
     */
    private static String buildIncentiveContent(String stationDesc,List<String> incentiveValueOptionList){
        if (CollectionUtils.isEmpty(incentiveValueOptionList) || StringUtils.isBlank(stationDesc)) {
            return StringUtils.EMPTY;
        }
        return stationDesc + ": " + String.join("/", incentiveValueOptionList);
    }


    /**
     * 基础激励
     * @param incentivePlanContent 激励方案内容
     * @return 激励方案内容
     */
    private static List<IncentiveContentRecordVO> convertBasicIncentivePlanContent(IncentivePlanContentDTO incentivePlanContent) {
        if (incentivePlanContent == null) {
            return new ArrayList<>();
        }
        List<IncentiveContentRecordVO> incentiveContentRecordList = new ArrayList<>();
        // 激励方案内容
        IncentiveContentRecordVO incentiveContentRecordVO = new IncentiveContentRecordVO();
        List<IncentivePlanCoefficientContentDTO> coefficient = incentivePlanContent.getCoefficient();
        if (CollectionUtils.isEmpty(coefficient) || coefficient.get(0) == null ) {
            return incentiveContentRecordList;
        }
        IncentivePlanFrameDTO frame = coefficient.get(0).getFrame();
        if (coefficient.get(0).getFrame() == null || CollectionUtils.isEmpty(frame.getResult()) || frame.getResult().get(0) == null) {
            return incentiveContentRecordList;
        }
        String val = frame.getResult().get(0).getVal();
        if(StringUtils.isBlank(val)){
            IncentiveResultLimitDTO resultLimit = frame.getResult().get(0).getResultLimit();
            if(null != resultLimit && null != resultLimit.getOptionLimit() && CollectionUtils.isNotEmpty(resultLimit.getOptionLimit().getOptionList())){
                val = StringUtils.join(resultLimit.getOptionLimit().getOptionList(), "/");
            }
        }
        incentiveContentRecordVO.setIncentiveContent("基础激励: " + val);
        // 激励周期默认为 6
        incentiveContentRecordVO.setIncentivePeriod("激励周期: 6");
        incentiveContentRecordList.add(incentiveContentRecordVO);
        return incentiveContentRecordList;
    }

    public static PolicyTemplateDeleteParam convertDeleteParam(PolicyTemplateDeleteRequest request){
        if (request == null) {
            return null;
        }
        AbstractOperation operation = TpWebUtil.getWebOperation();
        PolicyTemplateDeleteParam param = new PolicyTemplateDeleteParam();
        param.setTemplateId(request.getId());
        param.setOperatorId(Long.valueOf(operation.getOperatorId()));
        Map<String, String> featureMap = new HashMap<>();
        featureMap.put(PolicyFeatureConstants.DELETE_REASON, request.getDeleteReason());
        param.setFeatureMap(featureMap);
        return param;
    }

    public static void fillOperateList(PolicyTemplateRecordVO recordVO,String highestLevelCode) {
        List<String> operateCodeList = new ArrayList<>();
        recordVO.setOperateCodeList(operateCodeList);
        if (TpsOrgNewDeptLevelEnum.CN_LEVEL.getCode().equals(highestLevelCode)) {
            operateCodeList.add(PolicyTemplateOperateEnum.POLICY_PANEL.getCode());
            operateCodeList.add(PolicyTemplateOperateEnum.DELETE.getCode());
            return;
        }
        if (TpsOrgNewDeptLevelEnum.RG_LEVEL.getCode().equals(highestLevelCode)) {
            operateCodeList.add(PolicyTemplateOperateEnum.REPORT.getCode());
        }
    }
}
