package com.cainiao.tp.nm.plan.policy.adaptor.convert;

import java.util.List;
import java.util.stream.Collectors;

import com.cainiao.tp.nm.plan.api.policy.application.dto.launchplan.ListItemLaunchDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.launchplan.ListLaunchDTO;
import org.apache.commons.collections4.CollectionUtils;

/**
 * @Date 2025/6/11 18:34
 */
public class ListLaunchAdaptorConvert {


    public static ListLaunchDTO tagListToDto(List<String> tagCodeList,String customType,String expressAttrCode){
        if (CollectionUtils.isEmpty(tagCodeList)) {
            return null;
        }
        ListLaunchDTO listLaunchDTO = new ListLaunchDTO();
        List<ListItemLaunchDTO> itemLaunch = tagCodeList.stream().map(tagCode ->{
            ListItemLaunchDTO listItemLaunchDTO = new ListItemLaunchDTO();
            listItemLaunchDTO.setType(customType);
            listItemLaunchDTO.setAttrCode(expressAttrCode);
            listItemLaunchDTO.setAttrValue(tagCode);
            return listItemLaunchDTO;
        }).collect(Collectors.toList());
        listLaunchDTO.setItemLaunch(itemLaunch);
        return listLaunchDTO;
    }
}
