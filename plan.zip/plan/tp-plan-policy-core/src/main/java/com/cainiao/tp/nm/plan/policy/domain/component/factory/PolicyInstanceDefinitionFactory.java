package com.cainiao.tp.nm.plan.policy.domain.component.factory;

import com.cainiao.tp.nm.plan.policy.domain.component.PolicyInstanceDefinition;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import java.util.Map;


@Slf4j
@Component
public class PolicyInstanceDefinitionFactory implements ApplicationContextAware, InitializingBean {

    private ApplicationContext applicationContext;

    final private Map<String, PolicyInstanceDefinition> priorityDecisionMap = Maps.newHashMap();

    @Override
    public void afterPropertiesSet() throws Exception {
        try {
            Map<String, PolicyInstanceDefinition> beanMap = applicationContext.getBeansOfType(PolicyInstanceDefinition.class);
            beanMap.values().forEach(
                    definition -> {
                        String key = definition.bizType();
                        if(StringUtils.isNotBlank(definition.customType())){
                            key += "_"  + definition.customType();
                        }
                        priorityDecisionMap.put(key, definition);
                    }
            );
        } catch (Exception e) {
            log.error("init policyInstanceDefinitionFactory failed", e);
            throw e;
        }
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    public PolicyInstanceDefinition getDefinition(String bizType, String customType) {
        String key = bizType;
        if(StringUtils.isNotBlank(customType)){
            key+= "_"  + customType;
        }
        return ObjectUtils.firstNonNull(priorityDecisionMap.get(key), priorityDecisionMap.get(bizType), priorityDecisionMap.get("default_default"));
    }
}
