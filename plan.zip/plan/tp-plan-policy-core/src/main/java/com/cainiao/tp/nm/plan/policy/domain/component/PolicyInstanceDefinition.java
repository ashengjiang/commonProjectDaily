package com.cainiao.tp.nm.plan.policy.domain.component;

import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyInstanceCreateParam;
import com.cainiao.tp.nm.plan.policy.domain.model.PolicyInstance;
import com.cainiao.tp.nm.plan.policy.domain.model.PolicyTemplate;

/**
 * @date: 2022-03-16
 * desc: 决策优先级
 */
public interface PolicyInstanceDefinition {

    /**
     * 业务类型
     */
    String bizType();

    /**
     * 客户类型
     */
    String customType();

    /**
     * 创建前校验
     * @return
     */
    void validCreate(PolicyTemplate template, PolicyInstanceCreateParam param);

    /**
     * 决策优先级
     * @return
     */
    void decisionPriority(PolicyTemplate template, PolicyInstance policyInstance);

}
