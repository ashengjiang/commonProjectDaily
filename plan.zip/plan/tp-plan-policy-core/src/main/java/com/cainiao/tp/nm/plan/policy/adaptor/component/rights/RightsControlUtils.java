package com.cainiao.tp.nm.plan.policy.adaptor.component.rights;

/**
 * @description 权限管控上下文工具类
 */
public class RightsControlUtils {

    private static final ThreadLocal<RightsControlContext> RIGHTS_CONTROL_CONTEXT = new ThreadLocal<>();

    protected static void setRightsControlContext(RightsControlContext context) {
        RIGHTS_CONTROL_CONTEXT.set(context);
    }

    public static RightsControlContext get(){
        return RIGHTS_CONTROL_CONTEXT.get();
    }

    protected static void clear(){
        RIGHTS_CONTROL_CONTEXT.remove();
    }
}
