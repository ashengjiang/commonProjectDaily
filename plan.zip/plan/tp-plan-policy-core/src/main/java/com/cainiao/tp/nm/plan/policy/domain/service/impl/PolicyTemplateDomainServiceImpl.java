package com.cainiao.tp.nm.plan.policy.domain.service.impl;

import com.cainiao.aladdin.exception.AladdinParamException;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.IncentivePlanDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyTemplateCreateParam;
import com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils;
import com.cainiao.tp.nm.plan.policy.domain.model.PolicyTemplate;
import com.cainiao.tp.nm.plan.policy.domain.model.valobj.incentiveplan.IncentivePlan;
import com.cainiao.tp.nm.plan.policy.domain.repository.PolicyTemplateRepository;
import com.cainiao.tp.nm.plan.policy.domain.service.PolicyTemplateDomainService;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @description: 政策模版领域服务
 * @date: 2025/3/10
 */
@Service
public class PolicyTemplateDomainServiceImpl implements PolicyTemplateDomainService {

    @Resource
    private PolicyTemplateRepository policyTemplateRepository;

    @Override
    public PolicyTemplate createTemplate(PolicyTemplateCreateParam param) {
        // 参数校验
        param.validate();
        LocalDateTime startTime = DateUtils.toLocalDateTimeYmdStart(param.getStartTimeStr());
        LocalDateTime endTime = DateUtils.addOrSubtractDays(DateUtils.toLocalDateTimeYmdStart(param.getEndTimeStr()), 1);

        // 历史模版校验
        List<PolicyTemplate> currentPolicyTemplates = policyTemplateRepository.get(param.getBizType(), param.getCustomType());
        if(CollectionUtils.isNotEmpty(currentPolicyTemplates)){
            Set<String> incentivePlanTypeSet = param.getIncentivePlanList().stream().map(IncentivePlanDTO::getIncentivePlanType).collect(Collectors.toSet());
            currentPolicyTemplates.stream()
                    .forEach(template ->{
                        Set<String> oldIncentivePlanTypeSet = template.getIncentivePlanList().stream().map(IncentivePlan::getIncentivePlanType).collect(Collectors.toSet());
                        if(template.getEndTime().compareTo(startTime)>0
                                && template.getStartTime().compareTo(endTime)<0
                                && !CollectionUtils.intersection(oldIncentivePlanTypeSet, incentivePlanTypeSet).isEmpty()){
                            throw new AladdinParamException("参数异常", "政策周期重叠");
                        }
                    });
        }

        // 创建模版
        PolicyTemplate policyTemplate = PolicyTemplate.create(param);

        return policyTemplate;
    }
}
