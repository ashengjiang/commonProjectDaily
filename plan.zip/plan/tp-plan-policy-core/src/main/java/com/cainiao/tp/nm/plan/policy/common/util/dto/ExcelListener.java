package com.cainiao.tp.nm.plan.policy.common.util.dto;




import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import com.alibaba.fastjson.JSON;

import java.util.ArrayList;
import java.util.List;


public class ExcelListener<T> extends AnalysisEventListener<T> {

    /**
     * 自定义用于暂时存储data。
     * 可以通过实例获取该值
     */
    private final List<T> getDataList = new ArrayList<>();

    /**
     * 通过 AnalysisContext 对象还可以获取当前 sheet，当前行等数据
     */
    @Override
    public void invoke(T object, AnalysisContext context) {
        //数据存储到list，供批量处理，或后续自己业务逻辑处理。
        getDataList.add(object);
        //根据业务自行 do something
        doSomething();
    }

    /**
     * 根据业务自行实现该方法
     */
    private void doSomething() {
    }

    @Override
    public void doAfterAllAnalysed(AnalysisContext context) {
//        getDataList.clear();
    }

    public List<T> getDataList() {
        return getDataList;
    }
}
