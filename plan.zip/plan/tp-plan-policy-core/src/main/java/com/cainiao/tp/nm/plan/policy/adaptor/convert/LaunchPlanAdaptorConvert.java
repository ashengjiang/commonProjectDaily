package com.cainiao.tp.nm.plan.policy.adaptor.convert;

import java.util.List;

import com.cainiao.aladdin.exception.AladdinParamException;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.LaunchPlanCreateRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.launchplan.AreaRuleLaunchVO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.launchplan.LaunchPlanDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.launchplan.ListLaunchDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.launchplan.RuleLaunchDTO;
import com.cainiao.tp.nm.plan.api.policy.common.constants.LaunchPlanTypeEnum;

/**
 * @Date 2025/6/11 18:27
 * @code desc: 投放方案转换
 */
public class LaunchPlanAdaptorConvert {

    public static LaunchPlanDTO createRequestToDto(LaunchPlanCreateRequest launchPlanCreateRequest,String customType) {
        if (launchPlanCreateRequest == null) {
            return null;
        }
        LaunchPlanDTO launchPlanDTO = new LaunchPlanDTO();

        String launchType = launchPlanCreateRequest.getLaunchType();
        AreaRuleLaunchVO areaRuleLaunch = launchPlanCreateRequest.getAreaRuleLaunch();
        List<String> tagCodeList = launchPlanCreateRequest.getTagCodeList();
        launchPlanDTO.setLaunchType(launchType);

        LaunchPlanTypeEnum launchPlanTypeEnum = LaunchPlanTypeEnum.getByType(launchType);
        if (launchPlanTypeEnum == null) {
            throw new AladdinParamException("launchType is invalid");
        }
        switch (launchPlanTypeEnum){
            case RULE:
                // 规则投放
                RuleLaunchDTO ruleLaunchDTO = RuleLaunchAdaptorConvert.voToDto(areaRuleLaunch);
                launchPlanDTO.setRuleLaunch(ruleLaunchDTO);
                break;
            case LIST:
                // 名单投放
                ListLaunchDTO listLaunchDTO = ListLaunchAdaptorConvert.tagListToDto(tagCodeList,customType,launchPlanCreateRequest.getEntityAttrCode());
                launchPlanDTO.setListLaunch(listLaunchDTO);
                break;
            default:
                break;
        }
        return launchPlanDTO;
    }

}
