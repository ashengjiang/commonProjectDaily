package com.cainiao.tp.nm.plan.policy.application.extension.definition;

import com.cainiao.tp.nm.plan.api.policy.application.dto.*;

public abstract class AbstractHistoryTableView  extends AbstractPolicyDashBoardView{

    public static final String CODE_DEFAULT="CODE_DEFAULT";


    @Override
    protected String getTempCode(PolicyTemplateDTO policyTemplateDTO){
        if (policyTemplateDTO == null) {
            return null;
        }
        PolicyViewRefTempDTO policyViewRefTempDTO = PolicyViewConfigHolder.getINSTANCE().getConfigMap().get(policyTemplateDTO.getId() + "");
        if(null==policyViewRefTempDTO){
            return null;
        }
        return policyViewRefTempDTO.getHistoryLogViewCode();
    }

    /**
     * 路由code
     * @return return
     */
    public abstract String  getCode();
}
