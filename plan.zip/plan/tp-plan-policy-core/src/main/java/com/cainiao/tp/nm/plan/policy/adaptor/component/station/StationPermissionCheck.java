package com.cainiao.tp.nm.plan.policy.adaptor.component.station;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @code date 2025年07月31日 10:25
 * @code desc:统一处理站点权限检测
 */
@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface StationPermissionCheck {
}
