package com.cainiao.tp.nm.plan.policy.common.util.query;


/**
 * 后置处理 */
public interface PostProcessHandler<T> {

    /**
     * 后置处理
     *
     * @param t 数据
     */
    void postProcess(T t);

}
