package com.cainiao.tp.nm.plan.policy.adaptor.rest;

import java.util.List;

import javax.annotation.Resource;

import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.aladdin.utils.Safes;
import com.cainiao.aladdin.validate.utils.ValidateUtil;
import com.cainiao.sutee.commons.base.model.Page;
import com.cainiao.sutee.commons.restful.result.CnRestResult;
import com.cainiao.tp.boot.annotation.TpController;
import com.cainiao.tp.boot.annotation.access.TpBucAccess;
import com.cainiao.tp.boot.annotation.access.TpMoziAccess;
import com.cainiao.tp.boot.utils.TpWebUtil;
import com.cainiao.tp.nm.plan.policy.adaptor.component.rights.RightsControl;
import com.cainiao.tp.nm.plan.policy.adaptor.convert.IncentivePlanAdaptorConvert;
import com.cainiao.tp.nm.plan.policy.adaptor.convert.PolicyMetaDataTypeAdaptorConvert;
import com.cainiao.tp.nm.plan.policy.adaptor.convert.PolicyTemplateAdaptorConvert;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.IncentiveExpenseItemQueryRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.PolicyTemplateCreateRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.PolicyTemplateDeleteRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.PolicyTemplateIncentiveQueryRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.PolicyTemplateQueryRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.PolicyTemplateIncentiveVO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.PolicyTemplateRecordVO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.incentiveplan.IncentiveExpenseItemVO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.incentiveplan.IncentivePlanVO;
import com.cainiao.tp.nm.plan.infra.port.policy.EmployeeRightsLoadManager;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyTemplateDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.PolicyIncentiveExpenseItemDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.IncentivePlanDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.IncentiveExpenseItemQueryParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.IncentivePlanQueryParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyTemplateCreateParam;
import com.cainiao.tp.nm.plan.api.policy.application.service.PolicyTemplateAppService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import com.cainiao.sutee.commons.restful.component.table.Table;

/**
 * @Date 2025/6/4 09:20
 * @code desc: 政策模板接口层
 */
@Slf4j
@TpBucAccess
@TpController
@TpMoziAccess(allowAliEmployee = true)
@RequestMapping("/policy/template")
public class PolicyTemplateController {


    @Resource
    private PolicyTemplateAppService policyTemplateAppService;

    @Resource
    private EmployeeRightsLoadManager employeeRightsLoadManager;

    /**
     * 创建政策模板
     * @param request 创建请求参数
     * @return void
     */
    @RightsControl(roleCodeArray = {"scale_policy_admin"})
    @PostMapping("/create")
    public CnRestResult<Void> create(@RequestBody PolicyTemplateCreateRequest request) {
        AbstractOperation operation = TpWebUtil.getWebOperation();
        request.validate();
        // 查询激励方案
        IncentivePlanQueryParam incentivePlanQueryParam = IncentivePlanAdaptorConvert.convertQueryParamByPolicyTemplate(request);
        List<IncentivePlanDTO> incentivePlanList = policyTemplateAppService.queryIncentivePlanList(incentivePlanQueryParam, operation);
        incentivePlanList = IncentivePlanAdaptorConvert.eliminateContent(Safes.of(incentivePlanList));
        // 创建政策模板
        PolicyTemplateCreateParam param = PolicyTemplateAdaptorConvert.convertCreateParam(request,incentivePlanList);
        policyTemplateAppService.create(param,operation);
        return CnRestResult.succeed();
    }

    /**
     * 查询政策模板列表
     * @param request 查询请求参数
     * @return 政策模板列表
     */
    @RightsControl(roleCodeArray = {"scale_policy_admin"})
    @GetMapping("/queryPolicyTemplateList")
    public CnRestResult<Table<PolicyTemplateRecordVO>> queryPolicyTemplateList(PolicyTemplateQueryRequest request) {
        AbstractOperation operation = TpWebUtil.getWebOperation();
        String highestLevelCode = employeeRightsLoadManager.getEmployeeHighestLevelCode(operation.getLongOperatorId());
        Page<PolicyTemplateDTO> policyTemplatePage = policyTemplateAppService.queryPolicyTemplateList(request, operation);
        return CnRestResult.succeed(Table.of(policyTemplatePage,policyTemplateDTO -> {
            PolicyTemplateRecordVO policyTemplateRecordVO = PolicyTemplateAdaptorConvert.convertVO(policyTemplateDTO);
            PolicyTemplateAdaptorConvert.fillOperateList(policyTemplateRecordVO,highestLevelCode);
            return policyTemplateRecordVO;
        }));

    }

    /**
     * 查询政策模板元数据
     * @return 政策模板元数据
     */
    @GetMapping("/queryMetaData")
    public CnRestResult<PolicyTemplateIncentiveVO> queryMetaData() {
        PolicyTemplateIncentiveVO incentiveVO = new PolicyTemplateIncentiveVO();
        // 客户类型
        incentiveVO.setCustomTypeList(PolicyMetaDataTypeAdaptorConvert.selectPolicyCustomTypeList());
        // 业务类型
        incentiveVO.setBizTypeList(PolicyMetaDataTypeAdaptorConvert.selectPolicyBizTypeList());
        // 投放方案类型
        incentiveVO.setLaunchTypeList(PolicyMetaDataTypeAdaptorConvert.selectLaunchTypeList());
        // 激励方案类型
        incentiveVO.setIncentivePlanTypeList(PolicyMetaDataTypeAdaptorConvert.selectIncentivePlanTypeList());
        return CnRestResult.succeed(incentiveVO);
    }

    /**
     * 查询激励方案
     * @return 激励方案
     */
    @RightsControl(roleCodeArray = {"scale_policy_admin"})
    @GetMapping("/queryIncentivePlanList")
    public CnRestResult<List<IncentivePlanVO>> queryIncentivePlanList(PolicyTemplateIncentiveQueryRequest request) {
        AbstractOperation operation = TpWebUtil.getWebOperation();
        if (request.getExpenseItemCode() == null){
            request.setExpenseItemCode(request.getOutIncentiveType());
        }
        ValidateUtil.validateAndThrow(request);
        IncentivePlanQueryParam queryParam = IncentivePlanAdaptorConvert.convertQueryParam(request);
        List<IncentivePlanDTO>  incentivePlanList = policyTemplateAppService.queryIncentivePlanList(queryParam,operation);
        return CnRestResult.succeed(IncentivePlanAdaptorConvert.dtoToVo(Safes.of(incentivePlanList)));
    }


    /**
     * 删除政策模板
     */
    @RightsControl(roleCodeArray = {"scale_policy_admin"})
    @PostMapping("/delete")
    public CnRestResult<Void> delete(@RequestBody PolicyTemplateDeleteRequest request) {
        AbstractOperation operation = TpWebUtil.getWebOperation();
        ValidateUtil.validateAndThrow(request);
        policyTemplateAppService.delete(PolicyTemplateAdaptorConvert.convertDeleteParam(request),operation);
        return CnRestResult.succeed();
    }

    /**
     * 查询激励费用项列表
     * @return 激励费用项列表
     */
    @RightsControl(roleCodeArray = {"scale_policy_admin"})
    @GetMapping("/queryIncentiveExpenseItemList")
    public CnRestResult<List<IncentiveExpenseItemVO>> queryIncentiveExpenseItemList(IncentiveExpenseItemQueryRequest request) {
        AbstractOperation operation = TpWebUtil.getWebOperation();
        ValidateUtil.validateAndThrow(request);
        IncentiveExpenseItemQueryParam queryParam = IncentivePlanAdaptorConvert.convertQueryParam(request);
        List<PolicyIncentiveExpenseItemDTO>  incentivePlanList = policyTemplateAppService.queryIncentiveExpenseItemList(queryParam,operation);
        return CnRestResult.succeed(IncentivePlanAdaptorConvert.dtoToExpenseItemVo(Safes.of(incentivePlanList)));
    }

    /**
     * 查询激励费用项详情
     * @return 激励费用项详情
     */
    @RightsControl(roleCodeArray = {"scale_policy_admin"})
    @GetMapping("/queryIncentiveExpenseItem")
    public CnRestResult<IncentivePlanVO> queryIncentiveExpenseItem(PolicyTemplateIncentiveQueryRequest request) {
        AbstractOperation operation = TpWebUtil.getWebOperation();
        ValidateUtil.validateAndThrow(request);
        IncentivePlanQueryParam queryParam = IncentivePlanAdaptorConvert.convertQueryParam(request);
        List<IncentivePlanDTO>  incentivePlanList = policyTemplateAppService.queryIncentivePlanList(queryParam,operation);
        if (CollectionUtils.isEmpty(incentivePlanList) || incentivePlanList.get(0) == null) {
            return CnRestResult.succeed();
        }
        return CnRestResult.succeed(IncentivePlanAdaptorConvert.dtoToVo(incentivePlanList.get(0)));
    }


}
