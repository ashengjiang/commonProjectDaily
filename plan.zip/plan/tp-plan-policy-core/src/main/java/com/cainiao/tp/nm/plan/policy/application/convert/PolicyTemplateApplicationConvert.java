package com.cainiao.tp.nm.plan.policy.application.convert;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.PolicyTemplateQueryRequest;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyTemplateDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.IncentivePlanDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.select.AreaSelectPlanDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.select.EntityAttrSelectPlanDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.select.SelectPlanDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.select.TagSelectPlanDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.launchplan.*;
import com.cainiao.tp.nm.plan.api.policy.application.dto.launchplan.*;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyTemplateQueryParam;
import com.cainiao.tp.nm.plan.policy.domain.model.PolicyTemplate;
import com.cainiao.tp.nm.plan.policy.domain.model.valobj.incentiveplan.IncentivePlan;
import com.cainiao.tp.nm.plan.policy.domain.model.valobj.launchplan.LaunchPlan;
import org.springframework.beans.BeanUtils;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @Date 2025/6/4 17:24
 */
public class PolicyTemplateApplicationConvert {

    public static PolicyTemplateDTO modelToDto(PolicyTemplate policyTemplate){
        if (policyTemplate == null) {
            return null;
        }
        PolicyTemplateDTO policyTemplateDTO = new PolicyTemplateDTO();
        BeanUtils.copyProperties(policyTemplate, policyTemplateDTO);

        LaunchPlanDTO launchPlan = JSONObject.parseObject(JSONObject.toJSONString(policyTemplate.getLaunchPlan()), LaunchPlanDTO.class);
        List<IncentivePlanDTO> incentivePlanList = JSONArray.parseArray(JSONArray.toJSONString(policyTemplate.getIncentivePlanList()), IncentivePlanDTO.class);

        policyTemplateDTO.setLaunchPlan(launchPlan);
        policyTemplateDTO.setIncentivePlanList(incentivePlanList);
        return policyTemplateDTO;
    }

    public static PolicyTemplate dtoToModel(PolicyTemplateDTO policyTemplateDTO){
        if (policyTemplateDTO == null) {
            return null;
        }
        LaunchPlan launchPlan = JSONObject.parseObject(JSONObject.toJSONString(policyTemplateDTO.getLaunchPlan()), LaunchPlan.class);
        List<IncentivePlan> incentivePlanList = JSONArray.parseArray(JSONArray.toJSONString(policyTemplateDTO.getIncentivePlanList()), IncentivePlan.class);

        return PolicyTemplate.builder()
            .id(policyTemplateDTO.getId())
            .templateName(policyTemplateDTO.getTemplateName())
            .customType(policyTemplateDTO.getCustomType())
            .bizType(policyTemplateDTO.getBizType())
            .startTime(policyTemplateDTO.getStartTime())
            .endTime(policyTemplateDTO.getEndTime())
            .status(policyTemplateDTO.getStatus())
            .version(policyTemplateDTO.getVersion())
            .lastOperatorId(policyTemplateDTO.getLastOperatorId())
            .launchPlan(launchPlan)
            .incentivePlanList(incentivePlanList)
            .featureMap(policyTemplateDTO.getFeatureMap())
            .build();
    }

    public static PolicyTemplateQueryParam queryParamConvert(PolicyTemplateQueryRequest request){
        if (request == null) {
            return null;
        }
        PolicyTemplateQueryParam queryParam = new PolicyTemplateQueryParam();
        queryParam.setDurationStatus(request.getDurationStatus());
        queryParam.setTemplateName(request.getTemplateName());
        queryParam.setBizType(request.getBizType());
        queryParam.setPageIndex(request.getPageIndex());
        queryParam.setPageSize(request.getPageSize());
        return queryParam;
    }

    public static SelectPlanDTO dtoToModel(LaunchPlanDTO launchPlanDTO){
        SelectPlanDTO selectPlan = new SelectPlanDTO();
        RuleLaunchDTO ruleLaunch = launchPlanDTO.getRuleLaunch();
        if(null != ruleLaunch){
            AreaRuleLaunchDTO areaRuleLaunch = ruleLaunch.getAreaRuleLaunch();
            if(null != areaRuleLaunch){
                AreaSelectPlanDTO areaSelectPlan = new AreaSelectPlanDTO();
                areaSelectPlan.setNational(areaRuleLaunch.isNational());
                areaSelectPlan.setProvinceCodeList(areaRuleLaunch.getProvinceCodeList());
                areaSelectPlan.setCityCodeList(areaRuleLaunch.getCityCodeList());
                areaSelectPlan.setDistrictCodeList(areaRuleLaunch.getDistrictCodeList());
                selectPlan.setAreaSelectPlan(areaSelectPlan);
            }

            TagRuleLaunchDTO tagRuleLaunch = ruleLaunch.getTagRuleLaunch();
            if(null != tagRuleLaunch){
                TagSelectPlanDTO tagSelectPlan = new TagSelectPlanDTO();
                tagSelectPlan.setTagCodeList(tagRuleLaunch.getTagCodeList());
                selectPlan.setTagSelectPlan(tagSelectPlan);
            }
        }

        ListLaunchDTO listLaunch = launchPlanDTO.getListLaunch();
        if(null != listLaunch && null != listLaunch.getItemLaunch()){
            selectPlan.setAttrSelectPlanList(listLaunch.getItemLaunch().stream().map(item -> {
                EntityAttrSelectPlanDTO attrSelectPlan = new EntityAttrSelectPlanDTO();
                attrSelectPlan.setType(item.getType());
                attrSelectPlan.setAttrCode(item.getAttrCode());
                attrSelectPlan.setAttrValue(item.getAttrValue());
                return attrSelectPlan;
            }).collect(Collectors.toList()));
        }
        return selectPlan;
    }


}
