package com.cainiao.tp.nm.plan.policy.adaptor.schedulerx;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.schedulerx.worker.domain.JobContext;
import com.alibaba.schedulerx.worker.processor.JavaProcessor;
import com.alibaba.schedulerx.worker.processor.ProcessResult;
import com.cainiao.aladdin.log.AladdinMapLog;
import com.cainiao.aladdin.log.BizType;
import com.cainiao.aladdin.log.utils.AladdinLogUtil;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.NewStaPerformSubsidySatisfyTouchJobDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.NewStaPerformSubsidyConfigDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.NewStaPerformSubsidySatisfyTouchParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.NewStaPerformNextLadderDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.NewStaPerformSubsidyDataDTO;
import com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyConfigManager;
import com.cainiao.tp.nm.plan.infra.port.policy.TgManager;
import com.cainiao.tp.nm.plan.infra.port.policy.TpPushStationMessageManager;
import com.cainiao.tp.nm.plan.policy.application.convert.NewStaPerformSubsidyConvert;
import com.taobao.eagleeye.EagleEye;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.List;

/**
 * @date: 2022/08/05
 * 新站实操激励，给满足激励条件的站点 下发触达消息
 */
@Slf4j
@Component
public class NewStaPerformSubsidySatisfyTouchJob extends JavaProcessor {

    @Resource
    private TgManager tgManager;
    @Resource
    private PolicyConfigManager policyConfigManager;
    @Resource
    private TpPushStationMessageManager tpPushStationMessageManager;

    @Override
    public ProcessResult process(JobContext jobContext) throws Exception {
        String traceId = EagleEye.generateTraceId(null);
        EagleEye.startTrace(traceId, "schedulerx", EagleEye.TYPE_CUSTOM_TRACE);
        NewStaPerformSubsidyConfigDTO subsidyConfig = policyConfigManager.getNewStaPerformSubsidyConfig();
        String goToUrl = policyConfigManager.getNewStaPerformSubsidyPopConfig().getGoToUrl();

        // 单个站点执行，调试
        String params = jobContext.getJobParameters();
        NewStaPerformSubsidySatisfyTouchJobDTO jobDTO = JSONObject.parseObject(params, NewStaPerformSubsidySatisfyTouchJobDTO.class);

        NewStaPerformSubsidySatisfyTouchParam subsidyParam = new NewStaPerformSubsidySatisfyTouchParam();
        if(StringUtils.isNotBlank(jobDTO.getStationId())){
            subsidyParam.setStationId(jobDTO.getStationId());
        }
        subsidyParam.setStatsMonth(DateUtils.toDateStr(LocalDateTime.now(), "yyyyMM"));
        subsidyParam.setPageSize(jobDTO.getPageSize());

        int maxLoop = jobDTO.getMaxLoop();
        int pageIndex = jobDTO.getPageIndex();
        while (pageIndex < maxLoop) {
            AladdinMapLog mapLog = AladdinLogUtil.newMapLog("NewStaPerformSubsidyTouchJob.process", BizType.DEFAULT);
            mapLog.addContext("pageIndex", pageIndex);

            try {
                subsidyParam.setPageNum(pageIndex);
                List<NewStaPerformSubsidyDataDTO> subsidyDataDTOS = tgManager.getListData(subsidyParam);
                if (CollectionUtils.isEmpty(subsidyDataDTOS)) {
                    break;
                }

                subsidyDataDTOS.forEach(data -> {
                    sendSatisfyPopup(data, subsidyConfig, goToUrl);
                });
                AladdinLogUtil.log(log, mapLog);

                if(subsidyDataDTOS.size() < jobDTO.getPageSize()){
                    break;
                }
                pageIndex++;
            } catch (Exception ex) {
                AladdinLogUtil.log(log, ex, mapLog);
                return new ProcessResult(false);
            }
        }

        return new ProcessResult(true);
    }

    private void sendSatisfyPopup(NewStaPerformSubsidyDataDTO subsidyData, NewStaPerformSubsidyConfigDTO subsidyConfig, String goToUrl){
        AladdinMapLog mapLog = AladdinLogUtil.newMapLog("NewStaPerformSubsidyTouchJob.sendSatisfyPopup", BizType.DEFAULT);
        try {
            Long stationId = Long.valueOf(subsidyData.getStationId());
            NewStaPerformNextLadderDTO nextLadderDTO = NewStaPerformSubsidyConvert.buildNextLadder(subsidyData, subsidyConfig);
            tpPushStationMessageManager.sendNewStaPerformSubsidySatisfyPopup(stationId, nextLadderDTO, goToUrl);
            mapLog.addParam("stationId", stationId);
            mapLog.addParam("nextLadder", nextLadderDTO);
            AladdinLogUtil.log(log, mapLog);
        } catch (Exception e) {
            AladdinLogUtil.log(log, e, mapLog);
        }
    }
}
