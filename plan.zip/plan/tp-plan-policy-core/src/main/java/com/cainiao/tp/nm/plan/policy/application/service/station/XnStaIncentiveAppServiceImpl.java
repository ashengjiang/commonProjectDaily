package com.cainiao.tp.nm.plan.policy.application.service.station;

import com.cainiao.aladdin.utils.Safes;
import com.cainiao.aladdin.validate.utils.ValidateUtil;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.XnStaIncentiveBillParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.XnStaOptCntStatsParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.station.XnStaIncentiveQueryParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.StationIncentiveBillDetailDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.XnStationOptCntStatsDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.light.XnStaPracticeIncentiveDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.light.XnStaPracticeIncentiveStatsDetailDTO;
import com.cainiao.tp.nm.plan.api.policy.application.service.station.XnStaIncentiveAppService;
import com.cainiao.tp.nm.plan.api.policy.common.constants.StationModeEnum;
import com.cainiao.tp.nm.plan.infra.port.policy.CacheManager;
import com.cainiao.tp.nm.plan.infra.port.policy.TgManager;
import com.cainiao.tp.nm.plan.policy.application.convert.XnStaIncentivePageDataConvert;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;

import static com.cainiao.tp.nm.plan.api.policy.common.constants.StationCommonConstants.ONE_DAY_EXPIRE;
import static com.cainiao.tp.nm.plan.api.policy.common.constants.StationCommonConstants.XN_STA_OPERATION_CARD_CACHE_KEY;
import static com.cainiao.tp.nm.plan.api.policy.common.constants.StationCommonConstants.XN_STA_OPERATION_STATS_CACHE_KEY;

/**
 * @code date 2025年08月08日 10:10
 * @code desc:null
 */
@Component
public class XnStaIncentiveAppServiceImpl implements XnStaIncentiveAppService {

    @Resource
    private TgManager tgManager;
    @Resource
    private CacheManager cacheManager;

    @Override
    public XnStaPracticeIncentiveDTO queryStaPracticeIncentiveBaseInfo(XnStaIncentiveQueryParam param) {
        ValidateUtil.validate(param);
        XnStaPracticeIncentiveDTO cacheDTO = cacheManager.get(buildOperationCacheKey(param), XnStaPracticeIncentiveDTO.class);
        if (Objects.nonNull(cacheDTO)) {
            return cacheDTO;
        }
        XnStaPracticeIncentiveDTO incentiveDTO = new XnStaPracticeIncentiveDTO();
        List<StationIncentiveBillDetailDTO> detailList = queryXnStaIncentiveDetail(param);
        if (validate(detailList)) {
            incentiveDTO.setNeedShow(false);
            return incentiveDTO;
        }
        String xnOptCnt = XnStaIncentivePageDataConvert.getXnOptCnt(detailList);
        BigDecimal incentiveAmount = XnStaIncentivePageDataConvert.getXnIncentiveAmount(detailList);
        incentiveDTO.setNeedShow(true);
        incentiveDTO.setOptCnt(xnOptCnt);
        incentiveDTO.setAmount(incentiveAmount.toString());
        cacheManager.set(buildOperationCacheKey(param), incentiveDTO, ONE_DAY_EXPIRE);
        return incentiveDTO;
    }

    @Override
    public XnStaPracticeIncentiveStatsDetailDTO queryStaPracticeIncentiveStatsDetail(XnStaIncentiveQueryParam param) {
        ValidateUtil.validate(param);
        XnStaPracticeIncentiveStatsDetailDTO cacheDTO = cacheManager.get(buildStatsDetailCacheKey(param), XnStaPracticeIncentiveStatsDetailDTO.class);
        if (Objects.nonNull(cacheDTO)) {
            return cacheDTO;
        }
        XnStaPracticeIncentiveStatsDetailDTO statsDetailDTO = new XnStaPracticeIncentiveStatsDetailDTO();
        List<StationIncentiveBillDetailDTO> detailList = queryXnStaIncentiveDetail(param);
        if (CollectionUtils.isEmpty(detailList)) {
            statsDetailDTO.setNeedShow(false);
            return statsDetailDTO;
        }
        StationIncentiveBillDetailDTO detail = Safes.of(detailList).stream().findFirst().orElse(null);
        List<XnStationOptCntStatsDTO> cntHistoryList = queryXnStaOptCntHistory(param);
        statsDetailDTO.setNeedShow(true);
        statsDetailDTO.setActivityCardStats(XnStaIncentivePageDataConvert.buildActivityStats(detailList));
        statsDetailDTO.setBaseConditions(XnStaIncentivePageDataConvert.buildHardwareCondition(detail));
        statsDetailDTO.setFlexibleConditions(XnStaIncentivePageDataConvert.buildStaTypeCondition(detail));
        statsDetailDTO.setOptCntHistory(XnStaIncentivePageDataConvert.buildOptCntHistory(cntHistoryList));
        cacheManager.set(buildStatsDetailCacheKey(param), statsDetailDTO, ONE_DAY_EXPIRE);
        return statsDetailDTO;
    }

    /**
     * 查询站点激励数据
     */
    public List<StationIncentiveBillDetailDTO> queryXnStaIncentiveDetail(XnStaIncentiveQueryParam paramh) {
        XnStaIncentiveBillParam request = new XnStaIncentiveBillParam();
        request.setStatsMonth(paramh.getStatsMonth());
        request.setStationMode(StationModeEnum.LIGHT.getType());
        request.setStationId(paramh.getStationId());
        return tgManager.getListData(request);
    }

    /**
     * 查询激励统计详情
     */
    public List<XnStationOptCntStatsDTO> queryXnStaOptCntHistory(XnStaIncentiveQueryParam param) {
        XnStaOptCntStatsParam request = new XnStaOptCntStatsParam();
        request.setStatsMonth(param.getStatsMonth());
        request.setStationId(param.getStationId());
        return tgManager.getListData(request);
    }

    private Boolean validate(List<StationIncentiveBillDetailDTO> detailDTOList) {
        if (CollectionUtils.isEmpty(detailDTOList)) {
            return true;
        }
        StationIncentiveBillDetailDTO detailDTO = detailDTOList.stream().findFirst().orElse(null);
        if (detailDTO == null) {
            return true;
        }
        return detailDTO.getIsRiskStation()
                || detailDTO.getIsYzStationTransfer()
                || detailDTO.getActivityType().equals("JV_ACTIVITY");
    }

    private String buildOperationCacheKey(XnStaIncentiveQueryParam param){
        return XN_STA_OPERATION_CARD_CACHE_KEY + param.getStationId()+":"+param.getStatsMonth();
    }

    private String buildStatsDetailCacheKey(XnStaIncentiveQueryParam param){
        return XN_STA_OPERATION_STATS_CACHE_KEY + param.getStationId()+":"+param.getStatsMonth();
    }
}
