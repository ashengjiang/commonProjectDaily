package com.cainiao.tp.nm.plan.policy.domain.component;

import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiverule.IncentiveRuleFillDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiverule.select.EntitySelectRuleDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyInstanceCreateParam;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyEntityAttrManager;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyBizTypeEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyCustomTypeEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyEntityAttrEnum;
import com.cainiao.tp.nm.plan.policy.domain.model.PolicyTemplate;
import com.cainiao.tp.nm.plan.policy.domain.model.valobj.incentiveplan.IncentivePlan;
import com.cainiao.tp.nm.plan.policy.domain.model.valobj.incentiveplan.select.EntityAttrSelectPlan;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @date: 2022-03-16
 * desc: 规模网点的扩展点实现
 */
@Slf4j
@Component
public class ScaleExpressDefinitionImpl extends AbstractPolicyInstanceDefinition {

    @Resource
    private PolicyEntityAttrManager policyEntityAttrManager;

    @Override
    public String bizType() {
        return PolicyBizTypeEnum.SCALE.getType();
    }

    @Override
    public String customType() {
        return PolicyCustomTypeEnum.EXPRESS.getType();
    }

    @Override
    public void validCreate(PolicyTemplate policyTemplate, PolicyInstanceCreateParam param) {
        super.validCreate(policyTemplate, param);

        Optional<IncentivePlan> first = policyTemplate.getIncentivePlanList().stream()
                .filter(plan -> plan.getIncentivePlanType().equals(param.getIncentivePlanType())).findFirst();
        AssertUtil.isTrue(first.isPresent(), "激励类型不存在");
        IncentivePlan incentivePlan = first.get();
        List<EntityAttrSelectPlan> attrSelectPlanList = incentivePlan.getContent().getSelectPlan().getAttrSelectPlanList();
        if(CollectionUtils.isEmpty(attrSelectPlanList)){
            return;
        }

        // 以后变成扩展点校验
        Map<String, List<String>> attrMap = attrSelectPlanList.stream()
                .filter(attr -> PolicyEntityAttrEnum.SIGN_PROTOCOL.getCode().equals(attr.getAttrCode()))
                .collect(Collectors.groupingBy(EntityAttrSelectPlan::getAttrCode
                        , Collectors.mapping(EntityAttrSelectPlan::getAttrValue, Collectors.toList())));

        List<IncentiveRuleFillDTO> fillList = param.getFillList();
        fillList.forEach(fill -> {
            EntitySelectRuleDTO entitySelectRule = fill.getSelectRule().getEntitySelectRule();
            AssertUtil.isTrue(null != entitySelectRule, "圈选对象错误");
            Map<String, Boolean> attrValMap = policyEntityAttrManager.hasAttr(entitySelectRule, attrMap);
            attrMap.forEach((k,v)->{
                AssertUtil.isTrue(Boolean.TRUE.equals(attrValMap.get(k)), "已签约名单中未查到该网点");
            });
        });
    }
}
