package com.cainiao.tp.nm.plan.policy.domain.repository;

import com.cainiao.sutee.commons.base.model.Page;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyInstanceQueryParam;
import com.cainiao.tp.nm.plan.policy.domain.model.PolicyInstance;

import java.util.List;

/**
 * @code date 2025年3月10日
 * @code desc: 政策实例仓储
 */
public interface PolicyInstanceRepository {

    PolicyInstance get(Long instanceId);

    List<PolicyInstance> listByTemplate(Long templateId, String incentivePlanType);

    Long create(PolicyInstance policyInstance);

    void updateStatus(PolicyInstance policyInstance);

    void updateBasic(PolicyInstance policyInstance);

    /**
     * 查询政策实例列表
     * @param queryParam 查询参数
     * @return 政策实例列表
     */
    Page<PolicyInstance> queryPolicyInstanceList(PolicyInstanceQueryParam queryParam);
}
