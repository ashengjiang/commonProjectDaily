package com.cainiao.tp.nm.plan.policy.application.service;

import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.cainiao.aladdin.lock.Lock;
import com.cainiao.aladdin.log.AladdinCommLog;
import com.cainiao.aladdin.log.utils.AladdinLogUtil;
import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.aladdin.utils.Safes;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.aladdin.validate.utils.ValidateUtil;
import com.cainiao.sutee.commons.base.model.CnPage;
import com.cainiao.sutee.commons.base.model.Page;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.PolicyTemplateQueryRequest;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyTemplateDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.PolicyApproveConfigDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.PolicyIncentiveExpenseItemDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.IncentivePlanContentDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.IncentivePlanDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.*;
import com.cainiao.tp.nm.plan.api.policy.application.service.PolicyTemplateAppService;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyConfigManager;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyIncentiveTemplateConfigManager;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyTairLockManager;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyTemplateQueryManager;
import com.cainiao.tp.nm.plan.policy.application.convert.PolicyTemplateApplicationConvert;
import com.cainiao.tp.nm.plan.policy.common.util.PolicyLockUtils;
import com.cainiao.tp.nm.plan.policy.domain.model.PolicyInstance;
import com.cainiao.tp.nm.plan.policy.domain.model.PolicyTemplate;
import com.cainiao.tp.nm.plan.policy.domain.repository.PolicyInstanceRepository;
import com.cainiao.tp.nm.plan.policy.domain.repository.PolicyTemplateRepository;
import com.cainiao.tp.nm.plan.policy.domain.service.PolicyTemplateDomainService;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @Date 2025/6/3 15:23
 * @code desc: 政策模板 appService
 */
@Slf4j
@HSFProvider(serviceInterface = PolicyTemplateAppService.class)
public class PolicyTemplateAppServiceImpl implements PolicyTemplateAppService {

    @Resource
    private PolicyTairLockManager policyTairLockManager;
    @Resource
    private PolicyConfigManager policyConfigManager;
    @Resource
    private PolicyTemplateDomainService policyTemplateDomainService;
    @Resource
    private PolicyIncentiveTemplateConfigManager policyIncentiveTemplateConfigManager;
    @Resource
    private PolicyTemplateRepository policyTemplateRepository;
    @Resource
    private PolicyInstanceRepository policyInstanceRepository;
    @Resource
    private PolicyTemplateQueryManager policyTemplateQueryManager;

    @Override
    public void create(PolicyTemplateCreateParam param, AbstractOperation operation) {
        AladdinCommLog aladdinCommLog = AladdinLogUtil.newCommLog(operation);
        Map<String,Object> logContext = Maps.newHashMap();
        aladdinCommLog.setParams(param);
        aladdinCommLog.setContext(logContext);
        Lock lock = null;
        try {
            // 权限校验
            rightCheck();
            // 基础非空校验
            ValidateUtil.validateAndThrow(param);
            lock = PolicyLockUtils.getPolicyTemplateLock(param.getBizType());
            policyTairLockManager.tryLockAndThrow(lock);

            // 如果不修改，直接使用激励方案的基础模版
            param.getIncentivePlanList().forEach(plan -> {
                if(null == plan.getContent()){
                    IncentivePlanDTO planDTO = policyIncentiveTemplateConfigManager.getIncentivePlanTemplate(param.getBizType()
                            , param.getCustomType(), plan.getIncentivePlanType() , plan.getIncentivePlanCode(), param.getStartTimeStr(), param.getEndTimeStr());
                    IncentivePlanContentDTO content = planDTO.getContent();
                    content.setSelectPlan(PolicyTemplateApplicationConvert.dtoToModel(param.getLaunchPlan()));
                    plan.setContent(content);
                }
            });

            // 调用领域服务
            PolicyTemplate policyTemplate = policyTemplateDomainService.createTemplate(param);

            // 根据审批，推动模版状态
            PolicyApproveConfigDTO approval = policyConfigManager.getApproveConfig(param.getBizType(), param.getCustomType());
            if(null != approval && approval.isTemplateApprove()){
                // 需要审批，审批中
                policyTemplate.approvaling();
            }else{
                // 无需审批，直接生效
                policyTemplate.effect();
            }

            // 调用仓储
            Long templateId = policyTemplateRepository.create(policyTemplate);
            // 发送应用事件

            AladdinLogUtil.log(log, aladdinCommLog);
        } catch (Throwable e) {
            AladdinLogUtil.log(log, e, aladdinCommLog);
            throw e;
        } finally {
            if (lock != null) {
                policyTairLockManager.release(lock);
            }
        }
    }

    @Override
    public void delete(PolicyTemplateDeleteParam param, AbstractOperation operation) {
        AladdinCommLog aladdinCommLog = AladdinLogUtil.newCommLog(operation);
        Map<String,Object> logContext = Maps.newHashMap();
        aladdinCommLog.setParams(param);
        aladdinCommLog.setContext(logContext);
        Lock lock = null;
        try {
            // 权限校验
            rightCheck();
            // 参数校验
            param.validate();

            // 获取政策模版
            PolicyTemplate policyTemplate = policyTemplateRepository.get(param.getTemplateId());
            AssertUtil.isTrue(null != policyTemplate, "模版不存在");

            lock = PolicyLockUtils.getPolicyTemplateLock(policyTemplate.getBizType());
            policyTairLockManager.tryLockAndThrow(lock);

            // 判断历史是否有实例
            PolicyInstanceQueryParam queryParam = new PolicyInstanceQueryParam();
            queryParam.setTemplateId(param.getTemplateId());
            queryParam.setPageSize(1);
            Page<PolicyInstance> policyInstancePage = policyInstanceRepository.queryPolicyInstanceList(queryParam);
            AssertUtil.isTrue(CollectionUtils.isEmpty(policyInstancePage.getPageItems()), "已存在提报数据，无法删除");

            //调用领域实体
            policyTemplate.delete(param);

            // 调用仓储
            policyTemplateRepository.delete(policyTemplate);

            AladdinLogUtil.log(log, aladdinCommLog);
        } catch (Throwable e) {
            AladdinLogUtil.log(log, e, aladdinCommLog);
            throw e;
        } finally {
            if (lock != null) {
                policyTairLockManager.release(lock);
            }
        }
    }

    @Override
    public Page<PolicyTemplateDTO> queryPolicyTemplateList(PolicyTemplateQueryRequest request, AbstractOperation operation) {
        // 权限校验
        rightCheck();
        Page<PolicyTemplate> policyTemplatePageResult = policyTemplateRepository.selectPage(PolicyTemplateApplicationConvert.queryParamConvert(request));
        List<PolicyTemplateDTO> templateDTOList = Safes.of(policyTemplatePageResult.getPageItems())
            .stream()
            .map(PolicyTemplateApplicationConvert::modelToDto)
            .collect(Collectors.toList());
        return CnPage.of(request.getPageIndex(), request.getPageSize(), templateDTOList, policyTemplatePageResult.getItemTotal());
    }

    @Override
    public List<IncentivePlanDTO> queryIncentivePlanList(IncentivePlanQueryParam param, AbstractOperation operation) {
        // 权限校验
        rightCheck();
        ValidateUtil.validateAndThrow(param);
        LocalDateTime startTime = param.getStartTime();
        LocalDateTime endTime = param.getEndTime();
        if (startTime == null || endTime == null) {
            return new ArrayList<>();
        }
        return policyTemplateQueryManager.queryIncentivePlanFromOutBiz(param);
    }

    @Override
    public List<PolicyIncentiveExpenseItemDTO> queryIncentiveExpenseItemList(IncentiveExpenseItemQueryParam queryParam,AbstractOperation operation) {
        // 权限校验
        rightCheck();
        ValidateUtil.validateAndThrow(queryParam);
        LocalDateTime startTime = queryParam.getStartTime();
        LocalDateTime endTime = queryParam.getEndTime();
        if (startTime == null || endTime == null) {
            return new ArrayList<>();
        }
        return policyTemplateQueryManager.queryIncentiveExpenseItemList(queryParam);
    }

    private void rightCheck() {
        /*RightsControlContext rightsControlContext = RightsControlUtils.get();
        String permissionDeniedPrompt = policyConfigManager.getPermissionDeniedPrompt();
        AssertUtil.notNull(rightsControlContext,permissionDeniedPrompt);
        AssertUtil.isTrue(rightsControlContext.isHasRoleRights(),permissionDeniedPrompt);*/
    }

}
