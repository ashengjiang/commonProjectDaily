package com.cainiao.tp.nm.plan.policy.common.util.dto;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import lombok.Getter;
import org.apache.commons.collections4.CollectionUtils;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

@Getter
public class ExcelHeadAndDataListener extends AnalysisEventListener<LinkedHashMap<Integer,String>> {

    /**
     * 自定义用于暂时存储data。
     * 可以通过实例获取该值
     */
    private final List<LinkedHashMap<Integer,String>> headerList = new ArrayList<>();

    /**
     * 自定义用于暂时存储data。
     * 可以通过实例获取该值
     */
    private final List<LinkedHashMap<Integer,String>> dataList = new ArrayList<>();

    /**
     * 通过 AnalysisContext 对象还可以获取当前 sheet，当前行等数据
     */
    @Override
    public void invoke(LinkedHashMap<Integer,String> object, AnalysisContext context) {
        if(CollectionUtils.isEmpty(headerList)){
            headerList.add(object);
        }else{
            dataList.add(object);
        }
    }

    @Override
    public void doAfterAllAnalysed(AnalysisContext context) {
    }

}
