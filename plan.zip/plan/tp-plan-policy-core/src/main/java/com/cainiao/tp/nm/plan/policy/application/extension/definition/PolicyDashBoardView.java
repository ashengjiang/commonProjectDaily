package com.cainiao.tp.nm.plan.policy.application.extension.definition;

import com.alibaba.fastjson.JSONObject;
import com.cainiao.tp.nm.plan.api.policy.application.dto.ViewHeadDTO;

import java.util.List;

public interface PolicyDashBoardView<M,N> {

  List<ViewHeadDTO>  getHeader(M m);

  List<JSONObject> getDataSource(List<N> t);

}
