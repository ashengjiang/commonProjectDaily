package com.cainiao.tp.nm.plan.policy.application.service.station;

import com.alibaba.fastjson.JSONObject;
import com.cainiao.aladdin.log.AladdinCommLog;
import com.cainiao.aladdin.log.BizType;
import com.cainiao.aladdin.log.utils.AladdinLogUtil;
import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.aladdin.validate.utils.ValidateUtil;
import com.cainiao.tp.nm.plan.api.policy.application.dto.StationDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.station.StationElementButtonQueryParam;
import com.cainiao.tp.nm.plan.api.policy.application.service.station.PGStationElementButtonService;
import com.cainiao.tp.nm.plan.api.policy.common.constants.StationCommonConstants;
import com.cainiao.tp.nm.plan.api.policy.common.constants.StationModeEnum;
import com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils;
import com.cainiao.tp.nm.plan.infra.port.policy.StaStationReadManager;
import com.cainiao.tp.nm.plan.policy.application.convert.PGStationButtonURLConvert;
import com.cainiao.tp.nm.plan.policy.common.util.FiscalQuarterComputeUtil;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;

import static com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils.YYYY_MM;

/**
 * @code date 2025年08月05日 10:47
 * @code desc:null
 */
@Slf4j
@Component
public class PGStationElementButtonServiceImpl implements PGStationElementButtonService {

    @Resource
    private StaStationReadManager staStationReadManager;
//    @Resource
//    private EmployeeRightsLoadManager employeeRightsLoadManager;


    @Override
    public String getButtonUrl(StationElementButtonQueryParam param, AbstractOperation abstractOperation) {
        AladdinCommLog aladdinCommLog = AladdinLogUtil.newCommLog(BizType.DEFAULT, abstractOperation);
        Map<String, Object> logContext = Maps.newHashMap();
        aladdinCommLog.setParams(JSONObject.toJSONString(param));
        aladdinCommLog.setContext(logContext);
        try {
            ValidateUtil.validate(param);
            String stationId = param.getStationId();
            String employeeId = param.getEmployeeId();
//            String highestDeptCode = employeeRightsLoadManager.getEmployeeHighestDeptCode(Long.valueOf(employeeId));
            StationDTO stationDTO = staStationReadManager.queryStation(stationId);
            AssertUtil.notNull(stationDTO, "站点不存在");
            Date gmtCreate = stationDTO.getGmtCreate();
            if (!isNeedShowButtonDateInRange(gmtCreate)) {
                return null;
            }
            String fiscalQuarter = FiscalQuarterComputeUtil.getFiscalQuarter(gmtCreate);
            AssertUtil.notNull(fiscalQuarter, "建站时间对应财年为空");
            String date = DateUtils.dateFormat(gmtCreate, YYYY_MM);
            String stationMode = stationId.startsWith(StationCommonConstants.LIGHT_STATION_MODE_FLAG) ? StationModeEnum.LIGHT.getType() : StationModeEnum.HEAVY.getType();
            return PGStationButtonURLConvert.assembleStaIncentiveJumpButton(stationMode, param.getSource(), fiscalQuarter, stationId, employeeId, date);
        } catch (Exception e) {
            AladdinLogUtil.log(log, e, aladdinCommLog);
            return null;
        }
    }
    public static boolean isNeedShowButtonDateInRange(Date date) {
        // 使用 Calendar 创建开始日期：2025年1月1日
        Calendar startCal = Calendar.getInstance();
        startCal.set(2025, Calendar.JANUARY, 1, 0, 0, 0);
        Date startDate = startCal.getTime();
        // 使用 Calendar 创建结束日期：2025年6月30日
        Calendar endCal = Calendar.getInstance();
        endCal.set(2025, Calendar.JUNE, 30, 23, 59, 59);
        Date endDate = endCal.getTime();
        // 判断当前日期是否在范围内
        return date.after(startDate) && date.before(endDate);
    }
}
