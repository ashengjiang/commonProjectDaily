package com.cainiao.tp.nm.plan.policy.adaptor.schedulerx;

import com.alibaba.fastjson.JSON;
import com.alibaba.schedulerx.worker.domain.JobContext;
import com.alibaba.schedulerx.worker.processor.ProcessResult;

import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.aladdin.operation.SystemBizOperation;
import com.cainiao.sutee.commons.base.model.Page;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.PolicyBatchSubmissionJobDTO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.PolicyInstanceQueryRequest;
import com.cainiao.tp.nm.plan.api.policy.application.dto.TpTicketDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.TicketInstanceApprovalStartParam;
import com.cainiao.tp.nm.plan.infra.port.policy.TicketApprovalManager;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyInstanceDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyInstanceLoseEffectParam;
import com.cainiao.tp.nm.plan.api.policy.application.service.PolicyInstanceAppService;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyConstants;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyFeatureConstants;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyInstanceApprovalStatusEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyInstanceStatusEnum;
import com.cainiao.tp.nm.plan.policy.common.util.AssertUtil;
import com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils;
import com.cainiao.tp.nm.plan.policy.common.util.JobExecuteResultUtils;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.Optional;

/**
 * @Date 2025/6/6 13:00
 * @code desc: 激励方案批量提交的定时任务
 */
@Component
@Slf4j
public class PolicyBatchSubmissionJob extends AbstractJob<PolicyBatchSubmissionJobDTO> {

    @Resource
    private PolicyInstanceAppService policyInstanceAppService;

    @Resource(name = "policyInstanceApprovalManagerImpl")
    private TicketApprovalManager<TicketInstanceApprovalStartParam, TpTicketDTO> policyInstanceApprovalManager;

    private final AbstractOperation opInfo = new SystemBizOperation(0L, "定时任务");

    @Override
    public ProcessResult handle(PolicyBatchSubmissionJobDTO policyBatchSubmissionJobDTO, JobContext context) {
        process(policyBatchSubmissionJobDTO);
        int failCount = JobExecuteResultUtils.getResultDTO().getFailCount();
        if (failCount > 0) {
            ProcessResult processResult = new ProcessResult(false);
            processResult.setResult(JSON.toJSONString(JobExecuteResultUtils.getResultDTO()));
            return processResult;
        }
        ProcessResult processResult = new ProcessResult(true);
        processResult.setResult(JSON.toJSONString(JobExecuteResultUtils.getResultDTO()));
        return processResult;
    }

    @Override
    public Class<PolicyBatchSubmissionJobDTO> getClassName() {
        return PolicyBatchSubmissionJobDTO.class;
    }

    /**
     * 处理任务
     * @param policyBatchSubmissionJobDTO 任务参数
     */
    private void process(PolicyBatchSubmissionJobDTO policyBatchSubmissionJobDTO){
        log.info("PolicyBatchSubmissionJob process,policyBatchSubmissionJobDTO={}", policyBatchSubmissionJobDTO);

        PolicyInstanceQueryRequest queryParam = new PolicyInstanceQueryRequest();
        queryParam.setApprovalStatus(PolicyInstanceApprovalStatusEnum.APPROVALING.getCode());
        queryParam.setStatus(PolicyInstanceStatusEnum.WAITING_EFFECT.getCode());
        Map<String,Boolean> orderFieldNameMap = Maps.newHashMap();
        orderFieldNameMap.put("id", true);
        queryParam.setOrderFieldNameMap(orderFieldNameMap);

        for (int pageIndex = 0; pageIndex < policyBatchSubmissionJobDTO.getMaxPageNum(); pageIndex++) {
            queryParam.setPageIndex(pageIndex + 1);
            queryParam.setPageSize(policyBatchSubmissionJobDTO.getPageSize());
            Page<PolicyInstanceDTO> policyInstancePage = policyInstanceAppService.queryPolicyInstanceList(queryParam, opInfo);
            if (pageIndex == 0 && policyInstancePage.getItemTotal() == 0) {
                break;
            }
            if (policyInstancePage.getItemTotal() == 0) {
                break;
            }
            if (CollectionUtils.isEmpty(policyInstancePage.getPageItems())){
                continue;
            }
            // 过滤出已过期的
            policyInstancePage.getPageItems().stream()
                .filter(policyInstanceDTO -> policyInstanceDTO != null && policyInstanceDTO.getStartTime() != null)
                .filter(policyInstanceDTO -> LocalDateTime.now().isAfter(policyInstanceDTO.getStartTime()))
                .forEach(policyInstanceDTO -> {
                    try {
                        // 取消任务
                        AssertUtil.notBlank(policyInstanceDTO.getApprovalFollowId(), "审批流id为空");
                        String approvalFollowId = policyInstanceDTO.getApprovalFollowId();
                        String nowTime = DateUtils.localDateTimeToYmdhmsStr(LocalDateTime.now());
                        LocalDateTime effectTime = policyInstanceDTO.getEffectTime();
                        String cancelReason;
                        if (effectTime == null){
                            cancelReason = String.format(PolicyConstants.LOSE_EFFECT_REASON, nowTime);
                        }else {
                            cancelReason = String.format(
                                PolicyConstants.LOSE_EFFECT_REASON_CONTAIN_EFFECT_TIME,
                                nowTime,
                                DateUtils.localDateTimeToYmdhmsStr(effectTime));
                        }
                        // 取消流程
                        policyInstanceApprovalManager.cancelProcessInstance(approvalFollowId, cancelReason);
                        // 失效政策实例
                        PolicyInstanceLoseEffectParam policyInstanceLoseEffectParam = new PolicyInstanceLoseEffectParam();
                        policyInstanceLoseEffectParam.setInstanceId(policyInstanceDTO.getId());
                        policyInstanceLoseEffectParam.setApprovalStatus(PolicyInstanceApprovalStatusEnum.OVERTIME_AUTO_REFUSE.getCode());
                        Map<String, String> featureMap = Optional.ofNullable(policyInstanceDTO.getFeatureMap()).orElse(Maps.newHashMap());
                        featureMap.put(PolicyFeatureConstants.CANCEL_REASON, cancelReason);
                        policyInstanceLoseEffectParam.setFeatureMap(featureMap);
                        policyInstanceAppService.loseEffect(policyInstanceLoseEffectParam, opInfo);
                        JobExecuteResultUtils.addSuccessCount();
                    } catch (Exception e) {
                        log.error("PolicyBatchSubmissionJob#process error,policyInstanceDTO={}", JSON.toJSONString(policyInstanceDTO), e);
                        JobExecuteResultUtils.addFailCount();
                    }
                });
            if (queryParam.getPageIndex() >= policyInstancePage.getPageTotal()){
                break;
            }
        }
    }

}
