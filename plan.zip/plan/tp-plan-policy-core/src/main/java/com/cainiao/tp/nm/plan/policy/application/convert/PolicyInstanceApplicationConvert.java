package com.cainiao.tp.nm.plan.policy.application.convert;

import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.PolicyInstanceQueryRequest;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyInstanceDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyInstanceCreateParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyInstanceQueryParam;
import com.cainiao.tp.nm.plan.policy.application.event.event.PolicyInstanceCreateEvent;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyFeatureConstants;
import com.cainiao.tp.nm.plan.policy.domain.model.PolicyInstance;
import org.apache.commons.collections4.MapUtils;

import java.util.Map;

/**
 * @Date 2025/6/9 09:42
 */
public class PolicyInstanceApplicationConvert {
    public static PolicyInstanceDTO modelToDto(PolicyInstance policyInstance){
        if (policyInstance == null) {
            return null;
        }
        PolicyInstanceDTO policyInstanceDTO = new PolicyInstanceDTO();
        policyInstanceDTO.setId(policyInstance.getId());
        policyInstanceDTO.setGmtCreate(policyInstance.getGmtCreate());
        policyInstanceDTO.setGmtModified(policyInstance.getGmtModified());
        policyInstanceDTO.setTemplateId(policyInstance.getTemplateId());
        policyInstanceDTO.setIncentivePlanType(policyInstance.getIncentivePlanType());
        policyInstanceDTO.setCustomType(policyInstance.getCustomType());
        policyInstanceDTO.setBizType(policyInstance.getBizType());
        policyInstanceDTO.setStartTime(policyInstance.getStartTime());
        policyInstanceDTO.setEndTime(policyInstance.getEndTime());
        policyInstanceDTO.setEffectTime(policyInstance.getEffectTime());
        policyInstanceDTO.setLoseEffectTime(policyInstance.getLoseEffectTime());
        policyInstanceDTO.setStatus(policyInstance.getStatus());
        policyInstanceDTO.setApprovalStatus(policyInstance.getApprovalStatus());
        Map<String, String> featureMap = policyInstance.getFeatureMap();
        if (MapUtils.isNotEmpty(featureMap)) {
            policyInstanceDTO.setApprovalFollowId(featureMap.get(PolicyFeatureConstants.APPROVAL_FOLLOW_ID));
        }
        policyInstanceDTO.setLastOperatorId(policyInstance.getLastOperatorId());
        policyInstanceDTO.setFeatureMap(policyInstance.getFeatureMap());
        return policyInstanceDTO;
    }

    public static PolicyInstanceQueryParam queryParamConvert(PolicyInstanceQueryRequest request){
        if (request == null) {
            return null;
        }
        PolicyInstanceQueryParam queryParam = new PolicyInstanceQueryParam();
        queryParam.setApprovalStatus(request.getApprovalStatus());
        queryParam.setStatus(request.getStatus());
        queryParam.setPageIndex(request.getPageIndex());
        queryParam.setPageSize(request.getPageSize());
        queryParam.setOrderFieldNameMap(request.getOrderFieldNameMap());
        return queryParam;
    }

    public static PolicyInstanceCreateEvent createEvent(PolicyInstanceCreateParam param, Long instanceId){
        PolicyInstanceCreateEvent event = new PolicyInstanceCreateEvent();
        event.setTemplateId(param.getTemplateId());
        event.setInstanceId(instanceId);
        event.setIncentivePlanType(param.getIncentivePlanType());
        event.setStartTime(param.getStartTime());
        event.setOperatorId(param.getOperatorId());
        return event;
    }
}
