package com.cainiao.tp.nm.plan.policy.adaptor.convert;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.PolicyMetaDataTypeVO;
import com.cainiao.tp.nm.plan.api.policy.common.constants.IncentivePlanTypeEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.LaunchPlanTypeEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyBizTypeEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyCustomTypeEnum;
import org.apache.commons.collections4.CollectionUtils;

/**
 * @Date 2025/6/5 13:37
 * @code desc: 政策模板元数据类型转换
 */
public class PolicyMetaDataTypeAdaptorConvert {


    public static List<PolicyMetaDataTypeVO> selectPolicyCustomTypeList(){
        List<PolicyCustomTypeEnum> customTypeEnums = Arrays.stream(PolicyCustomTypeEnum.values()).collect(Collectors.toList());
        return convertByPolicyCustomTypeEnumList(customTypeEnums);
    }

    public static List<PolicyMetaDataTypeVO> selectPolicyBizTypeList(){
        List<PolicyBizTypeEnum> customTypeEnums = new ArrayList<>();
        customTypeEnums.add(PolicyBizTypeEnum.SCALE);
        return convertByPolicyBizTypeEnumList(customTypeEnums);
    }

    public static List<PolicyMetaDataTypeVO> selectLaunchTypeList(){
        List<LaunchPlanTypeEnum> customTypeEnums = Arrays.stream(LaunchPlanTypeEnum.values()).collect(Collectors.toList());
        return convertByLaunchTypeEnumList(customTypeEnums);
    }
    public static List<PolicyMetaDataTypeVO> selectIncentivePlanTypeList() {
        List<IncentivePlanTypeEnum> incentivePlanTypeEnum = Arrays.stream(IncentivePlanTypeEnum.values()).collect(Collectors.toList());
        return convertByIncentivePlanTypeEnumList(incentivePlanTypeEnum);
    }

    /**
     * 转换
     * @param incentivePlanTypeEnumList 激励方案类型列表
     * @return 政策模板元数据类型列表
     */
    public static List<PolicyMetaDataTypeVO> convertByIncentivePlanTypeEnumList(List<IncentivePlanTypeEnum> incentivePlanTypeEnumList){
        if (CollectionUtils.isEmpty(incentivePlanTypeEnumList)){
            return new ArrayList<>();
        }
        return incentivePlanTypeEnumList.stream().map(customTypeEnum ->{
            PolicyMetaDataTypeVO metaDataTypeVO = new PolicyMetaDataTypeVO();
            metaDataTypeVO.setType(customTypeEnum.getType());
            metaDataTypeVO.setDesc(customTypeEnum.getDesc());
            return metaDataTypeVO;
        }).collect(Collectors.toList());
    }
    /**
     * 转换
     * @param customTypeEnumList 投放方案类型列表
     * @return 政策模板元数据类型列表
     */
    public static List<PolicyMetaDataTypeVO> convertByLaunchTypeEnumList(List<LaunchPlanTypeEnum> customTypeEnumList){
        if (CollectionUtils.isEmpty(customTypeEnumList)){
            return new ArrayList<>();
        }
        return customTypeEnumList.stream().map(customTypeEnum ->{
            PolicyMetaDataTypeVO metaDataTypeVO = new PolicyMetaDataTypeVO();
            metaDataTypeVO.setType(customTypeEnum.getType());
            metaDataTypeVO.setDesc(customTypeEnum.getDesc());
            return metaDataTypeVO;
        }).collect(Collectors.toList());
    }


    /**
     * 转换
     * @param customTypeEnumList 政策业务类型列表
     * @return 政策模板元数据类型列表
     */
    public static List<PolicyMetaDataTypeVO> convertByPolicyBizTypeEnumList(List<PolicyBizTypeEnum> customTypeEnumList){
        if (CollectionUtils.isEmpty(customTypeEnumList)){
            return new ArrayList<>();
        }
        return customTypeEnumList.stream().map(customTypeEnum ->{
            PolicyMetaDataTypeVO metaDataTypeVO = new PolicyMetaDataTypeVO();
            metaDataTypeVO.setType(customTypeEnum.getType());
            metaDataTypeVO.setDesc(customTypeEnum.getDesc());
            return metaDataTypeVO;
        }).collect(Collectors.toList());
    }

    /**
     * 转换
     * @param customTypeEnumList 政策客户类型列表
     * @return 政策模板元数据类型列表
     */
    public static List<PolicyMetaDataTypeVO> convertByPolicyCustomTypeEnumList(List<PolicyCustomTypeEnum> customTypeEnumList){
        if (CollectionUtils.isEmpty(customTypeEnumList)){
            return new ArrayList<>();
        }
        return customTypeEnumList.stream().map(customTypeEnum ->{
            PolicyMetaDataTypeVO metaDataTypeVO = new PolicyMetaDataTypeVO();
            metaDataTypeVO.setType(customTypeEnum.getType());
            metaDataTypeVO.setDesc(customTypeEnum.getDesc());
            return metaDataTypeVO;
        }).collect(Collectors.toList());
    }

}
