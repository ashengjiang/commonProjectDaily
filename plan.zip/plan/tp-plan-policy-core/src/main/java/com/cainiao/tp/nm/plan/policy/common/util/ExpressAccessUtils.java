package com.cainiao.tp.nm.plan.policy.common.util;


import com.cainiao.tp.nm.plan.api.policy.application.dto.ExpressContentDTO;
import com.taobao.mtop.api.agent.MtopContext;

/**
 * @code date 2025年06月26日 15:59
 * @code desc:获取mtop上下文
 */
public class ExpressAccessUtils {

    public static final String SESSION_ID = "caiNiaoSessionId";
    public static final String ACCOUNT_ID = "caiNiaoAccountId";

    public static ExpressContentDTO getContext() {
        ExpressContentDTO contentDTO = new ExpressContentDTO();
        contentDTO.setUserId(MtopContext.getUserId() == 0L ? Long.parseLong(MtopContext.getHeader(ACCOUNT_ID)) : MtopContext.getUserId());
        contentDTO.setSessionId(MtopContext.getHeader(SESSION_ID));
        contentDTO.setAppKey(MtopContext.getAppKey());
        return contentDTO;
    }

}
