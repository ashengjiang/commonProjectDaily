package com.cainiao.tp.nm.plan.policy.application.extension.definition;


import com.cainiao.tp.nm.plan.api.policy.application.dto.base.BaseTableDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyInstanceRuleDTO;

import java.util.List;

/**
 * @code date 2025年06月09日 14:39
 * @code desc: 政策看板视图转换
 * @code <R,T>: R:出参 T:入参
 */
public interface PolicyDashBoardViewTransform {

    String getTransformType();

    BaseTableDTO transform(List<PolicyInstanceRuleDTO> ruleDTOList);
}
