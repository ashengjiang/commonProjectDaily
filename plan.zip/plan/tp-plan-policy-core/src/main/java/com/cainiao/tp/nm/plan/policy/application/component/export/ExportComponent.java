package com.cainiao.tp.nm.plan.policy.application.component.export;


import com.cainiao.tp.nm.plan.api.policy.application.dto.ExportResultDTO;

public interface ExportComponent<Request> {


    /**
     * 返回的结果是ossKey
     *
     * @param request request
     * @return return
     */
    ExportResultDTO executeExport(Request request);



    /**
     * 类型
     *
     * @return return
     */
    String getCode();

}
