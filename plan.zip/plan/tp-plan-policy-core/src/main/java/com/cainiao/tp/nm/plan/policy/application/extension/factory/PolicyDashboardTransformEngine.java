package com.cainiao.tp.nm.plan.policy.application.extension.factory;

import com.alibaba.fastjson.JSONObject;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyTemplateDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.ViewHeadDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.base.BaseTableDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyInstanceRuleDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.base.ColumnDTO;
import com.cainiao.tp.nm.plan.policy.application.extension.definition.*;
import com.cainiao.tp.nm.plan.policy.common.util.AssertUtil;
import com.cainiao.tp.nm.plan.policy.common.util.ViewUtils;
import com.google.common.collect.Maps;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @code date 2025年06月09日 14:35
 * @code desc: 政策看板视图转换
 */
@Component
public class PolicyDashboardTransformEngine implements InitializingBean {

    @Resource
    List<PolicyDashBoardViewTransform> transformList;
    @Resource
    List<AbstractMainTableView> mainTableViewList;
    @Resource
    List<AbstractHistoryTableView> historyTableViewList;

    private final static LocalDateTime OLD_MAX_OPEN_TIME = LocalDateTime.of(2025, 7, 30, 0, 0);
    private final Map<String, PolicyDashBoardViewTransform> transformEngineMap = Maps.newConcurrentMap();


    public BaseTableDTO transform(List<PolicyInstanceRuleDTO> ruleDTOList, String transformType) {
        PolicyDashBoardViewTransform engine = transformEngineMap.get(transformType);
        return engine.transform(ruleDTOList);
    }

    public BaseTableDTO transformMainTableView(List<PolicyInstanceRuleDTO> ruleDTOList, String transformType, PolicyTemplateDTO dto) {
        LocalDateTime startTime = dto.getStartTime();
        if (startTime.isBefore(OLD_MAX_OPEN_TIME)) {
            return transform(ruleDTOList, transformType);
        }
        AbstractMainTableView abstractMainTableView = mainTableViewList.stream().filter(view -> AbstractMainTableView.CODE_DEFAULT.equals(view.getCode())).findFirst().orElse(null);
        AssertUtil.notNull(abstractMainTableView, "主表视图不存在");
        return execute(abstractMainTableView, ruleDTOList, dto);
    }

    public BaseTableDTO transformHistoryTableView(List<PolicyInstanceRuleDTO> ruleDTOList, String transformType, PolicyTemplateDTO dto) {
        LocalDateTime startTime = dto.getStartTime();
        if (startTime.isBefore(OLD_MAX_OPEN_TIME)) {
            return transform(ruleDTOList, transformType);
        }
        AbstractHistoryTableView abstractMainTableView = historyTableViewList.stream().filter(view -> AbstractMainTableView.CODE_DEFAULT.equals(view.getCode())).findFirst().orElse(null);
        AssertUtil.notNull(abstractMainTableView, "历史列表展示不存在");

        return execute(abstractMainTableView, ruleDTOList, dto);
    }

    private BaseTableDTO execute(AbstractPolicyDashBoardView policyDashBoardView, List<PolicyInstanceRuleDTO> ruleDTOList, PolicyTemplateDTO dto) {
        List<ViewHeadDTO> header = policyDashBoardView.getHeader(dto);
        List<JSONObject> dataSource = policyDashBoardView.getDataSource(ruleDTOList);

        BaseTableDTO baseTableDTO = new BaseTableDTO();
        baseTableDTO.setColumns(getTableHead(header));

        List<Object> resultList = dataSource.stream().map(data -> ViewUtils.getViewData(header, data)).collect(Collectors.toList());
        baseTableDTO.setDataSource(resultList);
        return baseTableDTO;
    }


    private List<ColumnDTO> getTableHead(List<ViewHeadDTO> header) {
        return header.stream().map(dto -> {
            Boolean show = dto.getShow();
            if(show!=null && !show) {
                return null;
            }
            ColumnDTO columnDTO = new ColumnDTO();
            columnDTO.setTitle(dto.getName());
            columnDTO.setDataIndex(dto.getKey());
            return columnDTO;
        }).filter(Objects::nonNull).collect(Collectors.toList());
    }


    @Override
    public void afterPropertiesSet() throws Exception {
        transformList.forEach(transform -> transformEngineMap.put(transform.getTransformType(), transform));
    }
}
