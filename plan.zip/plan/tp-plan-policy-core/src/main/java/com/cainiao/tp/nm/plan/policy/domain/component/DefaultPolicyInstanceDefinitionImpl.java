package com.cainiao.tp.nm.plan.policy.domain.component;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @date: 2022-03-16
 * desc: 默认的扩展点实现
 */
@Slf4j
@Component
public class DefaultPolicyInstanceDefinitionImpl extends AbstractPolicyInstanceDefinition {

    @Override
    public String bizType() {
        return "default";
    }

    @Override
    public String customType() {
        return "default";
    }

}
