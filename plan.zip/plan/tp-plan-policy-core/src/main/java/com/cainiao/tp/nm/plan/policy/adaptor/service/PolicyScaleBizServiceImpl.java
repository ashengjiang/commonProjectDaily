package com.cainiao.tp.nm.plan.policy.adaptor.service;

import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.fastjson.JSONObject;
import com.cainiao.aladdin.log.AladdinCommLog;
import com.cainiao.aladdin.log.BizType;
import com.cainiao.aladdin.log.utils.AladdinLogUtil;
import com.cainiao.aladdin.validate.utils.AssertUtil;
import com.cainiao.aladdin.validate.utils.ValidateUtil;
import com.cainiao.sutee.commons.base.result.CnResult;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.StaScalePolicyCoefficientDTO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.StaScalePolicyByCollectQueryRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.StationAnnualPolicyQueryRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.service.PolicyScaleBizService;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiverule.IncentiveRuleFrameDTO;
import com.cainiao.tp.nm.plan.api.policy.common.constants.*;
import com.cainiao.tp.nm.plan.infra.port.collect.CollectPointInfoDTO;
import com.cainiao.tp.nm.plan.infra.port.collect.TseCollectPointManager;
import com.cainiao.tp.nm.plan.infra.port.tag.TseTagManager;
import com.cainiao.tp.nm.plan.policy.domain.model.PolicyInstance;
import com.cainiao.tp.nm.plan.policy.domain.model.PolicyTemplate;
import com.cainiao.tp.nm.plan.policy.domain.model.valobj.incentiverule.IncentiveRule;
import com.cainiao.tp.nm.plan.policy.domain.model.valobj.incentiverule.IncentiveRuleCoefficientContent;
import com.cainiao.tp.nm.plan.policy.domain.model.valobj.incentiverule.IncentiveRuleFrame;
import com.cainiao.tp.nm.plan.policy.domain.model.valobj.incentiverule.select.AreaSelectRule;
import com.cainiao.tp.nm.plan.policy.domain.model.valobj.incentiverule.select.TagSelectRule;
import com.cainiao.tp.nm.plan.policy.domain.model.valobj.launchplan.LaunchPlan;
import com.cainiao.tp.nm.plan.policy.domain.model.valobj.launchplan.RuleLaunch;
import com.cainiao.tp.nm.plan.policy.domain.model.valobj.launchplan.TagRuleLaunch;
import com.cainiao.tp.nm.plan.policy.domain.repository.PolicyInstanceRepository;
import com.cainiao.tp.nm.plan.policy.domain.repository.PolicyTemplateRepository;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * @code date 2025年05月29日 16:28
 * @code desc:规则政策对外业务接口(具体业务用例，无需通用)
 */
@Slf4j
@HSFProvider(serviceInterface = PolicyScaleBizService.class)
public class PolicyScaleBizServiceImpl implements PolicyScaleBizService {

    @Resource
    private PolicyTemplateRepository policyTemplateRepository;
    @Resource
    private PolicyInstanceRepository policyInstanceRepository;
    @Resource
    private TseTagManager tseTagManager;
    @Resource
    private TseCollectPointManager tseCollectPointManager;

    @Override
    public CnResult<IncentiveRuleFrameDTO> queryStationAnnualPolicyInstance(StationAnnualPolicyQueryRequest request) {
        AladdinCommLog aladdinCommLog = AladdinLogUtil.newCommLog(BizType.DEFAULT, "queryStationAnnualPolicyInstance");
        Map<String,Object> logContext = Maps.newHashMap();
        aladdinCommLog.setParams(request);
        aladdinCommLog.setContext(logContext);
        try {
            LocalDateTime now = LocalDateTime.now();
            List<PolicyTemplate> policyTemplates =
                    policyTemplateRepository.get(PolicyBizTypeEnum.ANNUAL.getType(), PolicyCustomTypeEnum.STATION.getType());

            Optional<PolicyTemplate> first = Optional.ofNullable(policyTemplates).orElse(Lists.newArrayList())
                    .stream().filter(pt -> pt.getStartTime().isBefore(now) && pt.getEndTime().isAfter(now)).findFirst();
            if(!first.isPresent()){
                logContext.put("filter", "政策模版不存在");
                AladdinLogUtil.log(log, aladdinCommLog);
                return CnResult.succeed();
            }

            Long templateId = first.get().getId();
            List<PolicyInstance> policyInstances = policyInstanceRepository.listByTemplate(templateId, IncentivePlanTypeEnum.BASIC.getType());
            if(CollectionUtils.isEmpty(policyInstances)){
                logContext.put("filter", "政策实例不存在");
                AladdinLogUtil.log(log, aladdinCommLog);
                return CnResult.succeed();
            }

            for(PolicyInstance pi : policyInstances){
                if(PolicyInstanceStatusEnum.EFFECT.getCode().equals(pi.getStatus())
                        && pi.getStartTime().isBefore(now) && pi.getEndTime().isAfter(now)){
                    // 目前业务是全国统一，直接返回，后序通过站点名单/区域/标签/属性等选择
                    Optional<IncentiveRuleFrame> frameOptional = Optional.ofNullable(pi.getIncentiveRuleList()).orElse(Lists.newArrayList())
                            .stream().filter(ir -> null != ir.getSelectRule()
                                    && null != ir.getSelectRule().getAreaSelectRule()
                                    && PolicyConstants.NATIONAL_PROVINCE_CODE.equals(ir.getSelectRule().getAreaSelectRule().getProvinceCode()))
                            .map(ir -> ir.getContent().getPrice()).findFirst();
                    if(frameOptional.isPresent()){
                        IncentiveRuleFrameDTO incentiveRuleFrame = JSONObject.parseObject(JSONObject.toJSONString(frameOptional.get()), IncentiveRuleFrameDTO.class);
                        aladdinCommLog.setReturnVal(incentiveRuleFrame);
                        AladdinLogUtil.log(log, aladdinCommLog);
                        return CnResult.succeed(incentiveRuleFrame);
                    }
                }
            }
            logContext.put("filter", "没有满足条件的政策实例");
            AladdinLogUtil.log(log, aladdinCommLog);
            return CnResult.succeed();
        } catch (Throwable e) {
            AladdinLogUtil.log(log, e, aladdinCommLog);
            throw e;
        }
    }

    @Override
    public CnResult<StaScalePolicyCoefficientDTO> queryStaScalePolicyByCollect(StaScalePolicyByCollectQueryRequest request) {
        AladdinCommLog aladdinCommLog = AladdinLogUtil.newCommLog(BizType.DEFAULT, "queryStaScalePolicyByCollect");
        Map<String,Object> logContext = Maps.newHashMap();
        aladdinCommLog.setParams(request);
        aladdinCommLog.setContext(logContext);
        try {
            ValidateUtil.validateAndThrow(request);
            String collectPointId = request.getCollectPointId();
            LocalDateTime policyDate = request.getPolicyDate();
            // 查询代收点的省市区
            CollectPointInfoDTO collectInfo = tseCollectPointManager.queryCollectInfo(collectPointId);
            AssertUtil.isTrue(null != collectInfo, "代收点不存在");

            // 查询政策
            List<PolicyTemplate> policyTemplates =
                    policyTemplateRepository.get(PolicyBizTypeEnum.SCALE.getType(), PolicyCustomTypeEnum.STATION.getType());
            Optional<PolicyTemplate> first = Optional.ofNullable(policyTemplates).orElse(Lists.newArrayList())
                    .stream().filter(pt -> pt.getStartTime().isBefore(policyDate) && pt.getEndTime().isAfter(policyDate)).findFirst();
            if(!first.isPresent()){
                logContext.put("filter", "政策模版不存在");
                AladdinLogUtil.log(log, aladdinCommLog);
                return CnResult.succeed();
            }

            Long templateId = first.get().getId();
            List<PolicyInstance> policyInstances = policyInstanceRepository.listByTemplate(templateId, IncentivePlanTypeEnum.BASIC.getType());
            if(CollectionUtils.isEmpty(policyInstances)){
                logContext.put("filter", "政策实例不存在");
                AladdinLogUtil.log(log, aladdinCommLog);
                return CnResult.succeed();
            }

            // 查询代收点标签
            List<String> tagPlanList = Optional.ofNullable(first.get().getLaunchPlan()).map(LaunchPlan::getRuleLaunch)
                    .map(RuleLaunch::getTagRuleLaunch).map(TagRuleLaunch::getTagCodeList).orElse(Lists.newArrayList());
            List<String> tagList = Lists.newArrayList();
            if(CollectionUtils.isNotEmpty(tagPlanList)){
                tagList = tseTagManager.queryCollectTag(collectPointId, tagPlanList);
                logContext.put("tagList", StringUtils.join(tagList, ","));
            }

            // 过滤政策实例子
            List<IncentiveRule> incentiveRuleList = Lists.newArrayList();
            for(PolicyInstance pi : policyInstances){
                if(!PolicyInstanceStatusEnum.EFFECT.getCode().equals(pi.getStatus())){
                    continue;
                }
                for(IncentiveRule ir : pi.getIncentiveRuleList()){
                    AreaSelectRule areaSelectRule = ir.getSelectRule().getAreaSelectRule();
                    TagSelectRule tagSelectRule = ir.getSelectRule().getTagSelectRule();
                    if(null == areaSelectRule
                            || !areaSelectRule.match(collectInfo.getProvinceCode(), collectInfo.getCityCode(), collectInfo.getDistrictCode())){
                        continue;
                    }
                    if(null != tagSelectRule && !tagSelectRule.match(tagList)){
                        continue;
                    }
                    incentiveRuleList.add(ir);
                }
            }

            if(CollectionUtils.isEmpty(incentiveRuleList)){
                logContext.put("filter", "不存在匹配的政策规则");
                AladdinLogUtil.log(log, aladdinCommLog);
                return CnResult.succeed();
            }

            IncentiveRule incentiveRule = incentiveRuleList.stream().sorted(Comparator.comparing(IncentiveRule::getPriority).reversed()).findFirst().get();
            List<IncentiveRuleCoefficientContent> coefficient = incentiveRule.getContent().getCoefficient();
            if(CollectionUtils.isEmpty(coefficient)){
                AladdinLogUtil.log(log, aladdinCommLog);
                return CnResult.succeed();
            }

            StaScalePolicyCoefficientDTO coefficientDTO = new StaScalePolicyCoefficientDTO();
            if(CollectionUtils.isNotEmpty(coefficient.get(0).getFrame().getResult())){
                coefficientDTO.setCoefficient(coefficient.get(0).getFrame().getResult().get(0).getVal());
            }
            coefficientDTO.setPolicyName(first.get().getTemplateName());
            coefficientDTO.setAoiBlank(tagList.contains("aoiBlank"));
            coefficientDTO.setAoiHighLevel(tagList.contains("aoiHighLevel"));
            coefficientDTO.setTempId(first.get().getId());
            aladdinCommLog.setReturnVal(coefficientDTO);
            AladdinLogUtil.log(log, aladdinCommLog);
            return CnResult.succeed(coefficientDTO);
        } catch (Throwable e) {
            AladdinLogUtil.log(log, e, aladdinCommLog);
            throw e;
        }
    }
}
