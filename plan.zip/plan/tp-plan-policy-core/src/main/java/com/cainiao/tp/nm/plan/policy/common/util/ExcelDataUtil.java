package com.cainiao.tp.nm.plan.policy.common.util;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.cainiao.tp.nm.plan.api.policy.application.dto.ExcelData;
import org.apache.commons.collections4.CollectionUtils;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


public class ExcelDataUtil {

    public static <T> T getData(List<ExcelData> dataList, Class<T> clazz) {
        JSONObject jsonObject = new JSONObject();
        for (ExcelData data : dataList) {
            jsonObject.put(data.getKey(), data.getData());
        }
        String jsonString = jsonObject.toJSONString();
        jsonObject.clear();
        return JSON.parseObject(jsonString, clazz);
    }


    public static Map<String, String> getData(List<ExcelData> dataList) {
        Map<String, String> map = new HashMap<>();
        for (ExcelData data : dataList) {
            map.put(data.getKey(), data.getData());
        }
        return map;
    }


    public static List<List<ExcelData>> toExcelData(List<Object> dataList) {
        if(CollectionUtils.isEmpty(dataList)){
            return Collections.emptyList();
        }
       return dataList.stream().map(dto->{
            JSONObject parse = (JSONObject)JSONObject.parse(JSON.toJSONString(dto));
           return parse.keySet().stream().map(key->new ExcelData(key, parse.getString(key))).collect(Collectors.toList());
        }).collect(Collectors.toList());
    }

}
