package com.cainiao.tp.nm.plan.policy.common.util;

import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.JobExecuteResultDTO;

/**
 * @Date 2025/6/6 11:11
 * @code desc: 定时任务执行结果工具类
 */
public class JobExecuteResultUtils {

    private static final ThreadLocal<JobExecuteResultDTO> EXECUTE_RESULT = new ThreadLocal<>();

    public static void init() {
        JobExecuteResultDTO jobExecuteResultDTO = EXECUTE_RESULT.get();
        if (null == jobExecuteResultDTO) {
            jobExecuteResultDTO = JobExecuteResultDTO.builder().build();
            EXECUTE_RESULT.set(jobExecuteResultDTO);
        }
    }

    public static JobExecuteResultDTO getResultDTO() {
        return EXECUTE_RESULT.get();
    }

    public static void remove() {
        EXECUTE_RESULT.remove();
    }


    public static void addSuccessCount() {
        JobExecuteResultDTO jobExecuteResultDTO = EXECUTE_RESULT.get();
        jobExecuteResultDTO.addSuccessCount();
    }

    public static void addExecuteSum() {
        JobExecuteResultDTO jobExecuteResultDTO = EXECUTE_RESULT.get();
        jobExecuteResultDTO.addExecuteSum();
    }

    public static void addFailCount() {
        JobExecuteResultDTO jobExecuteResultDTO = EXECUTE_RESULT.get();
        jobExecuteResultDTO.addFailCount();
    }

    public static void addIgnoreCount() {
        JobExecuteResultDTO jobExecuteResultDTO = EXECUTE_RESULT.get();
        jobExecuteResultDTO.addIgnoreCount();
    }

    public static void addFailCode(String code) {
        JobExecuteResultDTO jobExecuteResultDTO = EXECUTE_RESULT.get();
        jobExecuteResultDTO.add(code);
    }
}