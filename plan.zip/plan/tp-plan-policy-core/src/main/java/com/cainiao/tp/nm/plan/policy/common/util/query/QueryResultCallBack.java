package com.cainiao.tp.nm.plan.policy.common.util.query;


import java.util.List;

public interface QueryResultCallBack<T> {

    /**
     * 查询数据
     *
     * @param pageNum  page
     * @param pageSize 每页数量
     * @return return
     */
    List<T> query(int pageNum, int pageSize);
}
