package com.cainiao.tp.nm.plan.policy.common.util.query;

import com.google.common.collect.Lists;
import org.junit.Test;

import java.util.Collections;
import java.util.List;


public class BatchQueryUtilsTest {


    /**
     * 测试为空列表的情况
     * 期望：不进行任何处理，handle方法不会被调用
     */
    @Test
    public void testQueryUntilNoDataEmptyList() {
        List<String> testList = Lists.newArrayList("1");
        BatchQueryUtils.queryUntilNoData(testList, ( a)->{
        });
    }



    @Test
    public void testQueryUntilNoDataEmptyList1() {
        List<String> testList = Lists.newArrayList("1");
        BatchQueryUtils.queryUntilNoData(testList, ( a)->{
        },1);
    }


    @Test
    public void testQueryUntilNoDataEmptyList2() {
        BatchQueryUtils.queryUntilNoData((i,page)->{
            if(i==5){
                return Collections.emptyList();
            }
            return Lists.newArrayList(1);
        }, ( a)->{
        },1);
    }


    @Test
    public void testQueryUntilNoDataEmptyList3() {
        BatchQueryUtils.queryUntilNoData((i,page)->{
            if(i==5){
                return Collections.emptyList();
            }
            return Lists.newArrayList(1);
        }, ( a)->{
        },1,1);
    }

}