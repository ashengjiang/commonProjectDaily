package com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param;

import java.util.List;

import com.base.BaseTest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.LaunchPlanCreateRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.launchplan.AreaRuleLaunchVO;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

/**
 * <a href="https://alidocs.dingtalk.com/i/nodes/dpYLaezmVNRMGX56C1aKjlBOVrMqPxX6">单元测试编写&生成FAQ</a>
 * Created By Thub IDEA插件
 *
 * @Date 2025/6/11 16:56
 */
public class LaunchPlanCreateRequestTest extends BaseTest {

    @Mock
    private AreaRuleLaunchVO areaRuleLaunch;
    @Mock
    private List<String> tagCodeList;

    @Before
    public void setUp() throws Exception {MockitoAnnotations.openMocks(this);}

    @Test
    public void testValidate() {
        LaunchPlanCreateRequest launchPlanCreateRequest = new LaunchPlanCreateRequest();
        launchPlanCreateRequest.setLaunchType("rule");
        AreaRuleLaunchVO areaRuleLaunch = new AreaRuleLaunchVO();
        areaRuleLaunch.setNational(true);
        launchPlanCreateRequest.setAreaRuleLaunch(areaRuleLaunch);
        // Run the method to be tested
        launchPlanCreateRequest.validate();

        // Verify the result
    }
}