package com.cainiao.tp.nm.plan.policy.adaptor.convert;

import com.base.BaseTest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.station.heavy.AssessmentCardVO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.station.heavy.StationAssessmentVO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.station.heavy.StationIncentiveVO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.station.light.XnStationIncentiveCardVO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.station.light.XnStationIncentiveStatsVO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.heavy.*;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.light.*;
import com.google.common.collect.Lists;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import java.util.Collections;

public class StationIncentiveConvertTest extends BaseTest {


    @InjectMocks
    private StationIncentiveConvert stationIncentiveConvert;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);
    }

    /**
     * 测试正常处理逻辑
     */
    @Test
    public void testStationIncentiveVONormal() {
        // 准备方法入参
        StationIncentiveDTO dto = new StationIncentiveDTO();
        dto.setDataDate("2023-10-01");
        dto.setTip(new IncentiveTipDTO());
        dto.setCardList(Collections.singletonList(new IncentiveCardDTO()));
        dto.setResultFeedbackMsg(null);
        dto.setNotActiveStation(null);
        // 调用需要测试的方法
        StationIncentiveVO result = StationIncentiveConvert.stationIncentiveVO(dto);
//        Assert.assertNotNull(result);
    }

    @Test
    public void testStationIncentiveVODTOisNull() {
        // 准备方法入参

        // 调用需要测试的方法
        StationIncentiveVO result = StationIncentiveConvert.stationIncentiveVO(null);
        // 验证结果
//        Assert.assertNotNull(result);
    }

    @Test
    public void testStationIncentiveVODTO() {
        // 准备方法入参
        StationIncentiveDTO dto = new StationIncentiveDTO();
        dto.setDataDate("2023-10-01");
        dto.setTip(new IncentiveTipDTO());
        dto.setCardList(Collections.singletonList(new IncentiveCardDTO()));
        dto.setResultFeedbackMsg("不通过验证");
        dto.setNotActiveStation(null);
        // 调用需要测试的方法
        StationIncentiveVO result = StationIncentiveConvert.stationIncentiveVO(dto);
        // 验证结果
//        Assert.assertNotNull(result);
    }

    /**
     * 测试传入的DTO为null时, 返回VO的notActiveStation字段是否被设置为STATS_Y
     */
    @Test
    public void testConvertAssessmentVONullDTO() {
        StationAssessmentVO result = StationIncentiveConvert.convertAssessmentVO(null);
//        Assert.assertNotNull(result);
    }

    /**
     * 测试传入的DTO有数据时，检查属性是否复制正确
     */
    @Test
    public void testConvertAssessmentVOCopyProperties() {
        StationAssessmentDTO dto = new StationAssessmentDTO();
        dto.setResultFeedbackMsg("测试反馈信息");
        dto.setNotActiveStation("Y");
        dto.setIsPass(true);
        StationAssessmentVO result = StationIncentiveConvert.convertAssessmentVO(dto);
//        Assert.assertNotNull(result);
    }

    /**
     * 测试当输入参数dto为空时，应该返回null
     */
    @Test
    public void testConvertXnIncentiveVOWhenDtoIsNull() {
        XnStaPracticeIncentiveDTO dto = null;
        XnStationIncentiveCardVO result = StationIncentiveConvert.convertXnIncentiveVO(dto);
        // 确认返回结果为null
//        Assert.assertNull(result);
    }

    /**
     * 测试BeanUtils是否成功将dto中的属性复制到vo中
     */
    @Test
    public void testConvertXnIncentiveVOCopyProperties() {
        // 创建dto并设置属性值
        XnStaPracticeIncentiveDTO dto = new XnStaPracticeIncentiveDTO();
        dto.setNeedShow(true);
        dto.setAmount("100");
        dto.setOptCnt("5");
        // 执行转换
        XnStationIncentiveCardVO result = StationIncentiveConvert.convertXnIncentiveVO(dto);
        // 验证属性值是否正确复制
//        Assert.assertNotNull(result);
    }

    /**
     * 测试复制卡片活动统计属性到目标VO
     */
    @Test
    public void testConvertXnIncentiveStatsVOCopyActivityCardStats() {
        XnStaPracticeIncentiveStatsDetailDTO dto = new XnStaPracticeIncentiveStatsDetailDTO();
        dto.setActivityCardStats(new ActivityStatsDTO());
        dto.setBaseConditions(Lists.newArrayList(new ActivityConditionDTO()));
        dto.setFlexibleConditions(Lists.newArrayList(new ActivityConditionDTO()));
        dto.setOptCntHistory(Lists.newArrayList(new OptCntHistoryDTO()));
        dto.setNeedShow(true);
        ActivityStatsDTO activityStatsDTO = new ActivityStatsDTO();
        // 设置activityStatsDTO的属性
        dto.setActivityCardStats(activityStatsDTO);
        XnStationIncentiveStatsVO result = StationIncentiveConvert.convertXnIncentiveStatsVO(dto);
        // 验证复制的属性是否正确
//        Assert.assertNotNull(result);
    }

    /**
     * 测试 convertCard 方法，当 DTO 包含 items，且 item 包含 tags 和 extraInfo 时
     * 验证嵌套的 List 也能被正确转换和设置
     */
    @Test
    public void testConvertCardWithTagsAndExtraInfo() {
        AssessmentCardDTO dto = new AssessmentCardDTO();
        dto.setTitle("考核卡片标题");
        dto.setIsMeet(true);
        AssessmentCardDTO.Item item = new AssessmentCardDTO.Item();

        AssessmentCardDTO.Tag tag = new AssessmentCardDTO.Tag();

        AssessmentCardDTO.ExtraInfo extraInfo = new AssessmentCardDTO.ExtraInfo();

        item.setTags(Lists.newArrayList(tag));
        item.setExtraInfo(Lists.newArrayList(extraInfo));
        dto.setItems(Lists.newArrayList(item));
        AssessmentCardVO result = StationIncentiveConvert.convertCard(dto);
//        assertNotNull(result);
    }
}