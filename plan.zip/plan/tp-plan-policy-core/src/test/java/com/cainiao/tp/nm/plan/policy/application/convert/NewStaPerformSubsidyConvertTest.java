package com.cainiao.tp.nm.plan.policy.application.convert;

import com.base.BaseTest;
import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.aladdin.utils.DateUtil;
import com.cainiao.tp.nm.plan.api.policy.application.dto.StationDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.NewStaPerformSubsidyConfigDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.NewStaPerformSubsidyDataDTO;
import com.cainiao.tp.nm.plan.api.policy.common.constants.NewStaPerformSubsidyViewEnum;
import com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils;
import com.cainiao.tp.nm.plan.policy.application.dto.NewStaPerformSubsidyViewDTO;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.*;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;

public class NewStaPerformSubsidyConvertTest extends BaseTest {

    @Test
    public void testJudgeView_WhenStationIsNull_ShouldThrowException() {
        try (MockedStatic<DateUtil> dateUtilMocked = Mockito.mockStatic(DateUtil.class)) {
            // Arrange
            StationDTO stationDTO = null;
            List<NewStaPerformSubsidyDataDTO> subsidyData = new ArrayList<>();
            NewStaPerformSubsidyConfigDTO subsidyConfig = new NewStaPerformSubsidyConfigDTO();

            // Act & Assert
            Exception exception = assertThrows(RuntimeException.class, () -> {
                NewStaPerformSubsidyConvert.judgeView(stationDTO, subsidyData, subsidyConfig);
            });
            assertTrue(exception.getMessage().contains("站点不存在"));
        }
    }

    @Test
    public void testJudgeView_WhenBasicConditionNotMet_ShouldReturnNotAllowed() {
        try (MockedStatic<DateUtil> dateUtilMocked = Mockito.mockStatic(DateUtil.class)) {
            // Arrange
            StationDTO stationDTO = createMockStationDTO();
            List<NewStaPerformSubsidyDataDTO> subsidyData = new ArrayList<>();
            NewStaPerformSubsidyConfigDTO subsidyConfig = new NewStaPerformSubsidyConfigDTO();
            subsidyConfig.setStartDate("2023-01-01");
            subsidyConfig.setEndDate("2024-12-31");

            // Mock DateUtil.getStr2SDate to return dates that make the condition fail
            Date mockBeginDate = new Date(System.currentTimeMillis() + 86400000); // Future date
            Date mockEndDate = new Date(System.currentTimeMillis() + 172800000); // Even later date
            dateUtilMocked.when(() -> DateUtil.getStr2SDate(any(String.class))).thenReturn(mockBeginDate, mockEndDate);

            // Act
            NewStaPerformSubsidyViewDTO result = NewStaPerformSubsidyConvert.judgeView(stationDTO, subsidyData, subsidyConfig);

            // Assert
            assertEquals(NewStaPerformSubsidyViewEnum.NOT_ALLOW_PARTICIPATE.getCode(), result.getViewCode());
            assertEquals("抱歉，不符合新入驻站点条件，无法参与活动", result.getNotAllowMsg());
        }
    }

    @Test
    public void testJudgeView_WhenBasicConditionMet_ShouldReturnAllowParticipate() {
        StationDTO stationDTO = createMockStationDTOForAllConditionsMet();
        List<NewStaPerformSubsidyDataDTO> subsidyData = new ArrayList<>();
        NewStaPerformSubsidyConfigDTO subsidyConfig = new NewStaPerformSubsidyConfigDTO();
        subsidyConfig.setStartDate("2023-01-01 00:00:00");
        subsidyConfig.setEndDate("2026-07-01 00:00:00");
        subsidyConfig.setFy26Q4StartDate("2026-01-01 00:00:00");
        subsidyConfig.setFy27Q1StartDate("2026-04-01 00:00:00");
        subsidyConfig.setRuleDetailTop100CityCodeList(Arrays.asList("CITY_CODE"));
        NewStaPerformSubsidyViewDTO result = NewStaPerformSubsidyConvert.judgeView(stationDTO, subsidyData, subsidyConfig);
        assertEquals(NewStaPerformSubsidyViewEnum.NOT_CUMULA_SUBSIDY.getCode(), result.getViewCode());
    }

    @Test
    public void testJudgeView_WhenBasicConditionMet_ShouldReturnHasCumParticipate() {
        StationDTO stationDTO = createMockStationDTOForAllConditionsMet();
        // Set gmtCreate to one month ago
        Date gmtCreate = new Date(System.currentTimeMillis() - 86400000*31); // One day ago
        stationDTO.setGmtCreate(gmtCreate);
        List<NewStaPerformSubsidyDataDTO> subsidyData = new ArrayList<>();
        NewStaPerformSubsidyDataDTO subsidyDataDTO = new NewStaPerformSubsidyDataDTO();
        subsidyDataDTO.setIsRisk(false);
        subsidyDataDTO.setIsBlackStation(false);
        subsidyDataDTO.setIsSatisfied(true);
        subsidyDataDTO.setIsSatisfyBaseCondition(true);
        subsidyDataDTO.setIsDdAoiDirectStation(false);
        subsidyDataDTO.setIsHighQualityAoiEst("Y");
        subsidyDataDTO.setIsLightStationNew(true);
        subsidyDataDTO.setTheoreticalAmount(1000);
        subsidyData.add(subsidyDataDTO);
        NewStaPerformSubsidyConfigDTO subsidyConfig = new NewStaPerformSubsidyConfigDTO();
        subsidyConfig.setStartDate("2023-01-01 00:00:00");
        subsidyConfig.setEndDate("2026-04-01 00:00:00");
        subsidyConfig.setFy26Q4StartDate("2026-01-01 00:00:00");
        subsidyConfig.setRuleDetailTop100CityCodeList(Arrays.asList("CITY_CODE"));
        NewStaPerformSubsidyViewDTO result = NewStaPerformSubsidyConvert.judgeView(stationDTO, subsidyData, subsidyConfig);
        assertEquals(NewStaPerformSubsidyViewEnum.HAS_CUMULA_SUBSIDY.getCode(), result.getViewCode());
    }

    // Helper methods to create mock objects
    private StationDTO createMockStationDTO() {
        StationDTO stationDTO = new StationDTO();
        stationDTO.setGmtCreate(new Date());
        stationDTO.setCityCode("CITY_CODE");
        stationDTO.setFeatureMap(new HashMap<>());
        return stationDTO;
    }

    private StationDTO createMockStationDTOForFy26Q4() {
        StationDTO stationDTO = new StationDTO();
        Date gmtCreate = new Date(System.currentTimeMillis() + 86400000); // One day in the future, ensuring it's after FY26Q4 date
        stationDTO.setGmtCreate(gmtCreate);
        stationDTO.setCityCode("OTHER_CITY"); // Not in top100 city list
        stationDTO.setFeatureMap(new HashMap<>());
        return stationDTO;
    }

    private StationDTO createMockStationDTOForBasicConditionMet() {
        StationDTO stationDTO = new StationDTO();
        Date gmtCreate = new Date(System.currentTimeMillis() - 86400000); // One day ago
        stationDTO.setGmtCreate(gmtCreate);
        stationDTO.setCityCode("CITY_CODE");
        Map<String, String> featureMap = new HashMap<>();
        featureMap.put("station_type", "professional_station");
        stationDTO.setFeatureMap(featureMap);
        return stationDTO;
    }

    private StationDTO createMockStationDTOForAllConditionsMet() {
        StationDTO stationDTO = new StationDTO();
        Date gmtCreate = new Date(System.currentTimeMillis() - 86400000); // One day ago
        stationDTO.setGmtCreate(gmtCreate);
        stationDTO.setCityCode("CITY_CODE");
        Map<String, String> featureMap = new HashMap<>();
        featureMap.put("station_type", "professional_station");
        featureMap.put("blank_aoi_id", "some_blank_aoi_id"); // Satisfies build station condition
        stationDTO.setFeatureMap(featureMap);
        return stationDTO;
    }
}