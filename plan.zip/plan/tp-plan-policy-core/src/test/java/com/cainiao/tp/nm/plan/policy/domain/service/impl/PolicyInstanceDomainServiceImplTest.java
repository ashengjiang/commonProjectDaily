package com.cainiao.tp.nm.plan.policy.domain.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyInstanceCreateParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyTemplateCreateParam;
import com.cainiao.tp.nm.plan.policy.domain.component.DefaultPolicyInstanceDefinitionImpl;
import com.cainiao.tp.nm.plan.policy.domain.component.factory.PolicyInstanceDefinitionFactory;
import com.cainiao.tp.nm.plan.policy.domain.model.PolicyInstance;
import com.cainiao.tp.nm.plan.policy.domain.model.PolicyTemplate;
import com.cainiao.tp.nm.plan.policy.domain.repository.PolicyInstanceRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class PolicyInstanceDomainServiceImplTest {

    @InjectMocks
    private PolicyInstanceDomainServiceImpl policyInstanceDomainService;

    @Mock
    private PolicyInstanceDefinitionFactory policyInstanceDefinitionFactory;

    @Mock
    protected PolicyInstanceRepository policyInstanceRepository;


    /**
     * 测试创建政策实例成功的场景
     */
    @Test
    public void testCreateInstanceSuccess() {
        // 准备测试数据
        String temParam = "{\"bizType\":\"scale\",\"customType\":\"station\",\"endTimeStr\":\"2025-08-30\",\"featureMap\":{\"effectOpportunity\":\"assign\"},\"incentivePlanList\":[{\"content\":{\"coefficient\":[{\"code\":\"basic\",\"frame\":{\"result\":[{\"code\":\"basic\",\"name\":\"默认\",\"resultLimit\":{\"canUpdate\":false},\"val\":\"1.0\"}]},\"name\":\"默认系数\"}],\"selectPlan\":{\"areaSelectPlan\":{\"cityCodeList\":[\"330100\"],\"national\":false,\"provinceCodeList\":[\"330000\"]}}},\"incentivePlanCode\":\"ceshi111test1\",\"incentivePlanType\":\"basic\",\"planName\":\"基础激励\"},{\"content\":{\"coefficient\":[{\"code\":\"basic\",\"frame\":{\"children\":[{\"arithLogic\":\"=\",\"factorCode\":\"stationType\",\"factorName\":\"站点类型\",\"factorResult\":{\"fixedVal\":\"non_station\",\"type\":\"fixed\"},\"incentiveFactorLimit\":{\"canUpdate\":false},\"result\":[{\"code\":\"basic\",\"name\":\"默认\",\"resultLimit\":{\"canUpdate\":true,\"limitType\":\"option\",\"optionLimit\":{\"optionList\":[\"0.6\",\"0.8\",\"1.0\",\"1.2\"]}}}]},{\"arithLogic\":\"=\",\"factorCode\":\"stationType\",\"factorName\":\"站点类型\",\"factorResult\":{\"fixedVal\":\"light_station\",\"type\":\"fixed\"},\"incentiveFactorLimit\":{\"canUpdate\":false},\"result\":[{\"code\":\"basic\",\"name\":\"默认\",\"resultLimit\":{\"canUpdate\":true,\"limitType\":\"option\",\"optionLimit\":{\"optionList\":[\"0.6\",\"0.8\",\"1.0\",\"1.2\"]}}}]},{\"arithLogic\":\"=\",\"factorCode\":\"stationType\",\"factorName\":\"站点类型\",\"factorResult\":{\"fixedVal\":\"normal_station\",\"type\":\"fixed\"},\"incentiveFactorLimit\":{\"canUpdate\":false},\"result\":[{\"code\":\"basic\",\"name\":\"默认\",\"resultLimit\":{\"canUpdate\":true,\"limitType\":\"option\",\"optionLimit\":{\"optionList\":[\"0.6\",\"0.8\",\"1.0\",\"1.2\"]}}}]}]},\"name\":\"默认系数\"}],\"selectPlan\":{\"areaSelectPlan\":{\"cityCodeList\":[\"330100\"],\"national\":false,\"provinceCodeList\":[\"330000\"]}}},\"incentivePlanCode\":\"ceshi111test2\",\"incentivePlanType\":\"flexible\",\"planName\":\"灵活激励\"}],\"launchPlan\":{\"launchType\":\"rule\",\"ruleLaunch\":{\"areaRuleLaunch\":{\"cityCodeList\":[\"330100\"],\"national\":false,\"provinceCodeList\":[\"330000\"]}}},\"operatorId\":303544,\"startTimeStr\":\"2025-07-01\",\"templateName\":\"建宇测试1\"}";
        String para ="{\"featureMap\":{\"effectOpportunity\":\"pass_morrow\"},\"fillList\":[{\"coefficientFill\":[{\"code\":\"basic\",\"fillMap\":{\"stationType2_basic_result\":{\"fixedVal\":\"1.0\",\"type\":\"fixed\"},\"stationType0_basic_result\":{\"fixedVal\":\"0.6\",\"type\":\"fixed\"},\"stationType1_basic_result\":{\"fixedVal\":\"0.8\",\"type\":\"fixed\"}}}],\"selectRule\":{\"areaSelectRule\":{\"cityCode\":\"330100\",\"districtCode\":\"330110\",\"provinceCode\":\"330000\"}}}],\"incentivePlanType\":\"flexible\",\"operatorId\":303544,\"templateId\":30}";
        PolicyTemplate template = PolicyTemplate.create(JSONObject.parseObject(temParam, PolicyTemplateCreateParam.class));
        PolicyInstanceCreateParam param = JSONObject.parseObject(para, PolicyInstanceCreateParam.class);

        // Mock方法
        DefaultPolicyInstanceDefinitionImpl policyInstanceDefinition = new DefaultPolicyInstanceDefinitionImpl();
        ReflectionTestUtils.setField(policyInstanceDefinition, "policyInstanceRepository", policyInstanceRepository);
        when(policyInstanceDefinitionFactory.getDefinition(any(), any())).thenReturn(policyInstanceDefinition);

        // 调用方法
        PolicyInstance instance = policyInstanceDomainService.createInstance(template, param);

        instance.effect();

        // 验证结果
        assertNotNull(instance);
        verify(policyInstanceDefinitionFactory).getDefinition(template.getBizType(), template.getCustomType());
    }


}