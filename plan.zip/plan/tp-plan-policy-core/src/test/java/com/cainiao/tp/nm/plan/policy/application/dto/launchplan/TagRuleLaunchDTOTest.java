package com.cainiao.tp.nm.plan.api.policy.application.dto.launchplan;

import java.util.Arrays;

import com.base.BaseTest;
import com.cainiao.aladdin.exception.AladdinParamException;
import com.cainiao.tp.nm.plan.api.policy.application.dto.launchplan.TagRuleLaunchDTO;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.MockitoAnnotations;

/**
 * <a href="https://alidocs.dingtalk.com/i/nodes/dpYLaezmVNRMGX56C1aKjlBOVrMqPxX6">单元测试编写&生成FAQ</a>
 * Created By Thub IDEA插件
 *
 * @Date 2025/6/4 16:46
 */
public class TagRuleLaunchDTOTest extends BaseTest {


    @Before
    public void setUp() throws Exception {MockitoAnnotations.openMocks(this);}

    @Test
    public void testValidate() {
        TagRuleLaunchDTO tagRuleLaunchDTO = new TagRuleLaunchDTO();
        try {
            tagRuleLaunchDTO.validate();
        }catch (AladdinParamException e){
            Assert.assertEquals("tagCodeList不能为空", e.getMessage());
        }
        tagRuleLaunchDTO.setTagCodeList(Arrays.asList("code1"));
        tagRuleLaunchDTO.validate();
    }
}