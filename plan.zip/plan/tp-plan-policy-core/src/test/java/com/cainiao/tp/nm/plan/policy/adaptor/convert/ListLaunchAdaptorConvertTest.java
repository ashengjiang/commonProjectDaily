package com.cainiao.tp.nm.plan.policy.adaptor.convert;

import java.util.Arrays;

import com.base.BaseTest;
import com.cainiao.tp.nm.plan.api.policy.application.dto.launchplan.ListLaunchDTO;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

/**
 * <a href="https://alidocs.dingtalk.com/i/nodes/dpYLaezmVNRMGX56C1aKjlBOVrMqPxX6">单元测试编写&生成FAQ</a>
 * Created By Thub IDEA插件
 *
 * @Date 2025/6/11 18:55
 */
public class ListLaunchAdaptorConvertTest extends BaseTest {

    @InjectMocks
    private ListLaunchAdaptorConvert listLaunchAdaptorConvert;

    @Before
    public void setUp() throws Exception {MockitoAnnotations.openMocks(this);}

    @Test
    public void testTagListToDto() {
        // Prepare method arguments

        // Run the method to be tested
        ListLaunchDTO result = ListLaunchAdaptorConvert.tagListToDto(Arrays.asList("code1","code2"), "station","sign_protocol");

        // Verify the result
        Assert.assertNotNull(result);
        Assert.assertNotNull(result.getItemLaunch());
        Assert.assertEquals(2, result.getItemLaunch().size());
        Assert.assertEquals("code1", result.getItemLaunch().get(0).getAttrValue());
        Assert.assertEquals("station", result.getItemLaunch().get(0).getType());
        Assert.assertEquals("sign_protocol", result.getItemLaunch().get(0).getAttrCode());
        Assert.assertEquals("code2", result.getItemLaunch().get(1).getAttrValue());
        Assert.assertEquals("station", result.getItemLaunch().get(1).getType());
        Assert.assertEquals("sign_protocol", result.getItemLaunch().get(1).getAttrCode());


    }
}