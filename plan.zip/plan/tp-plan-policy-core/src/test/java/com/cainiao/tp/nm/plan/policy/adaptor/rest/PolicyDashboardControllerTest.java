package com.cainiao.tp.nm.plan.policy.adaptor.rest;

import com.cainiao.sutee.commons.restful.result.CnRestResult;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.PolicyInstanceQueryRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.PolicyInstanceRuleHistoryQueryRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.PolicyTemplateDashboardQueryRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.BaseTableVO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.PolicyStatisticsVO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.PolicyTemplateDetailVO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyInstanceRuleDetailDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyInstanceStatisticsDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyTemplateDetailDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.base.BaseTableDTO;
import com.cainiao.tp.nm.plan.api.policy.application.service.dashboard.PolicyDashboardAppService;
import com.google.common.collect.Lists;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.List;

import static com.cainiao.tp.nm.plan.policy.application.convert.PolicyInstanceRuleApplicationConvert.buildRuleColumn;
import static org.mockito.Mockito.any;


@RunWith(MockitoJUnitRunner.class)
public class PolicyDashboardControllerTest {

    @InjectMocks
    private PolicyDashboardController policyDashboardController;
    @Mock
    private PolicyDashboardAppService policyDashboardAppService;


    @Test
    public void testQueryPolicyInstanceDetail() {
        PolicyTemplateDashboardQueryRequest request = new PolicyTemplateDashboardQueryRequest();
        request.setPolicyType("scale");
        PolicyTemplateDetailDTO policyTemplateDetailDTO = new PolicyTemplateDetailDTO();
        policyTemplateDetailDTO.setId(1L);
        policyTemplateDetailDTO.setName("测试政策实例详情");
        policyTemplateDetailDTO.setLabel("测试政策实例详情");
        policyTemplateDetailDTO.setValue("1");
        policyTemplateDetailDTO.setCustomerType("scale");
        policyTemplateDetailDTO.setCustomerTypeName("station");
        policyTemplateDetailDTO.setStartDate("2023-01-01");
        policyTemplateDetailDTO.setEndDate("2023-01-01");
        Mockito.when(policyDashboardAppService.queryPolicyInstanceDetail(any(), any())).thenReturn(Lists.newArrayList(policyTemplateDetailDTO));
        CnRestResult<List<PolicyTemplateDetailVO>> result = policyDashboardController.queryPolicyInstanceDetail(request);
        Assert.assertNotNull(result);
        Assert.assertTrue(result.isSuccess());
    }

    @Test
    public void testQueryPolicyInstanceDetailWithNullDetail() {
        PolicyTemplateDashboardQueryRequest request = new PolicyTemplateDashboardQueryRequest();
        request.setPolicyType("scale");
        Mockito.when(policyDashboardAppService.queryPolicyInstanceDetail(any(), any())).thenReturn(Lists.newArrayList());
        CnRestResult<List<PolicyTemplateDetailVO>> result = policyDashboardController.queryPolicyInstanceDetail(request);
        Assert.assertNotNull(result);
        Assert.assertTrue(result.isSuccess());
    }

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testQueryPolicyInstanceStatistics() {
        PolicyInstanceQueryRequest request = new PolicyInstanceQueryRequest();
        request.setPolicyTemplateId(1L);
        PolicyInstanceStatisticsDTO statisticsDTO = new PolicyInstanceStatisticsDTO();
        statisticsDTO.setTitle("xxx");
        statisticsDTO.setValue("1");
        statisticsDTO.setUrl("1");
        Mockito.when(policyDashboardAppService.queryPolicyInstanceStatistics(any(), any())).thenReturn(Lists.newArrayList(statisticsDTO));
        CnRestResult<List<PolicyStatisticsVO>> result = policyDashboardController.queryPolicyInstanceStatistics(request);
        Assert.assertNotNull(result);
        Assert.assertTrue(result.isSuccess());
    }

    @Test
    public void testQueryPolicyInstanceStatisticsWithNullStatistics() {
        PolicyInstanceQueryRequest request = new PolicyInstanceQueryRequest();
        request.setPolicyTemplateId(1L);
        Mockito.when(policyDashboardAppService.queryPolicyInstanceStatistics(any(), any())).thenReturn(Lists.newArrayList());
        CnRestResult<List<PolicyStatisticsVO>> result = policyDashboardController.queryPolicyInstanceStatistics(request);
        Assert.assertNotNull(result);
        Assert.assertTrue(result.isSuccess());
    }

    @Test
    public void testQueryApprovedPolicyInstanceItem() {

        PolicyInstanceQueryRequest request = new PolicyInstanceQueryRequest();
        request.setPolicyTemplateId(1L);
        request.setCustomType("station");
        BaseTableDTO tableDTO = new BaseTableDTO();
        tableDTO.setColumns(buildRuleColumn(request.getCustomType()));
        tableDTO.setDataSource(Lists.newArrayList(new PolicyInstanceRuleDetailDTO()));
        Mockito.when(policyDashboardAppService.queryApprovedPolicyInstanceRule(any(), any()))
                .thenReturn(tableDTO);
        CnRestResult<BaseTableVO> result = policyDashboardController.queryApprovedPolicyInstanceItem(request);
        Assert.assertNotNull(result);
        Assert.assertTrue(result.isSuccess());
    }

    @Test
    public void testQueryApprovedPolicyInstanceItemWithNullItem() {

        PolicyInstanceQueryRequest request = new PolicyInstanceQueryRequest();
        request.setPolicyTemplateId(1L);
        request.setCustomType("station");
        Mockito.when(policyDashboardAppService.queryApprovedPolicyInstanceRule(any(), any()))
                .thenReturn(null);
        CnRestResult<BaseTableVO> result = policyDashboardController.queryApprovedPolicyInstanceItem(request);
        Assert.assertNotNull(result);
        Assert.assertTrue(result.isSuccess());
    }


    @Test
    public void testQueryPolicyInstanceItemReportHistory() {

        PolicyInstanceRuleHistoryQueryRequest request = new PolicyInstanceRuleHistoryQueryRequest();
        request.setPolicyTemplateId(1L);
        request.setCustomType("station");
        BaseTableDTO tableDTO = new BaseTableDTO();
        tableDTO.setColumns(buildRuleColumn(request.getCustomType()));
        tableDTO.setDataSource(Lists.newArrayList(new PolicyInstanceRuleDetailDTO()));
        Mockito.when(policyDashboardAppService.queryPolicyInstanceInstanceRuleReportHistory(any(), any()))
                .thenReturn(tableDTO);
        CnRestResult<BaseTableVO> result = policyDashboardController.queryPolicyInstanceItemReportHistory(request);
        Assert.assertNotNull(result);
        Assert.assertTrue(result.isSuccess());
    }

    @Test
    public void testQueryPolicyInstanceItemReportHistoryWithNullItem() {

        PolicyInstanceRuleHistoryQueryRequest request = new PolicyInstanceRuleHistoryQueryRequest();
        request.setPolicyTemplateId(1L);
        request.setCustomType("station");
        Mockito.when(policyDashboardAppService.queryPolicyInstanceInstanceRuleReportHistory(any(), any()))
                .thenReturn(null);
        CnRestResult<BaseTableVO> result = policyDashboardController.queryPolicyInstanceItemReportHistory(request);
        Assert.assertNotNull(result);
        Assert.assertTrue(result.isSuccess());
    }
}