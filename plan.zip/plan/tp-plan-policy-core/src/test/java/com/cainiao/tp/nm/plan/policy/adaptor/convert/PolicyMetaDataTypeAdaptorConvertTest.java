package com.cainiao.tp.nm.plan.policy.adaptor.convert;

import java.util.List;

import com.base.BaseTest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.PolicyMetaDataTypeVO;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

/**
 * <a href="https://alidocs.dingtalk.com/i/nodes/dpYLaezmVNRMGX56C1aKjlBOVrMqPxX6">单元测试编写&生成FAQ</a>
 * Created By Thub IDEA插件
 *
 * @Date 2025/6/5 18:14
 */
public class PolicyMetaDataTypeAdaptorConvertTest extends BaseTest {

    @InjectMocks
    private PolicyMetaDataTypeAdaptorConvert policyMetaDataTypeAdaptorConvert;

    @Before
    public void setUp() throws Exception {MockitoAnnotations.openMocks(this);}

    @Test
    public void testSelectPolicyCustomTypeList() {
        // Run the method to be tested
        List<PolicyMetaDataTypeVO> result = PolicyMetaDataTypeAdaptorConvert.selectPolicyCustomTypeList();

        Assert.assertNotNull(result);
        Assert.assertEquals(2, result.size());
    }

    @Test
    public void testSelectPolicyBizTypeList() {
        // Run the method to be tested
        List<PolicyMetaDataTypeVO> result = PolicyMetaDataTypeAdaptorConvert.selectPolicyBizTypeList();

        // Verify the result
        Assert.assertNotNull(result);
        Assert.assertEquals(1, result.size());
    }

    @Test
    public void testSelectLaunchTypeList(){
        // Run the method to be tested
        List<PolicyMetaDataTypeVO> result = PolicyMetaDataTypeAdaptorConvert.selectLaunchTypeList();

        // Verify the result
        Assert.assertNotNull(result);
        Assert.assertEquals(2, result.size());
    }
}