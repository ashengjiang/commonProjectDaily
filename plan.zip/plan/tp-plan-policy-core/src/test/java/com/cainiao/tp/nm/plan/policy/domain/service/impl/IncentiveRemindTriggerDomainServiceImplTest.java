package com.cainiao.tp.nm.plan.policy.domain.service.impl;

import com.cainiao.tp.nm.plan.api.policy.application.dto.IncentiveRemindHolder;
import com.cainiao.tp.nm.plan.policy.domain.service.IncentiveRemindTriggerDomainService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockedStatic;
import org.mockito.junit.MockitoJUnitRunner;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

/**
 * վ��ʵ�ټ����������ʹ����ռ����������ʵ�ֵ�Ԫ����
 *
 * @date 2026-03-27
 */
@RunWith(MockitoJUnitRunner.class)
public class IncentiveRemindTriggerDomainServiceImplTest {

    private IncentiveRemindTriggerDomainService service;

    private static final LocalDate TEST_JOIN_DATE = LocalDate.of(2026, 3, 15);
    private static final LocalDate TEST_TODAY = LocalDate.of(2026, 4, 8);

    @Before
    public void setUp() {
        service = new IncentiveRemindTriggerDomainServiceImpl();
    }

    // ========== calcAssessMonthOffset ���� ==========

    /**
     * ���Գ�����T�£���פ���£�
     */
    @Test
    public void testCalcAssessMonthOffset_TMonth() {
        try (MockedStatic<IncentiveRemindHolder> mockedHolder = mockStatic(IncentiveRemindHolder.class)) {
            IncentiveRemindHolder holder = mock(IncentiveRemindHolder.class);
            when(holder.getMaxAssessMonthOffsetValue()).thenReturn(3);
            mockedHolder.when(IncentiveRemindHolder::getINSTANCE).thenReturn(holder);

            int result = service.calcAssessMonthOffset(TEST_JOIN_DATE, TEST_TODAY);

            assertEquals("T��ƫ����ӦΪ 1", 1, result);
        }
    }

    /**
     * ���Գ�����T+1��
     */
    @Test
    public void testCalcAssessMonthOffset_T1Month() {
        LocalDate today = LocalDate.of(2026, 4, 15);
        try (MockedStatic<IncentiveRemindHolder> mockedHolder = mockStatic(IncentiveRemindHolder.class)) {
            IncentiveRemindHolder holder = mock(IncentiveRemindHolder.class);
            when(holder.getMaxAssessMonthOffsetValue()).thenReturn(3);
            mockedHolder.when(IncentiveRemindHolder::getINSTANCE).thenReturn(holder);

            int result = service.calcAssessMonthOffset(TEST_JOIN_DATE, today);

            assertEquals("T+1��ƫ����ӦΪ 1", 1, result);
        }
    }

    /**
     * ���Գ�����T+2��
     */
    @Test
    public void testCalcAssessMonthOffset_T2Month() {
        LocalDate today = LocalDate.of(2026, 5, 15);
        try (MockedStatic<IncentiveRemindHolder> mockedHolder = mockStatic(IncentiveRemindHolder.class)) {
            IncentiveRemindHolder holder = mock(IncentiveRemindHolder.class);
            when(holder.getMaxAssessMonthOffsetValue()).thenReturn(3);
            mockedHolder.when(IncentiveRemindHolder::getINSTANCE).thenReturn(holder);

            int result = service.calcAssessMonthOffset(TEST_JOIN_DATE, today);

            assertEquals("T+2��ƫ����ӦΪ 2", 2, result);
        }
    }

    /**
     * ���Գ�����T+3��
     */
    @Test
    public void testCalcAssessMonthOffset_T3Month() {
        LocalDate today = LocalDate.of(2026, 6, 15);
        try (MockedStatic<IncentiveRemindHolder> mockedHolder = mockStatic(IncentiveRemindHolder.class)) {
            IncentiveRemindHolder holder = mock(IncentiveRemindHolder.class);
            when(holder.getMaxAssessMonthOffsetValue()).thenReturn(3);
            mockedHolder.when(IncentiveRemindHolder::getINSTANCE).thenReturn(holder);

            int result = service.calcAssessMonthOffset(TEST_JOIN_DATE, today);

            assertEquals("T+3��ƫ����ӦΪ 3", 3, result);
        }
    }

    /**
     * ���Գ��������������ڣ�T+4�£�
     */
    @Test
    public void testCalcAssessMonthOffset_ExceedMaxMonth() {
        LocalDate today = LocalDate.of(2026, 7, 15);
        try (MockedStatic<IncentiveRemindHolder> mockedHolder = mockStatic(IncentiveRemindHolder.class)) {
            IncentiveRemindHolder holder = mock(IncentiveRemindHolder.class);
            when(holder.getMaxAssessMonthOffsetValue()).thenReturn(3);
            mockedHolder.when(IncentiveRemindHolder::getINSTANCE).thenReturn(holder);

            int result = service.calcAssessMonthOffset(TEST_JOIN_DATE, today);

            assertEquals("����������Ӧ���� -1", -1, result);
        }
    }

    /**
     * ���Գ�������פ������δ������ƫ������
     */
    @Test
    public void testCalcAssessMonthOffset_NegativeOffset() {
        LocalDate today = LocalDate.of(2026, 2, 15);
        try (MockedStatic<IncentiveRemindHolder> mockedHolder = mockStatic(IncentiveRemindHolder.class)) {
            IncentiveRemindHolder holder = mock(IncentiveRemindHolder.class);
            when(holder.getMaxAssessMonthOffsetValue()).thenReturn(3);
            mockedHolder.when(IncentiveRemindHolder::getINSTANCE).thenReturn(holder);

            int result = service.calcAssessMonthOffset(TEST_JOIN_DATE, today);

            assertEquals("��ƫ����Ӧ���� -1", -1, result);
        }
    }

    /**
     * ���Գ�����T+3�³������������
     */
    @Test
    public void testCalcAssessMonthOffset_T3MonthExceedLastTriggerDay() {
        LocalDate today = LocalDate.of(2026, 6, 20);
        try (MockedStatic<IncentiveRemindHolder> mockedHolder = mockStatic(IncentiveRemindHolder.class)) {
            IncentiveRemindHolder holder = mock(IncentiveRemindHolder.class);
            when(holder.getMaxAssessMonthOffsetValue()).thenReturn(3);
            when(holder.getT3TriggerDayList()).thenReturn(Arrays.asList(10, 15));
            mockedHolder.when(IncentiveRemindHolder::getINSTANCE).thenReturn(holder);

            int result = service.calcAssessMonthOffset(TEST_JOIN_DATE, today);

            assertEquals("�������������Ӧ���� -1", -1, result);
        }
    }

    /**
     * ���Գ�����T+3��δ�������������
     */
    @Test
    public void testCalcAssessMonthOffset_T3MonthNotExceedLastTriggerDay() {
        LocalDate today = LocalDate.of(2026, 6, 15);
        try (MockedStatic<IncentiveRemindHolder> mockedHolder = mockStatic(IncentiveRemindHolder.class)) {
            IncentiveRemindHolder holder = mock(IncentiveRemindHolder.class);
            when(holder.getMaxAssessMonthOffsetValue()).thenReturn(3);
            when(holder.getT3TriggerDayList()).thenReturn(Arrays.asList(10, 15, 20));
            mockedHolder.when(IncentiveRemindHolder::getINSTANCE).thenReturn(holder);

            int result = service.calcAssessMonthOffset(TEST_JOIN_DATE, today);

            assertEquals("δ�������������Ӧ���� 3", 3, result);
        }
    }

    /**
     * ���Գ�����T+3���������б�Ϊ��
     */
    @Test
    public void testCalcAssessMonthOffset_T3TriggerDayListEmpty() {
        LocalDate today = LocalDate.of(2026, 6, 15);
        try (MockedStatic<IncentiveRemindHolder> mockedHolder = mockStatic(IncentiveRemindHolder.class)) {
            IncentiveRemindHolder holder = mock(IncentiveRemindHolder.class);
            when(holder.getMaxAssessMonthOffsetValue()).thenReturn(3);
            when(holder.getT3TriggerDayList()).thenReturn(Collections.emptyList());
            mockedHolder.when(IncentiveRemindHolder::getINSTANCE).thenReturn(holder);

            int result = service.calcAssessMonthOffset(TEST_JOIN_DATE, today);

            assertEquals("T3�������б�Ϊ��Ӧ���� -1", -1, result);
        }
    }

    // ========== isTriggerDay ���� ==========

    /**
     * ���Գ�����T��������ƥ��
     */
    @Test
    public void testIsTriggerDay_TMonth_Match() {
        LocalDate today = LocalDate.of(2026, 3, 20);
        try (MockedStatic<IncentiveRemindHolder> mockedHolder = mockStatic(IncentiveRemindHolder.class)) {
            IncentiveRemindHolder holder = mock(IncentiveRemindHolder.class);
            when(holder.getMaxAssessMonthOffsetValue()).thenReturn(3);
            when(holder.getTMonthDayOffsetList()).thenReturn(Arrays.asList(5));
            mockedHolder.when(IncentiveRemindHolder::getINSTANCE).thenReturn(holder);

            boolean result = service.isTriggerDay(TEST_JOIN_DATE, today);

            assertTrue("T��������Ӧƥ��", result);
        }
    }

    /**
     * ���Գ�����T�������ղ�ƥ��
     */
    @Test
    public void testIsTriggerDay_TMonth_NotMatch() {
        LocalDate today = LocalDate.of(2026, 3, 25);
        try (MockedStatic<IncentiveRemindHolder> mockedHolder = mockStatic(IncentiveRemindHolder.class)) {
            IncentiveRemindHolder holder = mock(IncentiveRemindHolder.class);
            when(holder.getMaxAssessMonthOffsetValue()).thenReturn(3);
            when(holder.getTMonthDayOffsetList()).thenReturn(Arrays.asList(5));
            mockedHolder.when(IncentiveRemindHolder::getINSTANCE).thenReturn(holder);

            boolean result = service.isTriggerDay(TEST_JOIN_DATE, today);

            assertFalse("T�������ղ�Ӧƥ��", result);
        }
    }

    /**
     * ���Գ�����T�������ճ����������һ��
     */
    @Test
    public void testIsTriggerDay_TMonth_ExceedLastDay() {
        LocalDate joinDate = LocalDate.of(2026, 3, 30);
        LocalDate today = LocalDate.of(2026, 3, 31);
        try (MockedStatic<IncentiveRemindHolder> mockedHolder = mockStatic(IncentiveRemindHolder.class)) {
            IncentiveRemindHolder holder = mock(IncentiveRemindHolder.class);
            when(holder.getMaxAssessMonthOffsetValue()).thenReturn(3);
            when(holder.getTMonthDayOffsetList()).thenReturn(Arrays.asList(5));
            mockedHolder.when(IncentiveRemindHolder::getINSTANCE).thenReturn(holder);

            boolean result = service.isTriggerDay(joinDate, today);

            assertTrue("�����������һ��Ӧȡ���һ��", result);
        }
    }

    /**
     * ���Գ�����T+1��������ƥ��
     */
    @Test
    public void testIsTriggerDay_T1Month_Match() {
        LocalDate today = LocalDate.of(2026, 4, 10);
        try (MockedStatic<IncentiveRemindHolder> mockedHolder = mockStatic(IncentiveRemindHolder.class)) {
            IncentiveRemindHolder holder = mock(IncentiveRemindHolder.class);
            when(holder.getMaxAssessMonthOffsetValue()).thenReturn(3);
            when(holder.getT1T2TriggerDayList()).thenReturn(Arrays.asList(10, 20));
            mockedHolder.when(IncentiveRemindHolder::getINSTANCE).thenReturn(holder);

            boolean result = service.isTriggerDay(TEST_JOIN_DATE, today);

            assertTrue("T+1��������Ӧƥ��", result);
        }
    }

    /**
     * ���Գ�����T+1�������ղ�ƥ��
     */
    @Test
    public void testIsTriggerDay_T1Month_NotMatch() {
        LocalDate today = LocalDate.of(2026, 4, 15);
        try (MockedStatic<IncentiveRemindHolder> mockedHolder = mockStatic(IncentiveRemindHolder.class)) {
            IncentiveRemindHolder holder = mock(IncentiveRemindHolder.class);
            when(holder.getMaxAssessMonthOffsetValue()).thenReturn(3);
            when(holder.getT1T2TriggerDayList()).thenReturn(Arrays.asList(10, 20));
            mockedHolder.when(IncentiveRemindHolder::getINSTANCE).thenReturn(holder);

            boolean result = service.isTriggerDay(TEST_JOIN_DATE, today);

            assertFalse("T+1�������ղ�Ӧƥ��", result);
        }
    }

    /**
     * ���Գ�����T+2��������ƥ��
     */
    @Test
    public void testIsTriggerDay_T2Month_Match() {
        LocalDate today = LocalDate.of(2026, 5, 20);
        try (MockedStatic<IncentiveRemindHolder> mockedHolder = mockStatic(IncentiveRemindHolder.class)) {
            IncentiveRemindHolder holder = mock(IncentiveRemindHolder.class);
            when(holder.getMaxAssessMonthOffsetValue()).thenReturn(3);
            when(holder.getT1T2TriggerDayList()).thenReturn(Arrays.asList(10, 20));
            mockedHolder.when(IncentiveRemindHolder::getINSTANCE).thenReturn(holder);

            boolean result = service.isTriggerDay(TEST_JOIN_DATE, today);

            assertTrue("T+2��������Ӧƥ��", result);
        }
    }

    /**
     * ���Գ�����T+3��������ƥ��
     */
    @Test
    public void testIsTriggerDay_T3Month_Match() {
        LocalDate today = LocalDate.of(2026, 6, 15);
        try (MockedStatic<IncentiveRemindHolder> mockedHolder = mockStatic(IncentiveRemindHolder.class)) {
            IncentiveRemindHolder holder = mock(IncentiveRemindHolder.class);
            when(holder.getMaxAssessMonthOffsetValue()).thenReturn(3);
            when(holder.getT3TriggerDayList()).thenReturn(Arrays.asList(10, 15, 20));
            mockedHolder.when(IncentiveRemindHolder::getINSTANCE).thenReturn(holder);

            boolean result = service.isTriggerDay(TEST_JOIN_DATE, today);

            assertTrue("T+3��������Ӧƥ��", result);
        }
    }

    /**
     * ���Գ�����T+3�������ղ�ƥ��
     */
    @Test
    public void testIsTriggerDay_T3Month_NotMatch() {
        LocalDate today = LocalDate.of(2026, 6, 25);
        try (MockedStatic<IncentiveRemindHolder> mockedHolder = mockStatic(IncentiveRemindHolder.class)) {
            IncentiveRemindHolder holder = mock(IncentiveRemindHolder.class);
            when(holder.getMaxAssessMonthOffsetValue()).thenReturn(3);
            when(holder.getT3TriggerDayList()).thenReturn(Arrays.asList(10, 15, 20));
            mockedHolder.when(IncentiveRemindHolder::getINSTANCE).thenReturn(holder);

            boolean result = service.isTriggerDay(TEST_JOIN_DATE, today);

            assertFalse("T+3�������ղ�Ӧƥ��", result);
        }
    }

    /**
     * ���Գ���������������
     */
    @Test
    public void testIsTriggerDay_ExceedMaxMonth() {
        LocalDate today = LocalDate.of(2026, 7, 15);
        try (MockedStatic<IncentiveRemindHolder> mockedHolder = mockStatic(IncentiveRemindHolder.class)) {
            IncentiveRemindHolder holder = mock(IncentiveRemindHolder.class);
            when(holder.getMaxAssessMonthOffsetValue()).thenReturn(3);
            mockedHolder.when(IncentiveRemindHolder::getINSTANCE).thenReturn(holder);

            boolean result = service.isTriggerDay(TEST_JOIN_DATE, today);

            assertFalse("���������ڲ�Ӧ����", result);
        }
    }
}
