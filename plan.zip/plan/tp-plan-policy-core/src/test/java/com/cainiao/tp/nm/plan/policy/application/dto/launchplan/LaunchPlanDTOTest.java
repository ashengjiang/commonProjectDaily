package com.cainiao.tp.nm.plan.api.policy.application.dto.launchplan;

import com.base.BaseTest;
import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.aladdin.exception.AladdinParamException;
import com.cainiao.tp.nm.plan.api.policy.application.dto.launchplan.AreaRuleLaunchDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.launchplan.LaunchPlanDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.launchplan.RuleLaunchDTO;
import com.cainiao.tp.nm.plan.api.policy.common.constants.LaunchPlanTypeEnum;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.MockitoAnnotations;

/**
 * <a href="https://alidocs.dingtalk.com/i/nodes/dpYLaezmVNRMGX56C1aKjlBOVrMqPxX6">单元测试编写&生成FAQ</a>
 * Created By Thub IDEA插件
 *
 * @Date 2025/6/4 16:35
 */
public class LaunchPlanDTOTest extends BaseTest {


    @Before
    public void setUp() throws Exception {MockitoAnnotations.openMocks(this);}

    @Test
    public void testValidate() {
        LaunchPlanDTO launchPlanDTO = new LaunchPlanDTO();
        try {
            launchPlanDTO.validate();
        }catch (AladdinParamException e){
            Assert.assertEquals("投放类型不合法", e.getMessage());
        }

        launchPlanDTO.setLaunchType(LaunchPlanTypeEnum.RULE.getType());
        RuleLaunchDTO ruleLaunchDTO = new RuleLaunchDTO();
        AreaRuleLaunchDTO areaRuleLaunchDTO = new AreaRuleLaunchDTO();
        ruleLaunchDTO.setAreaRuleLaunch(areaRuleLaunchDTO);
        launchPlanDTO.setRuleLaunch(ruleLaunchDTO);
        try {
            launchPlanDTO.validate();
        }catch (AladdinBizException e){
            Assert.assertEquals("参数不能全空", e.getMessage());
        }
    }
}