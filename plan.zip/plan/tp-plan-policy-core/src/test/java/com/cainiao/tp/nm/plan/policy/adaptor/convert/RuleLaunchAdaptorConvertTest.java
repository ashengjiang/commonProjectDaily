package com.cainiao.tp.nm.plan.policy.adaptor.convert;

import java.util.Arrays;

import com.base.BaseTest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.launchplan.AreaRuleLaunchVO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.launchplan.RuleLaunchDTO;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

/**
 * <a href="https://alidocs.dingtalk.com/i/nodes/dpYLaezmVNRMGX56C1aKjlBOVrMqPxX6">单元测试编写&生成FAQ</a>
 * Created By Thub IDEA插件
 *
 * @Date 2025/6/11 18:49
 */
public class RuleLaunchAdaptorConvertTest extends BaseTest {

    @InjectMocks
    private RuleLaunchAdaptorConvert ruleLaunchAdaptorConvert;

    @Before
    public void setUp() throws Exception {MockitoAnnotations.openMocks(this);}

    @Test
    public void testVoToDto() {
        // Prepare method arguments
        AreaRuleLaunchVO areaRuleLaunchVO = new AreaRuleLaunchVO();
        areaRuleLaunchVO.setProvinceCodeList(Arrays.asList("1", "2"));
        areaRuleLaunchVO.setCityCodeList(Arrays.asList("3", "4"));
        areaRuleLaunchVO.setDistrictCodeList(Arrays.asList("5", "6"));
        // Run the method to be tested
        RuleLaunchDTO result = RuleLaunchAdaptorConvert.voToDto(areaRuleLaunchVO);

        // Verify the results
        Assert.assertNotNull(result);
        Assert.assertNotNull(result.getAreaRuleLaunch());
        Assert.assertNotNull(result.getAreaRuleLaunch().getProvinceCodeList());
        Assert.assertNotNull(result.getAreaRuleLaunch().getCityCodeList());
        Assert.assertNotNull(result.getAreaRuleLaunch().getDistrictCodeList());
        Assert.assertFalse( result.getAreaRuleLaunch().isNational());
    }
}