package com.cainiao.tp.nm.plan.policy.application.convert;

import static org.mockito.Mockito.*;

import com.base.BaseTest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.PolicyInstanceQueryRequest;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyInstanceDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyInstanceCreateParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyInstanceQueryParam;
import com.cainiao.tp.nm.plan.policy.application.event.event.PolicyInstanceCreateEvent;
import com.cainiao.tp.nm.plan.policy.domain.model.PolicyInstance;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

/**
 * <a href="https://alidocs.dingtalk.com/i/nodes/dpYLaezmVNRMGX56C1aKjlBOVrMqPxX6">单元测试编写&生成FAQ</a>
 * Created By Thub IDEA插件
 *
 * @Date 2025/6/26 16:20
 */
public class PolicyInstanceApplicationConvertTest extends BaseTest {

    @InjectMocks
    private PolicyInstanceApplicationConvert policyInstanceApplicationConvert;

    @Before
    public void setUp() throws Exception {MockitoAnnotations.openMocks(this);}

    @Test
    public void testModelToDto() {
        // Prepare method arguments

        // Run the method to be tested
        PolicyInstanceDTO result = PolicyInstanceApplicationConvert.modelToDto(PolicyInstance.builder().build());

        // Verify the result
        assert result != null;
    }

    @Test
    public void testQueryParamConvert() {
        // Prepare method arguments

        // Run the method to be tested
        PolicyInstanceQueryParam result = PolicyInstanceApplicationConvert.queryParamConvert(new PolicyInstanceQueryRequest());

        // Verify the result
        assert result != null;
    }

    @Test
    public void testCreateEvent(){
        // Prepare method arguments

        // Run the method to be tested
        PolicyInstanceCreateEvent result = PolicyInstanceApplicationConvert.createEvent(new PolicyInstanceCreateParam(), 1L);

        // Verify the result
        assert result != null;
    }
}