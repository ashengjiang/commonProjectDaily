package com.cainiao.tp.nm.plan.policy.application.convert;

import com.alibaba.fastjson.JSONObject;
import com.cainiao.tp.nm.plan.api.policy.application.dto.AssessmentMetricGroupDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.StationAssessmentConfigHolder;
import com.cainiao.tp.nm.plan.api.policy.application.dto.StationIncentivePageConfigHolder;
import com.cainiao.tp.nm.plan.api.policy.application.dto.StationDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.NewStaPerformSubsidyConfigDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.StationIncentiveBillDetailDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.heavy.AssessmentCardDTO;
import com.cainiao.tp.nm.plan.policy.common.util.ReflectUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class StationIncentiveAssessmentConvertTest{

    private  final String list = "[{\"amountCent\":\"20000\",\"arrivePkgCnt20250101_20250228SumCnt\":\"8478\",\"avg20250226_20250228TxCnt\":\"0.0\",\"chargeOffBillTime\":\"2025-07-06 05:19:33\",\"checkStartDate\":\"20250101\",\"checkStartMonth\":\"202501\",\"cpCode\":\"STO\",\"cycleNum\":\"6\",\"cycleRange\":\"20250601~20250630\",\"dispatchStatus\":\"has_chargeoff\",\"ds\":\"2025-08-11\",\"entryOperateTime\":\"2025-01-15 00:00:00\",\"firstOver100ArrCnt\":\"189\",\"firstOver100ArrDate\":\"20250101\",\"fiscalQuarter\":\"fy25q4\",\"incentivePlanType\":\"base\",\"isApplyQuit\":false,\"isBlackStation\":false,\"isBlankAoiEst\":true,\"isCollectionPointTransfer\":false,\"isCountrySideTransfer\":false,\"isDecorationPass\":true,\"isExpressEst\":true,\"isFocalStation\":false,\"isHighQualityAoiEst\":\"true\",\"isKeyStation\":\"N\",\"isLightStationNew\":false,\"isParticipateCpEstSta\":false,\"isQuit\":false,\"isReverseStationEst\":false,\"isRiskStation\":false,\"isSatisfied\":true,\"isSatisfyBaseCondition\":true,\"isScanExpressSettleIn\":true,\"isStationChanged\":false,\"marginedTime\":\"2025-01-01 00:17:02\",\"noSatisfyBaseReason\":\"\",\"noSatisfyReason\":\"\",\"orgCode\":\"519003\",\"staSoftStatus\":\"运营期\",\"staStatusName\":\"运营中\",\"stationCode\":\"V7562122\",\"stationId\":\"1070360\",\"stationMode\":\"heavy\",\"stationName\":\"珠海吉大航天综合楼B栋店\",\"stationSubType\":\"社区专业点\",\"statsMonth\":\"202506\",\"statsMonthArrCnt\":\"6187\",\"statsMonthAvgVaildArrCnt\":\"206.23333333333332\",\"statsMonthBqArrCnt\":\"6082\",\"statsMonthBqArrRate\":\"0.9830289316308388\",\"statsMonthGpyPickupCnt\":\"5785\",\"statsMonthGpyPickupRate\":\"0.9627225827924779\",\"statsMonthPickupCnt\":\"6009\",\"statsMonthVaildArrDays\":\"30\",\"statsRange\":\"20250601~20250630\",\"theoreticalAmount\":\"20000\"}]\n";

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);
        // 初始化配置数据
        String config = "{\"metricGroupMap\":{\"fy25q4\":[{\"title\":\"重点站前提\",\"code\":\"keyStation\",\"dataDate\":\"统计日期\",\"isMeet\":\"\",\"target\":\"\",\"items\":[\"staSumVailArrCnt\",\"staCollectPointAvgArrCnt\",\"isKeyStation\",\"isKeyStationQualified\"]},{\"title\":\"入库实操\",\"code\":\"warehouseOperation\",\"dataDate\":\"统计日期\",\"isMeet\":\"组内指标是否都合格\",\"target\":\"1. 与Q3 一致，【累计实操入库天数】+【月日均入库包裹量】2项指标达标即=预计达标\",\"items\":[\"staFirstOver100Arr\",\"staStatsMonthVailArrDay\",\"staStatsMonthAvgVailArrCnt\",\"staPeriodCollectPointTxArrCnt\"]},{\"title\":\"设备使用\",\"code\":\"equipmentUse\",\"dataDate\":\"统计日期\",\"isMeet\":\"\",\"target\":\"1. 月日均入库单量<500单站点：菜鸟把枪使用率≥50%或菜鸟高拍仪使用率≥50%，或灯条驿站，三者需满足其一。2. 月日均入库单量≥500票的站点：菜鸟高拍仪使用率≥50%或菜鸟灯条站点，两者需满足其一。\",\"items\":[\"monthAvgDayArrCnt\",\"cnGpyArrRate\",\"cnBqArrRate\",\"isLightStation\"]},{\"title\":\"基础条件\",\"code\":\"stationBase\",\"dataDate\":\"统计日期\",\"target\":\"\",\"isMeet\":\"\",\"items\":[\"stationOperationStatus\",\"stationLifeStatus\",\"stationIsQuit\"]}],\"fy25q2\":[{\"title\":\"入库实操\",\"code\":\"warehouseOperation\",\"dataDate\":\"统计日期\",\"isMeet\":\"组内指标是否都合格\",\"target\":\"1. 与Q3 一致，【累计实操入库天数】+【月日均入库包裹量】2项指标达标即=预计达标\",\"items\":[\"staFirstOver100Arr\",\"staStatsMonthVailArrDay\",\"staStatsMonthAvgVailArrCnt\"]},{\"title\":\"设备使用\",\"code\":\"equipmentUse\",\"dataDate\":\"统计日期\",\"isMeet\":\"\",\"items\":[\"staStatsMonthBqOrGpyArrRate\"]},{\"title\":\"站点信息\",\"code\":\"stationBase\",\"dataDate\":\"统计日期\",\"target\":\"\",\"isMeet\":\"\",\"items\":[\"stationOperationStatus\",\"stationLifeStatus\",\"stationIsQuit\"]}],\"fy25q3\":[{\"title\":\"入库实操\",\"code\":\"warehouseOperation\",\"dataDate\":\"统计日期\",\"isMeet\":\"组内指标是否都合格\",\"target\":\"1. 与Q3 一致，【累计实操入库天数】+【月日均入库包裹量】2项指标达标即=预计达标\",\"items\":[\"staFirstOver100Arr\",\"staStatsMonthVailArrDay\",\"staStatsMonthAvgVailArrCnt\"]},{\"title\":\"设备使用\",\"code\":\"equipmentUse\",\"dataDate\":\"统计日期\",\"isMeet\":\"\",\"items\":[\"staStatsMonthBqOrGpyArrRate\"]},{\"title\":\"站点信息\",\"code\":\"stationBase\",\"dataDate\":\"统计日期\",\"target\":\"\",\"isMeet\":\"\",\"items\":[\"stationOperationStatus\",\"stationLifeStatus\",\"stationIsQuit\"]}],\"fy26q1\":[{\"title\":\"入库实操\",\"code\":\"warehouseOperation\",\"dataDate\":\"\",\"isMeet\":\"\",\"items\":[\"staFirstOver100Arr\",\"staStatsMonthVailArrDay\",\"staStatsMonthAvgVailArrCnt\"]},{\"title\":\"设备使用\",\"code\":\"equipmentUse\",\"dataDate\":\"统计日期\",\"isMeet\":\"\",\"items\":[\"staStatsMonthBqOrGpyArrRate\"]},{\"title\":\"站点类型\",\"code\":\"stationType\",\"dataDate\":\"\",\"target\":\"\",\"isMeet\":\"\",\"items\":[\"isLightStation\"]},{\"title\":\"站点信息\",\"code\":\"stationBase\",\"dataDate\":\"统计日期\",\"target\":\"\",\"isMeet\":\"\",\"items\":[\"stationOperationStatus\",\"stationLifeStatus\",\"stationIsQuit\"]}],\"test\":[{\"title\":\"领补贴必达条件\",\"code\":\"subsidyCond\",\"items\":[\"leijishicaorukutianshu\",\"rijunrukubaoguoliang\",\"cainiaoshebeishiyongqingkuang\",\"jichutiaojiandabiao\"]}]},\"xnMetricgroup\":{\"fy26q1\":[\"cnGpyArrRate\",\"cnBqArrRate\",\"isLightStation\"],\"fy25q4\":[\"cnGpyArrRate\",\"cnBqArrRate\"],\"default\":[\"cnGpyArrRate\",\"cnBqArrRate\"]},\"metricItemMap\":{\"staFirstOver100Arr\":{\"showCycleNum\":\"1\",\"unit\":\"单\",\"tip\":\"站点入驻后首次入库包裹量首次到达100单，作为考核起点\",\"title\":\"站点首次入库100单达标情况\",\"target\":\"目标: ≥100单\",\"qualifiedDate\":\"达标时间：>=100单，显示达标时间XX年X月X日\",\"valueField\":[\"firstOver100ArrCnt\"],\"qualifiedQl\":\"if(firstOver100ArrCnt==null){return false} if(firstOver100ArrCnt >= 100){return true} else{return false}\",\"valueQl\":\"\"},\"staSettleFirstisQualified\":{\"showCycleNum\":\"\",\"unit\":\"单\",\"tip\":\"站点入驻后首次入库包裹量首次到达100单，作为考核起点\",\"title\":\"站点入驻后首次入库包裹量达标\",\"target\":\"目标: ≥100单\",\"qualifiedDate\":\"达标日期\",\"valueField\":[\"firstOver100ArrCnt\"],\"qualifiedQl\":\"if(firstOver100ArrCnt==null){return false} if(firstOver100ArrCnt >= 100){return true} else{return false}\",\"valueQl\":\"\"},\"staStatsMonthAvgVailArrCnt\":{\"showCycleNum\":\"\",\"unit\":\"单\",\"tip\":\"入库包裹总量/自然日。若首次代收包裹达标日-月末>15，分子分母为首次代收达标日到月末的包裹量和天数；若首次代收包裹达标日-月末<15，顺延至次月1日开始统计，分子分母为次月包裹量和天数；春节假期（1.25-1.31；2.1-2.8）以及双十一期间（11.1-11.3和11.13-11.17）单量剔除计算\",\"title\":\"月日均入库包裹数\",\"target\":\"目标: ≥100单\",\"qualifiedDate\":\"\",\"valueField\":[\"statsMonthAvgVaildArrCnt\"],\"qualifiedQl\":\"if(statsMonthAvgVaildArrCnt==null){return false} if(statsMonthAvgVaildArrCnt >= 100){return true} else{return false}\",\"valueQl\":\"import java.math.BigDecimal; return new BigDecimal(statsMonthAvgVaildArrCnt).toBigInteger()\"},\"staStatsMonthVailArrDay\":{\"showCycleNum\":\"\",\"unit\":\"天\",\"tip\":\"首次代收包裹达标日到月末<15，顺延至次月1日开始统计；包裹入库单量>0为当日有实操\",\"title\":\"累计实操入库天数\",\"target\":\"目标：≥15天\",\"qualifiedDate\":\"\",\"valueField\":[\"statsMonthVaildArrDays\"],\"qualifiedQl\":\"if(statsMonthVaildArrDays==null){return false} if(statsMonthVaildArrDays >= 15){return true} else{return false}\",\"valueQl\":\"\",\"extra\":\"“不达标”（备注：首次代收包裹达标日-月末<15，顺延至次月1日开始统计）\"},\"staPeriodCollectPointTxArrCnt\":{\"showCycleNum\":\"\",\"unit\":\"单\",\"tip\":\"首次代收包裹达标日到月末<15，顺延至次月1日开始统计；包裹入库单量>0为当日有实操\",\"title\":\"周期内原代收点日均代收淘系包裹量\",\"target\":\"目标：≥15天\",\"qualifiedDate\":\"\",\"valueField\":[\"statsMonthAvgTxCnt\"],\"qualifiedQl\":\"\"},\"stationOperationStatus\":{\"showCycleNum\":\"\",\"unit\":\"\",\"tip\":\"站点生命周期条件\",\"title\":\"站点生命周期\",\"target\":\"目标：运营期\",\"qualifiedDate\":\"\",\"valueField\":[\"staSoftStatus\"],\"qualifiedQl\":\"if(staSoftStatus==null){return false} if(staSoftStatus == '运营期'){return true} else{return false}\",\"valueQl\":\"\"},\"stationLifeStatus\":{\"showCycleNum\":\"\",\"unit\":\"\",\"tip\":\"站点状态条件\",\"title\":\"站点状态\",\"target\":\"目标：运营中\",\"qualifiedDate\":\"\",\"valueField\":[\"staStatusName\"],\"qualifiedQl\":\"if(staStatusName==null){return false} if(staStatusName == '运营中'){return true} else{return false}\",\"valueQl\":\"\"},\"stationIsQuit\":{\"showCycleNum\":\"\",\"unit\":\"\",\"tip\":\"站点是否申请退出条件\",\"title\":\"站点是否申请退出\",\"target\":\"目标：否\",\"qualifiedDate\":\"\",\"valueField\":[\"isApplyQuit\"],\"qualifiedQl\":\"if(isApplyQuit==null){return false} return !isApplyQuit\",\"valueQl\":\"if(isApplyQuit==null){return '否'} if(isApplyQuit){return '是'} else{return '否'}\"},\"isLightStation\":{\"showCycleNum\":\"\",\"unit\":\"\",\"tip\":\"\",\"title\":\"是否灯条站\",\"target\":\"结算月末近7日日均绑定灯条数大于等于30，且近7日实操天数≥3天\",\"qualifiedDate\":\"\",\"valueField\":[\"isLightStationNew\"],\"qualifiedQl\":\"if(isLightStationNew == null) {return false} if(isLightStationNew) {return true} else {return false}\",\"valueQl\":\"if(isLightStationNew == null) {return '否'} if(isLightStationNew) {return '是'} else {return '否'}\"},\"staStatsMonthBqOrGpyArrRate\":{\"showCycleNum\":\"\",\"unit\":\"%\",\"tip\":\"把枪入库单量月汇总/入库单量月汇总；高拍仪出库单量月汇总/出库单量月汇总\",\"title\":\"月菜鸟巴枪或高拍仪使用率\",\"target\":\"目标：月菜鸟巴枪使用率≥50% 或 菜鸟高拍仪使用率≥50%\",\"qualifiedDate\":\"\",\"valueField\":[\"statsMonthBqArrRate\",\"statsMonthGpyPickupRate\"],\"qualifiedQl\":\"import com.cainiao.tp.nm.plan.policy.common.util.QlUtils;QlUtils.maxRateIsQualified(statsMonthBqArrRate,statsMonthGpyPickupRate)\",\"valueQl\":\"import com.cainiao.tp.nm.plan.policy.common.util.QlUtils;QlUtils.maxRateFormat(statsMonthBqArrRate,statsMonthGpyPickupRate)\"},\"staSumVailArrCnt\":{\"showCycleNum\":\"\",\"unit\":\"单\",\"tip\":\"\",\"title\":\"累计实操入库单量\",\"target\":\"目标：2025.1.1-2025.2.28日≥500单，3月入驻站不考核\",\"qualifiedDate\":\"\",\"valueField\":[\"arrivePkgCnt20250101_20250228SumCnt\"],\"qualifiedQl\":\"if(arrivePkgCnt20250101_20250228SumCnt == null) {return false} if(arrivePkgCnt20250101_20250228SumCnt > 500) {return true} else {return false}\",\"valueQl\":\"\",\"extra\":\"达标状态：>=500单显示“预计达标”，其他展示为“预计不达标”\"},\"staCollectPointAvgArrCnt\":{\"showCycleNum\":\"\",\"unit\":\"单\",\"tip\":\"\",\"title\":\"2月底原代收点日均入库淘系单量\",\"target\":\"目标：2025.2.26-2025.2.28日均单量≤5  \",\"qualifiedDate\":\"\",\"valueField\":[\"avg20250226_20250228TxCnt\"],\"qualifiedQl\":\"if(avg20250226_20250228TxCnt == null) {return false} if(avg20250226_20250228TxCnt <= 5) {return true} else {return false}\",\"valueQl\":\"\",\"extra\":\"达标状态：≤5   单显示“预计达标”，其他展示为“预计不达标\"},\"isKeyStation\":{\"showCycleNum\":\"\",\"unit\":\"\",\"tip\":\"\",\"title\":\"是否重点站建站\",\"target\":\"【重点站=1】且【是否翻站码入驻站点=1】\",\"qualifiedDate\":\"\",\"valueField\":[\"isReverseStationEst\"],\"qualifiedQl\":\"if(isReverseStationEst == null) {return false} if(isReverseStationEst) {return true} else {return false}\",\"valueQl\":\"if(isReverseStationEst == null) {return '否'} if(isReverseStationEst) {return '是'} else {return '否'}\",\"extra\":\"\"},\"isKeyStationQualified\":{\"showCycleNum\":\"\",\"unit\":\"\",\"tip\":\"\",\"title\":\"重点站考核是否达标\",\"target\":\"\",\"qualifiedDate\":\"\",\"valueField\":[\"isKeyStation\"],\"qualifiedQl\":\"if(isKeyStation == null) {return false} if(isKeyStation == Y) {return true} else {return false}\",\"valueQl\":\"\",\"extra\":\"\"},\"monthAvgDayArrCnt\":{\"showCycleNum\":\"\",\"unit\":\"单\",\"tip\":\"\",\"title\":\"月日均入库单量\",\"target\":\"\",\"qualifiedDate\":\"\",\"valueField\":[\"statsMonthAvgVaildArrCnt\"],\"qualifiedQl\":\"\",\"valueQl\":\"import java.math.BigDecimal; return new BigDecimal(statsMonthAvgVaildArrCnt).toBigInteger()\"},\"cnGpyArrRate\":{\"showCycleNum\":\"\",\"unit\":\"%\",\"tip\":\"\",\"title\":\"菜鸟高拍仪使用率\",\"target\":\"目标：菜鸟高拍仪使用率≥50%\",\"qualifiedDate\":\"\",\"valueField\":[\"statsMonthGpyPickupRate\"],\"qualifiedQl\":\"if(statsMonthGpyPickupRate == null) {return false} if(isKeyStation >= 0.5) {return true} else {return false}\",\"valueQl\":\"import com.cainiao.tp.nm.plan.policy.common.util.QlUtils;QlUtils.rateFormat(statsMonthGpyPickupRate)\"},\"cnBqArrRate\":{\"showCycleNum\":\"\",\"unit\":\"%\",\"tip\":\"\",\"title\":\"菜鸟巴枪使用率\",\"target\":\"目标：菜鸟巴枪使用率≥50%\",\"qualifiedDate\":\"\",\"valueField\":[\"statsMonthBqArrRate\"],\"qualifiedQl\":\"if(statsMonthBqArrRate == null) {return false} if(statsMonthBqArrRate >= 0.5) {return true} else {return false}\",\"valueQl\":\"import com.cainiao.tp.nm.plan.policy.common.util.QlUtils;QlUtils.rateFormat(statsMonthBqArrRate)\"},\"leijishicaorukutianshu\":{\"tip\":\"\",\"title\":\"月累计实操入库天数≥15天\",\"qualifiedDate\":\"当前累计x天\",\"valueField\":[\"firstOver100ArrCnt\"],\"qualifiedQl\":\"if(firstOver100ArrCnt==null){return false} if(firstOver100ArrCnt >= 100){return true} else{return false}\",\"valueQl\":\"\"},\"rijunrukubaoguoliang\":{\"tip\":\"\",\"title\":\"日均入库包裹量≥100单\",\"qualifiedDate\":\"当前日均x单\",\"valueField\":[\"firstOver100ArrCnt\"],\"qualifiedQl\":\"if(firstOver100ArrCnt==null){return false} if(firstOver100ArrCnt >= 100){return true} else{return false}\",\"valueQl\":\"\"},\"cainiaoshebeishiyongqingkuang\":{\"tip\":\"菜鸟把枪使用率≥50% 或 菜鸟高拍仪使用率≥50% 或 站点是灯条驿站\",\"title\":\"菜鸟设备使用达标\",\"qualifiedDate\":\"三选一达标即可\",\"valueField\":[\"firstOver100ArrCnt\"],\"qualifiedQl\":\"if(firstOver100ArrCnt==null){return false} if(firstOver100ArrCnt >= 100){return true} else{return false}\",\"valueQl\":\"\"},\"jichutiaojiandabiao\":{\"tip\":\"站点完成转正、处于运营期且站点状态为运营中/临时关闭、站点未退出\",\"title\":\"菜鸟基础条件达标\",\"qualifiedDate\":\"满足运营状态等\",\"valueField\":[\"firstOver100ArrCnt\"],\"qualifiedQl\":\"if(firstOver100ArrCnt==null){return false} if(firstOver100ArrCnt >= 100){return true} else{return false}\",\"valueQl\":\"\"}}}";
        StationAssessmentConfigHolder configHolder = JSONObject.parseObject(config, StationAssessmentConfigHolder.class);
        StationAssessmentConfigHolder.setINSTANCE(configHolder);
    }

    @Test
    public void testBuildAssessmentSuccessfulCallToAssembleMetrics() {
        List<StationIncentiveBillDetailDTO> detailDTOS = JSONObject.parseArray(list, StationIncentiveBillDetailDTO.class);
        StationIncentiveBillDetailDTO dto = detailDTOS.stream().findFirst().get();
        dto.setCycleNum("1");
        List<AssessmentCardDTO> assessmentCardDTOS = StationIncentiveAssessmentConvert.buildAssessment(dto, "fy25q4");
        Assert.assertNotNull(assessmentCardDTOS);
    }

    // =========================================================================
    // getNewStaPerformRuleDetailUrl 单元测试
    //
    // 方法逻辑分支：
    //   1. stationDTO == null → 返回 null
    //   2. isEntryFy27Q1（gmtCreate after fy27Q1StartDate）：
    //      - cityCode 在 Top20 列表 → ruleDetailFy27Q1Top20Url
    //      - 否则              → ruleDetailFy27Q1Url
    //   3. isEntryFy26Q4（gmtCreate after fy26Q4StartDate AND before fy27Q1StartDate）：
    //      - cityCode 在 Top20 列表  → ruleDetailFy26Q4Top20Url
    //      - cityCode 在 Top100 列表 → ruleDetailFy26Q4Top100Url
    //      - 否则                    → ""
    //   4. 其他（FY26Q4 之前老站点）：
    //      - cityCode 在 Top20 列表 → ruleDetailTop20Url
    //      - 否则                   → ruleDetailUrl
    //
    // DateUtil.getStr2SDate 使用 "yyyy-MM-dd HH:mm:ss" 格式解析日期字符串。
    // =========================================================================

    /** FY26Q4 开始日期，格式与 DateUtil.getStr2SDate 一致 */
    private static final String FY26Q4_START_DATE = "2025-10-01 00:00:00";
    /** FY27Q1 开始日期 */
    private static final String FY27Q1_START_DATE = "2026-01-01 00:00:00";

    /** Top20 城市编码 */
    private static final String TOP20_CITY_CODE = "330100";
    /** Top100 城市编码（不在 Top20 中） */
    private static final String TOP100_CITY_CODE = "440100";
    /** 普通城市编码（不在任何列表中） */
    private static final String NORMAL_CITY_CODE = "999999";

    /**
     * 将 "yyyy-MM-dd HH:mm:ss" 格式的日期字符串偏移指定天数后返回 Date 对象。
     * 与 DateUtil.getStr2SDate 使用相同的格式，保证测试数据与被测代码一致。
     */
    private Date parseDateWithOffset(String dateStr, int offsetDays) throws Exception {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date base = sdf.parse(dateStr);
        return new Date(base.getTime() + (long) offsetDays * 24 * 60 * 60 * 1000);
    }

    /**
     * 构建包含所有 URL 和城市列表的基础配置。
     */
    private NewStaPerformSubsidyConfigDTO buildSubsidyConfig() {
        NewStaPerformSubsidyConfigDTO config = new NewStaPerformSubsidyConfigDTO();
        config.setFy26Q4StartDate(FY26Q4_START_DATE);
        config.setFy27Q1StartDate(FY27Q1_START_DATE);
        config.setRuleDetailUrl("http://rule-default");
        config.setRuleDetailTop20Url("http://rule-top20");
        config.setRuleDetailFy26Q4Top20Url("http://rule-fy26q4-top20");
        config.setRuleDetailFy26Q4Top100Url("http://rule-fy26q4-top100");
        config.setRuleDetailFy27Q1Url("http://rule-fy27q1");
        config.setRuleDetailFy27Q1Top20Url("http://rule-fy27q1-top20");
        config.setRuleDetailTop20CityCodeList(Arrays.asList(TOP20_CITY_CODE));
        config.setRuleDetailTop100CityCodeList(Arrays.asList(TOP100_CITY_CODE));
        return config;
    }

    /**
     * 构建指定入驻时间和城市编码的站点 DTO。
     */
    private StationDTO buildStationDTO(Date gmtCreate, String cityCode) {
        StationDTO stationDTO = new StationDTO();
        stationDTO.setGmtCreate(gmtCreate);
        stationDTO.setCityCode(cityCode);
        return stationDTO;
    }

    /**
     * 通过反射调用私有静态方法 getNewStaPerformRuleDetailUrl。
     */
    private String invokeGetNewStaPerformRuleDetailUrl(StationDTO stationDTO, NewStaPerformSubsidyConfigDTO config)
            throws Exception {
        Method method = StationIncentiveAssessmentConvert.class.getDeclaredMethod(
                "getNewStaPerformRuleDetailUrl",
                StationDTO.class,
                NewStaPerformSubsidyConfigDTO.class
        );
        method.setAccessible(true);
        return (String) method.invoke(null, stationDTO, config);
    }

    // ---- 分支1：stationDTO 为 null ----

    @Test
    public void testGetRuleDetailUrl_returnNull_whenStationDTOIsNull() throws Exception {
        NewStaPerformSubsidyConfigDTO config = buildSubsidyConfig();
        String result = invokeGetNewStaPerformRuleDetailUrl(null, config);
        assertNull("stationDTO 为 null 时应返回 null", result);
    }

    // ---- 分支2：isEntryFy27Q1 = true（入驻时间严格晚于 FY27Q1 开始时间） ----

    @Test
    public void testGetRuleDetailUrl_returnFy27Q1Top20Url_whenFy27Q1EntryAndTop20City() throws Exception {
        NewStaPerformSubsidyConfigDTO config = buildSubsidyConfig();
        // 入驻时间在 FY27Q1 开始后 30 天，满足 gmtCreate.after(fy27Q1Date)
        StationDTO station = buildStationDTO(parseDateWithOffset(FY27Q1_START_DATE, 30), TOP20_CITY_CODE);
        String result = invokeGetNewStaPerformRuleDetailUrl(station, config);
        assertEquals("FY27Q1 入驻 + Top20 城市，应返回 FY27Q1 Top20 URL",
                "http://rule-fy27q1-top20", result);
    }

    @Test
    public void testGetRuleDetailUrl_returnFy27Q1Url_whenFy27Q1EntryAndNonTop20City() throws Exception {
        NewStaPerformSubsidyConfigDTO config = buildSubsidyConfig();
        StationDTO station = buildStationDTO(parseDateWithOffset(FY27Q1_START_DATE, 30), NORMAL_CITY_CODE);
        String result = invokeGetNewStaPerformRuleDetailUrl(station, config);
        assertEquals("FY27Q1 入驻 + 普通城市，应返回 FY27Q1 默认 URL",
                "http://rule-fy27q1", result);
    }

    @Test
    public void testGetRuleDetailUrl_returnFy27Q1Url_whenFy27Q1EntryAndTop100CityNotInTop20() throws Exception {
        NewStaPerformSubsidyConfigDTO config = buildSubsidyConfig();
        // FY27Q1 分支无 Top100 判断，Top100 城市应走默认 URL
        StationDTO station = buildStationDTO(parseDateWithOffset(FY27Q1_START_DATE, 30), TOP100_CITY_CODE);
        String result = invokeGetNewStaPerformRuleDetailUrl(station, config);
        assertEquals("FY27Q1 入驻 + Top100 城市（不在 Top20），应返回 FY27Q1 默认 URL",
                "http://rule-fy27q1", result);
    }

    @Test
    public void testGetRuleDetailUrl_returnFy27Q1Url_whenFy27Q1EntryAndTop20ListIsEmpty() throws Exception {
        NewStaPerformSubsidyConfigDTO config = buildSubsidyConfig();
        config.setRuleDetailTop20CityCodeList(Collections.emptyList());
        StationDTO station = buildStationDTO(parseDateWithOffset(FY27Q1_START_DATE, 30), TOP20_CITY_CODE);
        String result = invokeGetNewStaPerformRuleDetailUrl(station, config);
        assertEquals("FY27Q1 入驻 + Top20 列表为空，应返回 FY27Q1 默认 URL",
                "http://rule-fy27q1", result);
    }

    @Test
    public void testGetRuleDetailUrl_returnFy27Q1Url_whenFy27Q1EntryAndTop20ListIsNull() throws Exception {
        NewStaPerformSubsidyConfigDTO config = buildSubsidyConfig();
        config.setRuleDetailTop20CityCodeList(null);
        StationDTO station = buildStationDTO(parseDateWithOffset(FY27Q1_START_DATE, 30), TOP20_CITY_CODE);
        String result = invokeGetNewStaPerformRuleDetailUrl(station, config);
        assertEquals("FY27Q1 入驻 + Top20 列表为 null，应返回 FY27Q1 默认 URL",
                "http://rule-fy27q1", result);
    }

    // ---- 分支3：isEntryFy26Q4 = true（入驻时间在 FY26Q4 和 FY27Q1 之间） ----

    @Test
    public void testGetRuleDetailUrl_returnFy26Q4Top20Url_whenFy26Q4EntryAndTop20City() throws Exception {
        NewStaPerformSubsidyConfigDTO config = buildSubsidyConfig();
        // 入驻时间在 FY26Q4 之后 30 天，且在 FY27Q1 之前
        StationDTO station = buildStationDTO(parseDateWithOffset(FY26Q4_START_DATE, 30), TOP20_CITY_CODE);
        String result = invokeGetNewStaPerformRuleDetailUrl(station, config);
        assertEquals("FY26Q4 入驻 + Top20 城市，应返回 FY26Q4 Top20 URL",
                "http://rule-fy26q4-top20", result);
    }

    @Test
    public void testGetRuleDetailUrl_returnFy26Q4Top100Url_whenFy26Q4EntryAndTop100City() throws Exception {
        NewStaPerformSubsidyConfigDTO config = buildSubsidyConfig();
        StationDTO station = buildStationDTO(parseDateWithOffset(FY26Q4_START_DATE, 30), TOP100_CITY_CODE);
        String result = invokeGetNewStaPerformRuleDetailUrl(station, config);
        assertEquals("FY26Q4 入驻 + Top100 城市（不在 Top20），应返回 FY26Q4 Top100 URL",
                "http://rule-fy26q4-top100", result);
    }

    @Test
    public void testGetRuleDetailUrl_returnEmptyString_whenFy26Q4EntryAndNormalCity() throws Exception {
        NewStaPerformSubsidyConfigDTO config = buildSubsidyConfig();
        StationDTO station = buildStationDTO(parseDateWithOffset(FY26Q4_START_DATE, 30), NORMAL_CITY_CODE);
        String result = invokeGetNewStaPerformRuleDetailUrl(station, config);
        assertEquals("FY26Q4 入驻 + 普通城市（不在任何列表），应返回空字符串", "", result);
    }

    @Test
    public void testGetRuleDetailUrl_returnEmptyString_whenFy26Q4EntryAndBothCityListsEmpty() throws Exception {
        NewStaPerformSubsidyConfigDTO config = buildSubsidyConfig();
        config.setRuleDetailTop20CityCodeList(Collections.emptyList());
        config.setRuleDetailTop100CityCodeList(Collections.emptyList());
        StationDTO station = buildStationDTO(parseDateWithOffset(FY26Q4_START_DATE, 30), TOP20_CITY_CODE);
        String result = invokeGetNewStaPerformRuleDetailUrl(station, config);
        assertEquals("FY26Q4 入驻 + 两个城市列表均为空，应返回空字符串", "", result);
    }

    // ---- 分支4：FY26Q4 之前老站点 ----

    @Test
    public void testGetRuleDetailUrl_returnTop20Url_whenBeforeFy26Q4AndTop20City() throws Exception {
        NewStaPerformSubsidyConfigDTO config = buildSubsidyConfig();
        // 入驻时间在 FY26Q4 开始前 30 天
        StationDTO station = buildStationDTO(parseDateWithOffset(FY26Q4_START_DATE, -30), TOP20_CITY_CODE);
        String result = invokeGetNewStaPerformRuleDetailUrl(station, config);
        assertEquals("FY26Q4 之前入驻 + Top20 城市，应返回 Top20 URL",
                "http://rule-top20", result);
    }

    @Test
    public void testGetRuleDetailUrl_returnDefaultUrl_whenBeforeFy26Q4AndNormalCity() throws Exception {
        NewStaPerformSubsidyConfigDTO config = buildSubsidyConfig();
        StationDTO station = buildStationDTO(parseDateWithOffset(FY26Q4_START_DATE, -30), NORMAL_CITY_CODE);
        String result = invokeGetNewStaPerformRuleDetailUrl(station, config);
        assertEquals("FY26Q4 之前入驻 + 普通城市，应返回默认 URL",
                "http://rule-default", result);
    }

    @Test
    public void testGetRuleDetailUrl_returnDefaultUrl_whenBeforeFy26Q4AndTop100CityNotInTop20() throws Exception {
        NewStaPerformSubsidyConfigDTO config = buildSubsidyConfig();
        // 老站点分支无 Top100 判断，Top100 城市应走默认 URL
        StationDTO station = buildStationDTO(parseDateWithOffset(FY26Q4_START_DATE, -30), TOP100_CITY_CODE);
        String result = invokeGetNewStaPerformRuleDetailUrl(station, config);
        assertEquals("FY26Q4 之前入驻 + Top100 城市（不在 Top20），应返回默认 URL",
                "http://rule-default", result);
    }

    @Test
    public void testGetRuleDetailUrl_returnDefaultUrl_whenBeforeFy26Q4AndTop20ListIsNull() throws Exception {
        NewStaPerformSubsidyConfigDTO config = buildSubsidyConfig();
        config.setRuleDetailTop20CityCodeList(null);
        StationDTO station = buildStationDTO(parseDateWithOffset(FY26Q4_START_DATE, -30), TOP20_CITY_CODE);
        String result = invokeGetNewStaPerformRuleDetailUrl(station, config);
        assertEquals("FY26Q4 之前入驻 + Top20 列表为 null，应返回默认 URL",
                "http://rule-default", result);
    }

    // ---- 边界时间点测试 ----

    @Test
    public void testGetRuleDetailUrl_exactlyOnFy27Q1StartDate_fallsToFy26Q4BranchOrOldBranch() throws Exception {
        NewStaPerformSubsidyConfigDTO config = buildSubsidyConfig();
        // gmtCreate 恰好等于 FY27Q1 开始时间：
        //   isEntryFy27Q1 = gmtCreate.after(fy27Q1Date) = false
        //   isEntryFy26Q4 = gmtCreate.after(fy26Q4Date) && gmtCreate.before(fy27Q1Date)
        //                 = true && false = false
        // 因此落入老站点分支
        StationDTO station = buildStationDTO(parseDateWithOffset(FY27Q1_START_DATE, 0), TOP20_CITY_CODE);
        String result = invokeGetNewStaPerformRuleDetailUrl(station, config);
        assertEquals("恰好等于 FY27Q1 开始时间（不满足 after），应走老站点 Top20 URL",
                "http://rule-top20", result);
    }

    @Test
    public void testGetRuleDetailUrl_exactlyOnFy26Q4StartDate_fallsToOldBranch() throws Exception {
        NewStaPerformSubsidyConfigDTO config = buildSubsidyConfig();
        // gmtCreate 恰好等于 FY26Q4 开始时间：
        //   isEntryFy27Q1 = false
        //   isEntryFy26Q4 = gmtCreate.after(fy26Q4Date) = false → 落入老站点分支
        StationDTO station = buildStationDTO(parseDateWithOffset(FY26Q4_START_DATE, 0), TOP20_CITY_CODE);
        String result = invokeGetNewStaPerformRuleDetailUrl(station, config);
        assertEquals("恰好等于 FY26Q4 开始时间（不满足 after），应走老站点 Top20 URL",
                "http://rule-top20", result);
    }

}