package com.cainiao.tp.nm.plan.policy.adaptor.convert;

import com.alibaba.fastjson.JSON;
import com.base.BaseTest;
import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.aladdin.operation.CNUserOperation;
import com.cainiao.tp.boot.utils.TpWebUtil;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.PolicyTemplateCreateRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.PolicyTemplateRecordVO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyTemplateDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.IncentivePlanDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.launchplan.AreaRuleLaunchDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.launchplan.LaunchPlanDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.launchplan.RuleLaunchDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyTemplateCreateParam;
import com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;

/**
 * <a href="https://alidocs.dingtalk.com/i/nodes/dpYLaezmVNRMGX56C1aKjlBOVrMqPxX6">单元测试编写&生成FAQ</a>
 * Created By Thub IDEA插件
 *
 * @Date 2025/6/4 15:24
 */
public class PolicyTemplateAdaptorConvertTest extends BaseTest {

    @InjectMocks
    private PolicyTemplateAdaptorConvert policyTemplateAdaptorConvert;

    private MockedStatic<TpWebUtil> tpWebUtilMockedStatic;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        tpWebUtilMockedStatic = Mockito.mockStatic(TpWebUtil.class);
        AbstractOperation operation = new CNUserOperation(1L, "test");
        tpWebUtilMockedStatic.when(TpWebUtil::getWebOperation).thenReturn(operation);
    }

    @After
    public void tearDown() throws Exception {
        if (tpWebUtilMockedStatic != null) {
            tpWebUtilMockedStatic.close();
        }
    }
    @Test
    public void testConvertCreateParam_rule() {
        PolicyTemplateCreateRequest createRequest = buildCreateRequest_rule();
        List<IncentivePlanDTO> incentivePlanDTOList = buildIncentivePlanList();
        incentivePlanDTOList = IncentivePlanAdaptorConvert.eliminateContent(incentivePlanDTOList);
        PolicyTemplateCreateParam createParam = PolicyTemplateAdaptorConvert.convertCreateParam(createRequest,incentivePlanDTOList);
        //System.out.println(JSON.toJSONString(createParam));
        Assert.assertNotNull(createParam);
        Assert.assertEquals("scale",createParam.getBizType());
        Assert.assertEquals("station",createParam.getCustomType());
        Assert.assertNotNull(createParam.getEndTimeStr());
        Assert.assertNotNull(createParam.getStartTimeStr());
        Assert.assertNotNull(createParam.getOperatorId());
        Assert.assertNotNull(createParam.getLaunchPlan());
        Assert.assertEquals("rule",createParam.getLaunchPlan().getLaunchType());
        Assert.assertFalse(createParam.getLaunchPlan().getRuleLaunch().getAreaRuleLaunch().isNational());
        Assert.assertEquals(2,createParam.getLaunchPlan().getRuleLaunch().getAreaRuleLaunch().getProvinceCodeList().size());
        Assert.assertEquals(2,createParam.getLaunchPlan().getRuleLaunch().getAreaRuleLaunch().getCityCodeList().size());
        Assert.assertEquals(2,createParam.getLaunchPlan().getRuleLaunch().getAreaRuleLaunch().getDistrictCodeList().size());

        Assert.assertEquals(2,createParam.getIncentivePlanList().size());
        Assert.assertEquals("FY26Q1规模站点基础激励",createParam.getIncentivePlanList().get(0).getPlanName());
        Assert.assertEquals("scale_sta_basic_incent_fy26q1",createParam.getIncentivePlanList().get(0).getIncentivePlanCode());
        Assert.assertEquals("basic",createParam.getIncentivePlanList().get(0).getIncentivePlanType());

        Assert.assertEquals("FY26Q1规模站点灵活激励",createParam.getIncentivePlanList().get(1).getPlanName());
        Assert.assertEquals("scale_sta_flexible_incent_fy26q1",createParam.getIncentivePlanList().get(1).getIncentivePlanCode());
        Assert.assertEquals("flexible",createParam.getIncentivePlanList().get(1).getIncentivePlanType());
    }

    @Test
    public void testConvertCreateParam_national() {
        PolicyTemplateCreateRequest createRequest = buildCreateRequest_national();
        List<IncentivePlanDTO> incentivePlanDTOList = buildIncentivePlanList();
        incentivePlanDTOList = IncentivePlanAdaptorConvert.eliminateContent(incentivePlanDTOList);
        PolicyTemplateCreateParam createParam = PolicyTemplateAdaptorConvert.convertCreateParam(createRequest,incentivePlanDTOList);
        //System.out.println(JSON.toJSONString(createParam));
        Assert.assertNotNull(createParam);
        Assert.assertEquals("scale",createParam.getBizType());
        Assert.assertEquals("station",createParam.getCustomType());
        Assert.assertNotNull(createParam.getEndTimeStr());
        Assert.assertNotNull(createParam.getStartTimeStr());
        Assert.assertNotNull(createParam.getOperatorId());
        Assert.assertNotNull(createParam.getLaunchPlan());
        Assert.assertEquals("rule",createParam.getLaunchPlan().getLaunchType());
        Assert.assertTrue(createParam.getLaunchPlan().getRuleLaunch().getAreaRuleLaunch().isNational());


        Assert.assertEquals(2,createParam.getIncentivePlanList().size());
        Assert.assertEquals("FY26Q1规模站点基础激励",createParam.getIncentivePlanList().get(0).getPlanName());
        Assert.assertEquals("scale_sta_basic_incent_fy26q1",createParam.getIncentivePlanList().get(0).getIncentivePlanCode());
        Assert.assertEquals("basic",createParam.getIncentivePlanList().get(0).getIncentivePlanType());

        Assert.assertEquals("FY26Q1规模站点灵活激励",createParam.getIncentivePlanList().get(1).getPlanName());
        Assert.assertEquals("scale_sta_flexible_incent_fy26q1",createParam.getIncentivePlanList().get(1).getIncentivePlanCode());
        Assert.assertEquals("flexible",createParam.getIncentivePlanList().get(1).getIncentivePlanType());
    }

    @Test
    public void testConvertCreateParam_list() {
        PolicyTemplateCreateRequest createRequest = buildCreateRequest_list();
        List<IncentivePlanDTO> incentivePlanDTOList = buildIncentivePlanList();
        incentivePlanDTOList = IncentivePlanAdaptorConvert.eliminateContent(incentivePlanDTOList);
        PolicyTemplateCreateParam createParam = PolicyTemplateAdaptorConvert.convertCreateParam(createRequest,incentivePlanDTOList);
        //System.out.println(JSON.toJSONString(createParam));
        Assert.assertNotNull(createParam);
        Assert.assertEquals("scale",createParam.getBizType());
        Assert.assertEquals("station",createParam.getCustomType());
        Assert.assertNotNull(createParam.getEndTimeStr());
        Assert.assertNotNull(createParam.getStartTimeStr());
        Assert.assertNotNull(createParam.getOperatorId());
        Assert.assertNotNull(createParam.getLaunchPlan());
        Assert.assertEquals("list",createParam.getLaunchPlan().getLaunchType());
        Assert.assertEquals(2,createParam.getLaunchPlan().getListLaunch().getItemLaunch().size());
        Assert.assertEquals("sign_protocol",createParam.getLaunchPlan().getListLaunch().getItemLaunch().get(0).getAttrCode());
        Assert.assertEquals("station",createParam.getLaunchPlan().getListLaunch().getItemLaunch().get(0).getType());
        Assert.assertEquals("code1",createParam.getLaunchPlan().getListLaunch().getItemLaunch().get(0).getAttrValue());

        Assert.assertEquals("sign_protocol",createParam.getLaunchPlan().getListLaunch().getItemLaunch().get(1).getAttrCode());
        Assert.assertEquals("station",createParam.getLaunchPlan().getListLaunch().getItemLaunch().get(1).getType());
        Assert.assertEquals("code2",createParam.getLaunchPlan().getListLaunch().getItemLaunch().get(1).getAttrValue());


        Assert.assertEquals(2,createParam.getIncentivePlanList().size());
        Assert.assertEquals("FY26Q1规模站点基础激励",createParam.getIncentivePlanList().get(0).getPlanName());
        Assert.assertEquals("scale_sta_basic_incent_fy26q1",createParam.getIncentivePlanList().get(0).getIncentivePlanCode());
        Assert.assertEquals("basic",createParam.getIncentivePlanList().get(0).getIncentivePlanType());

        Assert.assertEquals("FY26Q1规模站点灵活激励",createParam.getIncentivePlanList().get(1).getPlanName());
        Assert.assertEquals("scale_sta_flexible_incent_fy26q1",createParam.getIncentivePlanList().get(1).getIncentivePlanCode());
        Assert.assertEquals("flexible",createParam.getIncentivePlanList().get(1).getIncentivePlanType());
    }

    @Test
    public void testConvertVO(){
        // 设置请求参数
        // 调用 tested method
        List<PolicyTemplateDTO> policyTemplateList = buildTestQueryPolicyTemplateDTOList();
        List<PolicyTemplateRecordVO> recordVOList = PolicyTemplateAdaptorConvert.convertVO(policyTemplateList);
        // 验证结果
        // 验证结果
        Assert.assertNotNull(recordVOList);
        Assert.assertEquals(1,recordVOList.size());
        Assert.assertEquals("FY26Q1规模站点政策",recordVOList.get(0).getTemplateName());
        Assert.assertEquals("规模",recordVOList.get(0).getBizTypeDesc());
        Assert.assertEquals("站点",recordVOList.get(0).getCustomTypeDesc());
        Assert.assertEquals(1,recordVOList.get(0).getId().longValue());
        Assert.assertEquals("已过期",recordVOList.get(0).getDurationStatusStr());
        Assert.assertEquals("2",recordVOList.get(0).getDurationStatus());
        Assert.assertEquals("2025.06.04-2025.06.04",recordVOList.get(0).getPeriod());
        Assert.assertEquals(2,recordVOList.get(0).getPolicyRuleList().size());

        Assert.assertEquals("基础激励", recordVOList.get(0).getPolicyRuleList().get(0).getPlanTitle());
        Assert.assertEquals("FY26Q1规模站点基础激励", recordVOList.get(0).getPolicyRuleList().get(0).getPlanName());
        Assert.assertEquals("basic", recordVOList.get(0).getPolicyRuleList().get(0).getIncentivePlanType());
        Assert.assertEquals(1, recordVOList.get(0).getPolicyRuleList().get(0).getContentRecordList().size());
        Assert.assertEquals("基础激励: 1", recordVOList.get(0).getPolicyRuleList().get(0).getContentRecordList().get(0).getIncentiveContent());
        Assert.assertEquals("激励周期: 6", recordVOList.get(0).getPolicyRuleList().get(0).getContentRecordList().get(0).getIncentivePeriod());

        Assert.assertEquals("灵活激励", recordVOList.get(0).getPolicyRuleList().get(1).getPlanTitle());
        Assert.assertEquals("FY26Q1规模站点灵活激励", recordVOList.get(0).getPolicyRuleList().get(1).getPlanName());
        Assert.assertEquals("flexible", recordVOList.get(0).getPolicyRuleList().get(1).getIncentivePlanType());
        Assert.assertEquals(3, recordVOList.get(0).getPolicyRuleList().get(1).getContentRecordList().size());
        Assert.assertEquals("无人站: 0.6/0.8/1.0/1.2", recordVOList.get(0).getPolicyRuleList().get(1).getContentRecordList().get(0)
            .getIncentiveContent());
        Assert.assertEquals("灯条站: 0.6/0.8/1.0/1.2", recordVOList.get(0).getPolicyRuleList().get(1).getContentRecordList().get(1)
            .getIncentiveContent());
        Assert.assertEquals("普通站: 0.6/0.8/1.0/1.2", recordVOList.get(0).getPolicyRuleList().get(1).getContentRecordList().get(2)
            .getIncentiveContent());
        Assert.assertEquals("激励周期: 6", recordVOList.get(0).getPolicyRuleList().get(1).getContentRecordList().get(0).getIncentivePeriod());
        Assert.assertEquals("激励周期: 6", recordVOList.get(0).getPolicyRuleList().get(1).getContentRecordList().get(1).getIncentivePeriod());
        Assert.assertEquals("激励周期: 6", recordVOList.get(0).getPolicyRuleList().get(1).getContentRecordList().get(2).getIncentivePeriod());
    }


    private List<PolicyTemplateDTO> buildTestQueryPolicyTemplateDTOList(){
        List<PolicyTemplateDTO> policyTemplateDTOList = new ArrayList<>();
        PolicyTemplateDTO policyTemplateDTO = new PolicyTemplateDTO();
        policyTemplateDTO.setId(1L);
        policyTemplateDTO.setTemplateName("FY26Q1规模站点政策");
        policyTemplateDTO.setStartTime(DateUtils.toLocalDateTimeYmdhms("2025-06-04 14:57:00"));
        policyTemplateDTO.setEndTime(DateUtils.toLocalDateTimeYmdhms("2025-06-05 14:57:00"));
        policyTemplateDTO.setBizType("scale");
        policyTemplateDTO.setCustomType("station");
        policyTemplateDTO.setLaunchPlan(buildLaunchPlanDTO());
        policyTemplateDTO.setIncentivePlanList(buildIncentivePlanList());
        policyTemplateDTO.setGmtCreate(DateUtils.toLocalDateTimeYmdhms("2025-06-04 14:57:00"));
        policyTemplateDTOList.add(policyTemplateDTO);
        return policyTemplateDTOList;
    }

    private LaunchPlanDTO buildLaunchPlanDTO(){
        LaunchPlanDTO launchPlan = new LaunchPlanDTO();
        launchPlan.setLaunchType("rule");
        RuleLaunchDTO ruleLaunch = new RuleLaunchDTO();
        AreaRuleLaunchDTO areaRuleLaunch = new AreaRuleLaunchDTO();
        areaRuleLaunch.setNational(true);
        ruleLaunch.setAreaRuleLaunch(areaRuleLaunch);
        launchPlan.setRuleLaunch(ruleLaunch);
        return launchPlan;
    }



    @Test
    public void testBuildData(){
        System.out.println(JSON.toJSONString(buildCreateRequest_rule()));
    }

    /**
     * 规则投放
     */
    private PolicyTemplateCreateRequest buildCreateRequest_rule() {
        String str
            = "{\"templateName\":\"FY26规模站点政策2\",\"customType\":\"station\",\"bizType\":\"scale\",\"startTimeStr\":\"2025-06-01\",\"endTimeStr\":\"2025-06-30\",\"incentivePlanTypeList\":[\"scale_sta_flexible_incent_fy26q1\",\"scale_sta_basic_incent_fy26q1\"],\"launchPlan\":{\"launchType\":\"rule\",\"areaRuleLaunch\":{\"provinceCodeList\":[\"1\",\"2\"],\"cityCodeList\":[\"3\",\"4\"],\"districtCodeList\":[\"5\",\"6\"]}}}";
        return JSON.parseObject(str, PolicyTemplateCreateRequest.class);
    }

    /**
     * 全国投放
     */
    private PolicyTemplateCreateRequest buildCreateRequest_national() {
        String str
            = "{\"templateName\":\"FY26规模站点政策2\",\"customType\":\"station\",\"bizType\":\"scale\",\"startTimeStr\":\"2025-06-01\",\"endTimeStr\":\"2025-06-30\",\"incentivePlanTypeList\":[\"scale_sta_flexible_incent_fy26q1\",\"scale_sta_basic_incent_fy26q1\"],\"launchPlan\":{\"launchType\":\"rule\",\"areaRuleLaunch\":{\"national\":true}}}";
        return JSON.parseObject(str, PolicyTemplateCreateRequest.class);
    }

    /**
     * 名单投放
     */
    private PolicyTemplateCreateRequest buildCreateRequest_list() {
        String str
            = "{\"templateName\":\"FY26规模站点政策2\",\"customType\":\"station\",\"bizType\":\"scale\",\"startTimeStr\":\"2025-06-01\",\"endTimeStr\":\"2025-06-30\",\"incentivePlanTypeList\":[\"scale_sta_flexible_incent_fy26q1\",\"scale_sta_basic_incent_fy26q1\"],\"launchPlan\":{\"launchType\":\"list\",\"entityAttrCode\":\"sign_protocol\",\"tagCodeList\":[\"code1\",\"code2\"]}}";
        return JSON.parseObject(str, PolicyTemplateCreateRequest.class);
    }

    /**
     * 激励方案
     */
    private List<IncentivePlanDTO> buildIncentivePlanList(){
        String str = "[{\"content\":{\"coefficient\":[{\"code\":\"basic\",\"frame\":{\"result\":[{\"code\":\"basic\",\"name\":\"默认\",\"val\":\"1\"}]},\"name\":\"默认系数\"}],\"selectPlan\":{\"areaSelectPlan\":{\"national\":true}}},\"incentivePlanType\":\"basic\",\"incentivePlanCode\":\"scale_sta_basic_incent_fy26q1\",\"planName\":\"FY26Q1规模站点基础激励\"},{\"content\":{\"coefficient\":[{\"code\":\"basic\",\"frame\":{\"children\":[{\"arithLogic\":\"=\",\"factorCode\":\"stationType\",\"factorName\":\"站点类型\",\"factorResult\":{\"fixedVal\":\"non_station\",\"type\":\"fixed\"},\"incentiveFactorLimit\":{\"canUpdate\":false},\"result\":[{\"code\":\"basic\",\"name\":\"默认\",\"resultLimit\":{\"canUpdate\":true,\"limitType\":\"option\",\"optionLimit\":{\"optionList\":[\"0.6\",\"0.8\",\"1.0\",\"1.2\"]}}}]},{\"arithLogic\":\"=\",\"factorCode\":\"stationType\",\"factorName\":\"站点类型\",\"factorResult\":{\"fixedVal\":\"light_station\",\"type\":\"fixed\"},\"incentiveFactorLimit\":{\"canUpdate\":false},\"result\":[{\"code\":\"basic\",\"name\":\"默认\",\"resultLimit\":{\"canUpdate\":true,\"limitType\":\"option\",\"optionLimit\":{\"optionList\":[\"0.6\",\"0.8\",\"1.0\",\"1.2\"]}}}]},{\"arithLogic\":\"=\",\"factorCode\":\"stationType\",\"factorName\":\"站点类型\",\"factorResult\":{\"fixedVal\":\"normal_station\",\"type\":\"fixed\"},\"incentiveFactorLimit\":{\"canUpdate\":false},\"result\":[{\"code\":\"basic\",\"name\":\"默认\",\"resultLimit\":{\"canUpdate\":true,\"limitType\":\"option\",\"optionLimit\":{\"optionList\":[\"0.6\",\"0.8\",\"1.0\",\"1.2\"]}}}]}]},\"name\":\"默认系数\"}],\"selectPlan\":{\"areaSelectPlan\":{\"national\":true}}},\"incentivePlanType\":\"flexible\",\"incentivePlanCode\":\"scale_sta_flexible_incent_fy26q1\",\"planName\":\"FY26Q1规模站点灵活激励\"}]";
        return JSON.parseArray(str, IncentivePlanDTO.class);
    }

}