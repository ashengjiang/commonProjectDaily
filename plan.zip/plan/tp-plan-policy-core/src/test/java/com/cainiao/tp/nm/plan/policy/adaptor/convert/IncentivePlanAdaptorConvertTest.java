package com.cainiao.tp.nm.plan.policy.adaptor.convert;

import java.util.List;

import com.alibaba.fastjson.JSON;

import com.base.BaseTest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.PolicyTemplateIncentiveQueryRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.incentiveplan.IncentivePlanVO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.IncentivePlanDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.IncentivePlanQueryParam;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

/**
 * <a href="https://alidocs.dingtalk.com/i/nodes/dpYLaezmVNRMGX56C1aKjlBOVrMqPxX6">单元测试编写&生成FAQ</a>
 * Created By Thub IDEA插件
 *
 * @Date 2025/6/11 17:20
 */
public class IncentivePlanAdaptorConvertTest extends BaseTest {

    @InjectMocks
    private IncentivePlanAdaptorConvert incentivePlanAdaptorConvert;

    @Before
    public void setUp() throws Exception {MockitoAnnotations.openMocks(this);}

    @Test
    public void testDtoToVo() {
        List<IncentivePlanDTO> incentivePlanDTOList = buildIncentivePlanList();
        // Run the method to be tested
        List<IncentivePlanVO> result = IncentivePlanAdaptorConvert.dtoToVo(incentivePlanDTOList);
        Assert.assertEquals(2, result.size());

        Assert.assertEquals("FY26Q1规模站点基础激励", result.get(0).getPlanName());
        Assert.assertEquals("基础激励", result.get(0).getPlanTitle());
        Assert.assertEquals("scale_sta_basic_incent_fy26q1", result.get(0).getIncentivePlanCode());
        Assert.assertEquals("basic", result.get(0).getIncentivePlanType());
        Assert.assertEquals(1, result.get(0).getBasicIncentiveContent().getValueList().size());
        Assert.assertEquals("1", result.get(0).getBasicIncentiveContent().getValueList().get(0));

        Assert.assertEquals("FY26Q1规模站点灵活激励", result.get(1).getPlanName());
        Assert.assertEquals("灵活激励", result.get(1).getPlanTitle());
        Assert.assertEquals("scale_sta_flexible_incent_fy26q1", result.get(1).getIncentivePlanCode());
        Assert.assertEquals("flexible", result.get(1).getIncentivePlanType());

        Assert.assertEquals("无人站", result.get(1).getFlexibleIncentiveContent().get(0).getStationTypeName());
        Assert.assertEquals("0.6", result.get(1).getFlexibleIncentiveContent().get(0).getValueList().get(0));
        Assert.assertEquals("0.8", result.get(1).getFlexibleIncentiveContent().get(0).getValueList().get(1));
        Assert.assertEquals("1.0", result.get(1).getFlexibleIncentiveContent().get(0).getValueList().get(2));
        Assert.assertEquals("1.2", result.get(1).getFlexibleIncentiveContent().get(0).getValueList().get(3));

        Assert.assertEquals("灯条站", result.get(1).getFlexibleIncentiveContent().get(1).getStationTypeName());
        Assert.assertEquals("0.6", result.get(1).getFlexibleIncentiveContent().get(1).getValueList().get(0));
        Assert.assertEquals("0.8", result.get(1).getFlexibleIncentiveContent().get(1).getValueList().get(1));
        Assert.assertEquals("1.0", result.get(1).getFlexibleIncentiveContent().get(1).getValueList().get(2));
        Assert.assertEquals("1.2", result.get(1).getFlexibleIncentiveContent().get(1).getValueList().get(3));

        Assert.assertEquals("普通站", result.get(1).getFlexibleIncentiveContent().get(2).getStationTypeName());
        Assert.assertEquals("0.6", result.get(1).getFlexibleIncentiveContent().get(2).getValueList().get(0));
        Assert.assertEquals("0.8", result.get(1).getFlexibleIncentiveContent().get(2).getValueList().get(1));
        Assert.assertEquals("1.0", result.get(1).getFlexibleIncentiveContent().get(2).getValueList().get(2));
        Assert.assertEquals("1.2", result.get(1).getFlexibleIncentiveContent().get(2).getValueList().get(3));

    }

    @Test
    public void buildData() {
        List<IncentivePlanDTO> incentivePlanDTOList = buildIncentivePlanList();
        // Run the method to be tested
        System.out.println(JSON.toJSONString(incentivePlanDTOList));

    }

    @Test
    public void testConvertQueryParam() {

        // Run the method to be tested
        IncentivePlanQueryParam result = IncentivePlanAdaptorConvert.convertQueryParam(buildIncentivePlanQueryRequest());

        // Verify the result
        Assert.assertNotNull(result);
        Assert.assertEquals("scale", result.getBizType());
        Assert.assertNotNull(result.getEndTime());
        Assert.assertNotNull(result.getStartTime());
        Assert.assertEquals(1, result.getOutIncentiveTypeList().size());
        Assert.assertEquals("scale_sta_basic_incent_fy26q1", result.getOutIncentiveTypeList().get(0));
    }

    @Test
    public void testEliminateContent(){
        // Prepare method arguments

        // Run the method to be tested
        List<IncentivePlanDTO> result = IncentivePlanAdaptorConvert.eliminateContent(buildIncentivePlanList());

        Assert.assertEquals(2, result.size());
        Assert.assertNull(result.get(0).getContent());
        Assert.assertNull(result.get(1).getContent());
    }

    /**
     * 激励方案
     */
    private List<IncentivePlanDTO> buildIncentivePlanList() {
        String str
            = "[{\"content\":{\"coefficient\":[{\"code\":\"basic\",\"frame\":{\"result\":[{\"code\":\"basic\",\"name\":\"默认\",\"val\":\"1\"}]},\"name\":\"默认系数\"}],\"selectPlan\":{\"areaSelectPlan\":{\"national\":true}}},\"incentivePlanType\":\"basic\",\"incentivePlanCode\":\"scale_sta_basic_incent_fy26q1\",\"planName\":\"FY26Q1规模站点基础激励\"},{\"content\":{\"coefficient\":[{\"code\":\"basic\",\"frame\":{\"children\":[{\"arithLogic\":\"=\",\"factorCode\":\"stationType\",\"factorName\":\"站点类型\",\"factorResult\":{\"fixedVal\":\"non_station\",\"type\":\"fixed\"},\"incentiveFactorLimit\":{\"canUpdate\":false},\"result\":[{\"code\":\"basic\",\"name\":\"默认\",\"resultLimit\":{\"canUpdate\":true,\"limitType\":\"option\",\"optionLimit\":{\"optionList\":[\"0.6\",\"0.8\",\"1.0\",\"1.2\"]}}}]},{\"arithLogic\":\"=\",\"factorCode\":\"stationType\",\"factorName\":\"站点类型\",\"factorResult\":{\"fixedVal\":\"light_station\",\"type\":\"fixed\"},\"incentiveFactorLimit\":{\"canUpdate\":false},\"result\":[{\"code\":\"basic\",\"name\":\"默认\",\"resultLimit\":{\"canUpdate\":true,\"limitType\":\"option\",\"optionLimit\":{\"optionList\":[\"0.6\",\"0.8\",\"1.0\",\"1.2\"]}}}]},{\"arithLogic\":\"=\",\"factorCode\":\"stationType\",\"factorName\":\"站点类型\",\"factorResult\":{\"fixedVal\":\"normal_station\",\"type\":\"fixed\"},\"incentiveFactorLimit\":{\"canUpdate\":false},\"result\":[{\"code\":\"basic\",\"name\":\"默认\",\"resultLimit\":{\"canUpdate\":true,\"limitType\":\"option\",\"optionLimit\":{\"optionList\":[\"0.6\",\"0.8\",\"1.0\",\"1.2\"]}}}]}]},\"name\":\"默认系数\"}],\"selectPlan\":{\"areaSelectPlan\":{\"national\":true}}},\"incentivePlanType\":\"flexible\",\"incentivePlanCode\":\"scale_sta_flexible_incent_fy26q1\",\"planName\":\"FY26Q1规模站点灵活激励\"}]";
        return JSON.parseArray(str, IncentivePlanDTO.class);
    }

    private PolicyTemplateIncentiveQueryRequest buildIncentivePlanQueryRequest() {
        String str
            = "{\"customType\":\"station\",\"bizType\":\"scale\",\"outIncentiveType\":\"scale_sta_basic_incent_fy26q1\",\"expenseItemCode\":\"scale_sta_basic_incent_fy26q1\",\"startTimeStr\":\"2025-06-01\",\"endTimeStr\":\"2025-07-01\"}";
        return JSON.parseObject(str, PolicyTemplateIncentiveQueryRequest.class);
    }


}