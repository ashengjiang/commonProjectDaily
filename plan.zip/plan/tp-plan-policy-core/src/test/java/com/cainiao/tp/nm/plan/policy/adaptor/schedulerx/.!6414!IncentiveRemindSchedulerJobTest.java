package com.cainiao.tp.nm.plan.policy.adaptor.schedulerx;

import com.alibaba.schedulerx.common.domain.InstanceStatus;
import com.alibaba.schedulerx.worker.domain.JobContext;
import com.alibaba.schedulerx.worker.processor.ProcessResult;
import com.cainiao.tp.nm.plan.infra.port.policy.IncentiveRemindStationManager;
import com.cainiao.tp.nm.plan.infra.port.policy.IncentiveRemindStationManager.ScrollResult;
import com.cainiao.tp.nm.plan.infra.port.policy.IncentiveRemindStationManager.StationJoinInfo;
import com.cainiao.tp.nm.plan.policy.application.service.IncentiveRemindApplicationService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

/**
