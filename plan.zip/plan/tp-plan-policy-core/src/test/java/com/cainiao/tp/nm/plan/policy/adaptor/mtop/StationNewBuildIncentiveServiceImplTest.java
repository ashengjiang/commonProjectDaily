package com.cainiao.tp.nm.plan.policy.adaptor.mtop;

import com.cainiao.sutee.commons.base.result.CnResult;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.StationIncentiveRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.station.heavy.StationAssessmentVO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.station.heavy.StationIncentiveVO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.station.StationIncentiveQueryParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.heavy.StationAssessmentDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.heavy.StationIncentiveDTO;
import com.cainiao.tp.nm.plan.api.policy.application.service.station.StationIncentiveAppService;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class StationNewBuildIncentiveServiceImplTest {
    @Mock
    private StationIncentiveAppService stationIncentiveAppService;
    @InjectMocks
    private StationNewBuildIncentiveServiceImpl stationNewBuildIncentiveServiceImpl;

    @Test
    public void testQueryStationNewBuildBillDetailConversionToStationIncentiveVO() {
        // 创建测试请求对象
        StationIncentiveRequest request = new StationIncentiveRequest();
        request.setQuarter("Q1");
        request.setPeriod("2023P1");
        request.setStationId("station123");
        // 创建DTO对象并设置其属性
        StationIncentiveDTO incentiveDTO = new StationIncentiveDTO();
        incentiveDTO.setNotActiveStation("Y");
        incentiveDTO.setResultFeedbackMsg("反馈消息");
        // mock service查询结果的返回值
        when(stationIncentiveAppService.queryStationIncentive(any(StationIncentiveQueryParam.class)))
                .thenReturn(incentiveDTO);
        // 执行方法
        CnResult<StationIncentiveVO> result = stationNewBuildIncentiveServiceImpl.queryStationNewBuildBillDetail(request);
        Assert.assertNotNull(result);
    }


    // 测试正常调用时获取激励考核详情的情况
    @Test
    public void testQueryStationIncentiveAssessmentSuccess() {
        StationIncentiveRequest request = new StationIncentiveRequest();
        request.setQuarter("1");
        request.setPeriod("2023-Q1");
        request.setStationId("ST001");
        StationAssessmentDTO assessmentDTO = new StationAssessmentDTO();
        when(stationIncentiveAppService.queryStationAssessment(any())).thenReturn(assessmentDTO);
        CnResult<StationAssessmentVO> result = stationNewBuildIncentiveServiceImpl.queryStationIncentiveAssessment(request);
        assertNotNull(result);
        // assertTrue(result.isSuccess());  // 此处根据实际情况进行放开或修改
        verify(stationIncentiveAppService, times(1)).queryStationAssessment(any());
    }
}