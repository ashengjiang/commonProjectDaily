package com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan;

import java.util.Arrays;

import com.base.BaseTest;
import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.aladdin.exception.AladdinParamException;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.limit.OptionLimitDTO;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.MockitoAnnotations;

/**
 * <a href="https://alidocs.dingtalk.com/i/nodes/dpYLaezmVNRMGX56C1aKjlBOVrMqPxX6">单元测试编写&生成FAQ</a>
 * Created By Thub IDEA插件
 *
 * @Date 2025/6/4 17:02
 */
public class OptionLimitDTOTest extends BaseTest {


    @Before
    public void setUp() throws Exception {MockitoAnnotations.openMocks(this);}

    @Test
    public void testValidate() {
        OptionLimitDTO optionLimitDTO = new OptionLimitDTO();
        try {
            optionLimitDTO.validate();
        }catch (AladdinParamException e) {
            Assert.assertEquals(e.getMessage(), "optionList不能为空");
        }
        optionLimitDTO.setOptionList(Arrays.asList("1", "1"));
        try {
            optionLimitDTO.validate();
        }catch (AladdinBizException e) {
            Assert.assertEquals(e.getMessage(), "选项值重复");
        }
        optionLimitDTO.setOptionList(Arrays.asList("1", "2"));
        optionLimitDTO.validate();
    }
}