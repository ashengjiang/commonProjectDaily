package com.cainiao.tp.nm.plan.policy.adaptor.convert;

import java.util.Arrays;

import com.base.BaseTest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.LaunchPlanCreateRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.launchplan.AreaRuleLaunchVO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.launchplan.LaunchPlanDTO;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

/**
 * <a href="https://alidocs.dingtalk.com/i/nodes/dpYLaezmVNRMGX56C1aKjlBOVrMqPxX6">单元测试编写&生成FAQ</a>
 * Created By Thub IDEA插件
 *
 * @Date 2025/6/11 18:53
 */
public class LaunchPlanAdaptorConvertTest extends BaseTest {

    @InjectMocks
    private LaunchPlanAdaptorConvert launchPlanAdaptorConvert;

    @Before
    public void setUp() throws Exception {MockitoAnnotations.openMocks(this);}

    @Test
    public void testCreateRequestToDto() {
        // Prepare method arguments
        LaunchPlanCreateRequest launchPlanCreateRequest = new LaunchPlanCreateRequest();
        launchPlanCreateRequest.setLaunchType("rule");
        AreaRuleLaunchVO areaRuleLaunchVO = new AreaRuleLaunchVO();
        areaRuleLaunchVO.setProvinceCodeList(Arrays.asList("1", "2"));
        areaRuleLaunchVO.setCityCodeList(Arrays.asList("3", "4"));
        areaRuleLaunchVO.setDistrictCodeList(Arrays.asList("5", "6"));
        launchPlanCreateRequest.setAreaRuleLaunch(areaRuleLaunchVO);
        // Run the method to be tested
        LaunchPlanDTO result = LaunchPlanAdaptorConvert.createRequestToDto(launchPlanCreateRequest, "station");

        // Verify the result
        Assert.assertNotNull(result);
        Assert.assertNotNull(result.getRuleLaunch());
        Assert.assertNotNull(result.getRuleLaunch().getAreaRuleLaunch());
        Assert.assertNotNull(result.getRuleLaunch().getAreaRuleLaunch().getProvinceCodeList());
        Assert.assertEquals(2, result.getRuleLaunch().getAreaRuleLaunch().getProvinceCodeList().size());
        Assert.assertEquals("1", result.getRuleLaunch().getAreaRuleLaunch().getProvinceCodeList().get(0));
        Assert.assertEquals("2", result.getRuleLaunch().getAreaRuleLaunch().getProvinceCodeList().get(1));
        Assert.assertNotNull(result.getRuleLaunch().getAreaRuleLaunch().getCityCodeList());

        Assert.assertEquals(2, result.getRuleLaunch().getAreaRuleLaunch().getCityCodeList().size());
        Assert.assertEquals("3", result.getRuleLaunch().getAreaRuleLaunch().getCityCodeList().get(0));
        Assert.assertEquals("4", result.getRuleLaunch().getAreaRuleLaunch().getCityCodeList().get(1));
        Assert.assertNotNull(result.getRuleLaunch().getAreaRuleLaunch().getDistrictCodeList());
        Assert.assertEquals(2, result.getRuleLaunch().getAreaRuleLaunch().getDistrictCodeList().size());
        Assert.assertEquals("5", result.getRuleLaunch().getAreaRuleLaunch().getDistrictCodeList().get(0));
        Assert.assertEquals("6", result.getRuleLaunch().getAreaRuleLaunch().getDistrictCodeList().get(1));

        LaunchPlanCreateRequest launchPlanCreateRequest2 = new LaunchPlanCreateRequest();
        launchPlanCreateRequest2.setEntityAttrCode("staCode");
        launchPlanCreateRequest2.setLaunchType("list");
        launchPlanCreateRequest2.setTagCodeList(Arrays.asList("code1", "code2"));
        LaunchPlanDTO result2 = LaunchPlanAdaptorConvert.createRequestToDto(launchPlanCreateRequest2, "station");
        Assert.assertNotNull(result2);
        Assert.assertNotNull(result2.getListLaunch());
        Assert.assertNotNull(result2.getListLaunch().getItemLaunch());
        Assert.assertEquals(2, result2.getListLaunch().getItemLaunch().size());
        Assert.assertEquals("code1", result2.getListLaunch().getItemLaunch().get(0).getAttrValue());
        Assert.assertEquals("station", result2.getListLaunch().getItemLaunch().get(0).getType());
        Assert.assertEquals("staCode", result2.getListLaunch().getItemLaunch().get(0).getAttrCode());
        Assert.assertEquals("code2", result2.getListLaunch().getItemLaunch().get(1).getAttrValue());
        Assert.assertEquals("station", result2.getListLaunch().getItemLaunch().get(1).getType());
        Assert.assertEquals("staCode", result2.getListLaunch().getItemLaunch().get(1).getAttrCode());
    }
}