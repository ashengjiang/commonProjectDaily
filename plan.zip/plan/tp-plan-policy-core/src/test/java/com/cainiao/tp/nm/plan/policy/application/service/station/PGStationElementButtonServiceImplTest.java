package com.cainiao.tp.nm.plan.policy.application.service.station;

import com.cainiao.aladdin.env.SystemEnvEnum;
import com.cainiao.aladdin.env.SystemEnvUtil;
import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.tp.nm.plan.api.policy.application.dto.StationDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.station.StationElementButtonQueryParam;
import com.cainiao.tp.nm.plan.infra.port.policy.StaStationReadManager;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Date;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class PGStationElementButtonServiceImplTest {


    @InjectMocks
    private PGStationElementButtonServiceImpl service;
    @Mock
    private StaStationReadManager staStationReadManager;

    // 根据站点ID判断站点模式
    @Test
    public void testGetButtonUrlStationModeDeterminedByStationId() {
        try (MockedStatic<SystemEnvUtil> envUtilMockedStatic = Mockito.mockStatic(SystemEnvUtil.class)) {
            envUtilMockedStatic.when(SystemEnvUtil::getEnv).thenReturn(SystemEnvEnum.PRE);
            // 创建入参对象，并设置属性
            StationElementButtonQueryParam param = new StationElementButtonQueryParam();
            param.setStationId("POINT_321");
            param.setEmployeeId("123456");
            param.setSource("XN");

            AbstractOperation operation = mock(AbstractOperation.class);
            // Mock StationDTO
            StationDTO stationDTO = mock(StationDTO.class);
            when(stationDTO.getGmtCreate()).thenReturn(new Date());
            when(staStationReadManager.queryStation(param.getStationId())).thenReturn(stationDTO);
            // 执行被测方法
            String result = service.getButtonUrl(param, operation);
//            Assert.assertNotNull(result);
        }
    }
}