package com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan;

import com.alibaba.fastjson.JSON;

import com.base.BaseTest;
import com.cainiao.aladdin.exception.AladdinParamException;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.IncentivePlanDTO;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.MockitoAnnotations;

/**
 * <a href="https://alidocs.dingtalk.com/i/nodes/dpYLaezmVNRMGX56C1aKjlBOVrMqPxX6">单元测试编写&生成FAQ</a>
 * Created By Thub IDEA插件
 *
 * @Date 2025/6/4 16:49
 */
public class IncentivePlanDTOTest extends BaseTest {

    @Before
    public void setUp() throws Exception {MockitoAnnotations.openMocks(this);}

    @Test
    public void testValidate() {
        IncentivePlanDTO incentivePlanDTO = new IncentivePlanDTO();
        try {
            incentivePlanDTO.validate();
        }catch (AladdinParamException e){
            Assert.assertEquals("planName不能为空,incentivePlanType不能为空,incentivePlanCode不能为空", e.getMessage());
        }
        buildBasic().validate();
        buildFlexible().validate();
    }

    /**
     * 基础激励
     */
    private IncentivePlanDTO buildBasic(){
        String str = "{\"content\":{\"coefficient\":[{\"code\":\"basic\",\"frame\":{\"result\":[{\"code\":\"basic\",\"name\":\"默认\",\"val\":\"1\"}]},\"name\":\"默认系数\"}],\"selectPlan\":{\"areaSelectPlan\":{\"national\":true}}},\"incentivePlanType\":\"basic\",\"incentivePlanCode\":\"scale_sta_basic_incent_fy26q1\",\"planName\":\"FY26Q1规模站点基础激励\"}";
        return JSON.parseObject(str, IncentivePlanDTO.class);
    }
    /**
     * 灵活激励
     */
    private IncentivePlanDTO buildFlexible(){
        String str = "{\"content\":{\"coefficient\":[{\"code\":\"basic\",\"frame\":{\"children\":[{\"arithLogic\":\"=\",\"factorCode\":\"stationType\",\"factorName\":\"站点类型\",\"factorResult\":{\"fixedVal\":\"non_station\",\"type\":\"fixed\"},\"incentiveFactorLimit\":{\"canUpdate\":false},\"result\":[{\"code\":\"basic\",\"name\":\"默认\",\"resultLimit\":{\"canUpdate\":true,\"limitType\":\"option\",\"optionLimit\":{\"optionList\":[\"0.6\",\"0.8\",\"1.0\",\"1.2\"]}}}]},{\"arithLogic\":\"=\",\"factorCode\":\"stationType\",\"factorName\":\"站点类型\",\"factorResult\":{\"fixedVal\":\"light_station\",\"type\":\"fixed\"},\"incentiveFactorLimit\":{\"canUpdate\":false},\"result\":[{\"code\":\"basic\",\"name\":\"默认\",\"resultLimit\":{\"canUpdate\":true,\"limitType\":\"option\",\"optionLimit\":{\"optionList\":[\"0.6\",\"0.8\",\"1.0\",\"1.2\"]}}}]},{\"arithLogic\":\"=\",\"factorCode\":\"stationType\",\"factorName\":\"站点类型\",\"factorResult\":{\"fixedVal\":\"normal_station\",\"type\":\"fixed\"},\"incentiveFactorLimit\":{\"canUpdate\":false},\"result\":[{\"code\":\"basic\",\"name\":\"默认\",\"resultLimit\":{\"canUpdate\":true,\"limitType\":\"option\",\"optionLimit\":{\"optionList\":[\"0.6\",\"0.8\",\"1.0\",\"1.2\"]}}}]}]},\"name\":\"默认系数\"}],\"selectPlan\":{\"areaSelectPlan\":{\"national\":true}}},\"incentivePlanType\":\"flexible\",\"incentivePlanCode\":\"scale_sta_flexible_incent_fy26q1\",\"planName\":\"FY26Q1规模站点灵活激励\"}";
        return JSON.parseObject(str, IncentivePlanDTO.class);
    }
}