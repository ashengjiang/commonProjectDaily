package com.cainiao.tp.nm.plan.policy.adaptor.schedulerx;

import com.alibaba.fastjson.JSON;
import com.alibaba.schedulerx.common.domain.InstanceStatus;
import com.alibaba.schedulerx.worker.domain.JobContext;
import com.alibaba.schedulerx.worker.processor.ProcessResult;
import com.base.BaseTest;
import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.sutee.commons.base.model.CnPage;
import com.cainiao.sutee.commons.base.model.Page;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.PolicyBatchSubmissionJobDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.TpTicketDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.TicketInstanceApprovalStartParam;
import com.cainiao.tp.nm.plan.infra.port.policy.TicketApprovalManager;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyInstanceDTO;
import com.cainiao.tp.nm.plan.api.policy.application.service.PolicyInstanceAppService;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyInstanceApprovalStatusEnum;
import com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import static org.mockito.Mockito.any;

/**
 * <a href="https://alidocs.dingtalk.com/i/nodes/dpYLaezmVNRMGX56C1aKjlBOVrMqPxX6">单元测试编写&生成FAQ</a>
 * Created By Thub IDEA插件
 *
 * @Date 2025/6/9 11:44
 */
public class PolicyBatchSubmissionJobTest extends BaseTest {

    @InjectMocks
    private PolicyBatchSubmissionJob policyBatchSubmissionJob;
    @Mock
    private PolicyInstanceAppService policyInstanceAppService;
    @Mock
    private TicketApprovalManager<TicketInstanceApprovalStartParam, TpTicketDTO> policyInstanceApprovalManager;
    @Mock
    private AbstractOperation opInfo;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testHandle() {
        // Setup, prepare mock data
        List<PolicyInstanceDTO> policyInstanceDTOList = new ArrayList<>();
        PolicyInstanceDTO policyInstanceDTO = new PolicyInstanceDTO();
        policyInstanceDTO.setId(1L);
        policyInstanceDTO.setStartTime(DateUtils.toLocalDateTimeYmdhms("2100-06-09 12:00:00"));
        policyInstanceDTO.setApprovalStatus(PolicyInstanceApprovalStatusEnum.APPROVALING.getCode());
        policyInstanceDTO.setApprovalFollowId("1");
        policyInstanceDTOList.add(policyInstanceDTO);

        PolicyInstanceDTO policyInstanceDTO2 = new PolicyInstanceDTO();
        policyInstanceDTO2.setId(2L);
        policyInstanceDTO2.setStartTime(DateUtils.toLocalDateTimeYmdhms("2025-06-01 10:00:00"));
        policyInstanceDTO2.setApprovalStatus(PolicyInstanceApprovalStatusEnum.APPROVALING.getCode());
        policyInstanceDTO2.setApprovalFollowId("2");
        policyInstanceDTOList.add(policyInstanceDTO2);

        PolicyInstanceDTO policyInstanceDTO3 = new PolicyInstanceDTO();
        policyInstanceDTO3.setId(3L);
        policyInstanceDTO3.setStartTime(DateUtils.toLocalDateTimeYmdhms("2025-06-01 10:00:00"));
        policyInstanceDTO3.setEffectTime(DateUtils.toLocalDateTimeYmdhms("2025-06-02 10:00:00"));
        policyInstanceDTO3.setApprovalStatus(PolicyInstanceApprovalStatusEnum.APPROVALING.getCode());
        policyInstanceDTO3.setApprovalFollowId("3");
        policyInstanceDTOList.add(policyInstanceDTO3);

        Page<PolicyInstanceDTO> page1 = CnPage.of(1, 10, policyInstanceDTOList, 3);
        Page<PolicyInstanceDTO> page2 = CnPage.of(1, 10, null, 0);

        Mockito.when(policyInstanceAppService.queryPolicyInstanceList(any(), any()))
            .thenReturn(page1,page2);

        // Prepare method arguments

        // Run the method to be tested
        PolicyBatchSubmissionJobDTO policyBatchSubmissionJobDTO = new PolicyBatchSubmissionJobDTO();
        policyBatchSubmissionJobDTO.setMaxPageNum(2);
        policyBatchSubmissionJobDTO.setPageSize(10);
        JobContext context = JobContext.newBuilder()
            .setJobParameters(JSON.toJSONString(policyBatchSubmissionJobDTO)).build();
        ProcessResult process = policyBatchSubmissionJob.process(context);

        // Verify the result
        Assert.assertEquals(InstanceStatus.SUCCESS,process.getStatus());

    }
}