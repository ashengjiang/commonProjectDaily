package com.cainiao.tp.nm.plan.policy.adaptor.service;

import com.alibaba.fastjson.JSONObject;
import com.cainiao.sutee.commons.base.result.CnResult;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.StaScalePolicyCoefficientDTO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.StaScalePolicyByCollectQueryRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.StationAnnualPolicyQueryRequest;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiverule.IncentiveRuleFrameDTO;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyInstanceStatusEnum;
import com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils;
import com.cainiao.tp.nm.plan.infra.port.collect.CollectPointInfoDTO;
import com.cainiao.tp.nm.plan.infra.port.collect.TseCollectPointManager;
import com.cainiao.tp.nm.plan.infra.port.tag.TseTagManager;
import com.cainiao.tp.nm.plan.policy.domain.model.PolicyInstance;
import com.cainiao.tp.nm.plan.policy.domain.model.PolicyTemplate;
import com.cainiao.tp.nm.plan.policy.domain.model.valobj.incentiverule.IncentiveRule;
import com.cainiao.tp.nm.plan.policy.domain.model.valobj.incentiverule.IncentiveRuleContent;
import com.cainiao.tp.nm.plan.policy.domain.model.valobj.incentiverule.select.SelectRule;
import com.cainiao.tp.nm.plan.policy.domain.model.valobj.launchplan.LaunchPlan;
import com.cainiao.tp.nm.plan.policy.domain.repository.PolicyInstanceRepository;
import com.cainiao.tp.nm.plan.policy.domain.repository.PolicyTemplateRepository;
import com.google.common.collect.Lists;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.time.LocalDateTime;
import java.util.Collections;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class PolicyScaleBizServiceImplTest {

    @Mock
    private PolicyTemplateRepository policyTemplateRepository;

    @Mock
    private PolicyInstanceRepository policyInstanceRepository;

    @InjectMocks
    private PolicyScaleBizServiceImpl policyScaleBizService;
    @Mock
    private TseCollectPointManager tseCollectPointManager;
    @Mock
    private TseTagManager tseTagManager;

    /**
     * 测试当没有找到有效的政策模板时，返回成功的CnResult
     */
    @Test
    public void testQueryStationAnnualPolicyInstanceNoValidTemplate() {
        // 设置请求参数
        StationAnnualPolicyQueryRequest request = new StationAnnualPolicyQueryRequest();
        request.setStationId("123");

        // Mock 模板查询返回空列表
        when(policyTemplateRepository.get(any(), any())).thenReturn(Collections.emptyList());

        // 调用方法并验证返回结果
        CnResult<IncentiveRuleFrameDTO> result = policyScaleBizService.queryStationAnnualPolicyInstance(request);
        assertTrue(result.isSuccess()); // 预期结果是成功
    }

    /**
     * 测试当找到有效的政策模板和政策实例，并且实例状态为EFFECT且匹配省份时，返回带有数据的CnResult
     */
    @Test
    public void testQueryStationAnnualPolicyInstanceEffectiveInstanceWithData() {
        // 设置请求参数
        StationAnnualPolicyQueryRequest request = new StationAnnualPolicyQueryRequest();
        request.setStationId("123");

        // 模拟返回有效的模板，使用构造器初始化所有必要的参数
        PolicyTemplate policyTemplate = PolicyTemplate.builder()
                .id(123L)
                .startTime(DateUtils.toLocalDateTimeYmdStart("2025-01-01"))
                .endTime(DateUtils.toLocalDateTimeYmdStart("2099-01-01"))
                .build();
        when(policyTemplateRepository.get(any(), any())).thenReturn(Collections.singletonList(policyTemplate));


        PolicyInstance policyInstance = PolicyInstance.builder()
                .id(456L)
                .templateId(123L)
                .status(PolicyInstanceStatusEnum.EFFECT.getCode())
                .startTime(DateUtils.toLocalDateTimeYmdStart("2025-01-01"))
                .endTime(DateUtils.toLocalDateTimeYmdStart("2099-01-01"))
                .build();

        when(policyInstanceRepository.listByTemplate(any(), any())).thenReturn(Collections.singletonList(policyInstance));

        // 调用方法并验证返回结果
        CnResult<IncentiveRuleFrameDTO> result = policyScaleBizService.queryStationAnnualPolicyInstance(request);

        // 断言返回结果
        assertTrue(result.isSuccess()); // 预期结果是成功
        // assertTrue(result.getData() != null); // 预期有数据返回，可以根据实际情况取消注释
    }

    /**
     * 测试当收集点标签正确且找到有效政策规则时，应该返回相应的系数数据
     */
    @Test
    public void testQueryStaScalePolicyByCollectSuccessScenario() {
        StaScalePolicyByCollectQueryRequest request = new StaScalePolicyByCollectQueryRequest();
        request.setCollectPointId("123");
        request.setPolicyDate(LocalDateTime.now());

        CollectPointInfoDTO collectPointInfo = new CollectPointInfoDTO();
        collectPointInfo.setProvinceCode("someProvince");
        collectPointInfo.setCityCode("330600");
        collectPointInfo.setDistrictCode("someDistrict");

        IncentiveRule incentiveRule = new IncentiveRule();
        incentiveRule.setPriority(1L);
        incentiveRule.setSelectRule(JSONObject.parseObject("{\"areaSelectRule\":{\"cityCode\":\"330600\",\"provinceCode\":\"330000\"},\"tagSelectRule\":{\"tagCodeList\":[\"aoiBlank\"]}}", SelectRule.class));
        incentiveRule.setContent(JSONObject.parseObject("{\"coefficient\":[{\"code\":\"basic\",\"frame\":{\"result\":[{\"code\":\"coefficient\",\"name\":\"默认\",\"resultLimit\":{\"canUpdate\":true,\"limitType\":\"option\",\"optionLimit\":{\"optionList\":[\"1.0\",\"1.5\"]},\"valType\":\"double\"},\"val\":\"1.5\"}]},\"name\":\"默认系数\"}]}", IncentiveRuleContent.class));

        PolicyTemplate policyTemplate = PolicyTemplate.builder().id(123L)
                .startTime(DateUtils.toLocalDateTimeYmdStart("2025-01-01"))
                .endTime(DateUtils.toLocalDateTimeYmdStart("2099-01-01"))
                .launchPlan(JSONObject.parseObject("{\"launchType\":\"rule\",\"ruleLaunch\":{\"areaRuleLaunch\":{\"national\":true},\"tagRuleLaunch\":{\"tagCodeList\":[\"aoiBlank\",\"aoiHighLevel\"]}}}", LaunchPlan.class))
                .build();
        PolicyInstance policyInstance = PolicyInstance.builder().id(456L).templateId(123L)
                .status(PolicyInstanceStatusEnum.EFFECT.getCode())
                .incentiveRuleList(Lists.newArrayList(incentiveRule))
                .build();

        // Mock method calls
        when(tseCollectPointManager.queryCollectInfo(request.getCollectPointId())).thenReturn(collectPointInfo);
        when(policyTemplateRepository.get(any(), any())).thenReturn(Lists.newArrayList(policyTemplate));
        when(policyInstanceRepository.listByTemplate(anyLong(), any())).thenReturn(Lists.newArrayList(policyInstance));
        when(tseTagManager.queryCollectTag(anyString(), anyList())).thenReturn(Lists.newArrayList("aoiBlank"));

        CnResult<StaScalePolicyCoefficientDTO> result = policyScaleBizService.queryStaScalePolicyByCollect(request);

        // 验证结果
        assertEquals(true, result.isSuccess()); // 预期成功返回
        // assertNotNull(result.getData()); // 预期获取系数 DTO
    }
}