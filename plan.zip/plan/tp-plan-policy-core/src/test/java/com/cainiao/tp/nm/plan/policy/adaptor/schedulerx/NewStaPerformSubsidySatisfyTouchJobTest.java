package com.cainiao.tp.nm.plan.policy.adaptor.schedulerx;

import com.alibaba.schedulerx.common.domain.InstanceStatus;
import com.alibaba.schedulerx.worker.domain.JobContext;
import com.alibaba.schedulerx.worker.processor.ProcessResult;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.NewStaPerformSubsidyConfigDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.NewStaPerformSubsidyPopConfigDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.NewStaPerformSubsidySatisfyTouchParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.NewStaPerformSubsidyDataDTO;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyConfigManager;
import com.cainiao.tp.nm.plan.infra.port.policy.TgManager;
import com.cainiao.tp.nm.plan.infra.port.policy.TpPushStationMessageManager;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Collections;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class NewStaPerformSubsidySatisfyTouchJobTest {

    @InjectMocks
    private NewStaPerformSubsidySatisfyTouchJob job;

    @Mock
    private TgManager tgManager;

    @Mock
    private PolicyConfigManager policyConfigManager;

    @Mock
    private TpPushStationMessageManager tpPushStationMessageManager;

    @Test
    public void testProcessWhenSubsidyDataFound() throws Exception {
        // 测试在成功找到补贴数据的情况下，process方法的执行情况
        JobContext.JobContextBuilder jobContextBuilder = JobContext.newBuilder();
        jobContextBuilder.setJobParameters("{\"stationId\":\"123456\", \"pageSize\":1, \"maxLoop\":5, \"pageIndex\":0}");
        JobContext jobContext = jobContextBuilder.build();

        NewStaPerformSubsidyConfigDTO configDTO = new NewStaPerformSubsidyConfigDTO();
        configDTO.setNewStaPerformSubsidyPriceQlExpress("qlExpress");
        configDTO.setNewStaPerformSubsidyPriceLadderList(Collections.singletonList(100.0));

        NewStaPerformSubsidyDataDTO dataDTO = new NewStaPerformSubsidyDataDTO();
        dataDTO.setCoefficient(1.0);
        dataDTO.setStatsMonthAvgVaildArrCnt(50.0);

        NewStaPerformSubsidyPopConfigDTO popConfigDTO = new NewStaPerformSubsidyPopConfigDTO();
        popConfigDTO.setGoToUrl("http://example.com");

        when(policyConfigManager.getNewStaPerformSubsidyConfig()).thenReturn(configDTO);
        when(policyConfigManager.getNewStaPerformSubsidyPopConfig()).thenReturn(popConfigDTO);
        when(tgManager.getListData(any(NewStaPerformSubsidySatisfyTouchParam.class)))
                .thenReturn(Collections.singletonList(dataDTO));

        ProcessResult result = job.process(jobContext);

//        verify(tpPushStationMessageManager, times(1)).sendNewStaPerformSubsidySatisfyPopup(anyLong(), any(), anyString());
        assertTrue(result.getStatus() == InstanceStatus.SUCCESS); // 为了验证 ProcessResult 状态是否成功
    }
}