package com.cainiao.tp.nm.plan.policy.application.convert;

import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.tp.nm.plan.api.policy.application.dto.BaseDivisionInfoDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.ExpressOutletsBaseInfoDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyInstanceRuleDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyInstanceRuleHistoryDetailDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyRuleDetailDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.base.ColumnDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiverule.IncentiveRuleDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiverule.IncentiveRuleDetailDTO;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyCustomTypeEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyRuleHistoryTableEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyRuleTableEnum;
import com.google.common.collect.Lists;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class PolicyInstanceRuleApplicationConvertTest {
    @InjectMocks
    private PolicyInstanceRuleApplicationConvert convert;


    @Test(expected = AladdinBizException.class)
    public void testBuildExpressOutletsBaseInfoSelectRuleDTONull() {
        PolicyInstanceRuleDTO ruleDTO = new PolicyInstanceRuleDTO();
        ruleDTO.setCustomType(PolicyCustomTypeEnum.EXPRESS.getType());
        ruleDTO.setLaunchObject("{}"); // JSON格式的字符串，用于构建SelectRuleDTO
        ruleDTO.setRuleContent("{}");
        ExpressOutletsBaseInfoDTO result = PolicyInstanceRuleApplicationConvert.buildExpressOutletsBaseInfo(ruleDTO);
        Assert.assertNull(result);
    }

    @Test
    public void testBuildExpressOutletsBaseInfoParamNull() {
        ExpressOutletsBaseInfoDTO result = PolicyInstanceRuleApplicationConvert.buildExpressOutletsBaseInfo(null);
        Assert.assertNull(result);
    }

    @Test
    public void testBuildExpressOutletsBaseInfoEntitySelectRuleTypeNotExpress() {
        PolicyInstanceRuleDTO ruleDTO = new PolicyInstanceRuleDTO();
        ruleDTO.setCustomType(PolicyCustomTypeEnum.STATION.getType());
        ExpressOutletsBaseInfoDTO result = PolicyInstanceRuleApplicationConvert.buildExpressOutletsBaseInfo(ruleDTO);
        Assert.assertNull(result);
    }

    @Test
    public void buildExpressOutletsBaseInfo() {
        PolicyInstanceRuleDTO ruleDTO = new PolicyInstanceRuleDTO();
        ruleDTO.setId(1L);
        ruleDTO.setInstanceId(2L);
        ruleDTO.setIncentivePlanType("flexible");
        ruleDTO.setTemplateId(3L);
        ruleDTO.setCustomType("express");
        ruleDTO.setApprovalStatus((byte) 0);
        ruleDTO.setProvinceCode("1");
        ruleDTO.setCityCode("2");
        ruleDTO.setDistrictCode("4");
        ruleDTO.setStartTime(LocalDateTime.now());
        ruleDTO.setEndTime(LocalDateTime.now());
        ruleDTO.setLaunchObject("{\"areaSelectRule\":{\"provinceCode\":\"330000\",\"cityCode\":\"330100\",\"districtCode\":\"330110\"},\"entitySelectRule\":{\"type\":\"express\",\"entityType\":\"jv\",\"entityId\":\"CP^^^LE40668900\",\"entityName\":\"兰西县xxxx\"},\"tagSelectRule\":{\"tagCodeList\":[\"STO\"]}}");
        ruleDTO.setRuleContent("{\"coefficient\":[{\"code\":\"basic\",\"name\":\"基础系数\",\"frame\":{\"children\":[{\"factorCode\":\"stationType\",\"arithLogic\":\"=\",\"factorResult\":{\"type\":\"fixed\",\"fixedVal\":\"non^^^station\"},\"result\":[{\"code\":\"basic\",\"name\":\"基础系数\",\"val\":\"0.6\"}]},{\"factorCode\":\"stationType\",\"arithLogic\":\"=\",\"factorResult\":{\"type\":\"fixed\",\"fixedVal\":\"light^^^station\"},\"result\":[{\"code\":\"basic\",\"name\":\"基础系数\",\"val\":\"0.8\"}]},{\"factorCode\":\"stationType\",\"arithLogic\":\"=\",\"factorResult\":{\"type\":\"fixed\",\"fixedVal\":\"normal^^^station\"},\"result\":[{\"code\":\"basic\",\"name\":\"基础系数\",\"val\":\"1.0\"}]}]}}]}");
        ExpressOutletsBaseInfoDTO result = PolicyInstanceRuleApplicationConvert.buildExpressOutletsBaseInfo(ruleDTO);
        Assert.assertNotNull(result);
        Assert.assertEquals("CP^^^LE40668900", result.getOrgCode());
        Assert.assertEquals("兰西县xxxx", result.getOrgName());
        Assert.assertEquals("JV", result.getOrgType());
    }

    @Test
    public void buildExpressOutletsBaseInfoNeedCpCode() {
        PolicyInstanceRuleDTO ruleDTO = new PolicyInstanceRuleDTO();
        ruleDTO.setId(1L);
        ruleDTO.setInstanceId(2L);
        ruleDTO.setIncentivePlanType("flexible");
        ruleDTO.setTemplateId(3L);
        ruleDTO.setCustomType("express");
        ruleDTO.setApprovalStatus((byte) 0);
        ruleDTO.setProvinceCode("1");
        ruleDTO.setCityCode("2");
        ruleDTO.setDistrictCode("4");
        ruleDTO.setStartTime(LocalDateTime.now());
        ruleDTO.setEndTime(LocalDateTime.now());
        ruleDTO.setLaunchObject("{\"areaSelectRule\":{\"provinceCode\":\"330000\",\"cityCode\":\"330100\",\"districtCode\":\"330110\"},\"entitySelectRule\":{\"type\":\"express\",\"entityType\":\"jv\",\"entityId\":\"CP^^^LE40668900\",\"entityName\":\"兰西县xxxx\"},\"tagSelectRule\":{\"tagCodeList\":[\"STO\"]}}");
        ruleDTO.setRuleContent("{\"coefficient\":[{\"code\":\"basic\",\"name\":\"基础系数\",\"frame\":{\"children\":[{\"factorCode\":\"stationType\",\"arithLogic\":\"=\",\"factorResult\":{\"type\":\"fixed\",\"fixedVal\":\"non^^^station\"},\"result\":[{\"code\":\"basic\",\"name\":\"基础系数\",\"val\":\"0.6\"}]},{\"factorCode\":\"stationType\",\"arithLogic\":\"=\",\"factorResult\":{\"type\":\"fixed\",\"fixedVal\":\"light^^^station\"},\"result\":[{\"code\":\"basic\",\"name\":\"基础系数\",\"val\":\"0.8\"}]},{\"factorCode\":\"stationType\",\"arithLogic\":\"=\",\"factorResult\":{\"type\":\"fixed\",\"fixedVal\":\"normal^^^station\"},\"result\":[{\"code\":\"basic\",\"name\":\"基础系数\",\"val\":\"1.0\"}]}]}}]}");
        ExpressOutletsBaseInfoDTO result = PolicyInstanceRuleApplicationConvert.buildExpressOutletsBaseInfo(ruleDTO);
        Assert.assertNotNull(result);
        Assert.assertEquals("CP^^^LE40668900", result.getOrgCode());
        Assert.assertEquals("JV", result.getOrgType());
    }


    @Test
    public void testBuildIncentiveRuleDetailWithNullRuleDTO() {
        List<IncentiveRuleDetailDTO> result = PolicyInstanceRuleApplicationConvert.buildIncentiveRuleDetail((PolicyInstanceRuleDTO) null);
        Assert.assertTrue(result.isEmpty());
    }

    @Test
    public void testBuildIncentiveRuleDTO() {
        PolicyInstanceRuleDTO ruleDTO = new PolicyInstanceRuleDTO();
        ruleDTO.setId(1L);
        ruleDTO.setInstanceId(2L);
        ruleDTO.setIncentivePlanType("flexible");
        ruleDTO.setTemplateId(3L);
        ruleDTO.setCustomType("express");
        ruleDTO.setApprovalStatus((byte) 0);
        ruleDTO.setProvinceCode("1");
        ruleDTO.setCityCode("2");
        ruleDTO.setDistrictCode("4");
        ruleDTO.setStartTime(LocalDateTime.now());
        ruleDTO.setEndTime(LocalDateTime.now());
        ruleDTO.setLaunchObject("{\"areaSelectRule\":{\"provinceCode\":\"330000\",\"cityCode\":\"330100\",\"districtCode\":\"330110\"},\"entitySelectRule\":{\"type\":\"express\",\"entityType\":\"org\",\"entityId\":\"LE40668900\",\"entityName\":\"兰西县xxxx\"},\"tagSelectRule\":{\"tagCodeList\":[\"STO\"]}}");
        ruleDTO.setRuleContent("{\"coefficient\":[{\"code\":\"basic\",\"name\":\"基础系数\",\"frame\":{\"children\":[{\"factorCode\":\"stationType\",\"arithLogic\":\"=\",\"factorResult\":{\"type\":\"fixed\",\"fixedVal\":\"non^^^station\"},\"result\":[{\"code\":\"basic\",\"name\":\"基础系数\",\"val\":\"0.6\"}]},{\"factorCode\":\"stationType\",\"arithLogic\":\"=\",\"factorResult\":{\"type\":\"fixed\",\"fixedVal\":\"light^^^station\"},\"result\":[{\"code\":\"basic\",\"name\":\"基础系数\",\"val\":\"0.8\"}]},{\"factorCode\":\"stationType\",\"arithLogic\":\"=\",\"factorResult\":{\"type\":\"fixed\",\"fixedVal\":\"normal^^^station\"},\"result\":[{\"code\":\"basic\",\"name\":\"基础系数\",\"val\":\"1.0\"}]}]}}]}");

        IncentiveRuleDTO incentiveRule = PolicyInstanceRuleApplicationConvert.buildIncentiveRuleDTO(ruleDTO);
        Assert.assertNotNull(incentiveRule);
    }

    @Test
    public void testBuildIncentiveRuleDetail() {
        PolicyInstanceRuleDTO ruleDTO = new PolicyInstanceRuleDTO();
        ruleDTO.setId(1L);
        ruleDTO.setInstanceId(2L);
        ruleDTO.setIncentivePlanType("flexible");
        ruleDTO.setTemplateId(3L);
        ruleDTO.setCustomType("express");
        ruleDTO.setApprovalStatus((byte) 0);
        ruleDTO.setProvinceCode("1");
        ruleDTO.setCityCode("2");
        ruleDTO.setDistrictCode("4");
        ruleDTO.setStartTime(LocalDateTime.now());
        ruleDTO.setEndTime(LocalDateTime.now());
        ruleDTO.setLaunchObject("{\"areaSelectRule\":{\"provinceCode\":\"330000\",\"cityCode\":\"330100\",\"districtCode\":\"330110\"},\"entitySelectRule\":{\"type\":\"express\",\"entityType\":\"org\",\"entityId\":\"LE40668900\",\"entityName\":\"兰西县xxxx\"},\"tagSelectRule\":{\"tagCodeList\":[\"STO\"]}}");
        ruleDTO.setRuleContent("{\"coefficient\":[{\"code\":\"basic\",\"name\":\"基础系数\",\"frame\":{\"children\":[{\"factorCode\":\"stationType\",\"arithLogic\":\"=\",\"factorResult\":{\"type\":\"fixed\",\"fixedVal\":\"non^^^station\"},\"result\":[{\"code\":\"basic\",\"name\":\"基础系数\",\"val\":\"0.6\"}]},{\"factorCode\":\"stationType\",\"arithLogic\":\"=\",\"factorResult\":{\"type\":\"fixed\",\"fixedVal\":\"light^^^station\"},\"result\":[{\"code\":\"basic\",\"name\":\"基础系数\",\"val\":\"0.8\"}]},{\"factorCode\":\"stationType\",\"arithLogic\":\"=\",\"factorResult\":{\"type\":\"fixed\",\"fixedVal\":\"normal^^^station\"},\"result\":[{\"code\":\"basic\",\"name\":\"基础系数\",\"val\":\"1.0\"}]}]}}]}");

        List<IncentiveRuleDetailDTO> detailDTOS = PolicyInstanceRuleApplicationConvert.buildIncentiveRuleDetail(ruleDTO);
        Assert.assertNotNull(detailDTOS);
        Assert.assertEquals(3, detailDTOS.size());

    }


    @Test
    public void testBuildHistoryRuleColumn() {
        List<PolicyRuleHistoryTableEnum> station = PolicyRuleHistoryTableEnum.getTableColumn("station");
        // 执行待测方法
        List<ColumnDTO> result = PolicyInstanceRuleApplicationConvert.buildHistoryRuleColumn("station");
        // 验证结果
        assertEquals(station.size(), result.size());
    }

    @Test
    public void testBuildRuleColumn() {
        List<PolicyRuleTableEnum> station = PolicyRuleTableEnum.getTableColumn("station");
        // 执行待测方法
        List<ColumnDTO> result = PolicyInstanceRuleApplicationConvert.buildRuleColumn("station");
        // 验证结果
        assertEquals(station.size(), result.size());
    }


    @Test
    public void testBuildDivisionMapNullInput() {
        Map<String, String> result = PolicyInstanceRuleApplicationConvert.buildDivisionMap(null);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testBuildDivisionMapValidInput() {
        // 创建测试数据
        BaseDivisionInfoDTO childDivision = new BaseDivisionInfoDTO();
        childDivision.setDivisionId(2L);
        childDivision.setDivisionName("Child Division");
        childDivision.setChildrenList(null);

        BaseDivisionInfoDTO divisionInfoDTO = new BaseDivisionInfoDTO();
        divisionInfoDTO.setDivisionId(1L);
        divisionInfoDTO.setDivisionName("Parent Division");
        divisionInfoDTO.setChildrenList(Lists.newArrayList(childDivision));
        Map<String, String> result = PolicyInstanceRuleApplicationConvert.buildDivisionMap(divisionInfoDTO);
        assertEquals("Parent Division", result.get("1"));
        assertEquals("Child Division", result.get("2"));
    }


//    @Test
//    public void testAssembleInstanceRuleTreeInputEmptyList() {
//        List<PolicyRuleDetailDTO> emptyList = Collections.emptyList();
//        List<PolicyRuleDetailDTO> result = PolicyInstanceRuleApplicationConvert.assembleInstanceRuleTree(emptyList);
//        // 验证返回结果是否为空集合
//        assertTrue(result.isEmpty());
//    }


//    @Test
//    public void testAssembleInstanceRuleTreeGroupByProvinceAndCity() {
//        List<PolicyRuleDetailDTO> dataSource = new ArrayList<>();
//        PolicyRuleDetailDTO dto1 = new PolicyRuleDetailDTO();
//        dto1.setProvince("Province1");
//        dto1.setCity("City1");
//        PolicyRuleDetailDTO dto2 = new PolicyRuleDetailDTO();
//        dto2.setProvince("Province1");
//        dto2.setCity("City1");
//        PolicyRuleDetailDTO dto3 = new PolicyRuleDetailDTO();
//        dto3.setProvince("Province2");
//        dto3.setCity("City2");
//        dataSource.add(dto1);
//        dataSource.add(dto2);
//        dataSource.add(dto3);
//        List<PolicyRuleDetailDTO> result = PolicyInstanceRuleApplicationConvert.assembleInstanceRuleTree(dataSource);
//        assertEquals(2, result.size());
//        assertEquals("Province1", result.get(0).getProvince());
//        assertEquals(1, result.get(0).getChildren().size());
//    }


    @Test
    public void testAssembleInstanceRuleTreeAddMainCityDataToTree() {
        List<PolicyRuleDetailDTO> dataSource = new ArrayList<>();
        PolicyRuleDetailDTO dto1 = new PolicyRuleDetailDTO();
        dto1.setProvince("Province1");
        dto1.setCity("City1");
        PolicyRuleDetailDTO dto2 = new PolicyRuleDetailDTO();
        dto2.setProvince("Province2");
        dto2.setCity("City2");
        dataSource.add(dto1);
        dataSource.add(dto2);
        List<PolicyRuleDetailDTO> result = PolicyInstanceRuleApplicationConvert.assembleInstanceRuleTree(dataSource);
        assertEquals(2, result.size());
        assertEquals("Province1", result.get(0).getProvince());
        assertEquals("Province2", result.get(1).getProvince());
    }


    @Test
    public void testMergeRuleStartTimeToEndTimeWithEmptyList() {
        List<PolicyInstanceRuleDTO> emptyList = new ArrayList<>();
        PolicyInstanceRuleApplicationConvert.mergeRuleStartTimeToEndTime(emptyList);
        assertEquals(0, emptyList.size());
    }

    @Test
    public void testMergeRuleStartTimeToEndTimeWithSingleElement() {
        List<PolicyInstanceRuleDTO> singleElementList = new ArrayList<>();
        PolicyInstanceRuleDTO ruleDTO = new PolicyInstanceRuleDTO();
        ruleDTO.setStartTime(LocalDateTime.now());
        ruleDTO.setEndTime(LocalDateTime.now());
        singleElementList.add(ruleDTO);
        PolicyInstanceRuleApplicationConvert.mergeRuleStartTimeToEndTime(singleElementList);
        assertEquals(1, singleElementList.size());
    }

    @Test
    public void testMergeRuleStartTimeToEndTimeWithMultipleElements() {
        List<PolicyInstanceRuleDTO> ruleDTOList = new ArrayList<>();

        // 创建并初始化多个PolicyInstanceRuleDTO。假设有两个元素。
        PolicyInstanceRuleDTO ruleDTO1 = new PolicyInstanceRuleDTO();
        ruleDTO1.setStartTime(LocalDateTime.of(2023, 10, 4, 10, 0));
        ruleDTO1.setEndTime(LocalDateTime.of(2023, 10, 4, 10, 0));

        PolicyInstanceRuleDTO ruleDTO2 = new PolicyInstanceRuleDTO();
        ruleDTO2.setStartTime(LocalDateTime.of(2023, 10, 5, 10, 0));
        ruleDTO2.setEndTime(LocalDateTime.of(2023, 10, 5, 10, 0));

        ruleDTOList.add(ruleDTO1);
        ruleDTOList.add(ruleDTO2);
        // 执行待测方法
        PolicyInstanceRuleApplicationConvert.mergeRuleStartTimeToEndTime(ruleDTOList);
        // 验证结果：第二个元素的结束时间
//        assertEquals(ruleDTO1.getStartTime(), ruleDTO2.getEndTime());
    }

    @Test
    public void testCheckOrgCodeNullBoth() {
        PolicyInstanceRuleDTO original = null;
        PolicyInstanceRuleDTO income = null;
        Boolean result = PolicyInstanceRuleApplicationConvert.checkOrgCode(original, income);
        Assert.assertFalse(result);
    }

    @Test
    public void testCheckOrgCodeNullOriginal() {
        PolicyInstanceRuleDTO original = null;
        PolicyInstanceRuleDTO income = createRuleDTOWithExpress("orgOne", "EXP123^^^001", "express");
        Boolean result = PolicyInstanceRuleApplicationConvert.checkOrgCode(original, income);
        Assert.assertFalse(result);
    }

    @Test
    public void testCheckOrgCodeNullIncome() {
        PolicyInstanceRuleDTO original = createRuleDTOWithExpress("orgOne", "EXP123^^^001", "express");
        PolicyInstanceRuleDTO income = null;
        Boolean result = PolicyInstanceRuleApplicationConvert.checkOrgCode(original, income);
        Assert.assertFalse(result);
    }

    @Test
    public void testCheckOrgCodeMatchingOrgCode() {
        PolicyInstanceRuleDTO original = createRuleDTOWithExpress("orgOne", "EXP123^^^001", "express");
        PolicyInstanceRuleDTO income = createRuleDTOWithExpress("orgTwo", "EXP123^^^001", "express");
        Boolean result = PolicyInstanceRuleApplicationConvert.checkOrgCode(original, income);
        Assert.assertTrue(result);
    }

    @Test
    public void testCheckOrgCodeNonMatchingOrgCode() {
        PolicyInstanceRuleDTO original = createRuleDTOWithExpress("orgOne", "EXP123^^^001", "express");
        PolicyInstanceRuleDTO income = createRuleDTOWithExpress("orgTwo", "EXP456^^^789", "express");
        Boolean result = PolicyInstanceRuleApplicationConvert.checkOrgCode(original, income);
        Assert.assertFalse(result);
    }

    private PolicyInstanceRuleDTO createRuleDTOWithExpress(String entityName, String entityId, String customType) {
        PolicyInstanceRuleDTO ruleDTO = new PolicyInstanceRuleDTO();
        ruleDTO.setCustomType(customType);
        ruleDTO.setLaunchObject("{\"areaSelectRule\":{}, \"entitySelectRule\":{\"entityName\":\"" + entityName + "\", \"entityType\":\"express\", \"entityId\":\"" + entityId + "\", \"type\":\"express\"}}");
        return ruleDTO;
    }

    /**
     * 测试处理第一条数据时更新生效时间和截止时间逻辑
     */
    @Test
    public void testMergeRuleDetailStartTimeToEndTimeUpdateFirstElement() {
        // 准备测试数据：只有一条数据
        List<PolicyRuleDetailDTO> ruleDetailDTOS = new ArrayList<>();
        PolicyRuleDetailDTO firstDTO = new PolicyRuleDetailDTO();
        firstDTO.setEffectTime("2023-10-01");
        ruleDetailDTOS.add(firstDTO);
        // 执行待测试方法
        PolicyInstanceRuleApplicationConvert.mergeRuleDetailStartTimeToEndTime(ruleDetailDTOS);
        // 验证第一条数据的生效时间被更新为截止时间
        assertEquals("2023-10-01", firstDTO.getEffectTime());
    }

    /**
     * 测试处理非第一条数据时更新生效时间和截止时间逻辑
     */
    @Test
    public void testMergeRuleDetailStartTimeToEndTimeUpdateNonFirstElement() {
        // 准备多条数据来测试非第一条数据的处理
        List<PolicyRuleDetailDTO> ruleDetailDTOS = new ArrayList<>();

        PolicyRuleDetailDTO firstDTO = new PolicyRuleDetailDTO();
        firstDTO.setEffectTime("2023-10-01");
        firstDTO.setDeadlineTime("2023-10-02");
        PolicyRuleDetailDTO secondDTO = new PolicyRuleDetailDTO();
        secondDTO.setEffectTime("2023-10-03");
        ruleDetailDTOS.add(firstDTO);
        ruleDetailDTOS.add(secondDTO);
        // 执行待测试方法
        PolicyInstanceRuleApplicationConvert.mergeRuleDetailStartTimeToEndTime(ruleDetailDTOS);
        // 验证非第一条数据的生效时间被正确更新为"effectTime至deadlineTime-1天"
        assertEquals("2023-10-03", secondDTO.getEffectTime());
    }

    @Test
    public void testMergeHistoryRuleDetailStartTimeToEndTimeWithMultipleElements() {
        // 创建并初始化多条PolicyInstanceRuleHistoryDetailDTO
        List<PolicyInstanceRuleHistoryDetailDTO> historyDetailDTOS = new ArrayList<>();
        PolicyInstanceRuleHistoryDetailDTO dto1 = new PolicyInstanceRuleHistoryDetailDTO();
        dto1.setEffectTime("2023-10-01");
        historyDetailDTOS.add(dto1);
        PolicyInstanceRuleHistoryDetailDTO dto2 = new PolicyInstanceRuleHistoryDetailDTO();
        dto2.setEffectTime("2023-10-02");
        historyDetailDTOS.add(dto2);
        // 执行待测方法
        PolicyInstanceRuleApplicationConvert.mergeHistoryRuleDetailStartTimeToEndTime(historyDetailDTOS);
        // 验证第二个元素的结束时间等于第一个元素的开始时间
//        assertEquals("2023-10-01", dto2.getEndTime());
    }

    @Test
    public void testMergeHistoryRuleDetailStartTimeToEndTimeWithSameEffectTime() {
        // 创建并初始化多条PolicyInstanceRuleHistoryDetailDTO，其中有些条目具有相同的开始时间
        List<PolicyInstanceRuleHistoryDetailDTO> historyDetailDTOS = new ArrayList<>();
        PolicyInstanceRuleHistoryDetailDTO dto1 = new PolicyInstanceRuleHistoryDetailDTO();
        dto1.setEffectTime("2023-10-01");
        dto1.setEndTime("2023-11-02");
        historyDetailDTOS.add(dto1);
        PolicyInstanceRuleHistoryDetailDTO dto2 = new PolicyInstanceRuleHistoryDetailDTO();
        dto2.setEffectTime("2023-10-01");
        dto2.setEndTime("2023-11-02");
        historyDetailDTOS.add(dto2);
        // 执行待测方法
        PolicyInstanceRuleApplicationConvert.mergeHistoryRuleDetailStartTimeToEndTime(historyDetailDTOS);
        assertEquals("2023-11-02", dto2.getEndTime());

    }

    /**
     * 测试customType为PolicyCustomTypeEnum.STATION.getType()时调用markStationInstanceRule
     * 验证策略规则的合并标记逻辑
     */
    @Test
    public void testMarkMergeDivisionInstanceRuleWithStationType() {
        List<PolicyRuleDetailDTO> dataSource = new ArrayList<>();
        PolicyRuleDetailDTO dto1 = new PolicyRuleDetailDTO();
        dto1.setProvince("Province1");
        dto1.setCity("City1");
        dto1.setDistrict(null);
        dto1.setEffectTime(LocalDateTime.now().toString());
        PolicyRuleDetailDTO dto2 = new PolicyRuleDetailDTO();
        dto2.setProvince("Province1");
        dto2.setCity("City1");
        dto2.setDistrict("District1");
        dto2.setEffectTime(LocalDateTime.now().minusDays(1).toString());
        dataSource.add(dto1);
        dataSource.add(dto2);
        List<PolicyRuleDetailDTO> result = PolicyInstanceRuleApplicationConvert.markMergeDivisionInstanceRule(dataSource, PolicyCustomTypeEnum.STATION.getType());
        assertEquals(2, result.size());
        assertEquals("Province1", result.get(0).getProvince());
        assertEquals("City1", result.get(0).getCity());
        // 由于district设置为null，经过方法逻辑应设置为“全城”
        assertEquals("全城", result.get(0).getDistrict());
    }

    /**
     * 测试根据orgCode对数据源分组并排序处理
     * 验证根据orgCode分组后的处理逻辑
     */
    @Test
    public void testMarkMergeDivisionInstanceRuleWithOrgCodeGrouping() {
        List<PolicyRuleDetailDTO> dataSource = new ArrayList<>();
        PolicyRuleDetailDTO dto1 = new PolicyRuleDetailDTO();
        dto1.setOrgCode("Org1");
        dto1.setEffectTime("2023-10-01");
        dto1.setDeadlineTime("2023-11-02");
        PolicyRuleDetailDTO dto2 = new PolicyRuleDetailDTO();
        dto2.setOrgCode("Org2");
        dto2.setEffectTime("2023-10-02");
        dto2.setDeadlineTime("2023-11-02");
        PolicyRuleDetailDTO dto3 = new PolicyRuleDetailDTO();
        dto3.setOrgCode("Org1");
        dto3.setEffectTime("2023-09-30");
        dto3.setDeadlineTime("2023-11-02");

        dataSource.add(dto1);
        dataSource.add(dto2);
        dataSource.add(dto3);
        List<PolicyRuleDetailDTO> result = PolicyInstanceRuleApplicationConvert.markMergeDivisionInstanceRule(dataSource, PolicyCustomTypeEnum.EXPRESS.getType());
        assertEquals(3, result.size());
        assertEquals("Org1", result.get(0).getOrgCode());
        // 验证数据排序逻辑
        assertEquals("2023-10-01", result.get(0).getEffectTime());
//        assertEquals("2023-09-30至2023-09-30", result.get(1).getEffectTime());
    }
}