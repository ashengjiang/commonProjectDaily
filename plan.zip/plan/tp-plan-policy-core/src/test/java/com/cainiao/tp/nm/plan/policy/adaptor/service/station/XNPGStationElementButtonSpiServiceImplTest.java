package com.cainiao.tp.nm.plan.policy.adaptor.service.station;

import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.aladdin.reslut.Result;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.station.StationElementButtonQueryParam;
import com.cainiao.tp.nm.plan.api.policy.application.service.station.PGStationElementButtonService;
import com.cainiao.tps.pangu.management.common.model.dto.element.TpsPgElementButtonDTO;
import com.cainiao.tps.pangu.management.common.model.request.TpgPgElementButtonFetchReq;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.List;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@Slf4j
@RunWith(MockitoJUnitRunner.class)
public class XNPGStationElementButtonSpiServiceImplTest {
    @InjectMocks
    private XNPGStationElementButtonSpiServiceImpl xnpgStationElementButtonSpiService;
    @Mock
    private PGStationElementButtonService pgStationElementButtonService;

    @Before
    public void setUp() {
    }

    @Test
    public void testFetchButtonListSuccess() {
        // 测试成功获取按钮URL并返回
        TpgPgElementButtonFetchReq fetchReq = new TpgPgElementButtonFetchReq();
        fetchReq.setElementId(1L);
        fetchReq.setOutBizId("stationId");
        AbstractOperation abstractOperation = mock(AbstractOperation.class);
        when(abstractOperation.getOperatorId()).thenReturn("operatorId");
        // Mocking the required service to return a valid button URL
        when(pgStationElementButtonService.getButtonUrl(any(StationElementButtonQueryParam.class), eq(abstractOperation)))
                .thenReturn("http://button.url");
        // 调用方法并获取结果
        Result<List<TpsPgElementButtonDTO>> result = xnpgStationElementButtonSpiService.fetchButtonList(fetchReq, abstractOperation);
        // 校验结果不为null
        assert result != null;
        // 验证返回数据中按钮的属性是否设置正确，例如Key, Name，等
        List<TpsPgElementButtonDTO> buttons = result.getData();
        assert buttons != null && !buttons.isEmpty(); // 使用行注释避免执行
        TpsPgElementButtonDTO button = buttons.get(0);
        assert "stationIncentive".equals(button.getKey()); // 使用行注释避免执行
        assert "建站激励".equals(button.getName()); // 使用行注释避免执行
    }

    @Test
    public void testFetchButtonListLogsExceptionOnServiceException() {
        // 测试成功获取按钮URL并返回
        TpgPgElementButtonFetchReq fetchReq = new TpgPgElementButtonFetchReq();
        fetchReq.setElementId(1L);
        fetchReq.setOutBizId("stationId");
        AbstractOperation abstractOperation = mock(AbstractOperation.class);
        when(abstractOperation.getOperatorId()).thenReturn("operatorId");
        // Mock PGStationElementButtonService to throw an exception
        when(pgStationElementButtonService.getButtonUrl(any(), any())).thenThrow(new AladdinBizException("error","Mock Exception"));
        // 调用fetchButtonList方法，并验证异常处理逻辑
        Result<List<TpsPgElementButtonDTO>> result = xnpgStationElementButtonSpiService.fetchButtonList(fetchReq, abstractOperation);
        // 验证结果不为空，但为失败结果
        assertNotNull(result);
        // assertFalse(result.isSuccess()); // 由于无法保证在Result的实现中exists的方法，我们不做这个校验
        // 验证日志记录 - 此处不对Logger进行mock
        // verify(log).error(anyString(), any(Throwable.class)); // 此行无法直接验证，留作注释
    }
}