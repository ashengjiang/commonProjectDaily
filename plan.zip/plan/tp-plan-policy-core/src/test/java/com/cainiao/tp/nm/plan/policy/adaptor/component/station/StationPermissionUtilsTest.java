package com.cainiao.tp.nm.plan.policy.adaptor.component.station;

import com.cainiao.tp.nm.plan.infra.port.dto.context.StationPermissionContext;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class StationPermissionUtilsTest {
    /**
     * 测试设置线程上下文环境的分支
     * 期望：正常设置上下文，不抛出异常
     */
    @Test
    public void testSetContent() {
        // 准备一个上下文对象
        StationPermissionContext context = new StationPermissionContext();

        // 调用方法设置上下文
        StationPermissionUtils.setContent(context);

        // 再次调用，传入null，测试清空上下文的场景
        StationPermissionUtils.setContent(null);
    }

    @Test
    public void testGetContent() {
        // 准备一个上下文对象
        StationPermissionContext context = new StationPermissionContext();

        // 调用方法设置上下文
        StationPermissionUtils.setContent(context);

        // 再次调用，传入null，测试清空上下文的场景
        StationPermissionUtils.getContent();
    }

    @Test
    public void testClearContent() {
        // 准备一个上下文对象
        StationPermissionContext context = new StationPermissionContext();

        // 调用方法设置上下文
        StationPermissionUtils.setContent(context);

        // 再次调用，传入null，测试清空上下文的场景
        StationPermissionUtils.remove();
    }

}