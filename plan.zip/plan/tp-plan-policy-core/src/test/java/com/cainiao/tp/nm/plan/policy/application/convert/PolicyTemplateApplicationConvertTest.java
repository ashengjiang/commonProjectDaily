package com.cainiao.tp.nm.plan.policy.application.convert;

import static org.mockito.Mockito.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.base.BaseTest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.PolicyTemplateQueryRequest;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyTemplateDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.select.SelectPlanDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.launchplan.AreaRuleLaunchDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.launchplan.LaunchPlanDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.launchplan.ListItemLaunchDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.launchplan.ListLaunchDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.launchplan.RuleLaunchDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.launchplan.TagRuleLaunchDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyTemplateQueryParam;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyBizTypeEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyCustomTypeEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyInstanceApprovalStatusEnum;
import com.cainiao.tp.nm.plan.api.policy.common.constants.PolicyTemplateStatusEnum;
import com.cainiao.tp.nm.plan.policy.domain.model.PolicyTemplate;
import com.cainiao.tp.nm.plan.policy.domain.model.valobj.incentiveplan.IncentivePlan;
import com.cainiao.tp.nm.plan.policy.domain.model.valobj.incentiveplan.IncentivePlanContent;
import com.cainiao.tp.nm.plan.policy.domain.model.valobj.launchplan.LaunchPlan;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

/**
 * <a href="https://alidocs.dingtalk.com/i/nodes/dpYLaezmVNRMGX56C1aKjlBOVrMqPxX6">单元测试编写&生成FAQ</a>
 * Created By Thub IDEA插件
 *
 * @Date 2025/6/9 17:30
 */
public class PolicyTemplateApplicationConvertTest extends BaseTest {

    @InjectMocks
    private PolicyTemplateApplicationConvert policyTemplateApplicationConvert;

    @Before
    public void setUp() throws Exception {MockitoAnnotations.openMocks(this);}

    @Test
    public void testModelToDto() {
        // Prepare method arguments
        LaunchPlan launchPlan = new LaunchPlan();
        List<IncentivePlan> incentivePlanList = new ArrayList<>();
        IncentivePlan incentivePlan1 = new IncentivePlan();
        IncentivePlanContent incentivePlanContent1 = new IncentivePlanContent();

        incentivePlan1.setPlanName("planName1");
        incentivePlan1.setIncentivePlanType("incentivePlanType1");
        incentivePlan1.setContent(incentivePlanContent1);

        PolicyTemplate policyTemplate = PolicyTemplate.builder()
            .id(1L)
            .templateName("templateName")
            .customType(PolicyCustomTypeEnum.STATION.getType())
            .bizType(PolicyBizTypeEnum.SCALE.getType())
            .startTime(LocalDateTime.now())
            .endTime(LocalDateTime.now())
            .status(PolicyTemplateStatusEnum.WAITING_EFFECT.getCode())
            .approvalStatus(PolicyInstanceApprovalStatusEnum.APPROVALING.getCode())
            .version(1L)
            .lastOperatorId(1L)
            .launchPlan(launchPlan)
            .incentivePlanList(incentivePlanList)
            .build();
        // Run the method to be tested
        PolicyTemplateDTO result = PolicyTemplateApplicationConvert.modelToDto(policyTemplate);

        // Verify the result
        assert result != null;
    }

    @Test
    public void testQueryParamConvert() {
        // Prepare method arguments

        PolicyTemplateQueryRequest request = new PolicyTemplateQueryRequest();
        request.setTemplateName("templateName");
        request.setDurationStatus("1");
        request.setPageIndex(1);
        request.setPageSize(10);

        // Run the method to be tested
        PolicyTemplateQueryParam result = PolicyTemplateApplicationConvert.queryParamConvert(request);

        // Verify the result
        assert result != null;
        assert result.getTemplateName().equals("templateName");
        assert "1".equals(result.getDurationStatus());
        assert result.getPageIndex() == 1;
        assert result.getPageSize() == 10;
    }

    @Test
    public void testDtoToModel(){
        // Prepare method arguments

        PolicyTemplateDTO policyTemplateDTO = new PolicyTemplateDTO();
        policyTemplateDTO.setLaunchPlan(new LaunchPlanDTO());
        policyTemplateDTO.setIncentivePlanList(new ArrayList<>());
        // Run the method to be tested
        PolicyTemplate result = PolicyTemplateApplicationConvert.dtoToModel(policyTemplateDTO);
        assert result != null;

        // Verify the result
    }


    @Test
    public void testDtoToModel2(){
        // Prepare method arguments

        LaunchPlanDTO policyTemplateDTO = new LaunchPlanDTO();
        RuleLaunchDTO ruleLaunchDTO = new RuleLaunchDTO();
        ruleLaunchDTO.setAreaRuleLaunch(new AreaRuleLaunchDTO());
        policyTemplateDTO.setRuleLaunch(ruleLaunchDTO);
        TagRuleLaunchDTO tagRuleLaunchDTO = new TagRuleLaunchDTO();
        ruleLaunchDTO.setTagRuleLaunch(tagRuleLaunchDTO);
        ListLaunchDTO listLaunchDTO = new ListLaunchDTO();
        List<ListItemLaunchDTO> itemLaunch = new ArrayList<>();
        ListItemLaunchDTO listItemLaunchDTO = new ListItemLaunchDTO();
        itemLaunch.add(listItemLaunchDTO);
        listLaunchDTO.setItemLaunch(itemLaunch);
        policyTemplateDTO.setListLaunch(listLaunchDTO);
        SelectPlanDTO selectPlanDTO = PolicyTemplateApplicationConvert.dtoToModel(policyTemplateDTO);
        assert selectPlanDTO != null;
    }
}