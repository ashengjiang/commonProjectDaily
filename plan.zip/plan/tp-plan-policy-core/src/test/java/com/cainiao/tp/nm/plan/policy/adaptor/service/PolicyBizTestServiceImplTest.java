package com.cainiao.tp.nm.plan.policy.adaptor.service;

import com.alibaba.fastjson.JSONObject;
import com.cainiao.sutee.commons.base.result.CnResult;
import com.cainiao.tp.nm.plan.api.policy.application.dto.StationDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.NewStaPerformSubsidyConfigDTO;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyConfigManager;
import com.cainiao.tp.nm.plan.infra.port.policy.StaStationReadManager;
import com.cainiao.tp.nm.plan.infra.port.policy.TpPushStationMessageManager;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class PolicyBizTestServiceImplTest {

    @Mock
    private TpPushStationMessageManager tpPushStationMessageManager;

    @Mock
    private StaStationReadManager staStationReadManager;

    @Mock
    private PolicyConfigManager policyConfigManager;

    @InjectMocks
    private PolicyBizTestServiceImpl policyBizTestService;

    /**
     * 测试 sendNewStaPerformSubsidyPopup 方法：站点存在，满足基本条件和建设条件，正常发送消息
     */
    @Test
    public void testSendNewStaPerformSubsidyPopupSuccess() {
        // 准备数据
        String stationStr ="{\"areaCode\":\"450107\",\"bizMode\":17,\"channel\":17,\"cityCode\":\"450100\",\"clientVersion\":1,\"contact\":\"罗绕露\",\"corporationAlipayId\":\"2088052545016336\",\"corporationAlipayNick\":\"18077153295\",\"corporationCnAccountId\":2219586510101,\"deliveryAddress\":\"广西壮族自治区^^^南宁市^^^西乡塘区^^^北湖街道^^^北湖街道万秀北路168号秀营出租公寓铺面C115号店\",\"enterpriseCnuserId\":2219645759016,\"feature\":\";supportActivity:2025-04-07;dispacthCode:EBR;p_f_c_i:1744430950000;ext_shoparea:45;picwaybill:https%3A%2F%2Fsta-upload.oss-cn-hangzhou.aliyuncs.com%2Fbpm-180%2F20250414%2Faa25cf9fdfef4d0fbc8f8b6698a7f532%2Fimage.jpg;pic_for_inner:https%3A%2F%2Ftps-join.oss-cn-zhangjiakou.aliyuncs.com%2Fimage%2F20250403%2F051fd7c38dff4e4eb1794dc5c9c464e7.jpeg;ext_stationlocation:first_floor;singned_time:2025-04-03+19%3A39%3A59;applyId:6300000002791716;new_cn:new_cn;probation_end_time:2025-04-21+00%3A00%3A00;new_cn_type:personal;ityWay:auto;sendPackageHomeWay:send_home;blank_aoi_id:450107_1321107013_1306692881;tax_info:2025-04-05_individual;pic_for_door:https%3A%2F%2Ftps-join.oss-cn-zhangjiakou.aliyuncs.com%2Fimage%2F20250403%2Ff696fb0a39e4477ea2d3fa54cd13e49d.jpeg;ityType:1;STATION_POINT:n;keepInpackageMode:false;margined_time:2025-04-05+20%3A55%3A54;singned:singned;dispacthCodeCN:%E4%B8%87%E7%A7%80%E6%9D%91%E7%A7%80%E8%90%A5%E5%85%AC;cnt_compliance_time:2025-04-05+20%3A56%3A25;print_type:3;margined:margined;serviceSwitch_DeWuSend:1;station_operating_tag:station_operating_tag;msg_charge:2025-04-05+20%3A55%3A54;lastTrafficHour:21;cor_agreement_invalid_time:2099-03-31;serviceSwitch_StationPlatformSend:1;serviceSwitch_KuaiShouSend:1;accountNo:5120022195865101010307978662;ext_minbiz:pioneer;ussct:2025-04-12+12%3A32%3A24;unifiedSmartCall:1;serviceSwitch_XhsSend:1;decorationDemolishStatus:-2;isCountrySideTransfer:n;shelfSet:5-5;lightShelfMode:10;smartCall_status:3;lastTrafficMinute:00;shelfMode:1;station_type:professional_station;openProfExamScore:100;professionalAnchorTime:2025-04-05+20%3A55%3A54;needCloudMonitor:y;\",\"featureMap\":{\"supportActivity\":\"2025-04-07\",\"dispacthCode\":\"EBR\",\"p_f_c_i\":\"1744430950000\",\"ext_shoparea\":\"45\",\"picwaybill\":\"https://sta-upload.oss-cn-hangzhou.aliyuncs.com/bpm-180/20250414/aa25cf9fdfef4d0fbc8f8b6698a7f532/image.jpg\",\"pic_for_inner\":\"https://tps-join.oss-cn-zhangjiakou.aliyuncs.com/image/20250403/051fd7c38dff4e4eb1794dc5c9c464e7.jpeg\",\"ext_stationlocation\":\"first_floor\",\"singned_time\":\"2025-04-03 19:39:59\",\"applyId\":\"6300000002791716\",\"new_cn\":\"new_cn\",\"probation_end_time\":\"2025-04-21 00:00:00\",\"new_cn_type\":\"personal\",\"ityWay\":\"auto\",\"sendPackageHomeWay\":\"send_home\",\"blank_aoi_id\":\"450107_1321107013_1306692881\",\"tax_info\":\"2025-04-05_individual\",\"pic_for_door\":\"https://tps-join.oss-cn-zhangjiakou.aliyuncs.com/image/20250403/f696fb0a39e4477ea2d3fa54cd13e49d.jpeg\",\"ityType\":\"1\",\"STATION_POINT\":\"n\",\"keepInpackageMode\":\"false\",\"margined_time\":\"2025-04-05 20:55:54\",\"singned\":\"singned\",\"dispacthCodeCN\":\"万秀村秀营公\",\"cnt_compliance_time\":\"2025-04-05 20:56:25\",\"print_type\":\"3\",\"margined\":\"margined\",\"serviceSwitch_DeWuSend\":\"1\",\"station_operating_tag\":\"station_operating_tag\",\"msg_charge\":\"2025-04-05 20:55:54\",\"lastTrafficHour\":\"21\",\"cor_agreement_invalid_time\":\"2099-03-31\",\"serviceSwitch_StationPlatformSend\":\"1\",\"serviceSwitch_KuaiShouSend\":\"1\",\"accountNo\":\"5120022195865101010307978662\",\"ext_minbiz\":\"pioneer\",\"ussct\":\"2025-04-12 12:32:24\",\"unifiedSmartCall\":\"1\",\"serviceSwitch_XhsSend\":\"1\",\"decorationDemolishStatus\":\"-2\",\"isCountrySideTransfer\":\"n\",\"shelfSet\":\"5-5\",\"lightShelfMode\":\"10\",\"smartCall_status\":\"3\",\"lastTrafficMinute\":\"00\",\"shelfMode\":\"1\",\"station_type\":\"professional_station\",\"openProfExamScore\":\"100\",\"professionalAnchorTime\":\"2025-04-05 20:55:54\",\"needCloudMonitor\":\"y\"},\"flag\":411304009,\"gmtCreate\":1743857754000,\"gmtModified\":1754767426000,\"instanceCode\":\"1090000001377140\",\"isDeleted\":0,\"lat\":\"2285317\",\"latitude\":22.85317,\"lng\":\"10830957\",\"longitude\":108.30957,\"mobile\":\"18077153295\",\"officeTime\":\"周一至周日10点00分到21点00分\",\"partnerId\":21000624260,\"provinceCode\":\"450000\",\"resourceId\":1216000000954680,\"stationCode\":\"V7715112\",\"stationId\":1095289,\"stationName\":\"南宁万秀村秀营公寓c115号店\",\"stationService\":1024,\"stationType\":1,\"status\":1,\"supportHomeService\":false,\"townCode\":\"450107002\",\"waybillUserId\":2219598010003}";
        String subsidyConfigStr ="{\"cumulativeSubsidyTip\":\"累计已补贴=历史月份已到账激励之和\",\"endDate\":\"2026-01-01 00:00:00\",\"newStaPerformSubsidyPriceLadderList\":[100.0,200.0,300.0,400.0,500.0,600.0,700.0,800.0,900.0,1000.0,1100.0,1200.0,1300.0,1400.0,1500.0,1600.0,1700.0,1800.0,1900.0,2000.0],\"newStaPerformSubsidyPriceQlExpress\":\"if(statsMonthAvgVaildArrCnt >= 2000){return 2000 * coefficient;}else if(statsMonthAvgVaildArrCnt >= 1900){return 1900 * coefficient;}else if(statsMonthAvgVaildArrCnt >= 1800){return 1800 * coefficient;}else if(statsMonthAvgVaildArrCnt >= 1700){return 1700 * coefficient;}else if(statsMonthAvgVaildArrCnt >= 1600){return 1600 * coefficient;}else if(statsMonthAvgVaildArrCnt >= 1500){return 1500 * coefficient;}else if(statsMonthAvgVaildArrCnt >= 1400){return 1400 * coefficient;}else if(statsMonthAvgVaildArrCnt >= 1300){return 1300 * coefficient;}else if(statsMonthAvgVaildArrCnt >= 1200){return 1200 * coefficient;}else if(statsMonthAvgVaildArrCnt >= 1100){return 1100 * coefficient;}else if(statsMonthAvgVaildArrCnt >= 1000){return 1000 * coefficient;}else if(statsMonthAvgVaildArrCnt >= 900){return 900 * coefficient;}else if(statsMonthAvgVaildArrCnt >= 800){return 800 * coefficient;}else if(statsMonthAvgVaildArrCnt >= 700){return 700 * coefficient;}else if(statsMonthAvgVaildArrCnt >= 600){return 600 * coefficient;}else if(statsMonthAvgVaildArrCnt >= 500){return 500 * coefficient;}else if(statsMonthAvgVaildArrCnt >= 400){return 400 * coefficient;}else if(statsMonthAvgVaildArrCnt >= 300){return 300 * coefficient;}else if(statsMonthAvgVaildArrCnt >= 200){return 200 * coefficient;}else if(statsMonthAvgVaildArrCnt >= 100){return 100 * coefficient;}return 0;\",\"ruleDetailUrl\":\"\",\"startDate\":\"2025-04-01 00:00:00\",\"subsidyDetailUrl\":\"\"}";

        Long stationId = 1L;
        // Mock行为
        when(staStationReadManager.queryStationById(stationId)).thenReturn(JSONObject.parseObject(stationStr, StationDTO.class));
        when(policyConfigManager.getNewStaPerformSubsidyConfig()).thenReturn(JSONObject.parseObject(subsidyConfigStr, NewStaPerformSubsidyConfigDTO.class));

        // 调用方法
        CnResult<Void> result = policyBizTestService.sendNewStaPerformSubsidyPopup(stationId);

        // 断言
        assertTrue(result.isSuccess());
        // verify(tpPushStationMessageManager).sendNewStaPerformSubsidyPopup(stationId);  // 确认消息发送
    }
}