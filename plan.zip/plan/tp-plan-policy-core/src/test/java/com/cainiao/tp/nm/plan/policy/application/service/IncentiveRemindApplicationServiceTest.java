package com.cainiao.tp.nm.plan.policy.application.service;

import com.cainiao.tp.nm.plan.api.policy.application.dto.IncentiveRemindRuleDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.IncentiveRemindHolder;
import com.cainiao.tp.nm.plan.infra.port.policy.IncentiveRemindRulePort;
import com.cainiao.tp.nm.plan.infra.port.policy.IncentiveRemindTairPort;
import com.cainiao.tp.nm.plan.infra.port.policy.TpPushStationMessageManager;
import com.cainiao.tp.nm.plan.policy.application.component.station.IncentiveAssessDataComponent;
import com.cainiao.tp.nm.plan.policy.application.dto.IncentiveAssessContextDTO;
import com.cainiao.tp.nm.plan.policy.domain.service.IncentiveRemindRuleMatchDomainService;
import com.cainiao.tp.nm.plan.policy.domain.service.IncentiveRemindTriggerDomainService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.MockitoJUnitRunner;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

/**
 * վ��ʵ�ټ�������Ӧ�÷���Ԫ����
 *
 * @date 2026-03-27
 */
@RunWith(MockitoJUnitRunner.class)
public class IncentiveRemindApplicationServiceTest {

    @Mock
    private IncentiveRemindTriggerDomainService incentiveRemindTriggerDomainService;

    @Mock
    private IncentiveRemindRuleMatchDomainService incentiveRemindRuleMatchDomainService;

    @Mock
    private IncentiveAssessDataComponent incentiveAssessDataComponent;

    @Mock
    private IncentiveRemindRulePort incentiveRemindRulePort;

    @Mock
    private IncentiveRemindTairPort incentiveRemindTairPort;

    @Mock
    private TpPushStationMessageManager tpPushStationMessageManager;

    @InjectMocks
    private IncentiveRemindApplicationService incentiveRemindApplicationService;

    private static final String TEST_STATION_ID = "123456";
    private static final LocalDate TEST_JOIN_DATE = LocalDate.of(2026, 3, 27);
    private static final LocalDate TEST_TODAY = LocalDate.of(2026, 4, 8);

    /**
     * ���Գ����������б�Ϊ�գ���������
     */
    @Test
    public void testProcessIncentiveRemind_EmptyRuleList() {
        // Mock ��Ϊ
        when(incentiveRemindRulePort.getRuleList()).thenReturn(Collections.emptyList());

        // ִ�в���
        incentiveRemindApplicationService.processIncentiveRemind(TEST_STATION_ID, TEST_JOIN_DATE);

        // ��֤û�е��ú�������
        verify(incentiveRemindTriggerDomainService, never()).calcAssessMonthOffset(any(), any());
        verify(incentiveRemindTairPort, never()).isAlreadySent(any(), any(), any());
        verify(tpPushStationMessageManager, never()).sendIncentiveRemindPopup(any(), any(), any(), any());
    }

    /**
     * ���Գ�����������ƫ��������6���£���������
     */
    @Test
    public void testProcessIncentiveRemind_AssessMonthOffsetExceeds6() {
        // Mock ��Ϊ
        IncentiveRemindRuleDTO rule = createMockRule("RULE1", "����1", "NOTIFY_CONTENT", "JUMP_TYPE", "SCHEME_CODE");
        when(incentiveRemindRulePort.getRuleList()).thenReturn(Collections.singletonList(rule));
        when(incentiveRemindTriggerDomainService.calcAssessMonthOffset(TEST_JOIN_DATE, TEST_TODAY)).thenReturn(7);

        // ִ�в���
        incentiveRemindApplicationService.processIncentiveRemind(TEST_STATION_ID, TEST_JOIN_DATE);

        // ��֤û�е��ú�������
        verify(incentiveAssessDataComponent, never()).buildAssessContext(any(), anyInt(), any());
        verify(incentiveRemindTairPort, never()).isAlreadySent(any(), any(), any());
        verify(tpPushStationMessageManager, never()).sendIncentiveRemindPopup(any(), any(), any(), any());
    }

    /**
     * ���Գ�������������Ϊ�գ���������
     */
    @Test
    public void testProcessIncentiveRemind_EmptyAssessData() {
        // Mock ��Ϊ
        IncentiveRemindRuleDTO rule = createMockRule("RULE1", "����1", "NOTIFY_CONTENT", "JUMP_TYPE", "SCHEME_CODE");
        when(incentiveRemindRulePort.getRuleList()).thenReturn(Collections.singletonList(rule));
        when(incentiveRemindTriggerDomainService.calcAssessMonthOffset(TEST_JOIN_DATE, TEST_TODAY)).thenReturn(1);
        when(incentiveAssessDataComponent.buildAssessContext(TEST_STATION_ID, 1, TEST_TODAY)).thenReturn(null);

        // ִ�в���
        incentiveRemindApplicationService.processIncentiveRemind(TEST_STATION_ID, TEST_JOIN_DATE);

        // ��֤û�е��ú�������
        verify(incentiveRemindRuleMatchDomainService, never()).matchRule(any(), any());
        verify(incentiveRemindTairPort, never()).isAlreadySent(any(), any(), any());
        verify(tpPushStationMessageManager, never()).sendIncentiveRemindPopup(any(), any(), any(), any());
    }

    /**
     * ���Գ��������շ����ʹ������ҷ�����δװ�ޣ���������
     */
    @Test
    public void testProcessIncentiveRemind_NotTriggerDay() {
        // Mock ��Ϊ
        IncentiveRemindRuleDTO rule = createMockRule("RULE1", "����1", "NOTIFY_CONTENT", "JUMP_TYPE", "SCHEME_CODE");
        when(incentiveRemindRulePort.getRuleList()).thenReturn(Collections.singletonList(rule));
        when(incentiveRemindTriggerDomainService.calcAssessMonthOffset(TEST_JOIN_DATE, TEST_TODAY)).thenReturn(1);
        
        IncentiveAssessContextDTO context = createMockContext(false, true);
        when(incentiveAssessDataComponent.buildAssessContext(TEST_STATION_ID, 1, TEST_TODAY)).thenReturn(context);
        when(incentiveRemindTriggerDomainService.isTriggerDay(TEST_JOIN_DATE, TEST_TODAY)).thenReturn(false);

        // ִ�в���
        incentiveRemindApplicationService.processIncentiveRemind(TEST_STATION_ID, TEST_JOIN_DATE);

        // ��֤û�е��ú�������
        verify(incentiveRemindRuleMatchDomainService, never()).matchRule(any(), any());
        verify(incentiveRemindTairPort, never()).isAlreadySent(any(), any(), any());
        verify(tpPushStationMessageManager, never()).sendIncentiveRemindPopup(any(), any(), any(), any());
    }

    /**
     * ���Գ������޹���ƥ�䣬������֪ͨ
     */
    @Test
    public void testProcessIncentiveRemind_NoRuleMatched() {
        // Mock ��Ϊ
        IncentiveRemindRuleDTO rule = createMockRule("RULE1", "����1", "NOTIFY_CONTENT", "JUMP_TYPE", "SCHEME_CODE");
        when(incentiveRemindRulePort.getRuleList()).thenReturn(Collections.singletonList(rule));
        when(incentiveRemindTriggerDomainService.calcAssessMonthOffset(TEST_JOIN_DATE, TEST_TODAY)).thenReturn(1);
        
        IncentiveAssessContextDTO context = createMockContext(false, true);
        when(incentiveAssessDataComponent.buildAssessContext(TEST_STATION_ID, 1, TEST_TODAY)).thenReturn(context);
        when(incentiveRemindTriggerDomainService.isTriggerDay(TEST_JOIN_DATE, TEST_TODAY)).thenReturn(true);
        when(incentiveRemindRuleMatchDomainService.matchRule(any(), any())).thenReturn(null);

        // ִ�в���
        incentiveRemindApplicationService.processIncentiveRemind(TEST_STATION_ID, TEST_JOIN_DATE);

        // ��֤û�е��ú�������
        verify(incentiveRemindTairPort, never()).isAlreadySent(any(), any(), any());
        verify(tpPushStationMessageManager, never()).sendIncentiveRemindPopup(any(), any(), any(), any());
    }

    /**
     * ���Գ�����֪ͨ�ѷ��ͣ�����
     */
    @Test
    public void testProcessIncentiveRemind_AlreadySent() {
        // Mock ��Ϊ
        IncentiveRemindRuleDTO rule = createMockRule("RULE1", "����1", "NOTIFY_CONTENT", "JUMP_TYPE", "SCHEME_CODE");
        when(incentiveRemindRulePort.getRuleList()).thenReturn(Collections.singletonList(rule));
        when(incentiveRemindTriggerDomainService.calcAssessMonthOffset(TEST_JOIN_DATE, TEST_TODAY)).thenReturn(1);
        
        IncentiveAssessContextDTO context = createMockContext(false, true);
        when(incentiveAssessDataComponent.buildAssessContext(TEST_STATION_ID, 1, TEST_TODAY)).thenReturn(context);
        when(incentiveRemindTriggerDomainService.isTriggerDay(TEST_JOIN_DATE, TEST_TODAY)).thenReturn(true);
        when(incentiveRemindRuleMatchDomainService.matchRule(any(), any())).thenReturn(rule);
        when(incentiveRemindTairPort.isAlreadySent(TEST_STATION_ID, "RULE1", "20260408")).thenReturn(true);

        // Mock IncentiveRemindHolder
        try (MockedStatic<IncentiveRemindHolder> mockedHolder = mockStatic(IncentiveRemindHolder.class)) {
            IncentiveRemindHolder holder = mock(IncentiveRemindHolder.class);
            when(holder.isIncentiveRemindGrayHit(TEST_STATION_ID)).thenReturn(true);
            mockedHolder.when(IncentiveRemindHolder::getINSTANCE).thenReturn(holder);

            // ִ�в���
            incentiveRemindApplicationService.processIncentiveRemind(TEST_STATION_ID, TEST_JOIN_DATE);

            // ��֤û�е��÷���֪ͨ
            verify(tpPushStationMessageManager, never()).sendIncentiveRemindPopup(any(), any(), any(), any());
            verify(incentiveRemindTairPort, never()).markAsSent(any(), any(), any());
        }
    }

    /**
     * ���Գ��������ڻҶ������У�����
     */
    @Test
    public void testProcessIncentiveRemind_NotInGrayList() {
        // Mock ��Ϊ
        IncentiveRemindRuleDTO rule = createMockRule("RULE1", "����1", "NOTIFY_CONTENT", "JUMP_TYPE", "SCHEME_CODE");
        when(incentiveRemindRulePort.getRuleList()).thenReturn(Collections.singletonList(rule));
        when(incentiveRemindTriggerDomainService.calcAssessMonthOffset(TEST_JOIN_DATE, TEST_TODAY)).thenReturn(1);
        
        IncentiveAssessContextDTO context = createMockContext(false, true);
        when(incentiveAssessDataComponent.buildAssessContext(TEST_STATION_ID, 1, TEST_TODAY)).thenReturn(context);
        when(incentiveRemindTriggerDomainService.isTriggerDay(TEST_JOIN_DATE, TEST_TODAY)).thenReturn(true);
        when(incentiveRemindRuleMatchDomainService.matchRule(any(), any())).thenReturn(rule);
        when(incentiveRemindTairPort.isAlreadySent(TEST_STATION_ID, "RULE1", "20260408")).thenReturn(false);

        // Mock IncentiveRemindHolder
        try (MockedStatic<IncentiveRemindHolder> mockedHolder = mockStatic(IncentiveRemindHolder.class)) {
            IncentiveRemindHolder holder = mock(IncentiveRemindHolder.class);
            when(holder.isIncentiveRemindGrayHit(TEST_STATION_ID)).thenReturn(false);
            mockedHolder.when(IncentiveRemindHolder::getINSTANCE).thenReturn(holder);

            // ִ�в���
            incentiveRemindApplicationService.processIncentiveRemind(TEST_STATION_ID, TEST_JOIN_DATE);

            // ��֤û�е��÷���֪ͨ
            verify(tpPushStationMessageManager, never()).sendIncentiveRemindPopup(any(), any(), any(), any());
            verify(incentiveRemindTairPort, never()).markAsSent(any(), any(), any());
        }
    }

    /**
     * ���Գ������������̣��ɹ�����֪ͨ
     */
    @Test
    public void testProcessIncentiveRemind_Success() {
        // Mock ��Ϊ
        IncentiveRemindRuleDTO rule = createMockRule("RULE1", "����1", "֪ͨ����", "JUMP_TYPE", "SCHEME_CODE");
        when(incentiveRemindRulePort.getRuleList()).thenReturn(Collections.singletonList(rule));
        when(incentiveRemindTriggerDomainService.calcAssessMonthOffset(TEST_JOIN_DATE, TEST_TODAY)).thenReturn(1);
        
        IncentiveAssessContextDTO context = createMockContext(false, true);
        when(incentiveAssessDataComponent.buildAssessContext(TEST_STATION_ID, 1, TEST_TODAY)).thenReturn(context);
        when(incentiveRemindTriggerDomainService.isTriggerDay(TEST_JOIN_DATE, TEST_TODAY)).thenReturn(true);
        when(incentiveRemindRuleMatchDomainService.matchRule(any(), any())).thenReturn(rule);
        when(incentiveRemindTairPort.isAlreadySent(TEST_STATION_ID, "RULE1", "20260408")).thenReturn(false);

        // Mock IncentiveRemindHolder
        try (MockedStatic<IncentiveRemindHolder> mockedHolder = mockStatic(IncentiveRemindHolder.class)) {
            IncentiveRemindHolder holder = mock(IncentiveRemindHolder.class);
            when(holder.isIncentiveRemindGrayHit(TEST_STATION_ID)).thenReturn(true);
            when(holder.getDecorationReportUrl()).thenReturn("http://example.com/decoration");
            when(holder.getActivityDetailUrl()).thenReturn("http://example.com/activity");
            mockedHolder.when(IncentiveRemindHolder::getINSTANCE).thenReturn(holder);

            // ִ�в���
            incentiveRemindApplicationService.processIncentiveRemind(TEST_STATION_ID, TEST_JOIN_DATE);

            // ��֤���÷���֪ͨ
            verify(tpPushStationMessageManager, times(1)).sendIncentiveRemindPopup(
                    eq(123456L), eq("֪ͨ����"), eq("http://example.com/activity"), eq("SCHEME_CODE"));
            // ��֤д����ط����
            verify(incentiveRemindTairPort, times(1)).markAsSent(TEST_STATION_ID, "RULE1", "20260408");
        }
    }

    /**
     * ���Գ�����װ�ޱ�����ת���ͣ�ʹ��װ�ޱ���URL
     */
    @Test
    public void testProcessIncentiveRemind_DecorationReportJumpType() {
        // Mock ��Ϊ
        IncentiveRemindRuleDTO rule = createMockRule("RULE1", "����1", "֪ͨ����", "DECORATION_REPORT", "SCHEME_CODE");
        when(incentiveRemindRulePort.getRuleList()).thenReturn(Collections.singletonList(rule));
        when(incentiveRemindTriggerDomainService.calcAssessMonthOffset(TEST_JOIN_DATE, TEST_TODAY)).thenReturn(1);
        
        IncentiveAssessContextDTO context = createMockContext(false, true);
        when(incentiveAssessDataComponent.buildAssessContext(TEST_STATION_ID, 1, TEST_TODAY)).thenReturn(context);
        when(incentiveRemindTriggerDomainService.isTriggerDay(TEST_JOIN_DATE, TEST_TODAY)).thenReturn(true);
        when(incentiveRemindRuleMatchDomainService.matchRule(any(), any())).thenReturn(rule);
        when(incentiveRemindTairPort.isAlreadySent(TEST_STATION_ID, "RULE1", "20260408")).thenReturn(false);

        // Mock IncentiveRemindHolder
        try (MockedStatic<IncentiveRemindHolder> mockedHolder = mockStatic(IncentiveRemindHolder.class)) {
            IncentiveRemindHolder holder = mock(IncentiveRemindHolder.class);
            when(holder.isIncentiveRemindGrayHit(TEST_STATION_ID)).thenReturn(true);
            when(holder.getDecorationReportUrl()).thenReturn("http://example.com/decoration");
            when(holder.getActivityDetailUrl()).thenReturn("http://example.com/activity");
            mockedHolder.when(IncentiveRemindHolder::getINSTANCE).thenReturn(holder);

            // ִ�в���
            incentiveRemindApplicationService.processIncentiveRemind(TEST_STATION_ID, TEST_JOIN_DATE);

            // ��֤ʹ��װ�ޱ���URL
            verify(tpPushStationMessageManager, times(1)).sendIncentiveRemindPopup(
                    eq(123456L), eq("֪ͨ����"), eq("http://example.com/decoration"), eq("SCHEME_CODE"));
        }
    }

    /**
     * ���Գ�����CYCLE3_DECOR_FAIL ����ʹ���¼�����
     */
    @Test
    public void testProcessIncentiveRemind_Cycle3DecorFailRule() {
        // Mock ��Ϊ
        IncentiveRemindRuleDTO rule = createMockRule("CYCLE3_DECOR_FAIL", "����1", "֪ͨ����", "JUMP_TYPE", "SCHEME_CODE");
        when(incentiveRemindRulePort.getRuleList()).thenReturn(Collections.singletonList(rule));
        when(incentiveRemindTriggerDomainService.calcAssessMonthOffset(TEST_JOIN_DATE, TEST_TODAY)).thenReturn(1);
        
        IncentiveAssessContextDTO context = createMockContext(false, true);
        when(incentiveAssessDataComponent.buildAssessContext(TEST_STATION_ID, 1, TEST_TODAY)).thenReturn(context);
        when(incentiveRemindTriggerDomainService.isTriggerDay(TEST_JOIN_DATE, TEST_TODAY)).thenReturn(true);
        when(incentiveRemindRuleMatchDomainService.matchRule(any(), any())).thenReturn(rule);
        when(incentiveRemindTairPort.isAlreadySent(TEST_STATION_ID, "CYCLE3_DECOR_FAIL", "202604")).thenReturn(false);

        // Mock IncentiveRemindHolder
        try (MockedStatic<IncentiveRemindHolder> mockedHolder = mockStatic(IncentiveRemindHolder.class)) {
            IncentiveRemindHolder holder = mock(IncentiveRemindHolder.class);
            when(holder.isIncentiveRemindGrayHit(TEST_STATION_ID)).thenReturn(true);
            when(holder.getDecorationReportUrl()).thenReturn("http://example.com/decoration");
            when(holder.getActivityDetailUrl()).thenReturn("http://example.com/activity");
            mockedHolder.when(IncentiveRemindHolder::getINSTANCE).thenReturn(holder);

            // ִ�в���
            incentiveRemindApplicationService.processIncentiveRemind(TEST_STATION_ID, TEST_JOIN_DATE);

            // ��֤ʹ���¼�����
            verify(incentiveRemindTairPort, times(1)).markAsSent(TEST_STATION_ID, "CYCLE3_DECOR_FAIL", "202604");
        }
    }

    /**
     * ���Գ��������¼�����δװ�ޣ���ʹ�Ǵ�����ҲҪ����֪ͨ
     */
    @Test
    public void testProcessIncentiveRemind_FirstIncentiveAndNoDeco() {
        // Mock ��Ϊ
        IncentiveRemindRuleDTO rule = createMockRule("RULE1", "����1", "֪ͨ����", "JUMP_TYPE", "SCHEME_CODE");
        when(incentiveRemindRulePort.getRuleList()).thenReturn(Collections.singletonList(rule));
        when(incentiveRemindTriggerDomainService.calcAssessMonthOffset(TEST_JOIN_DATE, TEST_TODAY)).thenReturn(1);
        
        IncentiveAssessContextDTO context = createMockContext(true, false);
        when(incentiveAssessDataComponent.buildAssessContext(TEST_STATION_ID, 1, TEST_TODAY)).thenReturn(context);
        when(incentiveRemindTriggerDomainService.isTriggerDay(TEST_JOIN_DATE, TEST_TODAY)).thenReturn(false);
        when(incentiveRemindRuleMatchDomainService.matchRule(any(), any())).thenReturn(rule);
        when(incentiveRemindTairPort.isAlreadySent(TEST_STATION_ID, "RULE1", "20260408")).thenReturn(false);

        // Mock IncentiveRemindHolder
        try (MockedStatic<IncentiveRemindHolder> mockedHolder = mockStatic(IncentiveRemindHolder.class)) {
            IncentiveRemindHolder holder = mock(IncentiveRemindHolder.class);
            when(holder.isIncentiveRemindGrayHit(TEST_STATION_ID)).thenReturn(true);
            when(holder.getDecorationReportUrl()).thenReturn("http://example.com/decoration");
            when(holder.getActivityDetailUrl()).thenReturn("http://example.com/activity");
            mockedHolder.when(IncentiveRemindHolder::getINSTANCE).thenReturn(holder);

            // ִ�в���
            incentiveRemindApplicationService.processIncentiveRemind(TEST_STATION_ID, TEST_JOIN_DATE);

            // ��֤����֪ͨ����ʹ�Ǵ����գ�
            verify(tpPushStationMessageManager, times(1)).sendIncentiveRemindPopup(
                    any(), any(), any(), any());
        }
    }

    /**
     * ���Գ������������ƥ�䵽��һ������
     */
    @Test
    public void testProcessIncentiveRemind_MultipleRules() {
        // Mock ��Ϊ
        IncentiveRemindRuleDTO rule1 = createMockRule("RULE1", "����1", "֪ͨ����1", "JUMP_TYPE", "SCHEME_CODE1");
        IncentiveRemindRuleDTO rule2 = createMockRule("RULE2", "����2", "֪ͨ����2", "JUMP_TYPE", "SCHEME_CODE2");
        when(incentiveRemindRulePort.getRuleList()).thenReturn(Arrays.asList(rule1, rule2));
        when(incentiveRemindTriggerDomainService.calcAssessMonthOffset(TEST_JOIN_DATE, TEST_TODAY)).thenReturn(1);
        
        IncentiveAssessContextDTO context = createMockContext(false, true);
        when(incentiveAssessDataComponent.buildAssessContext(TEST_STATION_ID, 1, TEST_TODAY)).thenReturn(context);
        when(incentiveRemindTriggerDomainService.isTriggerDay(TEST_JOIN_DATE, TEST_TODAY)).thenReturn(true);
        when(incentiveRemindRuleMatchDomainService.matchRule(any(), any())).thenReturn(rule1);
        when(incentiveRemindTairPort.isAlreadySent(TEST_STATION_ID, "RULE1", "20260408")).thenReturn(false);

        // Mock IncentiveRemindHolder
        try (MockedStatic<IncentiveRemindHolder> mockedHolder = mockStatic(IncentiveRemindHolder.class)) {
            IncentiveRemindHolder holder = mock(IncentiveRemindHolder.class);
            when(holder.isIncentiveRemindGrayHit(TEST_STATION_ID)).thenReturn(true);
            when(holder.getDecorationReportUrl()).thenReturn("http://example.com/decoration");
            when(holder.getActivityDetailUrl()).thenReturn("http://example.com/activity");
            mockedHolder.when(IncentiveRemindHolder::getINSTANCE).thenReturn(holder);

            // ִ�в���
            incentiveRemindApplicationService.processIncentiveRemind(TEST_STATION_ID, TEST_JOIN_DATE);

            // ��֤ʹ�õ�һ������
            verify(tpPushStationMessageManager, times(1)).sendIncentiveRemindPopup(
                    eq(123456L), eq("֪ͨ����1"), any(), eq("SCHEME_CODE1"));
        }
    }

    // ========== �������� ==========

    private IncentiveRemindRuleDTO createMockRule(String ruleCode, String ruleName, String notifyContent, 
                                                  String jumpType, String noticeSchemeCode) {
        IncentiveRemindRuleDTO rule = new IncentiveRemindRuleDTO();
        rule.setRuleCode(ruleCode);
        rule.setRuleName(ruleName);
        rule.setNotifyContent(notifyContent);
        rule.setJumpType(jumpType);
        rule.setNoticeSchemeCode(noticeSchemeCode);
        return rule;
    }

    private IncentiveAssessContextDTO createMockContext(boolean isSatisfied, boolean isDecorationPass) {
        return IncentiveAssessContextDTO.builder()
                .stationId(TEST_STATION_ID)
                .assessMonthOffset(1)
                .isSatisfied(isSatisfied)
                .isDecorationPass(isDecorationPass)
                .build();
    }
}
