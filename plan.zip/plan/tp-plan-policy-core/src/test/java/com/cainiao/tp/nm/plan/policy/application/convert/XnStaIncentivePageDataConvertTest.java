package com.cainiao.tp.nm.plan.policy.application.convert;

import com.alibaba.fastjson.JSONObject;
import com.cainiao.tp.nm.plan.api.policy.application.dto.StationIncentivePageConfigHolder;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.StationIncentiveBillDetailDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.XnStationOptCntStatsDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.light.ActivityConditionDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.light.ActivityStatsDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.light.OptCntHistoryDTO;
import com.google.common.collect.Lists;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.class)
public class XnStaIncentivePageDataConvertTest {

    private final String nonBaseDetailList = "[{\"firstOver100ArrCnt\":\"501\",\"statsMonthBqArrRate\":\"0.9982279500604108\",\"noSatisfyBaseReason\":\"\",\"statsMonthBqArrCnt\":\"12393\",\"cycleRange\":\"20250401~20250430\",\"chargeOffBillTime\":\"2025-05-22 16:13:17\",\"ds\":\"2025-07-10\",\"stationSubType\":\"社区专业点\",\"checkStartMonth\":\"202504\",\"entryOperateTime\":\"2025-04-15 00:00:00\",\"statsMonthAvgVaildArrCnt\":\"413.8333333333333\",\"stationId\":\"1094379\",\"isCollectionPointTransfer\":true,\"isExpressEst\":false,\"noSatisfyReason\":\"\",\"amountCent\":\"40000\",\"isRiskStation\":false,\"checkStartDate\":\"20250401\",\"firstOver100ArrDate\":\"20250401\",\"isParticipateCpEstSta\":false,\"cycleNum\":\"1\",\"isDecorationPass\":true,\"isLightStationNew\":true,\"isQuit\":false,\"stationCode\":\"V5326297\",\"staStatusName\":\"运营中\",\"isStationChanged\":false,\"staSoftStatus\":\"运营期\",\"statsMonthGpyPickupRate\":\"0.9749152542372881\",\"statsRange\":\"20250401~20250430\",\"isApplyQuit\":false,\"statsMonthPickupCnt\":\"11800\",\"statsMonthVaildArrDays\":\"30\",\"isBlackStation\":false,\"stationName\":\"青岛适园雅居12号楼店\",\"isUnmannedStation\":false,\"statsMonthArrCnt\":\"12415\",\"isScanExpressSettleIn\":false,\"marginedTime\":\"2025-04-01 08:18:15\",\"isBlankAoiEst\":false,\"statsMonthGpyPickupCnt\":\"11504\",\"incentivePlanType\":\"base\",\"dispatchStatus\":\"has_chargeoff\",\"isCountrySideTransfer\":false,\"statsMonth\":\"202504\",\"stationMode\":\"heavy\",\"isSatisfied\":true,\"activityType\":\"STATION_ACTIVITY\",\"isReverseStationEst\":true,\"isSatisfyBaseCondition\":true}]";
    @Before
    public void setUp() throws Exception {
        // 初始化配置数据
        String config = "{\"inspireRange\":[{\"optCnt\":100,\"amount\":\"100\"},{\"optCnt\":200,\"amount\":\"200\"},{\"optCnt\":300,\"amount\":\"300\"},{\"optCnt\":400,\"amount\":\"400\"},{\"optCnt\":500,\"amount\":\"500\"},{\"optCnt\":600,\"amount\":\"600\"},{\"optCnt\":700,\"amount\":\"700\"},{\"optCnt\":800,\"amount\":\"800\"},{\"optCnt\":900,\"amount\":\"900\"},{\"optCnt\":1000,\"amount\":\"1000\"},{\"optCnt\":1100,\"amount\":\"1100\"},{\"optCnt\":1200,\"amount\":\"1200\"},{\"optCnt\":1300,\"amount\":\"1300\"},{\"optCnt\":1400,\"amount\":\"1400\"},{\"optCnt\":1500,\"amount\":\"1500\"},{\"optCnt\":1600,\"amount\":\"1600\"},{\"optCnt\":1700,\"amount\":\"1700\"},{\"optCnt\":1800,\"amount\":\"1800\"},{\"optCnt\":1900,\"amount\":\"1900\"},{\"optCnt\":2000,\"amount\":\"2000\"}]}";
        StationIncentivePageConfigHolder configHolder = JSONObject.parseObject(config, StationIncentivePageConfigHolder.class);
        StationIncentivePageConfigHolder.setINSTANCE(configHolder);
    }

    @Test
    public void testGetXnIncentiveAmount() {
        List<StationIncentiveBillDetailDTO> baseDetails = JSONObject.parseArray(nonBaseDetailList, StationIncentiveBillDetailDTO.class);
        BigDecimal incentiveAmount = XnStaIncentivePageDataConvert.getXnIncentiveAmount(baseDetails);
        Assert.assertNotNull(incentiveAmount);
        Assert.assertEquals(new BigDecimal("400"), incentiveAmount);
    }

    @Test
    public void testGetXnOptCnt() {
        List<StationIncentiveBillDetailDTO> baseDetails = JSONObject.parseArray(nonBaseDetailList, StationIncentiveBillDetailDTO.class);
        String cnt = XnStaIncentivePageDataConvert.getXnOptCnt(baseDetails);
        Assert.assertNotNull(cnt);
        Assert.assertEquals("414",cnt);
    }

    @Test
    public void testBuildActivityStats() {
        List<StationIncentiveBillDetailDTO> baseDetails = JSONObject.parseArray(nonBaseDetailList, StationIncentiveBillDetailDTO.class);
        ActivityStatsDTO activityStats = XnStaIncentivePageDataConvert.buildActivityStats(baseDetails);
        Assert.assertNotNull(activityStats);
        Assert.assertEquals("PROCESS",activityStats.getStatus());
    }


    @Test
    public void testBuildInspireRange() {
        List<StationIncentiveBillDetailDTO> baseDetails = JSONObject.parseArray(nonBaseDetailList, StationIncentiveBillDetailDTO.class);
        List<ActivityStatsDTO.PracticeInspireRangeDO> practiceInspireRangeDOS = XnStaIncentivePageDataConvert.buildInspireRange(null);
        Assert.assertNotNull(practiceInspireRangeDOS);
    }

    @Test
    public void tesBuildStaTypeCondition() {
        List<StationIncentiveBillDetailDTO> baseDetails = JSONObject.parseArray(nonBaseDetailList, StationIncentiveBillDetailDTO.class);
        StationIncentiveBillDetailDTO detailDTO = baseDetails.stream().findFirst().orElse(null);
        List<ActivityConditionDTO> activityConditionDTOS = XnStaIncentivePageDataConvert.buildStaTypeCondition(detailDTO);
        Assert.assertNull(activityConditionDTOS);
    }

    @Test
    public void tesBuildStaTypeConditionIsBase() {
        List<StationIncentiveBillDetailDTO> baseDetails = JSONObject.parseArray(nonBaseDetailList, StationIncentiveBillDetailDTO.class);
        StationIncentiveBillDetailDTO detailDTO = baseDetails.stream().findFirst().orElse(null);
        detailDTO.setFiscalQuarter("fy26q1");
        List<ActivityConditionDTO> activityConditionDTOS = XnStaIncentivePageDataConvert.buildStaTypeCondition(detailDTO);
        Assert.assertNotNull(activityConditionDTOS);
    }

    @Test
    public void tesBuildHardwareCondition() {
        List<StationIncentiveBillDetailDTO> baseDetails = JSONObject.parseArray(nonBaseDetailList, StationIncentiveBillDetailDTO.class);
        StationIncentiveBillDetailDTO detailDTO = baseDetails.stream().findFirst().orElse(null);
        List<ActivityConditionDTO> activityConditionDTOS = XnStaIncentivePageDataConvert.buildHardwareCondition(detailDTO);
        Assert.assertNotNull(activityConditionDTOS);
    }

    @Test
    public void testBuildOptCntHistory() {
        XnStationOptCntStatsDTO xnStationOptCntStatsDTO = new XnStationOptCntStatsDTO();
        xnStationOptCntStatsDTO.setStationId("1");
        xnStationOptCntStatsDTO.setActivityType("sta");
        xnStationOptCntStatsDTO.setJvCode("jv");
        xnStationOptCntStatsDTO.setIncentivePlanType("base");
        xnStationOptCntStatsDTO.setStationName("name");
        xnStationOptCntStatsDTO.setFiscalQuarter("fy26q1");
        xnStationOptCntStatsDTO.setStatsMonthArrCnt("100");
        xnStationOptCntStatsDTO.setStatsMonth("202505");
        xnStationOptCntStatsDTO.setStatsDate("20250501");
        xnStationOptCntStatsDTO.setStatsMonthAvgVaildArrCnt("100");

        List<XnStationOptCntStatsDTO> optCntStatsDTOS = Lists.newArrayList(xnStationOptCntStatsDTO);
        List<OptCntHistoryDTO> optCntHistories = XnStaIncentivePageDataConvert.buildOptCntHistory(optCntStatsDTOS);

        Assert.assertNotNull(optCntHistories);
        Assert.assertEquals(1L,optCntHistories.size());
    }
}