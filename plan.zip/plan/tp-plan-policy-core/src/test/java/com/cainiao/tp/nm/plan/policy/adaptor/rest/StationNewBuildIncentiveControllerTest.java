package com.cainiao.tp.nm.plan.policy.adaptor.rest;

import com.cainiao.sutee.commons.restful.result.CnRestResult;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.StationIncentiveRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.XnStationIncentiveRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.station.heavy.StationAssessmentVO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.station.heavy.StationIncentiveVO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.station.light.XnStationIncentiveCardVO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.station.light.XnStationIncentiveStatsVO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.station.XnStaIncentiveQueryParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.heavy.AssessmentCardDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.heavy.StationAssessmentDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.heavy.StationIncentiveDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.light.ActivityConditionDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.light.ActivityStatsDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.light.OptCntHistoryDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.light.XnStaPracticeIncentiveDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.light.XnStaPracticeIncentiveStatsDetailDTO;
import com.cainiao.tp.nm.plan.api.policy.application.service.station.StationIncentiveAppService;
import com.cainiao.tp.nm.plan.api.policy.application.service.station.XnStaIncentiveAppService;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class StationNewBuildIncentiveControllerTest {
    @InjectMocks
    private StationNewBuildIncentiveController stationNewBuildIncentiveController;
    @Mock
    private StationIncentiveAppService incentiveAppService;

    @Mock
    private XnStaIncentiveAppService xnStaIncentiveAppService;
    @Before
    public void setUp() {
        // 进行基础的Mock初始化
    }


    @Test
    public void testQueryStationNewBuildBillDetailWithNotActiveStation() {
        StationIncentiveRequest request = new StationIncentiveRequest();
        request.setStationId("123");
        request.setQuarter("Q1");
        StationIncentiveDTO incentiveDTO = new StationIncentiveDTO();
        incentiveDTO.setNotActiveStation("NotActive");

        // 设置Mock返回值
        Mockito.when(incentiveAppService.queryStationIncentive(Mockito.any())).thenReturn(incentiveDTO);
        // 调用待测试的方法
        CnRestResult<StationIncentiveVO> result = stationNewBuildIncentiveController.queryStationNewBuildBillDetail(request);
        // 验证返回结果
        Assert.assertNotNull(result);
        Assert.assertTrue(result.isSuccess());
    }

    @Test
    public void testQueryStationIncentiveAssessment() {
        // Setup
        final StationIncentiveRequest request = new StationIncentiveRequest();
        request.setStationId("stationId");
        request.setQuarter("quarter");
        request.setPeriod("period");

        final StationAssessmentDTO assessmentDTO = new StationAssessmentDTO();
        final AssessmentCardDTO warehouseOperationCard = new AssessmentCardDTO();
        warehouseOperationCard.setCode("code");
        warehouseOperationCard.setTitle("title");
        warehouseOperationCard.setIsMeet(false);
        warehouseOperationCard.setDataDate("dataDate");
        assessmentDTO.setWarehouseOperationCard(warehouseOperationCard);

        when(incentiveAppService.queryStationAssessment(any())).thenReturn(assessmentDTO);

        // Run the test
        final CnRestResult<StationAssessmentVO> result = stationNewBuildIncentiveController.queryStationIncentiveAssessment(
                request);
        Assert.assertNotNull(result);
        // Verify the results
    }

    @Test
    public void testQueryXnStaIncentiveBaseInfo() {
        // Setup
        final XnStationIncentiveRequest request = new XnStationIncentiveRequest();
        request.setStationId("stationId");
        request.setStatsMonth("statsMonth");

        // Configure XnStaIncentiveAppService.queryStaPracticeIncentiveBaseInfo(...).
        final XnStaPracticeIncentiveDTO incentiveDTO = new XnStaPracticeIncentiveDTO();
        incentiveDTO.setNeedShow(false);
        incentiveDTO.setAmount("amount");
        incentiveDTO.setOptCnt("optCnt");

        when(xnStaIncentiveAppService.queryStaPracticeIncentiveBaseInfo(any())).thenReturn(incentiveDTO);

        // Run the test
        final CnRestResult<XnStationIncentiveCardVO> result = stationNewBuildIncentiveController.queryXnStaIncentiveBaseInfo(
                request);
        Assert.assertNotNull(result);
        // Verify the results
    }

    @Test
    public void testQueryXnStaIncentiveStatsDetail() {
        // Setup
        final XnStationIncentiveRequest request = new XnStationIncentiveRequest();
        request.setStationId("stationId");
        request.setStatsMonth("statsMonth");

        // Configure XnStaIncentiveAppService.queryStaPracticeIncentiveStatsDetail(...).
        final XnStaPracticeIncentiveStatsDetailDTO statsDetailDTO = new XnStaPracticeIncentiveStatsDetailDTO();
        final ActivityStatsDTO activityCardStats = new ActivityStatsDTO();
        statsDetailDTO.setActivityCardStats(activityCardStats);
        final ActivityConditionDTO activityConditionDTO = new ActivityConditionDTO();
        statsDetailDTO.setBaseConditions(Arrays.asList(activityConditionDTO));
        final ActivityConditionDTO activityConditionDTO1 = new ActivityConditionDTO();
        statsDetailDTO.setFlexibleConditions(Arrays.asList(activityConditionDTO1));
        final OptCntHistoryDTO optCntHistoryDTO = new OptCntHistoryDTO();
        statsDetailDTO.setOptCntHistory(Arrays.asList(optCntHistoryDTO));
        statsDetailDTO.setNeedShow(false);

        when(xnStaIncentiveAppService.queryStaPracticeIncentiveStatsDetail(any())).thenReturn(statsDetailDTO);

        // Run the test
        final CnRestResult<XnStationIncentiveStatsVO> result = stationNewBuildIncentiveController.queryXnStaIncentiveStatsDetail(
                request);
        Assert.assertNotNull(result);
        // Verify the results
    }
}