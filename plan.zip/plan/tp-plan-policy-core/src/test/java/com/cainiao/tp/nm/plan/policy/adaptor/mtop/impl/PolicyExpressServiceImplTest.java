package com.cainiao.tp.nm.plan.policy.adaptor.mtop.impl;

import com.base.BaseTest;
import com.cainiao.sutee.commons.base.result.CnResult;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.ExpressOutletsDetailDTO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.ExpressOutletsDivisionDTO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.PolicyExpressDTO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.PolicyExpressQueryRequest;
import com.cainiao.tp.nm.plan.api.policy.application.dto.ExpressContentDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyInstanceRuleDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyTemplateDTO;
import com.cainiao.tp.nm.plan.infra.port.policy.ExpressAccessCheckManager;
import com.cainiao.tp.nm.plan.infra.port.policy.ExpressOutletsDetailManager;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyInstanceRuleQueryManager;
import com.cainiao.tp.nm.plan.policy.adaptor.mtop.PolicyExpressServiceImpl;
import com.cainiao.tp.nm.plan.policy.common.util.ExpressAccessUtils;
import com.cainiao.tp.nm.plan.policy.domain.repository.PolicyTemplateRepository;
import com.google.common.collect.Lists;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.time.LocalDateTime;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class PolicyExpressServiceImplTest extends BaseTest {
    @InjectMocks
    private PolicyExpressServiceImpl policyExpressServiceImpl;
    @Mock
    private PolicyInstanceRuleQueryManager instanceRuleReadAppService;
    @Mock
    private ExpressOutletsDetailManager expressOutletsDetailManager;
    @Mock
    private PolicyTemplateRepository policyTemplateRepository;
    @Mock
    private ExpressAccessCheckManager ExpressAccessCheckManager;
    private MockedStatic<ExpressAccessUtils> expressAccessUtilsMockedStatic;

    private static ExpressOutletsDivisionDTO getJointVentureInfoDTO() {
        ExpressOutletsDivisionDTO expressOutletsDivisionDTO = new ExpressOutletsDivisionDTO();
        expressOutletsDivisionDTO.setExpressId("jv123");
        expressOutletsDivisionDTO.setOrgName("jv");
        expressOutletsDivisionDTO.setOrgType("jv");
        expressOutletsDivisionDTO.setProvinceCode("1");
        expressOutletsDivisionDTO.setCityCode("2");
        expressOutletsDivisionDTO.setDistrictCode("3");
        return expressOutletsDivisionDTO;
    }

    private static ExpressOutletsDivisionDTO getStationExpressDTO() {
        ExpressOutletsDivisionDTO expressOutletsDivisionDTO = new ExpressOutletsDivisionDTO();
        expressOutletsDivisionDTO.setExpressId("cp^^^org");
        expressOutletsDivisionDTO.setOrgName("express");
        expressOutletsDivisionDTO.setOrgType("express");
        expressOutletsDivisionDTO.setProvinceCode("1");
        expressOutletsDivisionDTO.setCityCode("2");
        expressOutletsDivisionDTO.setDistrictCode("3");
        return expressOutletsDivisionDTO;
    }

    @Before
    public void before() {
        expressAccessUtilsMockedStatic = Mockito.mockStatic(ExpressAccessUtils.class);
        ExpressContentDTO expressContentDTO = new ExpressContentDTO();
        expressAccessUtilsMockedStatic.when(ExpressAccessUtils::getContext).thenReturn(expressContentDTO);
    }

    @After
    public void after() {
        expressAccessUtilsMockedStatic.close();
    }

    @Test
    public void testQueryOutletsPolicyJV() {
        PolicyExpressQueryRequest request = new PolicyExpressQueryRequest();
        request.setOrgType("jv");
        request.setOrgCode("LE40668900");
        request.setEmployeeId("1111");

        doNothing().when(ExpressAccessCheckManager).checkExpAndJVAccess(any());

        ExpressOutletsDetailDTO detailDTO = new ExpressOutletsDetailDTO();
        detailDTO.setOrgType("jv");
        ExpressOutletsDivisionDTO jointVentureInfoDTO = getJointVentureInfoDTO();
        detailDTO.setExpressOutletsDivisionDTO(jointVentureInfoDTO);
        when(expressOutletsDetailManager.queryExpressOutletsDetail(any())).thenReturn(detailDTO);
        PolicyInstanceRuleDTO ruleDTO = new PolicyInstanceRuleDTO();
        ruleDTO.setId(1L);
        ruleDTO.setInstanceId(2L);
        ruleDTO.setIncentivePlanType("flexible");
        ruleDTO.setTemplateId(3L);
        ruleDTO.setCustomType("express");
        ruleDTO.setApprovalStatus((byte) 0);
        ruleDTO.setProvinceCode("1");
        ruleDTO.setCityCode("2");
        ruleDTO.setDistrictCode("4");
        ruleDTO.setStartTime(LocalDateTime.now());
        ruleDTO.setEndTime(LocalDateTime.now());
        ruleDTO.setLaunchObject("{\"areaSelectRule\":{\"provinceCode\":\"330000\",\"cityCode\":\"330100\",\"districtCode\":\"330110\"},\"entitySelectRule\":{\"type\":\"express\",\"entityType\":\"jv\",\"entityId\":\"CP^^^LE40668900\",\"entityName\":\"兰西县xxxx\"},\"tagSelectRule\":{\"tagCodeList\":[\"STO\"]}}");
        ruleDTO.setRuleContent("{\"coefficient\":[{\"code\":\"basic\",\"name\":\"基础系数\",\"frame\":{\"children\":[{\"factorCode\":\"stationType\",\"arithLogic\":\"=\",\"factorResult\":{\"type\":\"fixed\",\"fixedVal\":\"non_station\"},\"result\":[{\"code\":\"basic\",\"name\":\"基础系数\",\"val\":\"0.6\"}]},{\"factorCode\":\"stationType\",\"arithLogic\":\"=\",\"factorResult\":{\"type\":\"fixed\",\"fixedVal\":\"light_station\"},\"result\":[{\"code\":\"basic\",\"name\":\"基础系数\",\"val\":\"0.8\"}]},{\"factorCode\":\"stationType\",\"arithLogic\":\"=\",\"factorResult\":{\"type\":\"fixed\",\"fixedVal\":\"normal_station\"},\"result\":[{\"code\":\"basic\",\"name\":\"基础系数\",\"val\":\"1.0\"}]}]}}]}");
        when(instanceRuleReadAppService.queryPolicyInstanceRuleByParam(any())).thenReturn(Lists.newArrayList(ruleDTO));


        PolicyTemplateDTO templateDTO = new PolicyTemplateDTO();
        templateDTO.setId(3L);
        templateDTO.setTemplateName("政策名");
        templateDTO.setCustomType("express");
        templateDTO.setBizType("scale");
        when(policyTemplateRepository.selectAll(any())).thenReturn(Lists.newArrayList(templateDTO));

        CnResult<PolicyExpressDTO> result = policyExpressServiceImpl.queryOutletsPolicy(request);
        Assert.assertTrue(result.isSuccess());
        Assert.assertNotNull(result.getData());
        Assert.assertEquals(result.getData().getTitle(), "政策名");
        Assert.assertTrue(result.getData().getHasPolicy());
    }

    @Test
    public void testQueryOutletsPolicyJVRuleIsNull() {
        PolicyExpressQueryRequest request = new PolicyExpressQueryRequest();
        request.setOrgType("jv");
        request.setOrgCode("LE40668900");
        request.setEmployeeId("1111");

        doNothing().when(ExpressAccessCheckManager).checkExpAndJVAccess(any());

        ExpressOutletsDetailDTO detailDTO = new ExpressOutletsDetailDTO();
        detailDTO.setOrgType("jv");
        ExpressOutletsDivisionDTO jointVentureInfoDTO = getJointVentureInfoDTO();
        detailDTO.setExpressOutletsDivisionDTO(jointVentureInfoDTO);
        when(expressOutletsDetailManager.queryExpressOutletsDetail(any())).thenReturn(detailDTO);


        when(instanceRuleReadAppService.queryPolicyInstanceRuleByParam(any())).thenReturn(Lists.newArrayList());


        CnResult<PolicyExpressDTO> result = policyExpressServiceImpl.queryOutletsPolicy(request);
        Assert.assertTrue(result.isSuccess());
        Assert.assertNull(result.getData().getIncentiveAmount());
        Assert.assertNull(result.getData().getTitle());
        Assert.assertFalse(result.getData().getHasPolicy());
    }

    @Test
    public void testQueryOutletsPolicyOrg() {
        PolicyExpressQueryRequest request = new PolicyExpressQueryRequest();
        request.setOrgType("org");
        request.setCpCode("STO");
        request.setOrgCode("LE40668900");
        request.setEmployeeId("1111");

        doNothing().when(ExpressAccessCheckManager).checkExpAndJVAccess(any());

        ExpressOutletsDetailDTO detailDTO = new ExpressOutletsDetailDTO();
        detailDTO.setOrgType("org");
        ExpressOutletsDivisionDTO stationExpressDTO = getStationExpressDTO();
        detailDTO.setExpressOutletsDivisionDTO(stationExpressDTO);
        when(expressOutletsDetailManager.queryExpressOutletsDetail(any())).thenReturn(detailDTO);
        PolicyInstanceRuleDTO ruleDTO = new PolicyInstanceRuleDTO();
        ruleDTO.setId(1L);
        ruleDTO.setInstanceId(2L);
        ruleDTO.setIncentivePlanType("flexible");
        ruleDTO.setTemplateId(3L);
        ruleDTO.setCustomType("express");
        ruleDTO.setApprovalStatus((byte) 0);
        ruleDTO.setProvinceCode("1");
        ruleDTO.setCityCode("2");
        ruleDTO.setDistrictCode("4");
        ruleDTO.setStartTime(LocalDateTime.now());
        ruleDTO.setEndTime(LocalDateTime.now());
        ruleDTO.setLaunchObject("{\"areaSelectRule\":{\"provinceCode\":\"330000\",\"cityCode\":\"330100\",\"districtCode\":\"330110\"},\"entitySelectRule\":{\"type\":\"express\",\"entityType\":\"jv\",\"entityId\":\"CP^^^LE40668900\",\"entityName\":\"兰西县xxxx\"},\"tagSelectRule\":{\"tagCodeList\":[\"STO\"]}}");
        ruleDTO.setRuleContent("{\"coefficient\":[{\"code\":\"basic\",\"name\":\"基础系数\",\"frame\":{\"children\":[{\"factorCode\":\"stationType\",\"arithLogic\":\"=\",\"factorResult\":{\"type\":\"fixed\",\"fixedVal\":\"non_station\"},\"result\":[{\"code\":\"basic\",\"name\":\"基础系数\",\"val\":\"0.6\"}]},{\"factorCode\":\"stationType\",\"arithLogic\":\"=\",\"factorResult\":{\"type\":\"fixed\",\"fixedVal\":\"light_station\"},\"result\":[{\"code\":\"basic\",\"name\":\"基础系数\",\"val\":\"0.8\"}]},{\"factorCode\":\"stationType\",\"arithLogic\":\"=\",\"factorResult\":{\"type\":\"fixed\",\"fixedVal\":\"normal_station\"},\"result\":[{\"code\":\"basic\",\"name\":\"基础系数\",\"val\":\"1.0\"}]}]}}]}");
        when(instanceRuleReadAppService.queryPolicyInstanceRuleByParam(any())).thenReturn(Lists.newArrayList(ruleDTO));

        PolicyTemplateDTO templateDTO = new PolicyTemplateDTO();
        templateDTO.setId(3L);
        templateDTO.setTemplateName("政策名");
        templateDTO.setCustomType("express");
        templateDTO.setBizType("scale");
        when(policyTemplateRepository.selectAll(any())).thenReturn(Lists.newArrayList(templateDTO));
        CnResult<PolicyExpressDTO> result = policyExpressServiceImpl.queryOutletsPolicy(request);
        Assert.assertTrue(result.isSuccess());
        Assert.assertNotNull(result.getData());
        Assert.assertEquals(result.getData().getTitle(), "政策名");
        Assert.assertTrue(result.getData().getHasPolicy());
    }

    @Test
    public void testQueryOutletsPolicyOrgRuleIsNull() {
        PolicyExpressQueryRequest request = new PolicyExpressQueryRequest();
        request.setOrgType("org");
        request.setCpCode("STO");
        request.setOrgCode("LE40668900");
        request.setEmployeeId("1111");

        doNothing().when(ExpressAccessCheckManager).checkExpAndJVAccess(any());

        ExpressOutletsDetailDTO detailDTO = new ExpressOutletsDetailDTO();
        detailDTO.setOrgType("org");
        ExpressOutletsDivisionDTO stationExpressDTO = getStationExpressDTO();
        detailDTO.setExpressOutletsDivisionDTO(stationExpressDTO);
        when(expressOutletsDetailManager.queryExpressOutletsDetail(any())).thenReturn(detailDTO);

        when(instanceRuleReadAppService.queryPolicyInstanceRuleByParam(any())).thenReturn(Lists.newArrayList());


        CnResult<PolicyExpressDTO> result = policyExpressServiceImpl.queryOutletsPolicy(request);
        Assert.assertTrue(result.isSuccess());
        Assert.assertNotNull(result.getData());
        Assert.assertNull(result.getData().getTitle());
        Assert.assertFalse(result.getData().getHasPolicy());
    }

    @Test
    public void testQueryOutletsPolicyOrgRuleInErr() {
        PolicyExpressQueryRequest request = new PolicyExpressQueryRequest();
        request.setOrgType("org");
        request.setCpCode("STO");
        request.setOrgCode("LE40668900");
        request.setEmployeeId("1111");

        doNothing().when(ExpressAccessCheckManager).checkExpAndJVAccess(any());

        ExpressOutletsDetailDTO detailDTO = new ExpressOutletsDetailDTO();
        detailDTO.setOrgType("org");
        ExpressOutletsDivisionDTO stationExpressDTO = getStationExpressDTO();
        detailDTO.setExpressOutletsDivisionDTO(stationExpressDTO);
        when(expressOutletsDetailManager.queryExpressOutletsDetail(any())).thenReturn(detailDTO);
        PolicyInstanceRuleDTO ruleDTO = new PolicyInstanceRuleDTO();
        ruleDTO.setId(1L);
        ruleDTO.setInstanceId(2L);
        ruleDTO.setIncentivePlanType("flexible");
        ruleDTO.setTemplateId(3L);
        ruleDTO.setCustomType("express");
        ruleDTO.setApprovalStatus((byte) 0);
        ruleDTO.setProvinceCode("1");
        ruleDTO.setCityCode("2");
        ruleDTO.setDistrictCode("4");
        ruleDTO.setStartTime(LocalDateTime.now());
        ruleDTO.setEndTime(LocalDateTime.now());
        ruleDTO.setLaunchObject("{\"areaSelectRule\":{\"provinceCode\":\"330000\",\"cityCode\":\"330100\",\"districtCode\":\"330110\"},\"entitySelectRule\":{\"type\":\"express\",\"entityType\":\"jv\",\"entityId\":\"CP^^^LE40668900\",\"entityName\":\"兰西县xxxx\"},\"tagSelectRule\":{\"tagCodeList\":[\"STO\"]}}");
        ruleDTO.setRuleContent("{\"coefficient\":[{\"code\":\"basic\",\"name\":\"基础系数\",\"frame\":{\"children\":[{\"factorCode\":\"stationType\",\"arithLogic\":\"=\",\"factorResult\":{\"type\":\"fixed\",\"fixedVal\":\"non_station\"},\"result\":[{\"code\":\"basic\",\"name\":\"基础系数\",\"val\":\"0.6\"}]},{\"factorCode\":\"stationType\",\"arithLogic\":\"=\",\"factorResult\":{\"type\":\"fixed\",\"fixedVal\":\"light_station\"},\"result\":[{\"code\":\"basic\",\"name\":\"基础系数\",\"val\":\"0.8\"}]},{\"factorCode\":\"stationType\",\"arithLogic\":\"=\",\"factorResult\":{\"type\":\"fixed\",\"fixedVal\":\"normal_station\"},\"result\":[{\"code\":\"basic\",\"name\":\"基础系数\",\"val\":\"1.0\"}]}]}}]}");
        when(instanceRuleReadAppService.queryPolicyInstanceRuleByParam(any())).thenReturn(Lists.newArrayList(ruleDTO));

        PolicyTemplateDTO templateDTO = new PolicyTemplateDTO();
        templateDTO.setId(3L);
        templateDTO.setTemplateName("政策名");
        templateDTO.setCustomType("express");
        templateDTO.setBizType("scale");

        PolicyTemplateDTO templateDTO2 = new PolicyTemplateDTO();
        templateDTO2.setId(2L);
        templateDTO2.setTemplateName("政策名2");
        templateDTO2.setCustomType("express");
        templateDTO2.setBizType("scale");
        when(policyTemplateRepository.selectAll(any())).thenReturn(Lists.newArrayList(templateDTO,templateDTO2));

        CnResult<PolicyExpressDTO> result = policyExpressServiceImpl.queryOutletsPolicy(request);
        Assert.assertTrue(result.isSuccess());
        Assert.assertNotNull(result.getData());
        Assert.assertFalse(result.getData().getHasPolicy());
        Assert.assertFalse(result.getData().getHasPolicy());
    }
}