package com.cainiao.tp.nm.plan.policy.domain.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.cainiao.aladdin.exception.AladdinParamException;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyTemplateCreateParam;
import com.cainiao.tp.nm.plan.policy.domain.model.PolicyTemplate;
import com.cainiao.tp.nm.plan.policy.domain.repository.PolicyTemplateRepository;
import com.google.common.collect.Lists;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Collections;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class PolicyTemplateDomainServiceImplTest {

    @InjectMocks
    private PolicyTemplateDomainServiceImpl policyTemplateDomainService;

    @Mock
    private PolicyTemplateRepository policyTemplateRepository;

    /**
     * 测试成功创建模板
     */
    @Test
    public void testCreateTemplateSuccess() {
        // 准备参数
        String temParam = "{\"bizType\":\"scale\",\"customType\":\"station\",\"endTimeStr\":\"2025-08-30\",\"featureMap\":{\"effectOpportunity\":\"assign\"},\"incentivePlanList\":[{\"content\":{\"coefficient\":[{\"code\":\"basic\",\"frame\":{\"result\":[{\"code\":\"basic\",\"name\":\"默认\",\"resultLimit\":{\"canUpdate\":false},\"val\":\"1.0\"}]},\"name\":\"默认系数\"}],\"selectPlan\":{\"areaSelectPlan\":{\"cityCodeList\":[\"330100\"],\"national\":false,\"provinceCodeList\":[\"330000\"]}}},\"incentivePlanCode\":\"ceshi111test1\",\"incentivePlanType\":\"basic\",\"planName\":\"基础激励\"},{\"content\":{\"coefficient\":[{\"code\":\"basic\",\"frame\":{\"children\":[{\"arithLogic\":\"=\",\"factorCode\":\"stationType\",\"factorName\":\"站点类型\",\"factorResult\":{\"fixedVal\":\"non_station\",\"type\":\"fixed\"},\"incentiveFactorLimit\":{\"canUpdate\":false},\"result\":[{\"code\":\"basic\",\"name\":\"默认\",\"resultLimit\":{\"canUpdate\":true,\"limitType\":\"option\",\"optionLimit\":{\"optionList\":[\"0.6\",\"0.8\",\"1.0\",\"1.2\"]}}}]},{\"arithLogic\":\"=\",\"factorCode\":\"stationType\",\"factorName\":\"站点类型\",\"factorResult\":{\"fixedVal\":\"light_station\",\"type\":\"fixed\"},\"incentiveFactorLimit\":{\"canUpdate\":false},\"result\":[{\"code\":\"basic\",\"name\":\"默认\",\"resultLimit\":{\"canUpdate\":true,\"limitType\":\"option\",\"optionLimit\":{\"optionList\":[\"0.6\",\"0.8\",\"1.0\",\"1.2\"]}}}]},{\"arithLogic\":\"=\",\"factorCode\":\"stationType\",\"factorName\":\"站点类型\",\"factorResult\":{\"fixedVal\":\"normal_station\",\"type\":\"fixed\"},\"incentiveFactorLimit\":{\"canUpdate\":false},\"result\":[{\"code\":\"basic\",\"name\":\"默认\",\"resultLimit\":{\"canUpdate\":true,\"limitType\":\"option\",\"optionLimit\":{\"optionList\":[\"0.6\",\"0.8\",\"1.0\",\"1.2\"]}}}]}]},\"name\":\"默认系数\"}],\"selectPlan\":{\"areaSelectPlan\":{\"cityCodeList\":[\"330100\"],\"national\":false,\"provinceCodeList\":[\"330000\"]}}},\"incentivePlanCode\":\"ceshi111test2\",\"incentivePlanType\":\"flexible\",\"planName\":\"灵活激励\"}],\"launchPlan\":{\"launchType\":\"rule\",\"ruleLaunch\":{\"areaRuleLaunch\":{\"cityCodeList\":[\"330100\"],\"national\":false,\"provinceCodeList\":[\"330000\"]}}},\"operatorId\":303544,\"startTimeStr\":\"2025-07-01\",\"templateName\":\"建宇测试1\"}";
        PolicyTemplateCreateParam param = JSONObject.parseObject(temParam, PolicyTemplateCreateParam.class);

        // 设定存储库返回值
        when(policyTemplateRepository.get(param.getBizType(), param.getCustomType())).thenReturn(Collections.emptyList());

        // 调用方法
        PolicyTemplate result = policyTemplateDomainService.createTemplate(param);

        // 验证结果
        assertNotNull(result);
        // 这里可以添加对 PolicyTemplate 的其他字段的断言，确保正常创建
    }

    @Test(expected = AladdinParamException.class)
    public void testCreateTemplateSuccess1() {
        // 准备参数
        String temParam = "{\"bizType\":\"scale\",\"customType\":\"station\",\"endTimeStr\":\"2025-08-30\",\"featureMap\":{\"effectOpportunity\":\"assign\"},\"incentivePlanList\":[{\"content\":{\"coefficient\":[{\"code\":\"basic\",\"frame\":{\"result\":[{\"code\":\"basic\",\"name\":\"默认\",\"resultLimit\":{\"canUpdate\":false},\"val\":\"1.0\"}]},\"name\":\"默认系数\"}],\"selectPlan\":{\"areaSelectPlan\":{\"cityCodeList\":[\"330100\"],\"national\":false,\"provinceCodeList\":[\"330000\"]}}},\"incentivePlanCode\":\"ceshi111test1\",\"incentivePlanType\":\"basic\",\"planName\":\"基础激励\"},{\"content\":{\"coefficient\":[{\"code\":\"basic\",\"frame\":{\"children\":[{\"arithLogic\":\"=\",\"factorCode\":\"stationType\",\"factorName\":\"站点类型\",\"factorResult\":{\"fixedVal\":\"non_station\",\"type\":\"fixed\"},\"incentiveFactorLimit\":{\"canUpdate\":false},\"result\":[{\"code\":\"basic\",\"name\":\"默认\",\"resultLimit\":{\"canUpdate\":true,\"limitType\":\"option\",\"optionLimit\":{\"optionList\":[\"0.6\",\"0.8\",\"1.0\",\"1.2\"]}}}]},{\"arithLogic\":\"=\",\"factorCode\":\"stationType\",\"factorName\":\"站点类型\",\"factorResult\":{\"fixedVal\":\"light_station\",\"type\":\"fixed\"},\"incentiveFactorLimit\":{\"canUpdate\":false},\"result\":[{\"code\":\"basic\",\"name\":\"默认\",\"resultLimit\":{\"canUpdate\":true,\"limitType\":\"option\",\"optionLimit\":{\"optionList\":[\"0.6\",\"0.8\",\"1.0\",\"1.2\"]}}}]},{\"arithLogic\":\"=\",\"factorCode\":\"stationType\",\"factorName\":\"站点类型\",\"factorResult\":{\"fixedVal\":\"normal_station\",\"type\":\"fixed\"},\"incentiveFactorLimit\":{\"canUpdate\":false},\"result\":[{\"code\":\"basic\",\"name\":\"默认\",\"resultLimit\":{\"canUpdate\":true,\"limitType\":\"option\",\"optionLimit\":{\"optionList\":[\"0.6\",\"0.8\",\"1.0\",\"1.2\"]}}}]}]},\"name\":\"默认系数\"}],\"selectPlan\":{\"areaSelectPlan\":{\"cityCodeList\":[\"330100\"],\"national\":false,\"provinceCodeList\":[\"330000\"]}}},\"incentivePlanCode\":\"ceshi111test2\",\"incentivePlanType\":\"flexible\",\"planName\":\"灵活激励\"}],\"launchPlan\":{\"launchType\":\"rule\",\"ruleLaunch\":{\"areaRuleLaunch\":{\"cityCodeList\":[\"330100\"],\"national\":false,\"provinceCodeList\":[\"330000\"]}}},\"operatorId\":303544,\"startTimeStr\":\"2025-07-01\",\"templateName\":\"建宇测试1\"}";
        PolicyTemplateCreateParam param = JSONObject.parseObject(temParam, PolicyTemplateCreateParam.class);

        // 设定存储库返回值
        when(policyTemplateRepository.get(param.getBizType(), param.getCustomType())).thenReturn(Lists.newArrayList(PolicyTemplate.create(param)));

        // 调用方法
        PolicyTemplate result = policyTemplateDomainService.createTemplate(param);

        // 验证结果
        assertNotNull(result);
        // 这里可以添加对 PolicyTemplate 的其他字段的断言，确保正常创建
    }
}