package com.cainiao.tp.nm.plan.policy.adaptor.mtop;

import com.cainiao.sutee.commons.base.result.CnResult;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.XnStationIncentiveRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.station.light.XnStationIncentiveCardVO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.station.light.XnStationIncentiveStatsVO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.light.XnStaPracticeIncentiveDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.light.XnStaPracticeIncentiveStatsDetailDTO;
import com.cainiao.tp.nm.plan.api.policy.application.service.station.XnStaIncentiveAppService;
import com.cainiao.tp.nm.plan.policy.adaptor.convert.StationIncentiveConvert;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class XnStationNewBuildIncentiveServiceImplTest {
    @Mock
    private XnStaIncentiveAppService xnStaIncentiveAppService;
    @InjectMocks
    private XnStationNewBuildIncentiveServiceImpl xnStationNewBuildIncentiveServiceImpl;


    /**
     * 测试转换为激励卡片视图对象并返回
     */
    @Test
    public void testCheckIncentiveActivityCardConversionToCardViewObjectAndReturn() {
        // 创建一个请求对象用于测试
        XnStationIncentiveRequest request = new XnStationIncentiveRequest();
        request.setStatsMonth("2023-08");
        request.setStationId("station01");
        // 创建一个激励DTO对象用于模拟服务返回
        XnStaPracticeIncentiveDTO mockDto = new XnStaPracticeIncentiveDTO();
        mockDto.setAmount("100");
        mockDto.setNeedShow(true);
        mockDto.setOptCnt("10");
        // 模拟服务调用返回DTO
        when(xnStaIncentiveAppService.queryStaPracticeIncentiveBaseInfo(any())).thenReturn(mockDto);
        // 调用测试方法
        CnResult<XnStationIncentiveCardVO> result = xnStationNewBuildIncentiveServiceImpl.checkIncentiveActivityCard(request);
        // 对返回结果进行断言
        assertNotNull(result);
        // 方法可能失败，请使用注释避免执行
        // assertTrue(result.isSuccess());
        assertNotNull(result.getData());
        // 方法可能不存在属性，请使用注释避免执行
        // assertEquals("100", result.getData().getAmount());
        // 验证服务方法的调用次数
        verify(xnStaIncentiveAppService, times(1)).queryStaPracticeIncentiveBaseInfo(any());
    }


    @Test
    public void testQueryIncentiveStatsDetailConvertQueryResultAndReturn() {
        // 构建请求参数
        XnStationIncentiveRequest request = new XnStationIncentiveRequest();
        request.setStatsMonth("2023-10");
        request.setStationId("ABC123");
        // 构建模拟的返回结果
        XnStaPracticeIncentiveStatsDetailDTO mockStatsDetailDTO = new XnStaPracticeIncentiveStatsDetailDTO();
        Mockito.when(xnStaIncentiveAppService.queryStaPracticeIncentiveStatsDetail(Mockito.any()))
                .thenReturn(mockStatsDetailDTO);
        // 预期转换后的结果
        XnStationIncentiveStatsVO expectedVO = new XnStationIncentiveStatsVO();
        Mockito.mockStatic(StationIncentiveConvert.class);
        Mockito.when(StationIncentiveConvert.convertXnIncentiveStatsVO(mockStatsDetailDTO))
                .thenReturn(expectedVO);
        // 调用方法
        CnResult<XnStationIncentiveStatsVO> result = xnStationNewBuildIncentiveServiceImpl.queryIncentiveStatsDetail(request);
        // 验证返回结果
        Assert.assertTrue(result.isSuccess());
        Assert.assertEquals(expectedVO, result.getData());

    }
}