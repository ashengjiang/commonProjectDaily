package com.cainiao.tp.nm.plan.policy.adaptor.rest;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.alibaba.fastjson.JSON;

import com.base.BaseTest;
import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.aladdin.operation.CNUserOperation;
import com.cainiao.sutee.commons.base.model.CnPage;
import com.cainiao.sutee.commons.base.model.Page;
import com.cainiao.sutee.commons.restful.component.table.Table;
import com.cainiao.sutee.commons.restful.result.CnRestResult;
import com.cainiao.tp.boot.utils.TpWebUtil;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.IncentiveExpenseItemQueryRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.PolicyTemplateCreateRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.PolicyTemplateDeleteRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.PolicyTemplateIncentiveQueryRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.PolicyTemplateQueryRequest;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.PolicyTemplateIncentiveVO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.PolicyTemplateRecordVO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.incentiveplan.IncentiveExpenseItemVO;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.vo.incentiveplan.IncentivePlanVO;
import com.cainiao.tp.nm.plan.infra.port.policy.EmployeeRightsLoadManager;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyTemplateDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.PolicyIncentiveExpenseItemDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.IncentivePlanDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.launchplan.LaunchPlanDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.launchplan.ListItemLaunchDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.launchplan.ListLaunchDTO;
import com.cainiao.tp.nm.plan.api.policy.application.service.PolicyTemplateAppService;
import com.cainiao.tp.nm.plan.api.policy.common.utils.DateUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.anyLong;

/**
 * <a href="https://alidocs.dingtalk.com/i/nodes/dpYLaezmVNRMGX56C1aKjlBOVrMqPxX6">单元测试编写&生成FAQ</a>
 * Created By Thub IDEA插件
 *
 * @Date 2025/6/4 14:57
 */
public class PolicyTemplateControllerTest extends BaseTest {

    @InjectMocks
    private PolicyTemplateController policyTemplateController;
    @Mock
    private PolicyTemplateAppService policyTemplateAppService;

    private MockedStatic<TpWebUtil> tpWebUtilMockedStatic;
    @Mock
    private EmployeeRightsLoadManager employeeRightsLoadManager;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        tpWebUtilMockedStatic = Mockito.mockStatic(TpWebUtil.class);
        AbstractOperation operation = new CNUserOperation(1L, "test");
        tpWebUtilMockedStatic.when(TpWebUtil::getWebOperation).thenReturn(operation);
    }

    @After
    public void tearDown() throws Exception {
        if (tpWebUtilMockedStatic != null) {
            tpWebUtilMockedStatic.close();
        }
    }

    @Test
    public void testCreate_rule() {
        PolicyTemplateCreateRequest createRequest = buildCreateRequest_rule();
        List<IncentivePlanDTO> incentivePlanDTOList = buildIncentivePlanList();

        // Setup, prepare mock data
        Mockito.when(policyTemplateAppService.queryIncentivePlanList(any(), any()))
            .thenReturn(incentivePlanDTOList);

        // Run the method to be tested
        CnRestResult<Void> result = policyTemplateController.create(createRequest);

        // Verify the result
        Assert.assertNotNull(result);
        Assert.assertTrue(result.isSuccess());
    }

    @Test
    public void testCreate_national() {
        PolicyTemplateCreateRequest createRequest = buildCreateRequest_national();
        List<IncentivePlanDTO> incentivePlanDTOList = buildIncentivePlanList();

        // Setup, prepare mock data
        Mockito.when(policyTemplateAppService.queryIncentivePlanList(any(), any()))
            .thenReturn(incentivePlanDTOList);

        // Run the method to be tested
        CnRestResult<Void> result = policyTemplateController.create(createRequest);

        // Verify the result
        Assert.assertNotNull(result);
        Assert.assertTrue(result.isSuccess());
    }

    @Test
    public void testCreate_list() {
        PolicyTemplateCreateRequest createRequest = buildCreateRequest_list();
        List<IncentivePlanDTO> incentivePlanDTOList = buildIncentivePlanList();

        // Setup, prepare mock data
        Mockito.when(policyTemplateAppService.queryIncentivePlanList(any(), any()))
            .thenReturn(incentivePlanDTOList);

        // Run the method to be tested
        CnRestResult<Void> result = policyTemplateController.create(createRequest);

        // Verify the result
        Assert.assertNotNull(result);
        Assert.assertTrue(result.isSuccess());
    }

    @Test
    public void testQueryPolicyTemplateList() {

        Page<PolicyTemplateDTO> page = CnPage.of(1, 10, buildPolicyTemplateList(), 1L);
        // Setup, prepare mock data
        Mockito.when(policyTemplateAppService.queryPolicyTemplateList(any(), any()))
            .thenReturn(page);
        Mockito.when(employeeRightsLoadManager.getEmployeeHighestLevelCode(anyLong()))
            .thenReturn("CN");

        PolicyTemplateQueryRequest request = new PolicyTemplateQueryRequest();
        // Run the method to be tested
        CnRestResult<Table<PolicyTemplateRecordVO>> result = policyTemplateController.queryPolicyTemplateList(request);

        // Verify the result
        Assert.assertNotNull(result);
        Assert.assertEquals(1, result.getData().getTableData().size());
        Assert.assertEquals("FY26规模站点政策", result.getData().getTableData().get(0).getTemplateName());
        Assert.assertEquals("scale", result.getData().getTableData().get(0).getBizType());
        Assert.assertEquals("规模", result.getData().getTableData().get(0).getBizTypeDesc());
        Assert.assertEquals("station", result.getData().getTableData().get(0).getCustomType());
        Assert.assertEquals("站点", result.getData().getTableData().get(0).getCustomTypeDesc());
        Assert.assertEquals("2", result.getData().getTableData().get(0).getDurationStatus());
        Assert.assertEquals("已过期", result.getData().getTableData().get(0).getDurationStatusStr());
        Assert.assertEquals(1, result.getData().getTableData().get(0).getId().longValue());
        Assert.assertEquals("2025.05.01-2025.05.31", result.getData().getTableData().get(0).getPeriod());
        Assert.assertEquals(2, result.getData().getTableData().get(0).getPolicyRuleList().size());

        Assert.assertEquals("基础激励", result.getData().getTableData().get(0).getPolicyRuleList().get(0).getPlanTitle());
        Assert.assertEquals("FY26Q1规模站点基础激励", result.getData().getTableData().get(0).getPolicyRuleList().get(0).getPlanName());
        Assert.assertEquals("basic", result.getData().getTableData().get(0).getPolicyRuleList().get(0).getIncentivePlanType());
        Assert.assertEquals(1, result.getData().getTableData().get(0).getPolicyRuleList().get(0).getContentRecordList().size());
        Assert.assertEquals("基础激励: 1", result.getData().getTableData().get(0).getPolicyRuleList().get(0).getContentRecordList().get(0)
            .getIncentiveContent());
        Assert.assertEquals("激励周期: 6", result.getData().getTableData().get(0).getPolicyRuleList().get(0).getContentRecordList().get(0)
            .getIncentivePeriod());

        Assert.assertEquals("灵活激励", result.getData().getTableData().get(0).getPolicyRuleList().get(1).getPlanTitle());
        Assert.assertEquals("FY26Q1规模站点灵活激励", result.getData().getTableData().get(0).getPolicyRuleList().get(1).getPlanName());
        Assert.assertEquals("flexible", result.getData().getTableData().get(0).getPolicyRuleList().get(1).getIncentivePlanType());
        Assert.assertEquals(3, result.getData().getTableData().get(0).getPolicyRuleList().get(1).getContentRecordList().size());
        Assert.assertEquals("无人站: 0.6/0.8/1.0/1.2", result.getData().getTableData().get(0).getPolicyRuleList().get(1).getContentRecordList().get(0)
            .getIncentiveContent());
        Assert.assertEquals("激励周期: 6", result.getData().getTableData().get(0).getPolicyRuleList().get(1).getContentRecordList().get(0)
            .getIncentivePeriod());
        Assert.assertEquals("灯条站: 0.6/0.8/1.0/1.2", result.getData().getTableData().get(0).getPolicyRuleList().get(1).getContentRecordList().get(1)
            .getIncentiveContent());
        Assert.assertEquals("激励周期: 6", result.getData().getTableData().get(0).getPolicyRuleList().get(1).getContentRecordList().get(1)
            .getIncentivePeriod());
        Assert.assertEquals("普通站: 0.6/0.8/1.0/1.2", result.getData().getTableData().get(0).getPolicyRuleList().get(1).getContentRecordList().get(2)
            .getIncentiveContent());
        Assert.assertEquals("激励周期: 6", result.getData().getTableData().get(0).getPolicyRuleList().get(1).getContentRecordList().get(1)
            .getIncentivePeriod());
        Assert.assertEquals(2, result.getData().getTableData().get(0).getOperateCodeList().size());
        Assert.assertEquals("policyPanel", result.getData().getTableData().get(0).getOperateCodeList().get(0));
        Assert.assertEquals("delete", result.getData().getTableData().get(0).getOperateCodeList().get(1));
    }

    @Test
    public void testQueryMetaData() {
        // Run the method to be tested
        CnRestResult<PolicyTemplateIncentiveVO> result = policyTemplateController.queryMetaData();

        // Verify the result
        Assert.assertNotNull(result);
        Assert.assertTrue(result.isSuccess());
        Assert.assertEquals(1, result.getData().getBizTypeList().size());
        Assert.assertEquals("scale", result.getData().getBizTypeList().get(0).getType());
        Assert.assertEquals("规模", result.getData().getBizTypeList().get(0).getDesc());
        //Assert.assertEquals("digitization", result.getData().getBizTypeList().get(1).getType());
        //Assert.assertEquals("线上化", result.getData().getBizTypeList().get(1).getDesc());

        Assert.assertEquals(2, result.getData().getCustomTypeList().size());
        Assert.assertEquals("station", result.getData().getCustomTypeList().get(0).getType());
        Assert.assertEquals("站点", result.getData().getCustomTypeList().get(0).getDesc());
        //Assert.assertEquals("express", result.getData().getCustomTypeList().get(1).getType());
        //Assert.assertEquals("网点", result.getData().getCustomTypeList().get(1).getDesc());

        Assert.assertEquals(2, result.getData().getLaunchTypeList().size());
        Assert.assertEquals("rule", result.getData().getLaunchTypeList().get(0).getType());
        Assert.assertEquals("规则投放", result.getData().getLaunchTypeList().get(0).getDesc());
        //Assert.assertEquals("list", result.getData().getLaunchTypeList().get(1).getType());
        //Assert.assertEquals("名单投放", result.getData().getLaunchTypeList().get(1).getDesc());
    }

    @Test
    public void testQueryIncentivePlanList() {
        // Setup, prepare mock data
        Mockito.when(policyTemplateAppService.queryIncentivePlanList(any(), any()))
            .thenReturn(buildIncentivePlanList());

        // Run the method to be tested
        CnRestResult<List<IncentivePlanVO>> result2 = policyTemplateController.queryIncentivePlanList(buildIncentivePlanQueryRequest());

        // Verify the result
        Assert.assertNotNull(result2);
        Assert.assertTrue(result2.isSuccess());
        Assert.assertEquals(2, result2.getData().size());
        Assert.assertEquals("FY26Q1规模站点基础激励", result2.getData().get(0).getPlanName());
        Assert.assertEquals("FY26Q1规模站点灵活激励", result2.getData().get(1).getPlanName());
        Assert.assertEquals("scale_sta_basic_incent_fy26q1", result2.getData().get(0).getIncentivePlanCode());
        Assert.assertEquals("scale_sta_flexible_incent_fy26q1", result2.getData().get(1).getIncentivePlanCode());
        Assert.assertEquals("基础激励", result2.getData().get(0).getPlanTitle());
        Assert.assertEquals("灵活激励", result2.getData().get(1).getPlanTitle());

        Assert.assertEquals("无人站", result2.getData().get(1).getFlexibleIncentiveContent().get(0).getStationTypeName());
        Assert.assertEquals("0.6", result2.getData().get(1).getFlexibleIncentiveContent().get(0).getValueList().get(0));
        Assert.assertEquals("0.8", result2.getData().get(1).getFlexibleIncentiveContent().get(0).getValueList().get(1));
        Assert.assertEquals("1.0", result2.getData().get(1).getFlexibleIncentiveContent().get(0).getValueList().get(2));
        Assert.assertEquals("1.2", result2.getData().get(1).getFlexibleIncentiveContent().get(0).getValueList().get(3));

        Assert.assertEquals("灯条站", result2.getData().get(1).getFlexibleIncentiveContent().get(1).getStationTypeName());
        Assert.assertEquals("0.6", result2.getData().get(1).getFlexibleIncentiveContent().get(1).getValueList().get(0));
        Assert.assertEquals("0.8", result2.getData().get(1).getFlexibleIncentiveContent().get(1).getValueList().get(1));
        Assert.assertEquals("1.0", result2.getData().get(1).getFlexibleIncentiveContent().get(1).getValueList().get(2));
        Assert.assertEquals("1.2", result2.getData().get(1).getFlexibleIncentiveContent().get(1).getValueList().get(3));

        Assert.assertEquals("普通站", result2.getData().get(1).getFlexibleIncentiveContent().get(2).getStationTypeName());
        Assert.assertEquals("0.6", result2.getData().get(1).getFlexibleIncentiveContent().get(2).getValueList().get(0));
        Assert.assertEquals("0.8", result2.getData().get(1).getFlexibleIncentiveContent().get(2).getValueList().get(1));
        Assert.assertEquals("1.0", result2.getData().get(1).getFlexibleIncentiveContent().get(2).getValueList().get(2));
        Assert.assertEquals("1.2", result2.getData().get(1).getFlexibleIncentiveContent().get(2).getValueList().get(3));
    }

    /**
     * 规则投放
     */
    private PolicyTemplateCreateRequest buildCreateRequest_rule() {
        String str
            = "{\"templateName\":\"FY26规模站点政策2\",\"customType\":\"station\",\"bizType\":\"scale\",\"startTimeStr\":\"2025-06-01\",\"endTimeStr\":\"2025-06-30\",\"incentivePlanTypeList\":[\"scale_sta_flexible_incent_fy26q1\",\"scale_sta_basic_incent_fy26q1\"],\"launchPlan\":{\"launchType\":\"rule\",\"areaRuleLaunch\":{\"provinceCodeList\":[\"1\",\"2\"],\"cityCodeList\":[\"3\",\"4\"],\"districtCodeList\":[\"5\",\"6\"]}}}";
        return JSON.parseObject(str, PolicyTemplateCreateRequest.class);
    }

    /**
     * 全国投放
     */
    private PolicyTemplateCreateRequest buildCreateRequest_national() {
        String str
            = "{\"templateName\":\"FY26规模站点政策2\",\"customType\":\"station\",\"bizType\":\"scale\",\"startTimeStr\":\"2025-06-01\",\"endTimeStr\":\"2025-06-30\",\"incentivePlanTypeList\":[\"scale_sta_flexible_incent_fy26q1\",\"scale_sta_basic_incent_fy26q1\"],\"launchPlan\":{\"launchType\":\"rule\",\"areaRuleLaunch\":{\"national\":true}}}";
        return JSON.parseObject(str, PolicyTemplateCreateRequest.class);
    }

    /**
     * 名单投放
     */
    private PolicyTemplateCreateRequest buildCreateRequest_list() {
        String str
            = "{\"templateName\":\"FY26规模站点政策2\",\"customType\":\"station\",\"bizType\":\"scale\",\"startTimeStr\":\"2025-06-01\",\"endTimeStr\":\"2025-06-30\",\"incentivePlanTypeList\":[\"scale_sta_flexible_incent_fy26q1\",\"scale_sta_basic_incent_fy26q1\"],\"launchPlan\":{\"launchType\":\"list\",\"entityAttrCode\":\"sign_protocol\",\"tagCodeList\":[\"code1\",\"code2\"]}}";
        return JSON.parseObject(str, PolicyTemplateCreateRequest.class);
    }

    /**
     * 激励方案
     */
    private List<IncentivePlanDTO> buildIncentivePlanList() {
        String str
            = "[{\"content\":{\"coefficient\":[{\"code\":\"basic\",\"frame\":{\"result\":[{\"code\":\"basic\",\"name\":\"默认\",\"val\":\"1\"}]},\"name\":\"默认系数\"}],\"selectPlan\":{\"areaSelectPlan\":{\"national\":true}}},\"incentivePlanType\":\"basic\",\"incentivePlanCode\":\"scale_sta_basic_incent_fy26q1\",\"planName\":\"FY26Q1规模站点基础激励\"},{\"content\":{\"coefficient\":[{\"code\":\"basic\",\"frame\":{\"children\":[{\"arithLogic\":\"=\",\"factorCode\":\"stationType\",\"factorName\":\"站点类型\",\"factorResult\":{\"fixedVal\":\"non_station\",\"type\":\"fixed\"},\"incentiveFactorLimit\":{\"canUpdate\":false},\"result\":[{\"code\":\"basic\",\"name\":\"默认\",\"resultLimit\":{\"canUpdate\":true,\"limitType\":\"option\",\"optionLimit\":{\"optionList\":[\"0.6\",\"0.8\",\"1.0\",\"1.2\"]}}}]},{\"arithLogic\":\"=\",\"factorCode\":\"stationType\",\"factorName\":\"站点类型\",\"factorResult\":{\"fixedVal\":\"light_station\",\"type\":\"fixed\"},\"incentiveFactorLimit\":{\"canUpdate\":false},\"result\":[{\"code\":\"basic\",\"name\":\"默认\",\"resultLimit\":{\"canUpdate\":true,\"limitType\":\"option\",\"optionLimit\":{\"optionList\":[\"0.6\",\"0.8\",\"1.0\",\"1.2\"]}}}]},{\"arithLogic\":\"=\",\"factorCode\":\"stationType\",\"factorName\":\"站点类型\",\"factorResult\":{\"fixedVal\":\"normal_station\",\"type\":\"fixed\"},\"incentiveFactorLimit\":{\"canUpdate\":false},\"result\":[{\"code\":\"basic\",\"name\":\"默认\",\"resultLimit\":{\"canUpdate\":true,\"limitType\":\"option\",\"optionLimit\":{\"optionList\":[\"0.6\",\"0.8\",\"1.0\",\"1.2\"]}}}]}]},\"name\":\"默认系数\"}],\"selectPlan\":{\"areaSelectPlan\":{\"national\":true}}},\"incentivePlanType\":\"flexible\",\"incentivePlanCode\":\"scale_sta_flexible_incent_fy26q1\",\"planName\":\"FY26Q1规模站点灵活激励\"}]";
        return JSON.parseArray(str, IncentivePlanDTO.class);
    }

    private List<PolicyTemplateDTO> buildPolicyTemplateList() {
        List<IncentivePlanDTO> incentivePlanDTOList = buildIncentivePlanList();
        PolicyTemplateDTO policyTemplateDTO1 = new PolicyTemplateDTO();
        policyTemplateDTO1.setId(1L);
        policyTemplateDTO1.setTemplateName("FY26规模站点政策");
        policyTemplateDTO1.setIncentivePlanList(incentivePlanDTOList);
        policyTemplateDTO1.setGmtCreate(LocalDateTime.now());
        policyTemplateDTO1.setGmtModified(LocalDateTime.now());
        policyTemplateDTO1.setStartTime(DateUtils.toLocalDateTimeYmdhms("2025-05-01 12:00:00"));
        policyTemplateDTO1.setEndTime(DateUtils.toLocalDateTimeYmdhms("2025-06-01 12:00:00"));
        policyTemplateDTO1.setCustomType("station");
        policyTemplateDTO1.setBizType("scale");
        policyTemplateDTO1.setStatus((byte)0);
        policyTemplateDTO1.setApprovalStatus((byte)1);
        policyTemplateDTO1.setVersion(1L);
        policyTemplateDTO1.setLastOperatorId(1L);
        policyTemplateDTO1.setApprovalFollowId(1L);
        policyTemplateDTO1.setLaunchPlan(launchPlanDTO_list());
        return Arrays.asList(policyTemplateDTO1);
    }

    private LaunchPlanDTO launchPlanDTO_list() {
        LaunchPlanDTO launchPlanDTO = new LaunchPlanDTO();
        launchPlanDTO.setLaunchType("list");
        ListLaunchDTO listLaunchDTO = new ListLaunchDTO();
        ListItemLaunchDTO listItemLaunchDTO = new ListItemLaunchDTO();
        listItemLaunchDTO.setType("station");
        listItemLaunchDTO.setAttrCode("staCode");
        listItemLaunchDTO.setAttrValue("code1");
        listLaunchDTO.setItemLaunch(Arrays.asList(listItemLaunchDTO));
        launchPlanDTO.setListLaunch(listLaunchDTO);
        return launchPlanDTO;
    }

    private PolicyTemplateIncentiveQueryRequest buildIncentivePlanQueryRequest() {
        String str
            = "{\"customType\":\"station\",\"bizType\":\"scale\",\"outIncentiveType\":\"scale_sta_basic_incent_fy26q1\",\"expenseItemCode\":\"scale_sta_basic_incent_fy26q1\",\"startTimeStr\":\"2025-06-01\",\"endTimeStr\":\"2025-07-01\"}";
        return JSON.parseObject(str, PolicyTemplateIncentiveQueryRequest.class);
    }

    @Test
    public void testDelete() {
        // Prepare method arguments
        PolicyTemplateDeleteRequest policyTemplateDeleteRequest = new PolicyTemplateDeleteRequest();
        policyTemplateDeleteRequest.setDeleteReason("test");
        policyTemplateDeleteRequest.setId(1L);
        // Run the method to be tested
        CnRestResult<Void> result = policyTemplateController.delete(policyTemplateDeleteRequest);

        // Verify the result
    }

    @Test
    public void test() {
        System.out.println(System.currentTimeMillis());
    }

    @Test
    public void testQueryIncentiveExpenseItemList() {
        List<PolicyIncentiveExpenseItemDTO> policyIncentiveExpenseItemDTOList = new ArrayList<>();
        PolicyIncentiveExpenseItemDTO policyIncentiveExpenseItemDTO = new PolicyIncentiveExpenseItemDTO();
        policyIncentiveExpenseItemDTO.setExpenseItemName("expenseItemName");
        policyIncentiveExpenseItemDTO.setExpenseItemCode("expenseItemCode");
        policyIncentiveExpenseItemDTOList.add(policyIncentiveExpenseItemDTO);
        // Setup, prepare mock data
        Mockito.when(policyTemplateAppService.queryIncentiveExpenseItemList(any(), any()))
            .thenReturn(policyIncentiveExpenseItemDTOList);

        IncentiveExpenseItemQueryRequest incentiveExpenseItemQueryRequest = new IncentiveExpenseItemQueryRequest();
        incentiveExpenseItemQueryRequest.setBizType("bizType");
        incentiveExpenseItemQueryRequest.setCustomType("customType");
        incentiveExpenseItemQueryRequest.setIncentivePlanType("incentivePlanType");
        incentiveExpenseItemQueryRequest.setStartTimeStr("2020-06-01");
        incentiveExpenseItemQueryRequest.setEndTimeStr("2020-06-30");
        // Run the method to be tested
        CnRestResult<List<IncentiveExpenseItemVO>> result = policyTemplateController.queryIncentiveExpenseItemList(incentiveExpenseItemQueryRequest);

        // Verify the result
        Assert.assertNotNull(result);
        Assert.assertEquals(1, result.getData().size());
        Assert.assertEquals("expenseItemName", result.getData().get(0).getExpenseItemName());
        Assert.assertEquals("expenseItemCode", result.getData().get(0).getExpenseItemCode());
    }

    @Test
    public void testQueryIncentiveExpenseItem(){
        List<IncentivePlanDTO> incentivePlanDTOList = new ArrayList<>();
        IncentivePlanDTO incentivePlanDTO = new IncentivePlanDTO();
        incentivePlanDTO.setIncentivePlanCode("incentivePlanCode");
        incentivePlanDTOList.add(incentivePlanDTO);
        // Setup, prepare mock data
        Mockito.when(policyTemplateAppService.queryIncentivePlanList(any(), any()))
            .thenReturn(incentivePlanDTOList);

        // Prepare method arguments
        PolicyTemplateIncentiveQueryRequest policyTemplateIncentiveQueryRequest = new PolicyTemplateIncentiveQueryRequest();
        policyTemplateIncentiveQueryRequest.setExpenseItemCode("expenseItemCode");
        policyTemplateIncentiveQueryRequest.setCustomType("customType");
        policyTemplateIncentiveQueryRequest.setBizType("bizType");
        policyTemplateIncentiveQueryRequest.setStartTimeStr("2020-06-01");
        policyTemplateIncentiveQueryRequest.setEndTimeStr("2020-06-30");
        // Run the method to be tested
        CnRestResult<IncentivePlanVO> result = policyTemplateController.queryIncentiveExpenseItem(policyTemplateIncentiveQueryRequest);

        // Verify the result
        Assert.assertNotNull(result);
        Assert.assertEquals("incentivePlanCode", result.getData().getIncentivePlanCode());
    }
}