package com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan;

import java.util.Arrays;

import com.base.BaseTest;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.IncentivePlanContentDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.IncentivePlanFrameDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.IncentivePlanResultDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.select.AreaSelectPlanDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.select.SelectPlanDTO;
import org.junit.Before;
import org.junit.Test;
import org.mockito.MockitoAnnotations;

/**
 * <a href="https://alidocs.dingtalk.com/i/nodes/dpYLaezmVNRMGX56C1aKjlBOVrMqPxX6">单元测试编写&生成FAQ</a>
 * Created By Thub IDEA插件
 *
 * @Date 2025/6/4 16:52
 */
public class IncentivePlanResultDTOTest extends BaseTest {

    @Before
    public void setUp() throws Exception {MockitoAnnotations.openMocks(this);}

    @Test
    public void testValidate() {
        IncentivePlanContentDTO incentivePlanContentDTO = new IncentivePlanContentDTO();
        SelectPlanDTO selectPlanDTO = new SelectPlanDTO();
        AreaSelectPlanDTO areaSelectPlanDTO = new AreaSelectPlanDTO();
        areaSelectPlanDTO.setNational(true);
        selectPlanDTO.setAreaSelectPlan(areaSelectPlanDTO);
        incentivePlanContentDTO.setSelectPlan(selectPlanDTO);
        IncentivePlanFrameDTO incentivePlanFrameDTO = new IncentivePlanFrameDTO();
        IncentivePlanResultDTO incentivePlanResultDTO = new IncentivePlanResultDTO();
        incentivePlanResultDTO.setCode("code");
        incentivePlanResultDTO.setName("name");
        incentivePlanFrameDTO.setResult(Arrays.asList(incentivePlanResultDTO));
        incentivePlanContentDTO.setPrice(incentivePlanFrameDTO);
        incentivePlanContentDTO.validate();
    }
}