package com.cainiao.tp.nm.plan.policy.application.extension.definition;

import com.alibaba.fastjson.JSONObject;
import com.cainiao.tp.nm.plan.api.policy.application.dto.BaseDivisionInfoDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.ExcelHead;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyInstanceRuleDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.TpExportHeadHolder;
import com.cainiao.tp.nm.plan.api.policy.application.dto.base.BaseTableDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.base.ColumnDTO;
import com.cainiao.tp.nm.plan.infra.port.policy.DivisionManager;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.mockito.Mockito.anyLong;


@RunWith(MockitoJUnitRunner.class)
public class ScaleMainTableDashboardTransformTest {

    @InjectMocks
    private ScaleMainTableDashboardTransform scaleMainTableDashboardTransform;
    @Mock
    private DivisionManager divisionManager;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);
    }

    private final String ruleDTOList = "[{\"approvalStatus\":2,\"launchObject\":\"{\\\"areaSelectRule\\\":{\\\"provinceCode\\\":\\\"330000\\\",\\\"cityCode\\\":\\\"330100\\\",\\\"districtCode\\\":\\\"330110\\\"}}\",\"gmtModified\":\"2025-06-10T16:38:08\",\"bizType\":\"scale\",\"districtCode\":\"330110\",\"provinceCode\":\"330000\",\"cityCode\":\"330100\",\"templateId\":1,\"incentivePlanType\":\"flexible\",\"priority\":4000250606,\"gmtCreate\":\"2025-06-06T11:17:28\",\"loseEffectTime\":\"2025-04-01T00:00:00\",\"ruleContent\":\"{\\\"coefficient\\\":[{\\\"code\\\":\\\"basic\\\",\\\"name\\\":\\\"基础系数\\\",\\\"frame\\\":{\\\"children\\\":[{\\\"factorCode\\\":\\\"stationType\\\",\\\"arithLogic\\\":\\\"=\\\",\\\"factorResult\\\":{\\\"type\\\":\\\"fixed\\\",\\\"fixedVal\\\":\\\"non_station\\\"},\\\"result\\\":[{\\\"code\\\":\\\"basic\\\",\\\"name\\\":\\\"基础系数\\\",\\\"val\\\":\\\"0.6\\\"}]},{\\\"factorCode\\\":\\\"stationType\\\",\\\"arithLogic\\\":\\\"=\\\",\\\"factorResult\\\":{\\\"type\\\":\\\"fixed\\\",\\\"fixedVal\\\":\\\"light_station\\\"},\\\"result\\\":[{\\\"code\\\":\\\"basic\\\",\\\"name\\\":\\\"基础系数\\\",\\\"val\\\":\\\"0.8\\\"}]},{\\\"factorCode\\\":\\\"stationType\\\",\\\"arithLogic\\\":\\\"=\\\",\\\"factorResult\\\":{\\\"type\\\":\\\"fixed\\\",\\\"fixedVal\\\":\\\"normal_station\\\"},\\\"result\\\":[{\\\"code\\\":\\\"basic\\\",\\\"name\\\":\\\"基础系数\\\",\\\"val\\\":\\\"1.0\\\"}]}]}}]}\",\"customType\":\"station\",\"instanceId\":1,\"isDeleted\":0,\"startTime\":\"2025-04-01T00:00:00\",\"id\":1,\"endTime\":\"2025-06-30T23:59:59\",\"effectTime\":\"2025-04-01T00:00:00\",\"status\":1}]";

    private final String divisionList = "{\"divisionLevel\":2,\"latitude\":0,\"divisionName\":\"浙江省\",\"divisionId\":330000,\"childrenList\":[{\"divisionLevel\":3,\"latitude\":0,\"divisionName\":\"杭州市\",\"divisionId\":330100,\"childrenList\":[{\"divisionLevel\":4,\"latitude\":0,\"divisionName\":\"余杭区\",\"divisionId\":330110,\"longitude\":0}],\"longitude\":0}],\"longitude\":0}";
    @Test
    public void testTransform() {
        List<PolicyInstanceRuleDTO> dtoList = JSONObject.parseArray(ruleDTOList, PolicyInstanceRuleDTO.class);
        BaseDivisionInfoDTO baseDivisionInfoDTO = JSONObject.parseObject(divisionList, BaseDivisionInfoDTO.class);
        Mockito.when(divisionManager.getProvinceByCode(anyLong())).thenReturn(Optional.ofNullable(baseDivisionInfoDTO));
        BaseTableDTO result = scaleMainTableDashboardTransform.transform(dtoList);
        Assert.assertNotNull(result);
    }

    @Test
    public void testBuildRuleColumn() {
        TpExportHeadHolder newTpExportHeadHolder=new TpExportHeadHolder();
        ExcelHead excelHead=new ExcelHead();
        excelHead.setIndex(0);
        excelHead.setHeadName("23");
        excelHead.setFieldKey("testCode");
        excelHead.setHeadDesc("");
        excelHead.setQlExpression("");
        Map<String, List<ExcelHead>> headConfig= Maps.newHashMap();
        headConfig.put("ScaleStationExport", Lists.newArrayList(excelHead));
        newTpExportHeadHolder.setHeadConfig(headConfig);
        TpExportHeadHolder.setINSTANCE(newTpExportHeadHolder);

        String customType = "station";
        // 调用方法
        List<ColumnDTO> result = scaleMainTableDashboardTransform.buildRuleColumn(customType);
        System.out.println(result);

        // 由于mock对象无法保证真实调用，verify语句进行行注释避免执行
        // verify(tpExportHeadHolder, times(1)).getHead(anyString());
    }

    @Test
    public void testBuildRuleColumn2() {
        TpExportHeadHolder newTpExportHeadHolder=new TpExportHeadHolder();
        ExcelHead excelHead=new ExcelHead();
        excelHead.setIndex(0);
        excelHead.setHeadName("23");
        excelHead.setFieldKey("testCode");
        excelHead.setHeadDesc("");
        excelHead.setQlExpression("");
        Map<String, List<ExcelHead>> headConfig= Maps.newHashMap();
        headConfig.put("ScaleExpressExport", Lists.newArrayList(excelHead));
        newTpExportHeadHolder.setHeadConfig(headConfig);
        TpExportHeadHolder.setINSTANCE(newTpExportHeadHolder);

        String customType = "express";
        // 调用方法
        List<ColumnDTO> result = scaleMainTableDashboardTransform.buildRuleColumn(customType);
        System.out.println(result);

        // 由于mock对象无法保证真实调用，verify语句进行行注释避免执行
        // verify(tpExportHeadHolder, times(1)).getHead(anyString());
    }
}