package com.cainiao.tp.nm.plan.policy.application.service.impl;

import com.alibaba.fastjson.JSON;
import com.base.BaseTest;
import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.aladdin.operation.CNUserOperation;
import com.cainiao.sutee.commons.base.model.CnPage;
import com.cainiao.sutee.commons.base.model.Page;
import com.cainiao.tp.nm.plan.api.policy.adaptor.dto.param.PolicyTemplateQueryRequest;
import com.cainiao.tp.nm.plan.api.policy.application.dto.PolicyTemplateDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.PolicyIncentiveExpenseItemDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.IncentivePlanContentDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.incentiveplan.IncentivePlanDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.IncentiveExpenseItemQueryParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.IncentivePlanQueryParam;
import com.cainiao.tp.nm.plan.api.policy.application.dto.param.PolicyTemplateCreateParam;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyConfigManager;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyIncentiveTemplateConfigManager;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyTairLockManager;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyTemplateQueryManager;
import com.cainiao.tp.nm.plan.policy.adaptor.component.rights.RightsControlContext;
import com.cainiao.tp.nm.plan.policy.adaptor.component.rights.RightsControlUtils;
import com.cainiao.tp.nm.plan.policy.application.service.PolicyTemplateAppServiceImpl;
import com.cainiao.tp.nm.plan.policy.domain.model.PolicyTemplate;
import com.cainiao.tp.nm.plan.policy.domain.repository.PolicyInstanceRepository;
import com.cainiao.tp.nm.plan.policy.domain.repository.PolicyTemplateRepository;
import com.cainiao.tp.nm.plan.policy.domain.service.PolicyTemplateDomainService;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.*;

/**
 * <a href="https://alidocs.dingtalk.com/i/nodes/dpYLaezmVNRMGX56C1aKjlBOVrMqPxX6">单元测试编写&生成FAQ</a>
 * Created By Thub IDEA插件
 *
 * @Date 2025/6/9 17:24
 */
@RunWith(MockitoJUnitRunner.class)
public class PolicyTemplateAppServiceImplTest extends BaseTest {

    @InjectMocks
    private PolicyTemplateAppServiceImpl policyTemplateAppServiceImpl;
    @Mock
    private PolicyTairLockManager policyTairLockManager;
    @Mock
    private PolicyConfigManager policyConfigManager;
    @Mock
    private PolicyTemplateRepository policyTemplateRepository;
    @Mock
    private PolicyTemplateQueryManager policyTemplateQueryManager;
    private MockedStatic<RightsControlUtils> rightsControlUtilsMockedStatic;
    @Mock
    private PolicyIncentiveTemplateConfigManager policyIncentiveTemplateConfigManager;
    @InjectMocks
    private PolicyTemplateAppServiceImpl policyTemplateAppService;
    @Mock
    private PolicyInstanceRepository policyInstanceRepository;
    @Mock
    private PolicyTemplateDomainService policyTemplateDomainService;


    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);
        rightsControlUtilsMockedStatic = Mockito.mockStatic(RightsControlUtils.class);
        RightsControlContext rightsControlContext = RightsControlContext.builder().hasCnRights(true).hasRoleRights(true).build();
        rightsControlUtilsMockedStatic.when(RightsControlUtils::get).thenReturn(rightsControlContext);
    }

    @After
    public void tearDown() throws Exception {
        if (rightsControlUtilsMockedStatic != null) {
            rightsControlUtilsMockedStatic.close();
        }
    }

    @Test
    public void testQueryPolicyTemplateList() {
        List<PolicyTemplate> policyTemplateList = new ArrayList<>();
        PolicyTemplate policyTemplate = PolicyTemplate.builder().id(1L).build();
        policyTemplateList.add(policyTemplate);
        Page<PolicyTemplate> listPageResult = CnPage.of(1, 20, policyTemplateList, 1L);
        // Setup, prepare mock data
        Mockito.when(policyTemplateRepository.selectPage(any()))
                .thenReturn(listPageResult);

        // Prepare method arguments

        // Run the method to be tested
        Page<PolicyTemplateDTO> result = policyTemplateAppServiceImpl.queryPolicyTemplateList(new PolicyTemplateQueryRequest(), null);

        // Verify the result
        Assert.assertNotNull(result);
        Assert.assertEquals(1, result.getPageNum());
        Assert.assertEquals(20, result.getPageSize());
        Assert.assertEquals(1, result.getPageTotal());
    }

    @Test
    public void testQueryIncentivePlanList() {
        List<IncentivePlanDTO> incentivePlanDTOList = new ArrayList<>();
        // Setup, prepare mock data
        Mockito.when(policyTemplateQueryManager.queryIncentivePlanFromOutBiz(any()))
                .thenReturn(incentivePlanDTOList);

        // Prepare method arguments

        // Run the method to be tested
        IncentivePlanQueryParam param = new IncentivePlanQueryParam();
        param.setCustomType("customType");
        param.setBizType("bizType");
        param.setEndTime(LocalDateTime.now());
        param.setStartTime(LocalDateTime.now());
        param.setOutIncentiveTypeList(Arrays.asList("scale_sta_flexible_incent_fy26q1", "scale_sta_basic_incent_fy26q1"));
        List<IncentivePlanDTO> result = policyTemplateAppServiceImpl.queryIncentivePlanList(param, null);

        // Verify the result
        Assert.assertNotNull(result);
    }

    @Test
    public void testCreate() {
        PolicyTemplateCreateParam param = buildCreateParamRule();
        param.setStartTimeStr("2025-06-01T00:00:00");
        param.setEndTimeStr("2025-06-30T23:59:59");
        // Run the method to be tested
        AbstractOperation operation = new CNUserOperation(1L, "test");
        IncentivePlanDTO incentivePlanDTO = new IncentivePlanDTO();
        incentivePlanDTO.setContent(buildBasicContent());
        when(policyIncentiveTemplateConfigManager.getIncentivePlanTemplate(any(), any(), any(), any(), any(), any())).thenReturn(incentivePlanDTO);
        PolicyTemplate policyTemplate = mock(PolicyTemplate.class);
        when(policyTemplateDomainService.createTemplate(param)).thenReturn(policyTemplate);
        policyTemplateAppServiceImpl.create(param, operation);

    }

    /**
     * 全国投放
     */
    private PolicyTemplateCreateParam buildCreateParamRule() {
        String str
                = "{\"bizType\":\"scale\",\"customType\":\"station\",\"endTime\":\"2025-06-30T23:59:59\",\"incentivePlanList\":[{\"incentivePlanCode\":\"scale_sta_basic_incent_fy26q1\",\"incentivePlanType\":\"basic\",\"planName\":\"FY26Q1规模站点基础激励\"},{\"incentivePlanCode\":\"scale_sta_flexible_incent_fy26q1\",\"incentivePlanType\":\"flexible\",\"planName\":\"FY26Q1规模站点灵活激励\"}],\"launchPlan\":{\"launchType\":\"rule\",\"ruleLaunch\":{\"areaRuleLaunch\":{\"national\":true}}},\"operatorId\":1,\"startTime\":\"2025-06-01T00:00:00\",\"templateName\":\"FY26规模站点政策2\"}";
        return JSON.parseObject(str, PolicyTemplateCreateParam.class);
    }

    private IncentivePlanContentDTO buildBasicContent() {
        String str = "{\"selectPlan\":{\"areaSelectPlan\":{\"national\":true}},\"coefficient\":[{\"code\":\"basic\",\"name\":\"默认系数\",\"frame\":{\"result\":[{\"code\":\"basic\",\"name\":\"默认\",\"val\":\"1.0\",\"resultLimit\":{\"canUpdate\":false}}]}}]}";
        return JSON.parseObject(str, IncentivePlanContentDTO.class);
    }

    private IncentivePlanContentDTO buildFlexibleContent() {
        String str = "{\"selectPlan\":{\"areaSelectPlan\":{\"national\":true}},\"coefficient\":[{\"code\":\"basic\",\"name\":\"默认系数\",\"frame\":{\"children\":[{\"factorCode\":\"stationType\",\"factorName\":\"站点类型\",\"arithLogic\":\"=\",\"incentiveFactorLimit\":{\"canUpdate\":false},\"factorResult\":{\"type\":\"fixed\",\"fixedVal\":\"non_station\"},\"result\":[{\"code\":\"basic\",\"name\":\"默认\",\"resultFillCode\":\"non_station\",\"resultLimit\":{\"limitType\":\"option\",\"optionLimit\":{\"optionList\":[\"0.6\",\"0.8\",\"1.0\",\"1.2\"]},\"canUpdate\":true}}]},{\"factorCode\":\"stationType\",\"factorName\":\"站点类型\",\"arithLogic\":\"=\",\"incentiveFactorLimit\":{\"canUpdate\":false},\"factorResult\":{\"type\":\"fixed\",\"fixedVal\":\"light_station\"},\"result\":[{\"code\":\"basic\",\"name\":\"默认\",\"resultFillCode\":\"light_station\",\"resultLimit\":{\"limitType\":\"option\",\"optionLimit\":{\"optionList\":[\"0.6\",\"0.8\",\"1.0\",\"1.2\"]},\"canUpdate\":true}}]},{\"factorCode\":\"stationType\",\"factorName\":\"站点类型\",\"arithLogic\":\"=\",\"incentiveFactorLimit\":{\"canUpdate\":false},\"factorResult\":{\"type\":\"fixed\",\"fixedVal\":\"normal_station\"},\"result\":[{\"code\":\"basic\",\"name\":\"默认\",\"resultFillCode\":\"normal_station\",\"resultLimit\":{\"limitType\":\"option\",\"optionLimit\":{\"optionList\":[\"0.6\",\"0.8\",\"1.0\",\"1.2\"]},\"canUpdate\":true}}]}]}}]}";
        return JSON.parseObject(str, IncentivePlanContentDTO.class);
    }


    @Test
    public void testQueryIncentiveExpenseItemList(){
        List<PolicyIncentiveExpenseItemDTO> policyIncentiveExpenseItemDTOList = new ArrayList<>();
        PolicyIncentiveExpenseItemDTO policyIncentiveExpenseItemDTO = new PolicyIncentiveExpenseItemDTO();
        policyIncentiveExpenseItemDTO.setExpenseItemName("expenseItemName");
        policyIncentiveExpenseItemDTO.setExpenseItemCode("expenseItemCode");
        policyIncentiveExpenseItemDTOList.add(policyIncentiveExpenseItemDTO);
        // Setup, prepare mock data
        when(policyTemplateQueryManager.queryIncentiveExpenseItemList(any()))
            .thenReturn(policyIncentiveExpenseItemDTOList);

        // Prepare method arguments
        IncentiveExpenseItemQueryParam incentiveExpenseItemQueryParam = new IncentiveExpenseItemQueryParam();
        incentiveExpenseItemQueryParam.setBizType("bizType");
        incentiveExpenseItemQueryParam.setCustomType("customType");
        incentiveExpenseItemQueryParam.setIncentivePlanType("incentivePlanType");

        incentiveExpenseItemQueryParam.setStartTime(LocalDateTime.now());
        incentiveExpenseItemQueryParam.setEndTime(LocalDateTime.now());
        // Run the method to be tested
        List<PolicyIncentiveExpenseItemDTO> result = policyTemplateAppServiceImpl.queryIncentiveExpenseItemList(incentiveExpenseItemQueryParam,
            null);

        Assert.assertNotNull(result);
        Assert.assertEquals(1, result.size());
        Assert.assertEquals("expenseItemName", result.get(0).getExpenseItemName());
        Assert.assertEquals("expenseItemCode", result.get(0).getExpenseItemCode());
        // Verify the result
    }

}