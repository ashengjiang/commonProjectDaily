package com.cainiao.tp.nm.plan.policy.application.convert;
import com.alibaba.fastjson.JSONObject;
import com.cainiao.tp.nm.plan.api.policy.application.dto.StationIncentivePageConfigHolder;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.StationIncentiveBillDetailDTO;
import com.google.common.collect.Lists;

import com.cainiao.tp.nm.plan.api.policy.application.dto.station.heavy.IncentiveCardDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.station.heavy.IncentiveTipDTO;
import com.google.common.collect.Maps;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

@RunWith(MockitoJUnitRunner.class)
public class StationIncentivePageDataConvertTest {
    private final String detailList = "[{\"billTime\":\"2025-04-30 00:00:00\",\"firstOver100ArrCnt\":\"501\",\"statsMonthBqArrRate\":\"0.9982279500604108\",\"noSatisfyBaseReason\":\"\",\"statsMonthBqArrCnt\":\"12393\",\"cycleRange\":\"20250401~20250430\",\"chargeOffBillTime\":\"2025-05-22 16:13:17\",\"ds\":\"2025-07-10\",\"stationSubType\":\"社区专业点\",\"checkStartMonth\":\"202504\",\"entryOperateTime\":\"2025-04-15 00:00:00\",\"statsMonthAvgVaildArrCnt\":\"413.8333333333333\",\"stationId\":\"1094379\",\"isCollectionPointTransfer\":true,\"isExpressEst\":false,\"noSatisfyReason\":\"\",\"amountCent\":\"40000\",\"isRiskStation\":false,\"checkStartDate\":\"20250401\",\"firstOver100ArrDate\":\"20250401\",\"isParticipateCpEstSta\":false,\"cycleNum\":\"1\",\"isDecorationPass\":true,\"isLightStationNew\":false,\"isQuit\":false,\"stationCode\":\"V5326297\",\"staStatusName\":\"运营中\",\"isStationChanged\":false,\"staSoftStatus\":\"运营期\",\"statsMonthGpyPickupRate\":\"0.9749152542372881\",\"statsRange\":\"20250401~20250430\",\"isApplyQuit\":false,\"statsMonthPickupCnt\":\"11800\",\"statsMonthVaildArrDays\":\"30\",\"isBlackStation\":false,\"stationName\":\"青岛适园雅居12号楼店\",\"isUnmannedStation\":false,\"statsMonthArrCnt\":\"12415\",\"isScanExpressSettleIn\":false,\"marginedTime\":\"2025-04-01 08:18:15\",\"isBlankAoiEst\":false,\"statsMonthGpyPickupCnt\":\"11504\",\"incentivePlanType\":\"base\",\"dispatchStatus\":\"has_chargeoff\",\"isCountrySideTransfer\":false,\"statsMonth\":\"202504\",\"stationMode\":\"heavy\",\"isSatisfied\":true,\"activityType\":\"STATION_ACTIVITY\",\"isReverseStationEst\":true,\"isSatisfyBaseCondition\":true},{\"billTime\":\"2025-04-30 00:00:00\",\"firstOver100ArrCnt\":\"501\",\"statsMonthBqArrRate\":\"0.9982279500604108\",\"noSatisfyBaseReason\":\"\",\"statsMonthBqArrCnt\":\"12393\",\"cycleRange\":\"20250401~20250430\",\"chargeOffBillTime\":\"2025-05-27 14:30:19\",\"ds\":\"2025-07-10\",\"stationSubType\":\"社区专业点\",\"checkStartMonth\":\"202504\",\"entryOperateTime\":\"2025-04-15 00:00:00\",\"statsMonthAvgVaildArrCnt\":\"413.8333333333333\",\"stationId\":\"1094379\",\"isCollectionPointTransfer\":true,\"isExpressEst\":false,\"noSatisfyReason\":\"\",\"amountCent\":\"56000\",\"isRiskStation\":false,\"checkStartDate\":\"20250401\",\"firstOver100ArrDate\":\"20250401\",\"isParticipateCpEstSta\":false,\"cycleNum\":\"1\",\"isDecorationPass\":true,\"coefficient\":\"1.4\",\"isLightStationNew\":false,\"isQuit\":false,\"stationCode\":\"V5326297\",\"staStatusName\":\"运营中\",\"isStationChanged\":false,\"staSoftStatus\":\"运营期\",\"statsMonthGpyPickupRate\":\"0.9749152542372881\",\"statsRange\":\"20250401~20250430\",\"isApplyQuit\":false,\"statsMonthPickupCnt\":\"11800\",\"statsMonthVaildArrDays\":\"30\",\"isBlackStation\":false,\"stationName\":\"青岛适园雅居12号楼店\",\"isUnmannedStation\":false,\"statsMonthArrCnt\":\"12415\",\"isScanExpressSettleIn\":false,\"marginedTime\":\"2025-04-01 08:18:15\",\"isBlankAoiEst\":false,\"statsMonthGpyPickupCnt\":\"11504\",\"incentivePlanType\":\"flexible\",\"dispatchStatus\":\"has_chargeoff\",\"isCountrySideTransfer\":false,\"statsMonth\":\"202504\",\"stationMode\":\"heavy\",\"isSatisfied\":true,\"activityType\":\"STATION_ACTIVITY\",\"isReverseStationEst\":true,\"isSatisfyBaseCondition\":true},{\"billTime\":\"2025-04-30 00:00:00\",\"firstOver100ArrCnt\":\"501\",\"statsMonthBqArrRate\":\"0.999909412084428\",\"noSatisfyBaseReason\":\"\",\"statsMonthBqArrCnt\":\"11038\",\"cycleRange\":\"20250501~20250531\",\"chargeOffBillTime\":\"2025-06-06 14:08:18\",\"ds\":\"2025-07-10\",\"stationSubType\":\"社区专业点\",\"checkStartMonth\":\"202504\",\"entryOperateTime\":\"2025-04-15 00:00:00\",\"statsMonthAvgVaildArrCnt\":\"356.0967741935484\",\"stationId\":\"1094379\",\"isCollectionPointTransfer\":true,\"isExpressEst\":false,\"noSatisfyReason\":\"\",\"amountCent\":\"30000\",\"isRiskStation\":false,\"checkStartDate\":\"20250401\",\"firstOver100ArrDate\":\"20250401\",\"isParticipateCpEstSta\":false,\"cycleNum\":\"2\",\"isDecorationPass\":true,\"isLightStationNew\":false,\"isQuit\":false,\"stationCode\":\"V5326297\",\"staStatusName\":\"运营中\",\"isStationChanged\":false,\"staSoftStatus\":\"运营期\",\"statsMonthGpyPickupRate\":\"0.9795781399808245\",\"statsRange\":\"20250501~20250531\",\"isApplyQuit\":false,\"statsMonthPickupCnt\":\"10430\",\"statsMonthVaildArrDays\":\"31\",\"isBlackStation\":false,\"stationName\":\"青岛适园雅居12号楼店\",\"isUnmannedStation\":false,\"statsMonthArrCnt\":\"11039\",\"isScanExpressSettleIn\":false,\"marginedTime\":\"2025-04-01 08:18:15\",\"isBlankAoiEst\":false,\"statsMonthGpyPickupCnt\":\"10217\",\"incentivePlanType\":\"base\",\"dispatchStatus\":\"has_chargeoff\",\"isCountrySideTransfer\":false,\"statsMonth\":\"202505\",\"stationMode\":\"heavy\",\"isSatisfied\":true,\"activityType\":\"STATION_ACTIVITY\",\"isReverseStationEst\":true,\"isSatisfyBaseCondition\":true},{\"billTime\":\"2025-04-30 00:00:00\",\"firstOver100ArrCnt\":\"501\",\"statsMonthBqArrRate\":\"0.999909412084428\",\"noSatisfyBaseReason\":\"\",\"statsMonthBqArrCnt\":\"11038\",\"cycleRange\":\"20250501~20250531\",\"chargeOffBillTime\":\"2025-06-13 08:20:54\",\"ds\":\"2025-07-10\",\"stationSubType\":\"社区专业点\",\"checkStartMonth\":\"202504\",\"entryOperateTime\":\"2025-04-15 00:00:00\",\"statsMonthAvgVaildArrCnt\":\"356.0967741935484\",\"stationId\":\"1094379\",\"isCollectionPointTransfer\":true,\"isExpressEst\":false,\"noSatisfyReason\":\"\",\"amountCent\":\"42000\",\"isRiskStation\":false,\"checkStartDate\":\"20250401\",\"firstOver100ArrDate\":\"20250401\",\"isParticipateCpEstSta\":false,\"cycleNum\":\"2\",\"isDecorationPass\":true,\"coefficient\":\"1.4\",\"isLightStationNew\":false,\"isQuit\":false,\"stationCode\":\"V5326297\",\"staStatusName\":\"运营中\",\"isStationChanged\":false,\"staSoftStatus\":\"运营期\",\"statsMonthGpyPickupRate\":\"0.9795781399808245\",\"statsRange\":\"20250501~20250531\",\"isApplyQuit\":false,\"statsMonthPickupCnt\":\"10430\",\"statsMonthVaildArrDays\":\"31\",\"isBlackStation\":false,\"stationName\":\"青岛适园雅居12号楼店\",\"isUnmannedStation\":false,\"statsMonthArrCnt\":\"11039\",\"isScanExpressSettleIn\":false,\"marginedTime\":\"2025-04-01 08:18:15\",\"isBlankAoiEst\":false,\"statsMonthGpyPickupCnt\":\"10217\",\"incentivePlanType\":\"flexible\",\"dispatchStatus\":\"has_chargeoff\",\"isCountrySideTransfer\":false,\"statsMonth\":\"202505\",\"stationMode\":\"heavy\",\"isSatisfied\":true,\"activityType\":\"STATION_ACTIVITY\",\"isReverseStationEst\":true,\"isSatisfyBaseCondition\":true},{\"billTime\":\"2025-04-30 00:00:00\",\"firstOver100ArrCnt\":\"501\",\"statsMonthBqArrRate\":\"0.999706974018363\",\"noSatisfyBaseReason\":\"\",\"statsMonthBqArrCnt\":\"10235\",\"cycleRange\":\"20250601~20250630\",\"ds\":\"2025-07-10\",\"stationSubType\":\"社区专业点\",\"checkStartMonth\":\"202504\",\"entryOperateTime\":\"2025-04-15 00:00:00\",\"statsMonthAvgVaildArrCnt\":\"341.26666666666665\",\"stationId\":\"1094379\",\"isCollectionPointTransfer\":true,\"isExpressEst\":false,\"noSatisfyReason\":\"\",\"amountCent\":\"42000\",\"isRiskStation\":false,\"checkStartDate\":\"20250401\",\"firstOver100ArrDate\":\"20250401\",\"isParticipateCpEstSta\":false,\"cycleNum\":\"3\",\"isDecorationPass\":true,\"coefficient\":\"1.4\",\"isLightStationNew\":false,\"isQuit\":false,\"stationCode\":\"V5326297\",\"staStatusName\":\"运营中\",\"isStationChanged\":false,\"staSoftStatus\":\"运营期\",\"statsMonthGpyPickupRate\":\"0.9796669050781649\",\"statsRange\":\"20250601~20250630\",\"isApplyQuit\":false,\"statsMonthPickupCnt\":\"9787\",\"statsMonthVaildArrDays\":\"30\",\"isBlackStation\":false,\"stationName\":\"青岛适园雅居12号楼店\",\"isUnmannedStation\":false,\"statsMonthArrCnt\":\"10238\",\"isScanExpressSettleIn\":false,\"marginedTime\":\"2025-04-01 08:18:15\",\"isBlankAoiEst\":false,\"statsMonthGpyPickupCnt\":\"9588\",\"incentivePlanType\":\"flexible\",\"isCountrySideTransfer\":false,\"statsMonth\":\"202506\",\"stationMode\":\"heavy\",\"isSatisfied\":true,\"activityType\":\"STATION_ACTIVITY\",\"isReverseStationEst\":true,\"isSatisfyBaseCondition\":true},{\"billTime\":\"2025-04-30 00:00:00\",\"firstOver100ArrCnt\":\"501\",\"statsMonthBqArrRate\":\"0.999706974018363\",\"stationCode\":\"V5326297\",\"noSatisfyBaseReason\":\"\",\"staStatusName\":\"运营中\",\"isStationChanged\":false,\"staSoftStatus\":\"运营期\",\"statsMonthBqArrCnt\":\"10235\",\"cycleRange\":\"20250601~20250630\",\"statsMonthGpyPickupRate\":\"0.9796669050781649\",\"statsRange\":\"20250601~20250630\",\"ds\":\"2025-07-10\",\"isApplyQuit\":false,\"stationSubType\":\"社区专业点\",\"statsMonthPickupCnt\":\"9787\",\"statsMonthVaildArrDays\":\"30\",\"isBlackStation\":false,\"checkStartMonth\":\"202504\",\"stationName\":\"青岛适园雅居12号楼店\",\"entryOperateTime\":\"2025-04-15 00:00:00\",\"statsMonthAvgVaildArrCnt\":\"341.26666666666665\",\"isUnmannedStation\":false,\"stationId\":\"1094379\",\"statsMonthArrCnt\":\"10238\",\"isCollectionPointTransfer\":true,\"isExpressEst\":false,\"isScanExpressSettleIn\":false,\"noSatisfyReason\":\"\",\"marginedTime\":\"2025-04-01 08:18:15\",\"amountCent\":\"30000\",\"isBlankAoiEst\":false,\"statsMonthGpyPickupCnt\":\"9588\",\"incentivePlanType\":\"base\",\"isRiskStation\":false,\"checkStartDate\":\"20250401\",\"isCountrySideTransfer\":false,\"statsMonth\":\"202506\",\"stationMode\":\"heavy\",\"firstOver100ArrDate\":\"20250401\",\"isParticipateCpEstSta\":false,\"cycleNum\":\"3\",\"isDecorationPass\":true,\"isSatisfied\":true,\"isLightStationNew\":false,\"activityType\":\"STATION_ACTIVITY\",\"isReverseStationEst\":true,\"isQuit\":false,\"isSatisfyBaseCondition\":true},{\"billTime\":\"2025-04-30 00:00:00\",\"firstOver100ArrCnt\":\"501\",\"statsMonthBqArrRate\":\"0.9785766158315178\",\"stationCode\":\"V5326297\",\"noSatisfyBaseReason\":\"\",\"staStatusName\":\"运营中\",\"isStationChanged\":false,\"staSoftStatus\":\"运营期\",\"statsMonthBqArrCnt\":\"2695\",\"cycleRange\":\"20250701~20250731\",\"statsMonthGpyPickupRate\":\"0.9846025801081981\",\"statsRange\":\"20250701~20250731\",\"ds\":\"2025-07-10\",\"isApplyQuit\":false,\"stationSubType\":\"社区专业点\",\"statsMonthPickupCnt\":\"2403\",\"statsMonthVaildArrDays\":\"10\",\"isBlackStation\":false,\"checkStartMonth\":\"202504\",\"stationName\":\"青岛适园雅居12号楼店\",\"entryOperateTime\":\"2025-04-15 00:00:00\",\"statsMonthAvgVaildArrCnt\":\"275.4\",\"isUnmannedStation\":false,\"stationId\":\"1094379\",\"statsMonthArrCnt\":\"2754\",\"isCollectionPointTransfer\":true,\"isExpressEst\":false,\"isScanExpressSettleIn\":false,\"noSatisfyReason\":\"考核期间累计实操入库天数＜15天/\",\"marginedTime\":\"2025-04-01 08:18:15\",\"amountCent\":\"0\",\"isBlankAoiEst\":false,\"statsMonthGpyPickupCnt\":\"2366\",\"incentivePlanType\":\"base\",\"isRiskStation\":false,\"checkStartDate\":\"20250401\",\"isCountrySideTransfer\":false,\"statsMonth\":\"202507\",\"stationMode\":\"heavy\",\"firstOver100ArrDate\":\"20250401\",\"isParticipateCpEstSta\":false,\"cycleNum\":\"4\",\"isDecorationPass\":true,\"isSatisfied\":false,\"isLightStationNew\":false,\"activityType\":\"STATION_ACTIVITY\",\"isReverseStationEst\":true,\"isQuit\":false,\"isSatisfyBaseCondition\":true},{\"billTime\":\"2025-04-30 00:00:00\",\"firstOver100ArrCnt\":\"501\",\"statsMonthBqArrRate\":\"0.9785766158315178\",\"noSatisfyBaseReason\":\"\",\"statsMonthBqArrCnt\":\"2695\",\"cycleRange\":\"20250701~20250731\",\"ds\":\"2025-07-10\",\"stationSubType\":\"社区专业点\",\"checkStartMonth\":\"202504\",\"entryOperateTime\":\"2025-04-15 00:00:00\",\"statsMonthAvgVaildArrCnt\":\"275.4\",\"stationId\":\"1094379\",\"isCollectionPointTransfer\":true,\"isExpressEst\":false,\"noSatisfyReason\":\"考核期间累计实操入库天数＜15天/\",\"amountCent\":\"0\",\"isRiskStation\":false,\"checkStartDate\":\"20250401\",\"firstOver100ArrDate\":\"20250401\",\"isParticipateCpEstSta\":false,\"cycleNum\":\"4\",\"isDecorationPass\":true,\"coefficient\":\"1.4\",\"isLightStationNew\":false,\"isQuit\":false,\"stationCode\":\"V5326297\",\"staStatusName\":\"运营中\",\"isStationChanged\":false,\"staSoftStatus\":\"运营期\",\"statsMonthGpyPickupRate\":\"0.9846025801081981\",\"statsRange\":\"20250701~20250731\",\"isApplyQuit\":false,\"statsMonthPickupCnt\":\"2403\",\"statsMonthVaildArrDays\":\"10\",\"isBlackStation\":false,\"stationName\":\"青岛适园雅居12号楼店\",\"isUnmannedStation\":false,\"statsMonthArrCnt\":\"2754\",\"isScanExpressSettleIn\":false,\"marginedTime\":\"2025-04-01 08:18:15\",\"isBlankAoiEst\":false,\"statsMonthGpyPickupCnt\":\"2366\",\"incentivePlanType\":\"flexible\",\"isCountrySideTransfer\":false,\"statsMonth\":\"202507\",\"stationMode\":\"heavy\",\"isSatisfied\":false,\"activityType\":\"STATION_ACTIVITY\",\"isReverseStationEst\":true,\"isSatisfyBaseCondition\":true}]";

    public void setUp() {
        MockitoAnnotations.openMocks(this);
        // 初始化配置数据
        String config = "{ \"tipTitle\":{\n" +
                "        \"YZZG\":\"第%s期补贴%s元到账，点击下方账单入口查看\",\n" +
                "        \"PG\":\"第%s期补贴%s元到账\"\n" +
                "    }}";
        StationIncentivePageConfigHolder configHolder = JSONObject.parseObject(config, StationIncentivePageConfigHolder.class);
        StationIncentivePageConfigHolder.setINSTANCE(configHolder);
    }
    /**
     * 测试assembleTip方法当输入列表为空时应返回null
     */
    @Test
    public void testAssembleTipWithEmptyList() {
        // 创建一个空的IncentiveCardDTO列表
        List<IncentiveCardDTO> emptyCardDTOList = Collections.emptyList();
        // 调用要测试的方法
        IncentiveTipDTO result = StationIncentivePageDataConvert.assembleTip(emptyCardDTOList,"PG");
        // 断言结果应为null
        assertNull(result);  // 当输入列表为空时，方法应返回null
    }

    @Test
    public void testAssembleTip() {
        try (MockedStatic<StationIncentivePageConfigHolder> mockedStatic = Mockito.mockStatic(StationIncentivePageConfigHolder.class)) {
            StationIncentivePageConfigHolder stationIncentivePageConfigHolder = new StationIncentivePageConfigHolder();
            HashMap<String, String> map = Maps.newHashMap();
            map.put("PG", "第%s期补贴%s元到账");
            stationIncentivePageConfigHolder.setTipTitle(map);
            mockedStatic.when(StationIncentivePageConfigHolder::getINSTANCE).thenReturn(stationIncentivePageConfigHolder);
            // 创建一个空的IncentiveCardDTO列表
            IncentiveCardDTO incentiveCardDTO = new IncentiveCardDTO();
            incentiveCardDTO.setTitle("");
            incentiveCardDTO.setPaid(Lists.newArrayList());
            incentiveCardDTO.setPeriod("");
            incentiveCardDTO.setBillDate("");
            incentiveCardDTO.setTags(Lists.newArrayList());
            incentiveCardDTO.setData(Lists.newArrayList());
            incentiveCardDTO.setIncentiveAmount("");
            // 调用要测试的方法
            IncentiveTipDTO result = StationIncentivePageDataConvert.assembleTip(Lists.newArrayList(incentiveCardDTO),"PG");
            // 断言结果应为null
            assertNotNull(result);  // 当输入列表为空时，方法应返回null
        }

    }


    @Test
    public void testAssembleCardIsNull() {
        // 创建一个空的IncentiveCardDTO列表
        List<StationIncentiveBillDetailDTO> emptyCardDTOList = Collections.emptyList();
        // 调用要测试的方法
        IncentiveCardDTO result = StationIncentivePageDataConvert.assembleCard(emptyCardDTOList, "fy26q1");
        // 断言结果应为null
        assertNull(result);  // 当输入列表为空时，方法应返回null
    }

    @Test
    public void testAssembleCard() {
        List<StationIncentiveBillDetailDTO> billDetailDTOS = JSONObject.parseArray(detailList, StationIncentiveBillDetailDTO.class);
        Map<String, List<StationIncentiveBillDetailDTO>> collect = billDetailDTOS.stream().collect(Collectors.groupingBy(StationIncentiveBillDetailDTO::getCycleNum));
        List<StationIncentiveBillDetailDTO> orDefault = collect.getOrDefault("1", Lists.newArrayList());
        // 调用要测试的方法
        IncentiveCardDTO result = StationIncentivePageDataConvert.assembleCard(orDefault, "fy26q1");
        // 断言结果应为null
        assertNotNull(result);  // 当输入列表为空时，方法应返回null
    }

    @Test
    public void testAssembleCardOnlyBseIncentive() {
        List<StationIncentiveBillDetailDTO> billDetailDTOS = JSONObject.parseArray(detailList, StationIncentiveBillDetailDTO.class);
        Map<String, List<StationIncentiveBillDetailDTO>> collect = billDetailDTOS.stream().collect(Collectors.groupingBy(StationIncentiveBillDetailDTO::getCycleNum));
        List<StationIncentiveBillDetailDTO> orDefault = collect.getOrDefault("1", Lists.newArrayList());
        // 调用要测试的方法
        IncentiveCardDTO result = StationIncentivePageDataConvert.assembleCard(orDefault, "fy25q4");
        // 断言结果应为null
        assertNotNull(result);  // 当输入列表为空时，方法应返回null
    }
}