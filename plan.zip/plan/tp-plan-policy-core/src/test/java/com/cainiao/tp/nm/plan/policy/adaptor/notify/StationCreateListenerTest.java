package com.cainiao.tp.nm.plan.policy.adaptor.notify;

import com.alibaba.cainiao.stationplatform.client.domain.StationStationDTO;
import com.alibaba.cainiao.stationplatform.common.notify.StationModifyEvent;
import com.alibaba.fastjson.JSONObject;
import com.cainiao.tp.nm.plan.api.policy.application.dto.StationDTO;
import com.cainiao.tp.nm.plan.api.policy.application.dto.config.NewStaPerformSubsidyConfigDTO;
import com.cainiao.tp.nm.plan.infra.port.policy.PolicyConfigManager;
import com.cainiao.tp.nm.plan.infra.port.policy.StaStationReadManager;
import com.cainiao.tp.nm.plan.infra.port.policy.TpPushStationMessageManager;
import com.taobao.notify.message.Message;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.lang.reflect.Method;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class StationCreateListenerTest {

    @Mock
    private PolicyConfigManager policyConfigManager;

    @Mock
    private TpPushStationMessageManager tpPushStationMessageManager;

    @Mock
    private StaStationReadManager staStationReadManager;

    @InjectMocks
    private StationCreateListener stationCreateListener;

    /**
     * 测试成功消费事件：站点信息存在且满足条件
     */
    @Test
    public void testDoConsumeSuccess() throws Exception {
        StationModifyEvent event = new StationModifyEvent();
        Long stationId = 1L;
        StationStationDTO stationDTO1 = new StationStationDTO();
        stationDTO1.setStationId(stationId);
        event.setBodyAfter(stationDTO1);

        // 准备数据
        String stationStr ="{\"areaCode\":\"450107\",\"bizMode\":17,\"channel\":17,\"cityCode\":\"500100\",\"clientVersion\":1,\"contact\":\"罗绕露\",\"corporationAlipayId\":\"2088052545016336\",\"corporationAlipayNick\":\"18077153295\",\"corporationCnAccountId\":2219586510101,\"deliveryAddress\":\"广西壮族自治区^^^南宁市^^^西乡塘区^^^北湖街道^^^北湖街道万秀北路168号秀营出租公寓铺面C115号店\",\"enterpriseCnuserId\":2219645759016,\"feature\":\";supportActivity:2025-04-07;dispacthCode:EBR;p_f_c_i:1744430950000;ext_shoparea:45;picwaybill:https%3A%2F%2Fsta-upload.oss-cn-hangzhou.aliyuncs.com%2Fbpm-180%2F20250414%2Faa25cf9fdfef4d0fbc8f8b6698a7f532%2Fimage.jpg;pic_for_inner:https%3A%2F%2Ftps-join.oss-cn-zhangjiakou.aliyuncs.com%2Fimage%2F20250403%2F051fd7c38dff4e4eb1794dc5c9c464e7.jpeg;ext_stationlocation:first_floor;singned_time:2025-04-03+19%3A39%3A59;applyId:6300000002791716;new_cn:new_cn;probation_end_time:2025-04-21+00%3A00%3A00;new_cn_type:personal;ityWay:auto;sendPackageHomeWay:send_home;blank_aoi_id:450107_1321107013_1306692881;tax_info:2025-04-05_individual;pic_for_door:https%3A%2F%2Ftps-join.oss-cn-zhangjiakou.aliyuncs.com%2Fimage%2F20250403%2Ff696fb0a39e4477ea2d3fa54cd13e49d.jpeg;ityType:1;STATION_POINT:n;keepInpackageMode:false;margined_time:2025-04-05+20%3A55%3A54;singned:singned;dispacthCodeCN:%E4%B8%87%E7%A7%80%E6%9D%91%E7%A7%80%E8%90%A5%E5%85%AC;cnt_compliance_time:2025-04-05+20%3A56%3A25;print_type:3;margined:margined;serviceSwitch_DeWuSend:1;station_operating_tag:station_operating_tag;msg_charge:2025-04-05+20%3A55%3A54;lastTrafficHour:21;cor_agreement_invalid_time:2099-03-31;serviceSwitch_StationPlatformSend:1;serviceSwitch_KuaiShouSend:1;accountNo:5120022195865101010307978662;ext_minbiz:pioneer;ussct:2025-04-12+12%3A32%3A24;unifiedSmartCall:1;serviceSwitch_XhsSend:1;decorationDemolishStatus:-2;isCountrySideTransfer:n;shelfSet:5-5;lightShelfMode:10;smartCall_status:3;lastTrafficMinute:00;shelfMode:1;station_type:professional_station;openProfExamScore:100;professionalAnchorTime:2025-04-05+20%3A55%3A54;needCloudMonitor:y;\",\"featureMap\":{\"supportActivity\":\"2025-04-07\",\"dispacthCode\":\"EBR\",\"p_f_c_i\":\"1744430950000\",\"ext_shoparea\":\"45\",\"picwaybill\":\"https://sta-upload.oss-cn-hangzhou.aliyuncs.com/bpm-180/20250414/aa25cf9fdfef4d0fbc8f8b6698a7f532/image.jpg\",\"pic_for_inner\":\"https://tps-join.oss-cn-zhangjiakou.aliyuncs.com/image/20250403/051fd7c38dff4e4eb1794dc5c9c464e7.jpeg\",\"ext_stationlocation\":\"first_floor\",\"singned_time\":\"2025-04-03 19:39:59\",\"applyId\":\"6300000002791716\",\"new_cn\":\"new_cn\",\"probation_end_time\":\"2025-04-21 00:00:00\",\"new_cn_type\":\"personal\",\"ityWay\":\"auto\",\"sendPackageHomeWay\":\"send_home\",\"blank_aoi_id\":\"450107_1321107013_1306692881\",\"tax_info\":\"2025-04-05_individual\",\"pic_for_door\":\"https://tps-join.oss-cn-zhangjiakou.aliyuncs.com/image/20250403/f696fb0a39e4477ea2d3fa54cd13e49d.jpeg\",\"ityType\":\"1\",\"STATION_POINT\":\"n\",\"keepInpackageMode\":\"false\",\"margined_time\":\"2025-04-05 20:55:54\",\"singned\":\"singned\",\"dispacthCodeCN\":\"万秀村秀营公\",\"cnt_compliance_time\":\"2025-04-05 20:56:25\",\"print_type\":\"3\",\"margined\":\"margined\",\"serviceSwitch_DeWuSend\":\"1\",\"station_operating_tag\":\"station_operating_tag\",\"msg_charge\":\"2025-04-05 20:55:54\",\"lastTrafficHour\":\"21\",\"cor_agreement_invalid_time\":\"2099-03-31\",\"serviceSwitch_StationPlatformSend\":\"1\",\"serviceSwitch_KuaiShouSend\":\"1\",\"accountNo\":\"5120022195865101010307978662\",\"ext_minbiz\":\"pioneer\",\"ussct\":\"2025-04-12 12:32:24\",\"unifiedSmartCall\":\"1\",\"serviceSwitch_XhsSend\":\"1\",\"decorationDemolishStatus\":\"-2\",\"isCountrySideTransfer\":\"n\",\"shelfSet\":\"5-5\",\"lightShelfMode\":\"10\",\"smartCall_status\":\"3\",\"lastTrafficMinute\":\"00\",\"shelfMode\":\"1\",\"station_type\":\"professional_station\",\"openProfExamScore\":\"100\",\"professionalAnchorTime\":\"2025-04-05 20:55:54\",\"needCloudMonitor\":\"y\"},\"flag\":411304009,\"gmtCreate\":1743857754000,\"gmtModified\":1754767426000,\"instanceCode\":\"1090000001377140\",\"isDeleted\":0,\"lat\":\"2285317\",\"latitude\":22.85317,\"lng\":\"10830957\",\"longitude\":108.30957,\"mobile\":\"18077153295\",\"officeTime\":\"周一至周日10点00分到21点00分\",\"partnerId\":21000624260,\"provinceCode\":\"450000\",\"resourceId\":1216000000954680,\"stationCode\":\"V7715112\",\"stationId\":1095289,\"stationName\":\"南宁万秀村秀营公寓c115号店\",\"stationService\":1024,\"stationType\":1,\"status\":1,\"supportHomeService\":false,\"townCode\":\"450107002\",\"waybillUserId\":2219598010003}";
        String subsidyConfigStr ="{\"cumulativeSubsidyTip\":\"累计已补贴=历史月份已到账激励之和\",\"startDate\":\"2025-04-01 00:00:00\",\"endDate\":\"2026-04-01 00:00:00\",\"ruleDetailTop20CityCodeList\":[\"330100\",\"420100\",\"510100\",\"320500\",\"410100\",\"120100\",\"130100\",\"430100\",\"370100\",\"310100\",\"340100\",\"110100\",\"330200\"],\"ruleDetailTop100CityCodeList\":[\"500100\",\"440100\",\"120100\",\"441900\",\"320500\",\"440300\",\"510100\",\"210100\",\"410100\",\"320100\",\"370200\",\"610100\",\"420100\",\"310100\",\"130100\",\"340100\",\"350100\",\"370700\"]}";
        StationDTO stationDTO = JSONObject.parseObject(stationStr, StationDTO.class);


        // Mock行为
        when(staStationReadManager.queryStationById(stationId)).thenReturn(stationDTO);
        when(policyConfigManager.getNewStaPerformSubsidyConfig()).thenReturn(JSONObject.parseObject(subsidyConfigStr, NewStaPerformSubsidyConfigDTO.class));

        // 使用反射调用私有方法
        Method method = StationCreateListener.class.getDeclaredMethod("doConsume", StationModifyEvent.class, Message.class);
        method.setAccessible(true);

        // 预期tpPushStationMessageManager.sendNewStaPerformSubsidyPopup会被调用
        doNothing().when(tpPushStationMessageManager).sendNewStaPerformSubsidyPopup(anyLong());

        boolean result = (boolean) method.invoke(stationCreateListener, event, mock(Message.class));

        verify(tpPushStationMessageManager, times(1)).sendNewStaPerformSubsidyPopup(anyLong());
        assertTrue(result);  // 断言消费成功
    }

    /**
     * 测试成功消费事件：站点信息存在且满足条件
     */
    @Test
    public void testDoConsumeFail() throws Exception {
        StationModifyEvent event = new StationModifyEvent();
        Long stationId = 1L;
        StationStationDTO stationDTO1 = new StationStationDTO();
        stationDTO1.setStationId(stationId);
        event.setBodyAfter(stationDTO1);

        // 准备数据
        String stationStr ="{\"areaCode\":\"450107\",\"bizMode\":17,\"channel\":17,\"cityCode\":\"450100\",\"clientVersion\":1,\"contact\":\"罗绕露\",\"corporationAlipayId\":\"2088052545016336\",\"corporationAlipayNick\":\"18077153295\",\"corporationCnAccountId\":2219586510101,\"deliveryAddress\":\"广西壮族自治区^^^南宁市^^^西乡塘区^^^北湖街道^^^北湖街道万秀北路168号秀营出租公寓铺面C115号店\",\"enterpriseCnuserId\":2219645759016,\"feature\":\";supportActivity:2025-04-07;dispacthCode:EBR;p_f_c_i:1744430950000;ext_shoparea:45;picwaybill:https%3A%2F%2Fsta-upload.oss-cn-hangzhou.aliyuncs.com%2Fbpm-180%2F20250414%2Faa25cf9fdfef4d0fbc8f8b6698a7f532%2Fimage.jpg;pic_for_inner:https%3A%2F%2Ftps-join.oss-cn-zhangjiakou.aliyuncs.com%2Fimage%2F20250403%2F051fd7c38dff4e4eb1794dc5c9c464e7.jpeg;ext_stationlocation:first_floor;singned_time:2025-04-03+19%3A39%3A59;applyId:6300000002791716;new_cn:new_cn;probation_end_time:2025-04-21+00%3A00%3A00;new_cn_type:personal;ityWay:auto;sendPackageHomeWay:send_home;blank_aoi_id:450107_1321107013_1306692881;tax_info:2025-04-05_individual;pic_for_door:https%3A%2F%2Ftps-join.oss-cn-zhangjiakou.aliyuncs.com%2Fimage%2F20250403%2Ff696fb0a39e4477ea2d3fa54cd13e49d.jpeg;ityType:1;STATION_POINT:n;keepInpackageMode:false;margined_time:2025-04-05+20%3A55%3A54;singned:singned;dispacthCodeCN:%E4%B8%87%E7%A7%80%E6%9D%91%E7%A7%80%E8%90%A5%E5%85%AC;cnt_compliance_time:2025-04-05+20%3A56%3A25;print_type:3;margined:margined;serviceSwitch_DeWuSend:1;station_operating_tag:station_operating_tag;msg_charge:2025-04-05+20%3A55%3A54;lastTrafficHour:21;cor_agreement_invalid_time:2099-03-31;serviceSwitch_StationPlatformSend:1;serviceSwitch_KuaiShouSend:1;accountNo:5120022195865101010307978662;ext_minbiz:pioneer;ussct:2025-04-12+12%3A32%3A24;unifiedSmartCall:1;serviceSwitch_XhsSend:1;decorationDemolishStatus:-2;isCountrySideTransfer:n;shelfSet:5-5;lightShelfMode:10;smartCall_status:3;lastTrafficMinute:00;shelfMode:1;station_type:professional_station;openProfExamScore:100;professionalAnchorTime:2025-04-05+20%3A55%3A54;needCloudMonitor:y;\",\"featureMap\":{\"supportActivity\":\"2025-04-07\",\"dispacthCode\":\"EBR\",\"p_f_c_i\":\"1744430950000\",\"ext_shoparea\":\"45\",\"picwaybill\":\"https://sta-upload.oss-cn-hangzhou.aliyuncs.com/bpm-180/20250414/aa25cf9fdfef4d0fbc8f8b6698a7f532/image.jpg\",\"pic_for_inner\":\"https://tps-join.oss-cn-zhangjiakou.aliyuncs.com/image/20250403/051fd7c38dff4e4eb1794dc5c9c464e7.jpeg\",\"ext_stationlocation\":\"first_floor\",\"singned_time\":\"2025-04-03 19:39:59\",\"applyId\":\"6300000002791716\",\"new_cn\":\"new_cn\",\"probation_end_time\":\"2025-04-21 00:00:00\",\"new_cn_type\":\"personal\",\"ityWay\":\"auto\",\"sendPackageHomeWay\":\"send_home\",\"blank_aoi_id\":\"450107_1321107013_1306692881\",\"tax_info\":\"2025-04-05_individual\",\"pic_for_door\":\"https://tps-join.oss-cn-zhangjiakou.aliyuncs.com/image/20250403/f696fb0a39e4477ea2d3fa54cd13e49d.jpeg\",\"ityType\":\"1\",\"STATION_POINT\":\"n\",\"keepInpackageMode\":\"false\",\"margined_time\":\"2025-04-05 20:55:54\",\"singned\":\"singned\",\"dispacthCodeCN\":\"万秀村秀营公\",\"cnt_compliance_time\":\"2025-04-05 20:56:25\",\"print_type\":\"3\",\"margined\":\"margined\",\"serviceSwitch_DeWuSend\":\"1\",\"station_operating_tag\":\"station_operating_tag\",\"msg_charge\":\"2025-04-05 20:55:54\",\"lastTrafficHour\":\"21\",\"cor_agreement_invalid_time\":\"2099-03-31\",\"serviceSwitch_StationPlatformSend\":\"1\",\"serviceSwitch_KuaiShouSend\":\"1\",\"accountNo\":\"5120022195865101010307978662\",\"ext_minbiz\":\"pioneer\",\"ussct\":\"2025-04-12 12:32:24\",\"unifiedSmartCall\":\"1\",\"serviceSwitch_XhsSend\":\"1\",\"decorationDemolishStatus\":\"-2\",\"isCountrySideTransfer\":\"n\",\"shelfSet\":\"5-5\",\"lightShelfMode\":\"10\",\"smartCall_status\":\"3\",\"lastTrafficMinute\":\"00\",\"shelfMode\":\"1\",\"station_type\":\"professional_station\",\"openProfExamScore\":\"100\",\"professionalAnchorTime\":\"2025-04-05 20:55:54\",\"needCloudMonitor\":\"y\"},\"flag\":411304009,\"gmtCreate\":1743857754000,\"gmtModified\":1754767426000,\"instanceCode\":\"1090000001377140\",\"isDeleted\":0,\"lat\":\"2285317\",\"latitude\":22.85317,\"lng\":\"10830957\",\"longitude\":108.30957,\"mobile\":\"18077153295\",\"officeTime\":\"周一至周日10点00分到21点00分\",\"partnerId\":21000624260,\"provinceCode\":\"450000\",\"resourceId\":1216000000954680,\"stationCode\":\"V7715112\",\"stationId\":1095289,\"stationName\":\"南宁万秀村秀营公寓c115号店\",\"stationService\":1024,\"stationType\":1,\"status\":1,\"supportHomeService\":false,\"townCode\":\"450107002\",\"waybillUserId\":2219598010003}";
        String subsidyConfigStr ="{\"cumulativeSubsidyTip\":\"累计已补贴=历史月份已到账激励之和\",\"startDate\":\"2025-04-01 00:00:00\",\"endDate\":\"2026-04-01 00:00:00\",\"ruleDetailTop20CityCodeList\":[\"330100\",\"420100\",\"510100\",\"320500\",\"410100\",\"120100\",\"130100\",\"430100\",\"370100\",\"310100\",\"340100\",\"110100\",\"330200\"],\"ruleDetailTop100CityCodeList\":[\"500100\",\"440100\",\"120100\",\"441900\",\"320500\",\"440300\",\"510100\",\"210100\",\"410100\",\"320100\",\"370200\",\"610100\",\"420100\",\"310100\",\"130100\",\"340100\",\"350100\",\"370700\"]}";
        StationDTO stationDTO = JSONObject.parseObject(stationStr, StationDTO.class);


        // Mock行为
        when(staStationReadManager.queryStationById(stationId)).thenReturn(stationDTO);
        when(policyConfigManager.getNewStaPerformSubsidyConfig()).thenReturn(JSONObject.parseObject(subsidyConfigStr, NewStaPerformSubsidyConfigDTO.class));

        // 使用反射调用私有方法
        Method method = StationCreateListener.class.getDeclaredMethod("doConsume", StationModifyEvent.class, Message.class);
        method.setAccessible(true);

        // 预期tpPushStationMessageManager.sendNewStaPerformSubsidyPopup会被调用
        doNothing().when(tpPushStationMessageManager).sendNewStaPerformSubsidyPopup(anyLong());

        boolean result = (boolean) method.invoke(stationCreateListener, event, mock(Message.class));

        verify(tpPushStationMessageManager, times(1)).sendNewStaPerformSubsidyPopup(anyLong());
        assertTrue(result);  // 断言消费成功
    }
}