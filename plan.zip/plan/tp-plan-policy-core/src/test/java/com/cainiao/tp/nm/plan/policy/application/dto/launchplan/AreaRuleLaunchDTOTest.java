package com.cainiao.tp.nm.plan.api.policy.application.dto.launchplan;

import com.base.BaseTest;
import com.cainiao.aladdin.exception.AladdinBizException;
import com.cainiao.tp.nm.plan.api.policy.application.dto.launchplan.AreaRuleLaunchDTO;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.MockitoAnnotations;

/**
 * <a href="https://alidocs.dingtalk.com/i/nodes/dpYLaezmVNRMGX56C1aKjlBOVrMqPxX6">单元测试编写&生成FAQ</a>
 * Created By Thub IDEA插件
 *
 * @Date 2025/6/4 16:49
 */
public class AreaRuleLaunchDTOTest extends BaseTest {


    @Before
    public void setUp() throws Exception {MockitoAnnotations.openMocks(this);}

    @Test
    public void testValidate() {
        AreaRuleLaunchDTO areaRuleLaunchDTO = new AreaRuleLaunchDTO();
        try {
            areaRuleLaunchDTO.validate();
        }catch (AladdinBizException e){
            Assert.assertEquals("参数不能全空", e.getMessage());
        }
    }
}