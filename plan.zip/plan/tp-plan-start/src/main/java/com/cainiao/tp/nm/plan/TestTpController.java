package com.cainiao.tp.nm.plan;


import com.cainiao.aladdin.reslut.Result;
import com.cainiao.tp.boot.annotation.TpController;
import com.cainiao.tp.boot.annotation.access.TpBucAccess;
import com.cainiao.tp.boot.annotation.access.TpMoziAccess;
import com.cainiao.tp.boot.utils.TpWebUtil;
import com.cainiao.tp.nm.plan.policy.adaptor.component.rights.RightsControl;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@TpController
@TpMoziAccess(allowAliEmployee = true)
@RequestMapping("/test")
public class TestTpController {



    @GetMapping("/getUserInfo")
    @RightsControl(roleCodeArray= {"tp_nm_plan_admin"})
    public com.cainiao.aladdin.reslut.Result<String> getUserInfo(){
        return Result.create(TpWebUtil.getWebOperation().getOperatorNick());
    }

}
