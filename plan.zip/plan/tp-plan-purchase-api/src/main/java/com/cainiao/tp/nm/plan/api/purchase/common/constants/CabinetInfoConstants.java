package com.cainiao.tp.nm.plan.api.purchase.common.constants;

/**
 * 柜子&&隔口类型
 */
public class CabinetInfoConstants {
    public static final String MAIN_CABINET = "主柜";
    public static final String SUB_CABINET = "副柜";
    public static final String TINY_GRID = "微小格口";
    public static final String SMALL_GRID = "小格口";
    public static final String MIDDLE_GRID = "中格口";
    public static final String BIG_GRID = "大格口";

}
