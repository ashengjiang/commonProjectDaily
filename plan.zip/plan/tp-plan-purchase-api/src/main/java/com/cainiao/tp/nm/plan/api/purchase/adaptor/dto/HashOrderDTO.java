package com.cainiao.tp.nm.plan.api.purchase.adaptor.dto;

import lombok.Data;

import java.io.Serializable;

@Data
public class HashOrderDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 已经下单 true 已经下单 false 未下单
     */
    private Boolean hashOrder;
}
