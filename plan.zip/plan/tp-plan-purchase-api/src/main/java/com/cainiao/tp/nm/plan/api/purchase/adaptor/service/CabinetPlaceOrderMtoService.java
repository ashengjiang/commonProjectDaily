package com.cainiao.tp.nm.plan.api.purchase.adaptor.service;

import com.cainiao.sutee.commons.base.result.CnResult;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.AgreementInfoDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.CabinetOrderDetailDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.PlaceOrderResultDTO;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.ExpressAgreementSubscriptionParam;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PlaceOrderParam;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.param.PreCalculateOrderParam;
import com.cainiao.tp.nm.plan.api.purchase.application.dto.vo.CabinetProductInfoResultVO;

/**
 * 柜子下单对外 MTOP 服务接口 */
public interface CabinetPlaceOrderMtoService {

    /**
     * 商品列表
     * @return return
     */
    CnResult<CabinetProductInfoResultVO> infoList();

    /**
     * 创建订购订单
     *
     * @param param 下单参数
     * @return 下单结果（含订单 ID、付款链接、前置检查状态等）
     */
    CnResult<PlaceOrderResultDTO> placeOrder(PlaceOrderParam param);

    /**
     * 预计算订单（柜子数量、格口数量、总价等）
     *
     * @param param 预计算参数
     * @return 订单明细
     */
    CnResult<CabinetOrderDetailDTO> preCalculateOrder(PreCalculateOrderParam param);

    /**
     * 协议订阅
     * @param param param
     * @return return
     */
    CnResult<Boolean> expressAgreementSubscription(ExpressAgreementSubscriptionParam param);

    /**
     * 查询站点协议
     * @return 协议
     */
    CnResult<AgreementInfoDTO> queryAgreementInfo();
}
