package com.cainiao.tp.nm.plan.api.purchase.common.constants;

/**
 * 订购支付单状态枚举
 */
public enum PurchasePaymentOrderStatusEnum {

    /**
     * 创建
     */
    CREATE(1, "创建"),

    /**
     * 部分支付
     */
    PARTIAL_PAID(5, "部分支付"),

    /**
     * 支付完成
     */
    PAID(10, "支付完成");

    private final Integer code;
    private final String desc;

    PurchasePaymentOrderStatusEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public Integer getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

}
