package com.cainiao.tp.nm.plan.api.purchase.application.dto;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

/**
 * 订购规则 DTO */
@Data
public class PurchaseRuleDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    private Long id;

    /**
     * 产品ID
     */
    private Long productId;

    /**
     * 类目 {@link com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseCategoryEnum}
     */
    private Integer categoryId;

    /**
     * 产品 SKU ID
     */
    private Long skuId;

    /**
     * 客户类型 1=站点 10=网点
     */
    private Integer customerType;

    /**
     * 协议 code 列表（按 sortOrder 升序）
     */
    private List<String> agreementCodeList;

    /**
     * 命中的支付方案 ID（即下单时使用的那一项）
     */
    private String paymentPlanId;

    /**
     * 命中的支付方案名称
     */
    private String paymentPlanName;

    /**
     * 命中的支付模式 {@link com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchasePaymentModeEnum}
     */
    private Integer paymentMode;

    /**
     * 提货类型列表 {@link com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchaseDeliveryTypeEnum}
     */
    private List<Integer> deliveryTypeList;

    /**
     * 开始时间
     */
    private LocalDateTime startTime;

    /**
     * 结束时间
     */
    private LocalDateTime endTime;

    /**
     * 优先级
     */
    private Integer level;

}
