package com.cainiao.tp.nm.plan.api.purchase.common.constants;

/**
 * 订购支付模式枚举
 */
public enum PurchasePaymentModeEnum {

    /**
     * 全款
     */
    FULL_PAYMENT(1, "全款"),

    /**
     * 贷款
     */
    LOAN(10, "贷款"),

    /**
     * 租赁
     */
    RENTAL(20, "租赁");

    private final Integer code;
    private final String desc;

    PurchasePaymentModeEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public Integer getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

}
