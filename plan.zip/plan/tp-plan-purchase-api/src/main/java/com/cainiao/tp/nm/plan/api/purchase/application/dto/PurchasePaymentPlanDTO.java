package com.cainiao.tp.nm.plan.api.purchase.application.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * 支付方案 DTO */
@Data
public class PurchasePaymentPlanDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    private Long id;

    /**
     * 支付编码
     */
    private String payCode;

    /**
     * 支付名称
     */
    private String payName;

    /**
     * 支付模式 {@link com.cainiao.tp.nm.plan.api.purchase.common.constants.PurchasePaymentModeEnum}
     */
    private Integer paymentMode;

    /**
     * 支付配置（JSON 字符串）
     */
    private String paymentConfig;

}
