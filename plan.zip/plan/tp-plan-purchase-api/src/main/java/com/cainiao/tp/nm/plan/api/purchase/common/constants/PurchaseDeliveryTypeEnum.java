package com.cainiao.tp.nm.plan.api.purchase.common.constants;

/**
 * 订购发货类型枚举
 */
public enum PurchaseDeliveryTypeEnum {

    /**
     * 自提
     */
    SELF_PICKUP(1, "自提"),

    /**
     * 商家物流
     */
    MERCHANT_LOGISTICS(10, "商家物流");

    private final Integer code;
    private final String desc;

    PurchaseDeliveryTypeEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public Integer getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

}
