package com.cainiao.tp.nm.plan.api.purchase.adaptor.service;

import com.cainiao.aladdin.operation.AbstractOperation;
import com.cainiao.sutee.commons.base.result.CnResult;
import com.cainiao.tp.nm.plan.api.purchase.adaptor.dto.HashOrderDTO;
import com.cainiao.tp.nm.plan.api.purchase.adaptor.dto.HashOrderParam;

public interface PurchaseOrderForOutService {

    /**
     * 判断在万里牛是否已经下单，不管是否取消，只要万里牛产生了订单就算
     * 给结算提供，但是用于非结算场景
     *
     * @param hashOrderParam param
     * @return return
     */
    CnResult<HashOrderDTO> hashOrder(HashOrderParam hashOrderParam, AbstractOperation operation);
}
