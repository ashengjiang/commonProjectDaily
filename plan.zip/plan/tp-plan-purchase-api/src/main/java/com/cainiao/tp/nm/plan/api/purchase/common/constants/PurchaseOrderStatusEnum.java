package com.cainiao.tp.nm.plan.api.purchase.common.constants;

/**
 * 订购订单状态枚举
 */
public enum PurchaseOrderStatusEnum {

    /**
     * 创建
     */
    CREATE(1, "创建"),

    /**
     * 签署中
     */
    SIGNING(5, "签署中"),

    /**
     * 已签署
     */
    SIGNED(10, "已签署"),

    /**
     * 支付中
     */
    PAYING(15, "支付中"),

    /**
     * 支付成功
     */
    PAID(20, "支付成功"),

    /**
     * 已发货
     */
    SHIPPED(30, "已发货"),

    /**
     * 已签收
     */
    RECEIVED(35, "已签收");

    private final Integer code;
    private final String desc;

    PurchaseOrderStatusEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public Integer getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

}
