/**
 * 柜子销售域对外契约（HSF / MTOP / DTO / 枚举 / 常量 / 错误码）。
 *
 * <p>本模块从 {@code cnt-iot-tickets/iot-aftersales-api} 迁移而来，
 * 详见仓库根目录 {@code .aone_copilot/rules/柜子代码迁移方案.md}。</p>
 *
 * <p>分包约束：</p>
 * <ul>
 *     <li>{@code adaptor.service.*}：HSF 服务接口</li>
 *     <li>{@code adaptor.dto.param.*}：HTTP/HSF 入参（类名以 {@code Request} 结尾）</li>
 *     <li>{@code adaptor.dto.vo.*}：HTTP/HSF 出参（类名以 {@code DTO} 结尾）</li>
 *     <li>{@code application.dto.*}：领域 DTO</li>
 *     <li>{@code common.constants.*}：常量与枚举</li>
 *     <li>{@code common.errorcode.*}：错误码</li>
 * </ul>
 *
 * <p><b>禁止</b>引入：万里牛 SDK / Spring / MyBatis / 任何业务三方 client。</p>
 */
package com.cainiao.tp.nm.plan.api.purchase;
