package com.cainiao.tp.nm.plan.api.purchase.application.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * @create 2026-01-19-11:42
 * @Description
 */
@Data
public class CabinetOrderDetailDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主柜个数
     */
    private Integer mainCabinetNum;
    /**
     * 副柜个数
     */
    private Integer subCabinetNum;
    /**
     * 总格口数
     */
    private Integer totalGridNum;
    /**
     * 微小格口数
     */
    private Integer tinyGridNum;
    /**
     * 小格口数
     */
    private Integer smallGridNum;
    /**
     * 中格口数
     */
    private Integer middleGridNum;
    /**
     * 大格口数
     */
    private Integer bigGridNum;
    /**
     * 总计价格
     */
    private Double totalPrice;
}
