package com.cainiao.tp.nm.plan.api.purchase.application.dto;

import com.cainiao.tp.nm.plan.api.purchase.application.dto.ProductInfoDTO;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class ProductInfoResultDTO implements Serializable {

    private static final long serialVersionUID = 1L;


    private List<ProductInfoDTO> productInfoList;
}
