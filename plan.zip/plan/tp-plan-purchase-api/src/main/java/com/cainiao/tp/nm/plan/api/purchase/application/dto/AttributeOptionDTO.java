package com.cainiao.tp.nm.plan.api.purchase.application.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * 属性产品标签 DTO */
@Data
public class AttributeOptionDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 属性编码
     */
    private String code;
    /**
     * 属性值
     */
    private String value;

    /**
     * 选项编码
     */
    private String optionCode;

    /**
     * 选项名称
     */
    private String optionName;
}
