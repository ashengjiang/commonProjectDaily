package com.cainiao.tp.nm.plan.api.purchase.application.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 已认证企业信息 */
@Data
public class CertifiedEnterpriseInfoDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 企业名称
     */
    private String enterpriseName;

    /**
     * 营业执照注册号 / 统一社会信用代码
     */
    private String regCode;

    /**
     * 法人姓名
     */
    private String legalPerson;

    /**
     * 法人手机号
     */
    private String legalMobile;

    /**
     * 经办人手机号
     */
    private String transactorMobile;

    /**
     * 签约手机号
     */
    private String signMobile;

    /**
     * 营业执照图片 OSS Key
     */
    private String picOssKey;

    /**
     * 最后修改时间
     */
    private Date gmtModified;
}
