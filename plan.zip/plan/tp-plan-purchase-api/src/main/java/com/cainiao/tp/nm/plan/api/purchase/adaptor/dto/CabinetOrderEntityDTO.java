package com.cainiao.tp.nm.plan.api.purchase.adaptor.dto;

import lombok.Data;

import java.io.Serializable;

@Data
public class CabinetOrderEntityDTO implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
     * 实体id
     */
    private String entityId;

    /**
     * 实体类型
     */
    private Integer entityType;

    /**
     * 实体code
     */
    private String entityCode;

    /**
     * 是否可购买
     */
    private Boolean canBuy;

    /**
     * 是否可查看
     */
    private Boolean canView;

    private Long userId;

    private String userType;

    private String userName;

    /**
     * 员工ID
     */
    private String employeeId;

    /**
     * 菜鸟账号ID
     */
    private Long cnUserAccountId;

}
