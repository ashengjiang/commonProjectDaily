package com.cainiao.tp.nm.plan.api.purchase.common.constants;

import lombok.Getter;

/**
 * 订购类目枚举
 */
@Getter
public enum PurchaseCategoryEnum {

    /**
     * 柜子
     */
    CABINET(100, "柜子");

    private final Integer code;
    private final String desc;

    PurchaseCategoryEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

}
