package com.cainiao.tp.nm.plan.api.purchase.adaptor.dto;

import com.cainiao.aladdin.validate.annotations.NotNull;
import lombok.Data;

import java.io.Serializable;

@Data
public class HashOrderParam implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 网点ID
     * PurchaseCustomerTypeEnum
     */
    @NotNull
    private String customerType;


    /**
     * 如果是网点，则为网点的expressId
     * 如果是站点，则为站点stationId
     */
    @NotNull
    private String customerId;

}
