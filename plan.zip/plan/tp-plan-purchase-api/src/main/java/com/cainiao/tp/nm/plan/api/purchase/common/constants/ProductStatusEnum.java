package com.cainiao.tp.nm.plan.api.purchase.common.constants;

/**
 * 商品状态枚举 */
public enum ProductStatusEnum {

    /**
     * 下架
     */
    OFF_SHELF(0, "下架"),

    /**
     * 上架
     */
    ON_SHELF(1, "上架");

    private final Integer code;
    private final String desc;

    ProductStatusEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public Integer getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
}
