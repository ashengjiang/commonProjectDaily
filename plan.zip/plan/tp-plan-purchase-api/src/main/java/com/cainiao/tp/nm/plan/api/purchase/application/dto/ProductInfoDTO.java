package com.cainiao.tp.nm.plan.api.purchase.application.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

@Data
public class ProductInfoDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 商品id
     */
    private Integer itemId;

    /**
     * 商品名称
     */
    private String itemTitle;


    /**
     * 商品示意图
     */
    private String pictureUrl;

    /**
     * 商品详情页
     */
    private String detailPicUrl;

    /**
     * 商品价格
     */
    private Double price;

    /**
     * 是否有库存
     */
    private Boolean haveInventory;


    /**
     * 属性产品标签
     */
    private List<AttributeOptionDTO> attributeOptionList;
}
