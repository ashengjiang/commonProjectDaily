package com.cainiao.tp.nm.plan.api.purchase.adaptor.dto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

/**
 * 柜机商城 Diamond 配置 DO
 * <p>
 * 对应源仓库 cnt-iot-tickets 的 CabinetMallConfigDO，迁移后精简掉已废弃字段。
 * dataId: com.cainiao.tp.nm.plan.purchase.cabinet.mall.config
 * </p> */
@Data
public class CabinetMallConfigDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    @Getter
    @Setter
    private static volatile CabinetMallConfigDTO INSTANCE = new CabinetMallConfigDTO();

    /**
     * 灰度实体 ID 列表（网点 expressId 或站点 stationId）
     */
    private List<String> greyEntityIdList;

    /**
     * 灰度城市列表（cityCode）
     */
    private List<Long> greyCityList;

    /**
     * 是否为网点端 AppKey（用于 MtopContext.getAppKey() 判断登录类型）
     */
    private List<String> expressAppKeyList;

    /**
     * 菜鸟生成万里牛免密登录密钥 appSecret
     */
    private String appSecret;

    /**
     * 万里牛域名
     */
    private String wlnDomain;

    /**
     * 免密登录链接（订单确认页面）
     */
    private String confirmOrderUrlNoNeedLogin;

    /**
     * 订单详情页面链接
     */
    private String orderDetailUrl;

    /**
     * 柜机单个商品购买最大数量
     */
    private Integer largestPurchaseNum;

    /**
     * 柜机商品 itemId 列表
     */
    private List<Integer> itemIdList;

    /**
     * 是否切换站点免登带签名
     */
    private Boolean isSwitchStationNoNeedLoginWithSign;

}
