package com.cainiao.tp.nm.plan.api.purchase.common.constants;

/**
 * 订购客户类型枚举
 */
public enum PurchaseCustomerTypeEnum {

    /**
     * 站点
     */
    STATION(1, "站点"),

    /**
     * 网点
     */
    OUTLET(2, "网点");

    private final Integer code;
    private final String desc;

    PurchaseCustomerTypeEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public Integer getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

}
