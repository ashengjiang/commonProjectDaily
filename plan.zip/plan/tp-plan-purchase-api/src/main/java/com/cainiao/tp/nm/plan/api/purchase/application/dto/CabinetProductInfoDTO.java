package com.cainiao.tp.nm.plan.api.purchase.application.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class CabinetProductInfoDTO implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
     * 商品id
     */
    private Integer itemId;
    /**
     * 商品名称
     */
    private String itemTitle;

    /**
     * 商品类型
     */
    private String skuTitle;

    /**
     * 商品示意图
     */
    private String pictureUrl;

    /**
     * 商品详情页
     */
    private String detailPicUrl;

    /**
     * 商品价格
     */
    private Double price;

    /**
     * 是否有库存
     */
    private Boolean haveInventory;

    /**
     * 商品列表
     */
    private List<CabinetGridInfo> gridList;


    @Data
    public static class CabinetGridInfo {
        /**
         * 格口类型:大格口、中格口、小格口、微小格口
         */
        private String gridType;

        /**
         * 尺寸
         */
        private String size;

        /**
         * 格口数量
         */
        private Integer num;

        public CabinetGridInfo(){}

    }

}
