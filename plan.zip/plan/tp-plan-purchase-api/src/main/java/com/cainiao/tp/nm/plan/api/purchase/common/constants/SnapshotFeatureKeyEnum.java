package com.cainiao.tp.nm.plan.api.purchase.common.constants;

import lombok.Getter;

/**
 * 订购快照 feature 扩展字段 key 枚举 */
@Getter
public enum SnapshotFeatureKeyEnum {

    /**
     * SKU 快照（整个 PurchaseProductSku 对象的 JSON 序列化）
     */
    SKU_SNAPSHOT("skuSnapshot", "SKU快照"),

    /**
     * 三方商品 ID（如万里牛 sourItemId）
     */
    SOUR_ITEM_ID("sourItemId", "三方商品ID"),

    /**
     * SN 码（设备序列号，从万里牛 snJson 中解析）
     */
    SN_CODE("sn", "SN码"),
    ;

    private final String key;
    private final String desc;

    SnapshotFeatureKeyEnum(String key, String desc) {
        this.key = key;
        this.desc = desc;
    }
}
