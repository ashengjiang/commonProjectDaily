package com.cainiao.tp.nm.plan.api.purchase.application.dto;

import lombok.Data;

import java.io.Serializable;

@Data
public class PlaceOrderResultDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 订购订单 ID
     */
    private Long orderId;

    /**
     * 商品购买支付链接
     */
    private String itemBuyUrl;

    /**
     * 实名认证，true=实名认证 false=未实名认证
     */
    private Boolean identityVerification;

    /**
     * 绑定资金账户 true=已绑定 false=未绑定
     */
    private Boolean bindFundingAccount;

    /**
     * 员工ID
     */
    private String employeeId;

    /**
     * 购买协议
     */
    private AgreementInfoDTO purchaseAgreement;

    /**
     * 支付宝代扣协议
     */
    private AgreementInfoDTO alipayWithholdingAgreement;
}
