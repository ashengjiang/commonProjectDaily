package com.cainiao.tp.nm.plan.api.purchase.common.constants;

import lombok.Getter;

/**
 * 万里牛 siteAppExtParam 扩展参数 key 枚举
 * <p>
 * 下单时传给万里牛的 siteAppExtParam JSON 中的 key，
 * 回调时从 {@code DuoNiuOrderDetailDTO.siteAppExtParam} 中解析使用。
 * </p> */
@Getter
public enum SiteAppExtParamKeyEnum {

    /**
     * 本地订购订单 ID
     */
    PLAN_ORDER_ID("planOrderId", "本地订购订单ID"),

    /**
     * 网点 ID
     */
    EXPRESS_ID("expressId", "网点ID"),

    /**
     * 驿站 ID
     */
    STATION_ID("stationId", "驿站ID"),
    ;

    private final String key;
    private final String desc;

    SiteAppExtParamKeyEnum(String key, String desc) {
        this.key = key;
        this.desc = desc;
    }
}
