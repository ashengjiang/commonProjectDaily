package com.cainiao.tp.nm.plan.api.purchase.common.constants;

import lombok.Getter;

/**
 * 商品标签枚举 */
@Getter
public enum ProductAttributeEnum {

    /**
     * 主柜类型
     */
    CABINET_TYPE("cabinet_type", "柜子类型"),

    /**
     * 格口信息
     */
    GRID_INFO("grid_info", "格口信息"),

    /**
     * 商品型号编码（对应万里牛 snJson 中的 key，如 S00F80）
     */
    MODEL_CODE("model_code", "商品型号编码"),
    ;

    private final String code;
    private final String desc;

    ProductAttributeEnum(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }
}
