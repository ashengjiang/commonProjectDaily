package com.cainiao.tp.nm.plan.api.purchase.common.constants;

/**
 * 订购履约平台枚举 */
public enum PurchaseFulfillmentPlatformEnum {

    /**
     * 万里牛
     */
    WANLINIU("WANLINIU", "万里牛");

    private final String code;
    private final String desc;

    PurchaseFulfillmentPlatformEnum(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public String getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

}
