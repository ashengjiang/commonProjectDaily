package com.cainiao.tp.nm.plan.api.purchase.application.dto;

import lombok.Data;

import java.io.Serializable;

@Data
public class AgreementInfoDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 协议code
     */
    private String agreementCode;

    /**
     * 协议名称
     */
    private String agreementName;

    /**
     * 协议名称
     */
    private String agreementId;

    /**
     * 是否签约 true=签约 false=未签约
     */
    private Boolean sign;

    /**
     * 协议链接查看链接
     */
    private String agreementUrl;
}
