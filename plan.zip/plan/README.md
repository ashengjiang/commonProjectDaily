## 技术栈

| 类别 | 技术 |
|------|------|
| 基础框架 | Spring Boot 2.5.12  |
| JDK 版本 | JDK 8 |
| 服务治理 |
| 数据库 | MySQL + MyBatis |
| 缓存 | Tair（分布式）+ Caffeine（本地） |
| 消息队列 | MetaQ |
| 配置中心 |  |
| 定时任务 | SchedulerX2 |
| 对象存储 | OSS |
| 审批流 | OA 审批|
| 对象映射 | MapStruct 1.4.2 |
| JSON 解析 | FastJSON 1.2.83 |
| 构建工具 | Maven |

## 工程结构

```
tp-nm-plan/
├── tp-plan-policy-api/        # 政策 API 定义模块
├── tp-plan-policy-core/       # 政策核心业务模块（DDD 四层架构）
│   ├── domain/                # 领域层（模型、服务、仓储接口、工厂）
│   ├── application/           # 应用层（服务、组件、扩展点、事件）
│   ├── adaptor/               # 适配层（REST/MTOP/MetaQ/SchedulerX/）
│   └── common/                # 公共工具
├── tp-plan-purchase-api/      # 采购 API 定义模块
├── tp-plan-purchase-core/     # 采购核心业务模块（智能柜下单等）
│   ├── domain/                # 领域层
│   ├── application/           # 应用层
│   └── adaptor/               # 适配层
├── tp-plan-infra/             # 基础设施实现模块（持久化、缓存、第三方集成）
├── tp-plan-infra-port/        # 基础设施端口定义模块（接口契约）
├── tp-plan-start/             # 应用启动模块
└── APP-META/                  # Docker 部署配置
```

## 架构设计

项目采用 **DDD（领域驱动设计）** 架构模式：

- **领域层（Domain）**：领域模型（值对象）、领域服务、仓储接口、领域工厂
- **应用层（Application）**：应用服务编排、扩展点、领域事件、应用组件（导入/导出/政策提交）
- **适配层（Adaptor）**：对外入口（REST / MTOP / MetaQ / SchedulerX / Notify / ）
- **基础设施层（Infrastructure）**：数据库访问、缓存、外部服务集成、消息发送

关键设计特征：
- **端口与适配器**：`infra-port` 定义接口契约，`infra` 提供实现，实现依赖倒置
- **扩展点机制**：`application/extension` 提供扩展点定义与工厂，支持业务差异化扩展
- **消息驱动**：MetaQ 消息消费与发送解耦

## 业务模块

| 模块 | 职责 |
|------|------|
| **政策核心** (tp-plan-policy-core) | 激励方案创建/审批/全生命周期管理；激励规则配置；投放计划制定与站点匹配投放；数据导入导出；站点维度政策查询 |
| **采购核心** (tp-plan-purchase-core) | 智能柜采购下单；协议管理；支付流程；订单状态流转 |

## 快速开始

### 环境要求

- JDK 8
- Maven 3.x
- Pandora SAR 包

### 本地启动

1. 导入项目到 IDE（IntelliJ IDEA / Eclipse）
2. 执行启动类 `com.cainiao.tp.nm.plan.Application`

### 命令行构建

```bash
# 打包
mvn clean package -DskipTests

# 通过 Maven 插件启动
mvn -pl tp-plan-start pandora-boot:run
```

### Fat Jar 方式启动

```bash
cd tp-plan-start/target
java -Dpandora.location=${SAR_PATH} -jar tp-plan-start-1.0.0-SNAPSHOT.jar
```

## 服务端口

| 端口 | 用途 |
|------|------|
| 7001 | HTTP 服务端口 |
| 7002 | 管理端点（Actuator） |
